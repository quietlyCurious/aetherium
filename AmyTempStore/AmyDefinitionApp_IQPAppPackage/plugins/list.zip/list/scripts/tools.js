export function getClosestTimestampIndex(target, arr) {
  let index = -1
  arr.reduce((prev, curr, i) => {
      return (Math.abs(curr - target) < Math.abs(prev - target) ? (index = i) && curr : prev)
  })
  return index
}

export function hexToRGBA(color) {
  const rgb = color.rgb
  return "rgba(" + rgb.r + "," + rgb.g + "," + rgb.b + "," + rgb.a + ")"
}

// https://github.com/PimpTrizkit/PJs/wiki/12.-Shade,-Blend-and-Convert-a-Web-Color-(pSBC.js)
export function shadeHexColor(color, percent) {
  let f = parseInt(color.slice(1), 16), t = percent < 0 ? 0 : 255, p = percent < 0 ? percent * -1 : percent, R = f >> 16, G = f >> 8 & 0x00FF, B = f & 0x0000FF;
  return "#" + (0x1000000 + (Math.round((t - R) * p) + R) * 0x10000 + (Math.round((t - G) * p) + G) * 0x100 + (Math.round((t - B) * p) + B)).toString(16).slice(1);
}

// https://stackoverflow.com/questions/12043187/how-to-check-if-hex-color-is-too-black?answertab=active#tab-top
export function isDark(color) {
  let c = color.substring(1)      // strip #
  let rgb = parseInt(c, 16)   // convert rrggbb to decimal
  let r = (rgb >> 16) & 0xff  // extract red
  let g = (rgb >> 8) & 0xff  // extract green
  let b = (rgb >> 0) & 0xff  // extract blue

  let luma = 0.2126 * r + 0.7152 * g + 0.0722 * b // per ITU-R BT.709

  if (luma < 40) {
      return true
  }
  return false
}

// function to create alpha channel background colors from properties on plugin
//
export function setColor(value, defaultColor)
{
  var color;
  if (value && value.hasOwnProperty('hex'))
  {
    color = value;
  }
  else
  {
    color = value ? JSON.parse(value) : defaultColor;
  }
  var opacity = Math.round(parseFloat(color.rgb.a) * 255);
  opacity = opacity.toString(16);
  opacity = ('00' + opacity).slice(-2);

  return color.hex + opacity;
};

// Color enumeration in format from Color Picker from plugin properties
//
export const COLORS = 
{
  BLACK : {hex:"#000000FF",rgb:{a:1}},
  GRAY  : {hex:"#9b9b9bFF",rgb:{a:1}},
  WHITE : {hex:"#FFFFFFFF",rgb:{a:1}},
  RED   : {hex:"#FF0000FF",rgb:{a:1}},
  GREEN : {hex:"#00FF00FF",rgb:{a:1}},
  BLUE  : {hex:"#0000FFFF",rgb:{a:1}},
  YELLOW: {hex:"#FFFF00FF",rgb:{a:1}},
  CLEAR : {hex:"#FFFFFF00",rgb:{a:0}}
}

export function connectData(inputValue, cb)
{
  // first time run, load the formula value (as a change data event will not fire)
  //
  if (inputValue.type === 'formula')
  {
    cb(inputValue.formula.data.value[0].value);
  }

  // Data link
  if (inputValue.type === 'manual')
  {
    cb(inputValue.manual);
  }
  else if (EMBED.fieldTypeIsGlobal(inputValue))
  {
    // Fetch data
    var value = EMBED.getGlobalData(inputValue);
    // update widget
    cb(value);

    EMBED.subscribeFieldToGlobalChange(inputValue, function(data)
    {
      cb(data);
    });
  }
  else if(EMBED.fieldTypeIsQuery(inputValue))
  {
    EMBED.subscribeFieldToQueryChange(inputValue, function(rows)
    {
      var fieldName = EMBED.getQueryOutput(inputValue)[0].fieldName;
      var fieldAlias = fieldName;
      if (inputValue.query.outputFieldsAliases)
      {
        fieldAlias = inputValue.query.outputFieldsAliases[0];
      }

      var output = rows[0][fieldName];
      cb(output, fieldAlias);
    });
  }
  else if(EMBED.fieldTypeIsFormula(inputValue))
  {
    // Fetch data
    var value = EMBED.getFormulaData(inputValue);
    // update widget
    cb(value);
    EMBED.subscribeFieldToFormulaChange(inputValue, function(data)
    {
      cb(data);
    });
  }
}