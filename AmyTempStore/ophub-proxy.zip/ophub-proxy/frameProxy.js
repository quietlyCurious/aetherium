// frameProxy.js
// Shared by twxEmbed.js and ophubEmbed.js: forwards one browser request to a
// product's web UI and sends the answer back in a form an Aetherium page can
// put in an iframe.
//
// What it changes on the way:
//   request   drops hop-by-hop headers and the browser's Origin/Referer (the
//             caller sets the product's own), adds whatever auth the caller
//             gives (an app key, a session cookie)
//   response  drops X-Frame-Options and CSP frame-ancestors (the "don't
//             frame me" headers); drops CSP upgrade-insecure-requests, which
//             would send the browser to https://localhost, where the proxy
//             doesn't listen (ERR_SSL_PROTOCOL_ERROR); drops cookies' Domain
//             so they stick to localhost; and rewrites redirects and, in HTML,
//             links that point at the product's own address so they stay on
//             the proxy; for a caller that asks (OpHub), adds sameSchemeShim.js
//             to the top of each whole page (never to HTML fragments a page
//             fetches, like AngularJS templates)
//   caching   pages (HTML) are always fetched fresh — a copy the browser kept
//             from before a proxy change would otherwise come back as a 304
// Everything else passes through byte for byte.
//
// Also forwards WebSocket connections (forwardUpgrade), for products whose
// pages keep one open, and streams server-sent events (forwardEventStream):
// OpHub delivers its license over an EventSource (/app/sse), and a stream
// that's buffered until it ends never arrives at all — OpHub then hides every
// component for an hour before falling back to a default license.
//
// DEMO-GRADE, like the rest of this proxy: every viewer runs as whoever the
// configured credential belongs to.

const DROP_REQUEST_HEADERS = new Set([
  'host', 'connection', 'keep-alive', 'content-length', 'transfer-encoding',
  'upgrade', 'expect', 'accept-encoding', 'origin', 'referer',
]);
const net = require('net');
const tls = require('tls');
const http = require('http');
const https = require('https');

const wantsEventStream = (req) => /text\/event-stream/i.test(req.headers.accept || '');

// Conditional-request headers, dropped for pages so the answer is never a 304
// for a copy rewritten differently before.
const CONDITIONAL_HEADERS = new Set(['if-none-match', 'if-modified-since']);
const wantsPage = (req) => /text\/html/i.test(req.headers.accept || '') || ['document', 'iframe'].includes(req.headers['sec-fetch-dest']);

// A whole page loaded into a tab or frame — where the shim goes — as opposed to
// an HTML fragment a page fetches for itself (AngularJS templates, which
// OpHub's lazily rendered components load). A fragment must reach the page
// exactly as sent: a template with an extra <script> in front no longer has a
// single root element, and AngularJS drops the component.
const isWholePage = (req, html) => {
  const dest = req.headers['sec-fetch-dest'];
  if (dest) return dest === 'document' || dest === 'iframe';
  return /^\s*(<!doctype|<html)/i.test(html);
};

const DROP_RESPONSE_HEADERS = new Set([
  'content-encoding', 'content-length', 'transfer-encoding', 'connection', 'keep-alive',
  'x-frame-options', 'strict-transport-security', 'set-cookie', 'content-security-policy',
]);

// CSP directives that can't work through a local http proxy.
const DROP_CSP = /^(frame-ancestors|upgrade-insecure-requests|block-all-mixed-content)\b/i;
function relaxCsp(csp) {
  const kept = csp.split(';').map(s => s.trim()).filter(d => d && !DROP_CSP.test(d));
  return kept.length ? kept.join('; ') : null;
}

// The product's own address, as it may appear in redirects and pages —
// with or without the default port.
function ownAddresses(base) {
  const url = new URL(base);
  const port = url.protocol === 'https:' ? '443' : '80';
  return [`${url.protocol}//${url.host}:${port}`, base];
}

const relativeTo = (value, addresses) => {
  const own = addresses.find(a => value.startsWith(a));
  return own ? value.slice(own.length) || '/' : value;
};

// HTML pages: the same CSP in a <meta> tag, absolute links to the product
// (which would leave the proxy), and, when asked, the shim script first in
// <head> so it runs before the page's own.
function rewriteHtml(html, addresses, shimPath = null) {
  let out = html.replace(/<meta[^>]+http-equiv=["']?content-security-policy["']?[^>]*>/gi,
    tag => tag.replace(/upgrade-insecure-requests;?\s*/gi, '').replace(/block-all-mixed-content;?\s*/gi, ''));
  addresses.forEach(a => { out = out.split(`${a}/`).join('/'); });
  if (shimPath) {
    const tag = `<script src="${shimPath}"></script>`;
    out = /<head[^>]*>/i.test(out) ? out.replace(/<head[^>]*>/i, m => `${m}${tag}`) : `${tag}${out}`;
  }
  return out;
}

function localizeCookie(cookie) {
  return cookie.split(';').map(s => s.trim()).filter(part => !/^domain=/i.test(part)).join('; ');
}

// The browser's own cookies for this origin, plus any configured ones it
// doesn't have yet — so a session the product refreshes through Set-Cookie
// wins over the (older) one pasted into .env.
function mergeCookies(browserCookie, configuredCookie) {
  if (!configuredCookie) return browserCookie || '';
  if (!browserCookie) return configuredCookie;
  const have = new Set(browserCookie.split(';').map(p => p.trim().split('=')[0]));
  const extra = configuredCookie.split(';').map(p => p.trim()).filter(p => p && !have.has(p.split('=')[0]));
  return [browserCookie, ...extra].join('; ');
}

function framingHeadersOf(response) {
  const csp = response.headers.get('content-security-policy') || '';
  return {
    status: response.status,
    location: response.headers.get('location') || null,
    xFrameOptions: response.headers.get('x-frame-options') || null,
    frameAncestors: (csp.split(';').map(s => s.trim()).find(d => /^frame-ancestors\b/i.test(d))) || null,
    contentSecurityPolicy: csp || null,
    strictTransportSecurity: response.headers.get('strict-transport-security') || null,
  };
}

// base: the product's address, e.g. https://mes.gedemo.io
// headers: extra request headers (auth); cookie: a configured cookie to merge
// label: for log lines and errors
// shimPath: where sameSchemeShim.js is served, to add it to pages (optional)
// alsoOwn: more addresses to treat as the product's own in redirects, e.g.
//   https://localhost:4100 when the product builds https links to this host
async function forwardForFraming(req, res, options) {
  if (wantsEventStream(req)) { forwardEventStream(req, res, options); return; }
  const { base, headers: extra = {}, cookie = '', label, shimPath = null, alsoOwn = [] } = options;
  const target = `${base}${req.originalUrl}`;
  const page = wantsPage(req);
  const headers = {};
  for (const [name, value] of Object.entries(req.headers)) {
    const lower = name.toLowerCase();
    if (DROP_REQUEST_HEADERS.has(lower) || (page && CONDITIONAL_HEADERS.has(lower))) continue;
    headers[name] = value;
  }
  const mergedCookie = mergeCookies(req.headers.cookie, cookie);
  if (mergedCookie) headers.cookie = mergedCookie;
  Object.assign(headers, extra);

  const hasBody = !['GET', 'HEAD'].includes(req.method) && Buffer.isBuffer(req.body) && req.body.length > 0;
  let upstream;
  try {
    upstream = await fetch(target, { method: req.method, headers, body: hasBody ? req.body : undefined, redirect: 'manual' });
  } catch (err) {
    console.error(`[${label}] could not reach ${base}:`, err.message);
    res.status(502).json({ error: `Proxy failed to reach ${label}`, detail: err.message });
    return;
  }

  const addresses = [...ownAddresses(base), ...alsoOwn];
  const isHtml = /text\/html/i.test(upstream.headers.get('content-type') || '');
  res.status(upstream.status);
  upstream.headers.forEach((value, name) => {
    const lower = name.toLowerCase();
    if (DROP_RESPONSE_HEADERS.has(lower)) return;
    if (isHtml && (lower === 'etag' || lower === 'last-modified' || lower === 'cache-control' || lower === 'expires')) return;
    if (lower === 'location') value = relativeTo(value, addresses);
    res.setHeader(name, value);
  });
  const csp = upstream.headers.get('content-security-policy');
  if (csp) {
    const relaxed = relaxCsp(csp);
    if (relaxed) res.setHeader('Content-Security-Policy', relaxed);
  }
  const cookies = upstream.headers.getSetCookie ? upstream.headers.getSetCookie() : [];
  if (cookies.length) res.setHeader('Set-Cookie', cookies.map(localizeCookie));

  if (req.method === 'HEAD' || upstream.status === 204 || upstream.status === 304) {
    res.end();
    return;
  }
  const body = Buffer.from(await upstream.arrayBuffer());
  if (isHtml) {
    res.setHeader('Cache-Control', 'no-store');
    const html = body.toString('utf8');
    res.send(rewriteHtml(html, addresses, isWholePage(req, html) ? shimPath : null));
    return;
  }
  res.send(body);
}

// A server-sent event stream (EventSource): passed through as it arrives,
// with no idle timeout — Node's fetch would end a quiet stream after five
// minutes. Closes the product's side when the browser goes away.
function forwardEventStream(req, res, { base, headers: extra = {}, cookie = '', label }) {
  const url = new URL(base);
  const client = url.protocol === 'https:' ? https : http;
  const headers = {};
  for (const [name, value] of Object.entries(req.headers)) {
    const lower = name.toLowerCase();
    if (DROP_REQUEST_HEADERS.has(lower) || CONDITIONAL_HEADERS.has(lower)) continue;
    headers[name] = value;
  }
  const mergedCookie = mergeCookies(req.headers.cookie, cookie);
  if (mergedCookie) headers.cookie = mergedCookie;
  Object.assign(headers, extra, { host: url.host, origin: base });

  const upstreamReq = client.request({
    protocol: url.protocol, hostname: url.hostname, port: url.port || undefined,
    method: req.method, path: req.originalUrl, headers,
  }, (upstream) => {
    res.status(upstream.statusCode || 502);
    Object.entries(upstream.headers).forEach(([name, value]) => {
      if (DROP_RESPONSE_HEADERS.has(name.toLowerCase())) return;
      res.setHeader(name, value);
    });
    const cookies = upstream.headers['set-cookie'] || [];
    if (cookies.length) res.setHeader('Set-Cookie', cookies.map(localizeCookie));
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();
    upstream.pipe(res);
  });
  upstreamReq.setTimeout(0);
  upstreamReq.on('error', (err) => {
    console.error(`[${label}] event stream ${req.originalUrl} failed:`, err.message);
    if (!res.headersSent) res.status(502).end(); else res.end();
  });
  res.on('close', () => upstreamReq.destroy());
  upstreamReq.end();
}

// A WebSocket (or any other HTTP upgrade): open the same request to the
// product, with its own Host and Origin and the merged cookie, then pass bytes
// both ways untouched. For an http.Server's 'upgrade' event.
function forwardUpgrade(req, socket, head, { base, cookie = '', label }) {
  const url = new URL(base);
  const secure = url.protocol === 'https:';
  const port = Number(url.port) || (secure ? 443 : 80);
  const upstream = secure
    ? tls.connect({ host: url.hostname, port, servername: url.hostname })
    : net.connect({ host: url.hostname, port });
  const fail = (err) => {
    console.error(`[${label}] WebSocket to ${base}${req.url} failed:`, err.message);
    socket.destroy();
    upstream.destroy();
  };
  upstream.on('error', fail);
  socket.on('error', () => upstream.destroy());
  upstream.on(secure ? 'secureConnect' : 'connect', () => {
    const headers = { ...req.headers, host: url.host, origin: base };
    const mergedCookie = mergeCookies(req.headers.cookie, cookie);
    if (mergedCookie) headers.cookie = mergedCookie;
    const lines = [`${req.method} ${req.url} HTTP/1.1`];
    Object.entries(headers).forEach(([k, v]) => (Array.isArray(v) ? v : [v]).forEach(one => lines.push(`${k}: ${one}`)));
    upstream.write(`${lines.join('\r\n')}\r\n\r\n`);
    if (head && head.length) upstream.write(head);
    socket.pipe(upstream).pipe(socket);
  });
}

// What the product says about being framed at `path`, asked the way a
// browser would (no credential) and with the credential.
async function probeFraming(base, path, credentialHeaders) {
  const probe = async (withCredential) => {
    try {
      const r = await fetch(`${base}${path}`, {
        redirect: 'manual',
        headers: { Accept: 'text/html', ...(withCredential ? credentialHeaders : {}) },
      });
      return framingHeadersOf(r);
    } catch (err) {
      return { error: err.message };
    }
  };
  return { withCredential: await probe(true), withoutCredential: await probe(false) };
}

module.exports = { forwardForFraming, forwardUpgrade, probeFraming, mergeCookies };
