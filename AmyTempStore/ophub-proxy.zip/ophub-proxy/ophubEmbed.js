// ophubEmbed.js
// Serves the Operations Hub web UI (its page runtime) THROUGH this proxy so
// an Aetherium page can iframe an OpHub page.
//
// Unlike ThingWorx, whose UI all lives under /Thingworx, OpHub's pages,
// scripts and services sit at many paths from the root (/run/v2/…,
// /app/ajax/…, and whatever its assets use) — they'd collide with Aetherium's
// own if served from Aetherium's origin. So OpHub gets its own port: everything
// on http://localhost:<OPHUB_EMBED_PORT>/ goes to OPHUB_BASE_URL, with the
// session cookie from .env added (frameProxy.js) and the framing headers
// removed. The iframe is then cross-origin to Aetherium, which is fine for
// showing a page; the live bridge (step 3) talks with postMessage, which
// works across origins.
//
// Routes:
//   on the embed port, everything     → <OPHUB_BASE_URL>/…  (cookie added)
//   GET /ophub-embed/info  (main port) → where the embed port is, the OpHub
//        address, and what OpHub says about framing a runtime page. Aetherium
//        calls this through the OpHub connection's Proxy URL. For a look at
//        one page, add its path:
//          /ophub-embed/info?path=/run/?app_name=App%26page_name=Page
//        (status, redirect, and the security headers OpHub sent).
//   POST /api/ophub/apps   (main port) → OpHub /site/ajax/AppMgr: the app list
//        (get_apps) and one app's pages and globals (get_app_details), for
//        Aetherium's page browser. Same pass-through as /api/ophub/flows.
//
// Hook it up in server.js, after the app.use(express.raw(...)) line:
//     require('./ophubEmbed')(app);
//
// Uses the same cookies as the rest of the proxy: OPHUB_COOKIE for the app
// runtime, OPHUB_SITE_COOKIE for the /site/ management layer.
//
// OpHub pages build some addresses as "https://" + this host; the proxy adds
// sameSchemeShim.js to each page to keep those on http (it explains why).
// WebSocket connections are forwarded too.

const express = require('express');
const { forwardForFraming, forwardUpgrade, probeFraming } = require('./frameProxy');
const SAME_SCHEME_SHIM = require('./sameSchemeShim');

const SHIM_PATH = '/__aetherium/same-scheme.js';

module.exports = function registerOphubEmbed(app) {
  const BASE = (process.env.OPHUB_BASE_URL || '').replace(/\/$/, '');
  const RUNTIME_COOKIE = process.env.OPHUB_COOKIE || '';
  const SITE_COOKIE = process.env.OPHUB_SITE_COOKIE || RUNTIME_COOKIE;
  const ORIGIN = process.env.OPHUB_ORIGIN || BASE;
  const PORT = Number(process.env.OPHUB_EMBED_PORT || 4100);
  const EMBED_URL = `http://localhost:${PORT}`;

  const cookieFor = (path) => (path.startsWith('/site/') ? SITE_COOKIE : RUNTIME_COOKIE);

  // The browser's Referer names the embed port; OpHub expects its own host.
  const refererFor = (req) => {
    const ref = req.headers.referer;
    if (ref && ref.startsWith(EMBED_URL)) return `${BASE}${ref.slice(EMBED_URL.length)}`;
    return `${BASE}/`;
  };

  app.get('/ophub-embed/info', async (req, res) => {
    const page = String(req.query.path || '/');
    const { withCredential, withoutCredential } = await probeFraming(BASE, page, { Cookie: RUNTIME_COOKIE });
    res.json({
      ophubBaseUrl: BASE,
      embedUrl: EMBED_URL,
      cookieConfigured: !!RUNTIME_COOKIE,
      withCookie: withCredential,
      withoutCookie: withoutCredential,
    });
  });

  // The page browser's calls. Like server.js's own OpHub routes: the body is
  // forwarded untouched, with the site-layer cookie.
  app.post('/api/ophub/apps', async (req, res) => {
    try {
      const upstream = await fetch(`${BASE}/site/ajax/AppMgr`, {
        method: 'POST',
        headers: {
          'Content-Type': req.headers['content-type'] || 'application/x-www-form-urlencoded;charset=UTF-8',
          Accept: 'application/json, text/plain, */*',
          Cookie: SITE_COOKIE,
          Origin: ORIGIN,
          Referer: `${BASE}/iqp/`,
        },
        body: req.body,
      });
      res.status(upstream.status);
      res.setHeader('Content-Type', upstream.headers.get('content-type') || 'application/json');
      res.send(await upstream.text());
    } catch (err) {
      res.status(502).json({ error: 'Proxy failed to reach OpHub', detail: err.message });
    }
  });

  const embed = express();
  embed.get(SHIM_PATH, (req, res) => {
    res.type('application/javascript').set('Cache-Control', 'no-store').send(SAME_SCHEME_SHIM);
  });
  embed.use(express.raw({ type: '*/*', limit: '20mb' }));
  embed.use((req, res) => forwardForFraming(req, res, {
    base: BASE,
    label: 'Operations Hub',
    cookie: cookieFor(req.path),
    headers: req.method === 'GET' || req.method === 'HEAD' ? {} : { Origin: ORIGIN, Referer: refererFor(req) },
    shimPath: SHIM_PATH,
    alsoOwn: [`https://localhost:${PORT}`],
  }));
  // A busy port shouldn't take the rest of the proxy down with it.
  const server = embed.listen(PORT, () => {
    console.log(`[ophub-embed] serving the OpHub UI from ${BASE || '(OPHUB_BASE_URL not set)'} at ${EMBED_URL}`);
  }).on('error', (err) => {
    console.error(`[ophub-embed] couldn't listen on port ${PORT} (${err.code}) — OpHub pages won't embed. Set OPHUB_EMBED_PORT in .env to a free port.`);
  });
  server.on('upgrade', (req, socket, head) => forwardUpgrade(req, socket, head, {
    base: BASE, cookie: cookieFor(req.url), label: 'ophub-embed',
  }));
};
