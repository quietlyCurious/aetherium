// sameSchemeShim.js
// A small script the proxy adds to the top of every OpHub page it serves
// (frameProxy.js puts the <script> tag in; ophubEmbed.js serves the file).
//
// Why: OpHub's runtime builds some of its own addresses as
// "https://" + location.host — its login check, for one
// (https://localhost:4100/app/checkLogin…). Through the proxy the page is on
// plain http://localhost:4100, where nothing answers https, so those calls fail
// with no status at all and the page stalls half-loaded.
//
// The script runs before OpHub's own and turns https://<this host>/… back into
// http://<this host>/… (and wss:// into ws://) for XMLHttpRequest, fetch,
// WebSocket, EventSource, link clicks, form submits, and page navigations
// (location.href = …, as OpHub's "Standard" login choice does — caught with
// the browser's Navigation API, which can cancel one and start the corrected
// one). Every other address is untouched.
// It only acts when the page really is on http — served from a real https
// server, it does nothing.
//
// Served as a file rather than inline, so a CSP of script-src 'self' (which
// OpHub may send) still lets it run.

module.exports = `(function () {
  if (location.protocol !== 'http:') return;
  var host = location.host;
  var swaps = [['https://' + host, 'http://' + host], ['wss://' + host, 'ws://' + host]];
  function fix(url) {
    if (url && typeof url === 'object' && url.href) url = url.href;
    if (typeof url !== 'string') return url;
    for (var i = 0; i < swaps.length; i++) {
      if (url.indexOf(swaps[i][0]) === 0) return swaps[i][1] + url.slice(swaps[i][0].length);
    }
    return url;
  }

  var open = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    var args = Array.prototype.slice.call(arguments);
    args[1] = fix(url);
    return open.apply(this, args);
  };

  if (window.fetch) {
    var realFetch = window.fetch;
    window.fetch = function (input, init) {
      if (typeof input === 'string' || (window.URL && input instanceof URL)) input = fix(input);
      else if (input && input.url && fix(input.url) !== input.url) input = new Request(fix(input.url), input);
      return realFetch.call(this, input, init);
    };
  }

  function wrapConstructor(name) {
    var Real = window[name];
    if (!Real) return;
    var Wrapped = function (url, more) {
      return arguments.length > 1 ? new Real(fix(url), more) : new Real(fix(url));
    };
    Wrapped.prototype = Real.prototype;
    ['CONNECTING', 'OPEN', 'CLOSING', 'CLOSED'].forEach(function (k) { if (k in Real) Wrapped[k] = Real[k]; });
    window[name] = Wrapped;
  }
  wrapConstructor('WebSocket');
  wrapConstructor('EventSource');

  // Page navigations to https://<this host>: cancel, and go to the http one.
  if (window.navigation && navigation.addEventListener) {
    navigation.addEventListener('navigate', function (e) {
      var to = e.destination && e.destination.url;
      var fixed = fix(to);
      if (fixed !== to && e.cancelable) {
        e.preventDefault();
        location.href = fixed;
      }
    });
  }

  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (form && form.action && fix(form.action) !== form.action) form.action = fix(form.action);
  }, true);

  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (a && fix(a.href) !== a.href) a.href = fix(a.href);
  }, true);
})();
`;
