// twxEmbed.js
// Serves the ThingWorx web UI (mashup runtime) THROUGH this proxy so an
// Aetherium page can iframe a mashup.
//
// Why: a mashup iframed straight from the ThingWorx server is refused (the
// step 1 spike confirmed it). Served through here, every request gets the app
// key added server-side and the framing headers removed (frameProxy.js).
// Aetherium's dev server forwards /Thingworx/* to this proxy
// (src/setupProxy.js), so the iframe ends up same-origin with Aetherium.
//
// Routes:
//   ALL  /Thingworx/*               → <TWX_BASE_URL>/Thingworx/*  (app key added)
//   GET  /twx-embed/diagnose?mashup=Name
//        The ThingWorx address, and what it says about framing its runtime.
//
// Hook it up in server.js, after the app.use(express.raw(...)) line:
//     require('./twxEmbed')(app);

const { forwardForFraming, probeFraming } = require('./frameProxy');

module.exports = function registerTwxEmbed(app) {
  const BASE = (process.env.TWX_BASE_URL || '').replace(/\/$/, '');
  const APP_KEY = process.env.TWX_APP_KEY || '';
  if (!BASE || !APP_KEY) {
    console.warn('[twx-embed] TWX_BASE_URL or TWX_APP_KEY missing in .env — /Thingworx/* will not work.');
  }

  app.get('/twx-embed/diagnose', async (req, res) => {
    const mashup = String(req.query.mashup || '');
    const runtimePath = '/Thingworx/Runtime/index.html';
    const { withCredential, withoutCredential } = await probeFraming(BASE, runtimePath, { appKey: APP_KEY });
    res.json({
      twxBaseUrl: BASE,
      directUrl: `${BASE}${runtimePath}${mashup ? `#mashup=${encodeURIComponent(mashup)}` : ''}`,
      appKeyConfigured: !!APP_KEY,
      // Names kept from the spike, which reads them.
      withAppKey: withCredential,
      withoutAppKey: withoutCredential,
    });
  });

  app.use('/Thingworx', (req, res) => forwardForFraming(req, res, {
    base: BASE,
    label: 'ThingWorx',
    // ThingWorx's CSRF checks compare these with its own host.
    headers: { appKey: APP_KEY, Origin: BASE, Referer: `${BASE}/Thingworx/Runtime/index.html` },
  }));

  console.log(`[twx-embed] serving ThingWorx UI from ${BASE || '(TWX_BASE_URL not set)'} at /Thingworx/*`);
};
