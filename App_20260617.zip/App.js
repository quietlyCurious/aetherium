import React, { useState, useMemo } from 'react';
import { Button, Popup, SelectBox, Splitter, TabPanel } from 'devextreme-react';
import { Item as SplitterItem } from 'devextreme-react/splitter';
import { Item as TabPanelItem } from 'devextreme-react/tab-panel';
import { ToolbarItem } from 'devextreme-react/popup';
import { TreeView } from 'devextreme-react';
import 'devextreme/dist/css/dx.fluent.blue.light.compact.css';
import './App.css';
import WIDGET_CONFIGS from './widgetConfigs';
import WIDGET_SAMPLE_DATA from './widgetSampleData';
import { TIERS, DEVICE_CATEGORIES, SPECIAL_PRESETS, ALL_DEVICES, BASE_TIER_ID, getTierById, getDeviceById, applyBreakpointOverrides } from './breakpointConfig';

// DevExtreme widget imports for live preview
import DataGrid from 'devextreme-react/data-grid';
import TreeList from 'devextreme-react/tree-list';
import { List } from 'devextreme-react/list';
import Gallery from 'devextreme-react/gallery';
import Chart from 'devextreme-react/chart';
import PieChart from 'devextreme-react/pie-chart';
import PolarChart from 'devextreme-react/polar-chart';
import Funnel from 'devextreme-react/funnel';
import Sankey from 'devextreme-react/sankey';
import TreeMap from 'devextreme-react/tree-map';
import Sparkline from 'devextreme-react/sparkline';
import Bullet from 'devextreme-react/bullet';
import BarGauge from 'devextreme-react/bar-gauge';
import LinearGauge from 'devextreme-react/linear-gauge';
import CircularGauge from 'devextreme-react/circular-gauge';
import RangeSelector from 'devextreme-react/range-selector';
import PivotGrid from 'devextreme-react/pivot-grid';
import TextBox from 'devextreme-react/text-box';
import TextArea from 'devextreme-react/text-area';
import NumberBox from 'devextreme-react/number-box';
import CheckBox from 'devextreme-react/check-box';
import TagBox from 'devextreme-react/tag-box';
import Lookup from 'devextreme-react/lookup';
import Autocomplete from 'devextreme-react/autocomplete';
import DropDownBox from 'devextreme-react/drop-down-box';
import DateBox from 'devextreme-react/date-box';
import DateRangeBox from 'devextreme-react/date-range-box';
import ColorBox from 'devextreme-react/color-box';
import Slider from 'devextreme-react/slider';
import RangeSlider from 'devextreme-react/range-slider';
import Switch from 'devextreme-react/switch';
import RadioGroup from 'devextreme-react/radio-group';
import ButtonGroup from 'devextreme-react/button-group';
import Calendar from 'devextreme-react/calendar';
import HtmlEditor from 'devextreme-react/html-editor';
import FileUploader from 'devextreme-react/file-uploader';
import Form from 'devextreme-react/form';
import Scheduler from 'devextreme-react/scheduler';
import Gantt from 'devextreme-react/gantt';

const ASSET_DATA = [
  { id: 'AURELIA', parentId: null, name: 'Aurelia', assetType: 'refinery', assetLevel: 'refinery' },
  { id: 'FERRUM',  parentId: null, name: 'Ferrum',  assetType: 'refinery', assetLevel: 'refinery' },

  { id: 'AURELIA_A1', parentId: 'AURELIA', name: 'A1', assetType: 'line', assetLevel: 'line' },
  { id: 'AURELIA_A1_INTAKE',        parentId: 'AURELIA_A1', name: 'Intake',        assetType: 'intake',        assetLevel: 'station' },
  { id: 'AURELIA_A1_STABILIZATION', parentId: 'AURELIA_A1', name: 'Stabilization', assetType: 'stabilization', assetLevel: 'station' },
  { id: 'AURELIA_A1_REFINEMENT',    parentId: 'AURELIA_A1', name: 'Refinement',    assetType: 'refinement',    assetLevel: 'station' },
  { id: 'AURELIA_A1_INSPECTION',    parentId: 'AURELIA_A1', name: 'Inspection',    assetType: 'inspection',    assetLevel: 'station' },
  { id: 'AURELIA_A1_BUFFER',        parentId: 'AURELIA_A1', name: 'Buffer',        assetType: 'buffer',        assetLevel: 'station' },
  { id: 'AURELIA_A1_OUTPUT',        parentId: 'AURELIA_A1', name: 'Output',        assetType: 'output',        assetLevel: 'station' },

  { id: 'AURELIA_A2', parentId: 'AURELIA', name: 'A2', assetType: 'line', assetLevel: 'line' },
  { id: 'AURELIA_A2_INTAKE',        parentId: 'AURELIA_A2', name: 'Intake',        assetType: 'intake',        assetLevel: 'station' },
  { id: 'AURELIA_A2_STABILIZATION', parentId: 'AURELIA_A2', name: 'Stabilization', assetType: 'stabilization', assetLevel: 'station' },
  { id: 'AURELIA_A2_REFINEMENT',    parentId: 'AURELIA_A2', name: 'Refinement',    assetType: 'refinement',    assetLevel: 'station' },
  { id: 'AURELIA_A2_INSPECTION',    parentId: 'AURELIA_A2', name: 'Inspection',    assetType: 'inspection',    assetLevel: 'station' },
  { id: 'AURELIA_A2_BUFFER',        parentId: 'AURELIA_A2', name: 'Buffer',        assetType: 'buffer',        assetLevel: 'station' },
  { id: 'AURELIA_A2_OUTPUT',        parentId: 'AURELIA_A2', name: 'Output',        assetType: 'output',        assetLevel: 'station' },

  { id: 'AURELIA_A3', parentId: 'AURELIA', name: 'A3', assetType: 'line', assetLevel: 'line' },
  { id: 'AURELIA_A3_INTAKE',        parentId: 'AURELIA_A3', name: 'Intake',        assetType: 'intake',        assetLevel: 'station' },
  { id: 'AURELIA_A3_STABILIZATION', parentId: 'AURELIA_A3', name: 'Stabilization', assetType: 'stabilization', assetLevel: 'station' },
  { id: 'AURELIA_A3_REFINEMENT',    parentId: 'AURELIA_A3', name: 'Refinement',    assetType: 'refinement',    assetLevel: 'station' },
  { id: 'AURELIA_A3_INSPECTION',    parentId: 'AURELIA_A3', name: 'Inspection',    assetType: 'inspection',    assetLevel: 'station' },
  { id: 'AURELIA_A3_BUFFER',        parentId: 'AURELIA_A3', name: 'Buffer',        assetType: 'buffer',        assetLevel: 'station' },
  { id: 'AURELIA_A3_OUTPUT',        parentId: 'AURELIA_A3', name: 'Output',        assetType: 'output',        assetLevel: 'station' },

  { id: 'AURELIA_A4', parentId: 'AURELIA', name: 'A4', assetType: 'line', assetLevel: 'line' },
  { id: 'AURELIA_A4_INTAKE',        parentId: 'AURELIA_A4', name: 'Intake',        assetType: 'intake',        assetLevel: 'station' },
  { id: 'AURELIA_A4_STABILIZATION', parentId: 'AURELIA_A4', name: 'Stabilization', assetType: 'stabilization', assetLevel: 'station' },
  { id: 'AURELIA_A4_REFINEMENT',    parentId: 'AURELIA_A4', name: 'Refinement',    assetType: 'refinement',    assetLevel: 'station' },
  { id: 'AURELIA_A4_INSPECTION',    parentId: 'AURELIA_A4', name: 'Inspection',    assetType: 'inspection',    assetLevel: 'station' },
  { id: 'AURELIA_A4_BUFFER',        parentId: 'AURELIA_A4', name: 'Buffer',        assetType: 'buffer',        assetLevel: 'station' },
  { id: 'AURELIA_A4_OUTPUT',        parentId: 'AURELIA_A4', name: 'Output',        assetType: 'output',        assetLevel: 'station' },

  { id: 'AURELIA_A5', parentId: 'AURELIA', name: 'A5', assetType: 'line', assetLevel: 'line' },
  { id: 'AURELIA_A5_INTAKE',        parentId: 'AURELIA_A5', name: 'Intake',        assetType: 'intake',        assetLevel: 'station' },
  { id: 'AURELIA_A5_STABILIZATION', parentId: 'AURELIA_A5', name: 'Stabilization', assetType: 'stabilization', assetLevel: 'station' },
  { id: 'AURELIA_A5_REFINEMENT',    parentId: 'AURELIA_A5', name: 'Refinement',    assetType: 'refinement',    assetLevel: 'station' },
  { id: 'AURELIA_A5_INSPECTION',    parentId: 'AURELIA_A5', name: 'Inspection',    assetType: 'inspection',    assetLevel: 'station' },
  { id: 'AURELIA_A5_BUFFER',        parentId: 'AURELIA_A5', name: 'Buffer',        assetType: 'buffer',        assetLevel: 'station' },
  { id: 'AURELIA_A5_OUTPUT',        parentId: 'AURELIA_A5', name: 'Output',        assetType: 'output',        assetLevel: 'station' },

  { id: 'AURELIA_A6', parentId: 'AURELIA', name: 'A6', assetType: 'line', assetLevel: 'line' },
  { id: 'AURELIA_A6_INTAKE',        parentId: 'AURELIA_A6', name: 'Intake',        assetType: 'intake',        assetLevel: 'station' },
  { id: 'AURELIA_A6_STABILIZATION', parentId: 'AURELIA_A6', name: 'Stabilization', assetType: 'stabilization', assetLevel: 'station' },
  { id: 'AURELIA_A6_REFINEMENT',    parentId: 'AURELIA_A6', name: 'Refinement',    assetType: 'refinement',    assetLevel: 'station' },
  { id: 'AURELIA_A6_INSPECTION',    parentId: 'AURELIA_A6', name: 'Inspection',    assetType: 'inspection',    assetLevel: 'station' },
  { id: 'AURELIA_A6_BUFFER',        parentId: 'AURELIA_A6', name: 'Buffer',        assetType: 'buffer',        assetLevel: 'station' },
  { id: 'AURELIA_A6_OUTPUT',        parentId: 'AURELIA_A6', name: 'Output',        assetType: 'output',        assetLevel: 'station' },

  { id: 'FERRUM_F1', parentId: 'FERRUM', name: 'F1', assetType: 'line', assetLevel: 'line' },
  { id: 'FERRUM_F1_BULK_INTAKE',  parentId: 'FERRUM_F1', name: 'Bulk Intake',  assetType: 'bulk_intake',  assetLevel: 'station' },
  { id: 'FERRUM_F1_POWER_CHARGE', parentId: 'FERRUM_F1', name: 'Power Charge', assetType: 'power_charge', assetLevel: 'station' },
  { id: 'FERRUM_F1_SHAPING',      parentId: 'FERRUM_F1', name: 'Shaping',      assetType: 'shaping',      assetLevel: 'station' },
  { id: 'FERRUM_F1_TRANSFER',     parentId: 'FERRUM_F1', name: 'Transfer',     assetType: 'transfer',     assetLevel: 'station' },
  { id: 'FERRUM_F1_OUTPUT',       parentId: 'FERRUM_F1', name: 'Output',       assetType: 'output',       assetLevel: 'station' },

  { id: 'FERRUM_F2', parentId: 'FERRUM', name: 'F2', assetType: 'line', assetLevel: 'line' },
  { id: 'FERRUM_F2_BULK_INTAKE',  parentId: 'FERRUM_F2', name: 'Bulk Intake',  assetType: 'bulk_intake',  assetLevel: 'station' },
  { id: 'FERRUM_F2_POWER_CHARGE', parentId: 'FERRUM_F2', name: 'Power Charge', assetType: 'power_charge', assetLevel: 'station' },
  { id: 'FERRUM_F2_SHAPING',      parentId: 'FERRUM_F2', name: 'Shaping',      assetType: 'shaping',      assetLevel: 'station' },
  { id: 'FERRUM_F2_TRANSFER',     parentId: 'FERRUM_F2', name: 'Transfer',     assetType: 'transfer',     assetLevel: 'station' },
  { id: 'FERRUM_F2_OUTPUT',       parentId: 'FERRUM_F2', name: 'Output',       assetType: 'output',       assetLevel: 'station' },

  { id: 'FERRUM_F3', parentId: 'FERRUM', name: 'F3', assetType: 'line', assetLevel: 'line' },
  { id: 'FERRUM_F3_BULK_INTAKE',  parentId: 'FERRUM_F3', name: 'Bulk Intake',  assetType: 'bulk_intake',  assetLevel: 'station' },
  { id: 'FERRUM_F3_POWER_CHARGE', parentId: 'FERRUM_F3', name: 'Power Charge', assetType: 'power_charge', assetLevel: 'station' },
  { id: 'FERRUM_F3_SHAPING',      parentId: 'FERRUM_F3', name: 'Shaping',      assetType: 'shaping',      assetLevel: 'station' },
  { id: 'FERRUM_F3_TRANSFER',     parentId: 'FERRUM_F3', name: 'Transfer',     assetType: 'transfer',     assetLevel: 'station' },
  { id: 'FERRUM_F3_OUTPUT',       parentId: 'FERRUM_F3', name: 'Output',       assetType: 'output',       assetLevel: 'station' },

  { id: 'FERRUM_F4', parentId: 'FERRUM', name: 'F4', assetType: 'line', assetLevel: 'line' },
  { id: 'FERRUM_F4_BULK_INTAKE',  parentId: 'FERRUM_F4', name: 'Bulk Intake',  assetType: 'bulk_intake',  assetLevel: 'station' },
  { id: 'FERRUM_F4_POWER_CHARGE', parentId: 'FERRUM_F4', name: 'Power Charge', assetType: 'power_charge', assetLevel: 'station' },
  { id: 'FERRUM_F4_SHAPING',      parentId: 'FERRUM_F4', name: 'Shaping',      assetType: 'shaping',      assetLevel: 'station' },
  { id: 'FERRUM_F4_TRANSFER',     parentId: 'FERRUM_F4', name: 'Transfer',     assetType: 'transfer',     assetLevel: 'station' },
  { id: 'FERRUM_F4_OUTPUT',       parentId: 'FERRUM_F4', name: 'Output',       assetType: 'output',       assetLevel: 'station' },

  { id: 'FERRUM_F5', parentId: 'FERRUM', name: 'F5', assetType: 'line', assetLevel: 'line' },
  { id: 'FERRUM_F5_BULK_INTAKE',  parentId: 'FERRUM_F5', name: 'Bulk Intake',  assetType: 'bulk_intake',  assetLevel: 'station' },
  { id: 'FERRUM_F5_POWER_CHARGE', parentId: 'FERRUM_F5', name: 'Power Charge', assetType: 'power_charge', assetLevel: 'station' },
  { id: 'FERRUM_F5_SHAPING',      parentId: 'FERRUM_F5', name: 'Shaping',      assetType: 'shaping',      assetLevel: 'station' },
  { id: 'FERRUM_F5_TRANSFER',     parentId: 'FERRUM_F5', name: 'Transfer',     assetType: 'transfer',     assetLevel: 'station' },
  { id: 'FERRUM_F5_OUTPUT',       parentId: 'FERRUM_F5', name: 'Output',       assetType: 'output',       assetLevel: 'station' },

  { id: 'FERRUM_F6', parentId: 'FERRUM', name: 'F6', assetType: 'line', assetLevel: 'line' },
  { id: 'FERRUM_F6_BULK_INTAKE',  parentId: 'FERRUM_F6', name: 'Bulk Intake',  assetType: 'bulk_intake',  assetLevel: 'station' },
  { id: 'FERRUM_F6_POWER_CHARGE', parentId: 'FERRUM_F6', name: 'Power Charge', assetType: 'power_charge', assetLevel: 'station' },
  { id: 'FERRUM_F6_SHAPING',      parentId: 'FERRUM_F6', name: 'Shaping',      assetType: 'shaping',      assetLevel: 'station' },
  { id: 'FERRUM_F6_TRANSFER',     parentId: 'FERRUM_F6', name: 'Transfer',     assetType: 'transfer',     assetLevel: 'station' },
  { id: 'FERRUM_F6_OUTPUT',       parentId: 'FERRUM_F6', name: 'Output',       assetType: 'output',       assetLevel: 'station' },
];

const TAGS_BY_LEVEL = {
  refinery: [
    { tagName: 'assetId',                   tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'assetName',                  tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'assetType',                  tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'assetLevel',                 tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'refinery',                   tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'line',                       tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'station',                    tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'assetParentId',              tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'sortOrder',                  tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'path',                       tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'refinery_throughput',        tagDomain: 'production',           tagCategory: 'kpi' },
    { tagName: 'refinery_oee',               tagDomain: 'derived metrics',      tagCategory: 'kpi' },
    { tagName: 'best_line',                  tagDomain: 'operations / control', tagCategory: 'kpi' },
    { tagName: 'worst_line',                 tagDomain: 'operations / control', tagCategory: 'kpi' },
    { tagName: 'refinery_health_index',      tagDomain: 'derived metrics',      tagCategory: 'kpi' },
    { tagName: 'refinery_instability_index', tagDomain: 'stability',            tagCategory: 'kpi' },
  ],
  line: [
    { tagName: 'assetId',             tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'assetName',           tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'assetType',           tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'assetLevel',          tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'refinery',            tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'line',                tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'station',             tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'assetParentId',       tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'sortOrder',           tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'path',                tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'line_throughput',     tagDomain: 'production',           tagCategory: 'kpi' },
    { tagName: 'line_oee',            tagDomain: 'derived metrics',      tagCategory: 'kpi' },
    { tagName: 'total_wip',           tagDomain: 'flow / wip',           tagCategory: 'kpi' },
    { tagName: 'bottleneck_station',  tagDomain: 'operations / control', tagCategory: 'kpi' },
    { tagName: 'system_health_index', tagDomain: 'derived metrics',      tagCategory: 'kpi' },
    { tagName: 'flow_efficiency',     tagDomain: 'flow / wip',           tagCategory: 'kpi' },
    { tagName: 'instability_index',   tagDomain: 'stability',            tagCategory: 'kpi' },
  ],
  station: [
    { tagName: 'assetId',          tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'assetName',        tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'assetType',        tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'assetLevel',       tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'refinery',         tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'line',             tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'station',          tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'assetParentId',    tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'sortOrder',        tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'path',             tagDomain: 'common',               tagCategory: 'property' },
    { tagName: 'throughput',       tagDomain: 'production',           tagCategory: 'kpi' },
    { tagName: 'oee',              tagDomain: 'derived metrics',      tagCategory: 'kpi' },
    { tagName: 'utilization',      tagDomain: 'operations / control', tagCategory: 'kpi' },
    { tagName: 'wip',              tagDomain: 'flow / wip',           tagCategory: 'kpi' },
    { tagName: 'queue_length',     tagDomain: 'flow / wip',           tagCategory: 'kpi' },
    { tagName: 'scrap_rate',       tagDomain: 'quality',              tagCategory: 'kpi' },
    { tagName: 'quality_score',    tagDomain: 'quality',              tagCategory: 'kpi' },
    { tagName: 'microstop_count',  tagDomain: 'events / losses',      tagCategory: 'kpi' },
    { tagName: 'blocking_events',  tagDomain: 'events / losses',      tagCategory: 'kpi' },
    { tagName: 'downtime_events',  tagDomain: 'events / losses',      tagCategory: 'kpi' },
    { tagName: 'instability_index', tagDomain: 'stability',           tagCategory: 'kpi' },
    { tagName: 'risk_score',       tagDomain: 'risk / delivery',      tagCategory: 'kpi' },
  ],
};

const ASSET_MAP = Object.fromEntries(ASSET_DATA.map(a => [a.id, a]));

function getChildren(assetId) {
  return ASSET_DATA.filter(a => a.parentId === assetId);
}

function buildDescendantTree(assetId) {
  const result = [];
  const asset = ASSET_MAP[assetId];
  if (!asset) return result;

  result.push({ ...asset, parentId: null, nodeType: 'asset' });

  const queue = [asset];
  while (queue.length > 0) {
    const current = queue.shift();
    const children = getChildren(current.id);
    for (const child of children) {
      result.push({ ...child, nodeType: 'asset' });
      queue.push(child);
    }
  }

  const assetNodes = [...result];
  for (const assetNode of assetNodes) {
    const tags = TAGS_BY_LEVEL[assetNode.assetLevel] || [];
    tags.forEach((tag) => {
      result.push({
        id: `${assetNode.id}__tag__${tag.tagName}`,
        parentId: assetNode.id,
        name: tag.tagName,
        tagDomain: tag.tagDomain,
        tagCategory: tag.tagCategory,
        nodeType: 'tag',
        assetType: null,
      });
    });
  }

  return result;
}

// Build a minimal tree from selected assets, adding bridge ancestors as placeholders
function buildSelectedAssetTree(selectedAssets) {
  const selectedIds = new Set(selectedAssets.map(a => a.id));
  const includedIds = new Set();

  // For each selected asset, walk up and include all ancestors
  selectedAssets.forEach(asset => {
    let current = ASSET_MAP[asset.id];
    while (current) {
      includedIds.add(current.id);
      current = current.parentId ? ASSET_MAP[current.parentId] : null;
    }
  });

  // Build flat list preserving original parentId relationships
  return Array.from(includedIds).map(id => {
    const asset = ASSET_MAP[id];
    return {
      ...asset,
      nodeType: 'asset',
      isPlaceholder: !selectedIds.has(id),
    };
  }).sort((a, b) => {
    // Sort by sortOrder to keep tree stable
    if (a.parentId === b.parentId) return (a.sortOrder || 0) - (b.sortOrder || 0);
    return 0;
  });
}


const DX_WIDGET_DATA = [
  { id: 'grids', parentId: null, name: 'Grids & Lists', assetType: 'category', assetLevel: 'category' },
  { id: 'charts', parentId: null, name: 'Charts & Visualization', assetType: 'category', assetLevel: 'category' },
  { id: 'editors', parentId: null, name: 'Editors', assetType: 'category', assetLevel: 'category' },
  { id: 'navigation', parentId: null, name: 'Navigation', assetType: 'category', assetLevel: 'category' },
  { id: 'layout', parentId: null, name: 'Layout', assetType: 'category', assetLevel: 'category' },
  { id: 'dialogs', parentId: null, name: 'Dialogs & Notifications', assetType: 'category', assetLevel: 'category' },
  { id: 'scheduling', parentId: null, name: 'Scheduling', assetType: 'category', assetLevel: 'category' },
  { id: 'misc', parentId: null, name: 'Miscellaneous', assetType: 'category', assetLevel: 'category' },

  // Grids & Lists
  { id: 'dx-datagrid', parentId: 'grids', name: 'DataGrid', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-treelist', parentId: 'grids', name: 'TreeList', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-cardview', parentId: 'grids', name: 'CardView', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-list', parentId: 'grids', name: 'List', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-treeview', parentId: 'grids', name: 'TreeView', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-gallery', parentId: 'grids', name: 'Gallery', assetType: 'widget', assetLevel: 'widget' },

  // Charts & Visualization
  { id: 'dx-chart', parentId: 'charts', name: 'Chart', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-piechart', parentId: 'charts', name: 'PieChart', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-polarchart', parentId: 'charts', name: 'PolarChart', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-funnel', parentId: 'charts', name: 'Funnel', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-sankey', parentId: 'charts', name: 'Sankey', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-treemap', parentId: 'charts', name: 'TreeMap', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-vectormap', parentId: 'charts', name: 'VectorMap', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-sparkline', parentId: 'charts', name: 'Sparkline', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-bullet', parentId: 'charts', name: 'Bullet', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-bargauge', parentId: 'charts', name: 'BarGauge', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-lineargauge', parentId: 'charts', name: 'LinearGauge', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-circulargauge', parentId: 'charts', name: 'CircularGauge', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-rangeselector', parentId: 'charts', name: 'RangeSelector', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-pivotgrid', parentId: 'charts', name: 'PivotGrid', assetType: 'widget', assetLevel: 'widget' },

  // Editors
  { id: 'dx-textbox', parentId: 'editors', name: 'TextBox', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-textarea', parentId: 'editors', name: 'TextArea', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-numberbox', parentId: 'editors', name: 'NumberBox', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-checkbox', parentId: 'editors', name: 'CheckBox', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-selectbox', parentId: 'editors', name: 'SelectBox', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-tagbox', parentId: 'editors', name: 'TagBox', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-lookup', parentId: 'editors', name: 'Lookup', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-autocomplete', parentId: 'editors', name: 'Autocomplete', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-dropdownbox', parentId: 'editors', name: 'DropDownBox', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-datebox', parentId: 'editors', name: 'DateBox', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-daterangebox', parentId: 'editors', name: 'DateRangeBox', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-colorbox', parentId: 'editors', name: 'ColorBox', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-slider', parentId: 'editors', name: 'Slider', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-rangeslider', parentId: 'editors', name: 'RangeSlider', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-switch', parentId: 'editors', name: 'Switch', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-radiogroup', parentId: 'editors', name: 'RadioGroup', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-buttongroup', parentId: 'editors', name: 'ButtonGroup', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-calendar', parentId: 'editors', name: 'Calendar', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-htmleditor', parentId: 'editors', name: 'HtmlEditor', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-fileuploader', parentId: 'editors', name: 'FileUploader', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-form', parentId: 'editors', name: 'Form', assetType: 'widget', assetLevel: 'widget' },

  // Navigation
  { id: 'dx-menu', parentId: 'navigation', name: 'Menu', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-contextmenu', parentId: 'navigation', name: 'ContextMenu', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-accordion', parentId: 'navigation', name: 'Accordion', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-tabs', parentId: 'navigation', name: 'Tabs', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-tabpanel', parentId: 'navigation', name: 'TabPanel', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-multiview', parentId: 'navigation', name: 'MultiView', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-toolbar', parentId: 'navigation', name: 'Toolbar', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-pagination', parentId: 'navigation', name: 'Pagination', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-stepper', parentId: 'navigation', name: 'Stepper', assetType: 'widget', assetLevel: 'widget' },

  // Layout
  { id: 'dx-box', parentId: 'layout', name: 'Box', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-responsivebox', parentId: 'layout', name: 'ResponsiveBox', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-splitter', parentId: 'layout', name: 'Splitter', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-scrollview', parentId: 'layout', name: 'ScrollView', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-resizable', parentId: 'layout', name: 'Resizable', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-draggable', parentId: 'layout', name: 'Draggable', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-sortable', parentId: 'layout', name: 'Sortable', assetType: 'widget', assetLevel: 'widget' },

  // Dialogs & Notifications
  { id: 'dx-popup', parentId: 'dialogs', name: 'Popup', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-popover', parentId: 'dialogs', name: 'Popover', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-tooltip', parentId: 'dialogs', name: 'Tooltip', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-toast', parentId: 'dialogs', name: 'Toast', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-loadpanel', parentId: 'dialogs', name: 'LoadPanel', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-loadindicator', parentId: 'dialogs', name: 'LoadIndicator', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-progressbar', parentId: 'dialogs', name: 'ProgressBar', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-actionsheet', parentId: 'dialogs', name: 'ActionSheet', assetType: 'widget', assetLevel: 'widget' },

  // Scheduling
  { id: 'dx-scheduler', parentId: 'scheduling', name: 'Scheduler', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-gantt', parentId: 'scheduling', name: 'Gantt', assetType: 'widget', assetLevel: 'widget' },

  // Miscellaneous
  { id: 'dx-button', parentId: 'misc', name: 'Button', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-dropdownbutton', parentId: 'misc', name: 'DropDownButton', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-speeddialalction', parentId: 'misc', name: 'SpeedDialAction', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-map', parentId: 'misc', name: 'Map', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-filemanager', parentId: 'misc', name: 'FileManager', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-diagram', parentId: 'misc', name: 'Diagram', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-chat', parentId: 'misc', name: 'Chat', assetType: 'widget', assetLevel: 'widget' },
  { id: 'dx-speechtotext', parentId: 'misc', name: 'SpeechToText', assetType: 'widget', assetLevel: 'widget' },
];

const STEPS = [
  { title: 'Select Asset' },
  { title: 'Step 2: Data Selection' },
  { title: 'Step 3: Placeholder' },
  { title: 'Step 4: Placeholder' },
];

const WIDGET_PROPERTIES = {
  // ─── GRIDS & LISTS ────────────────────────────────────────────────────────
  DataGrid: [
    { name: 'showBorders', label: 'Show Borders', type: 'bool', default: false },
    { name: 'showRowLines', label: 'Show Row Lines', type: 'bool', default: false },
    { name: 'showColumnLines', label: 'Show Column Lines', type: 'bool', default: true },
    { name: 'showColumnHeaders', label: 'Column Headers', type: 'bool', default: true },
    { name: 'allowColumnReordering', label: 'Col Reordering', type: 'bool', default: false },
    { name: 'allowColumnResizing', label: 'Col Resizing', type: 'bool', default: false },
    { name: 'columnAutoWidth', label: 'Column Auto Width', type: 'bool', default: false },
    { name: 'hoverStateEnabled', label: 'Hover State', type: 'bool', default: false },
    { name: 'rowAlternationEnabled', label: 'Row Alternation', type: 'bool', default: false },
    { name: 'wordWrapEnabled', label: 'Word Wrap', type: 'bool', default: false },
    { name: 'pager.visible', label: 'Pager Visible', type: 'bool', default: true },
    { name: 'searchPanel.visible', label: 'Search Panel', type: 'bool', default: false },
    { name: 'filterRow.visible', label: 'Filter Row', type: 'bool', default: false },
    { name: 'groupPanel.visible', label: 'Group Panel', type: 'bool', default: false },
    { name: 'headerFilter.visible', label: 'Header Filter', type: 'bool', default: false },
    { name: 'selection.mode', label: 'Selection Mode', type: 'enum', options: ['none','single','multiple'], default: 'none' },
    { name: 'editing.mode', label: 'Edit Mode', type: 'enum', options: ['row','cell','batch','form','popup'], default: 'row' },
    { name: 'editing.allowAdding', label: 'Allow Adding', type: 'bool', default: false },
    { name: 'editing.allowUpdating', label: 'Allow Updating', type: 'bool', default: false },
    { name: 'editing.allowDeleting', label: 'Allow Deleting', type: 'bool', default: false },
    { name: 'scrolling.mode', label: 'Scrolling Mode', type: 'enum', options: ['standard','virtual','infinite'], default: 'standard' },
    { name: 'paging.pageSize', label: 'Page Size', type: 'number', default: 20 },
  ],
  TreeList: [
    { name: 'showBorders', label: 'Show Borders', type: 'bool', default: false },
    { name: 'showRowLines', label: 'Show Row Lines', type: 'bool', default: false },
    { name: 'showColumnLines', label: 'Show Column Lines', type: 'bool', default: true },
    { name: 'allowColumnResizing', label: 'Col Resizing', type: 'bool', default: false },
    { name: 'autoExpandAll', label: 'Auto Expand All', type: 'bool', default: false },
    { name: 'hoverStateEnabled', label: 'Hover State', type: 'bool', default: false },
    { name: 'rowAlternationEnabled', label: 'Row Alternation', type: 'bool', default: false },
    { name: 'filterRow.visible', label: 'Filter Row', type: 'bool', default: false },
    { name: 'searchPanel.visible', label: 'Search Panel', type: 'bool', default: false },
    { name: 'selection.mode', label: 'Selection Mode', type: 'enum', options: ['none','single','multiple'], default: 'none' },
    { name: 'selection.recursive', label: 'Recursive Select', type: 'bool', default: false },
    { name: 'editing.mode', label: 'Edit Mode', type: 'enum', options: ['row','cell','batch','form','popup'], default: 'row' },
    { name: 'editing.allowAdding', label: 'Allow Adding', type: 'bool', default: false },
    { name: 'editing.allowUpdating', label: 'Allow Updating', type: 'bool', default: false },
    { name: 'editing.allowDeleting', label: 'Allow Deleting', type: 'bool', default: false },
    { name: 'scrolling.mode', label: 'Scrolling Mode', type: 'enum', options: ['standard','virtual'], default: 'standard' },
    { name: 'keyExpr', label: 'Key Expr', type: 'string', default: 'id' },
    { name: 'parentIdExpr', label: 'Parent ID Expr', type: 'string', default: 'parentId' },
  ],
  List: [
    { name: 'selectionMode', label: 'Selection Mode', type: 'enum', options: ['none','single','multiple','all'], default: 'none' },
    { name: 'showSelectionControls', label: 'Selection Controls', type: 'bool', default: false },
    { name: 'searchEnabled', label: 'Search Enabled', type: 'bool', default: false },
    { name: 'allowItemDeleting', label: 'Allow Delete', type: 'bool', default: false },
    { name: 'allowItemReordering', label: 'Allow Reorder', type: 'bool', default: false },
    { name: 'grouped', label: 'Grouped', type: 'bool', default: false },
    { name: 'pullRefreshEnabled', label: 'Pull to Refresh', type: 'bool', default: false },
    { name: 'pageLoadMode', label: 'Page Load Mode', type: 'enum', options: ['scrollBottom','nextButton'], default: 'scrollBottom' },
    { name: 'showScrollbar', label: 'Show Scrollbar', type: 'enum', options: ['onScroll','onHover','always','never'], default: 'onScroll' },
    { name: 'noDataText', label: 'No Data Text', type: 'string', default: 'No data' },
  ],
  TreeView: [
    { name: 'showCheckBoxesMode', label: 'Checkboxes', type: 'enum', options: ['none','normal','selectAll'], default: 'none' },
    { name: 'selectionMode', label: 'Selection Mode', type: 'enum', options: ['single','multiple'], default: 'multiple' },
    { name: 'searchEnabled', label: 'Search Enabled', type: 'bool', default: false },
    { name: 'expandAllEnabled', label: 'Expand All Button', type: 'bool', default: false },
    { name: 'selectByClick', label: 'Select by Click', type: 'bool', default: false },
    { name: 'selectNodesRecursive', label: 'Recursive Select', type: 'bool', default: true },
    { name: 'expandNodesRecursive', label: 'Recursive Expand', type: 'bool', default: true },
    { name: 'animationEnabled', label: 'Animation', type: 'bool', default: true },
    { name: 'dataStructure', label: 'Data Structure', type: 'enum', options: ['tree','plain'], default: 'tree' },
    { name: 'noDataText', label: 'No Data Text', type: 'string', default: 'No data' },
  ],
  Gallery: [
    { name: 'loop', label: 'Loop', type: 'bool', default: false },
    { name: 'showIndicator', label: 'Show Indicator', type: 'bool', default: true },
    { name: 'showNavButtons', label: 'Nav Buttons', type: 'bool', default: false },
    { name: 'swipeEnabled', label: 'Swipe Enabled', type: 'bool', default: true },
    { name: 'stretchImages', label: 'Stretch Images', type: 'bool', default: false },
    { name: 'animationEnabled', label: 'Animation', type: 'bool', default: true },
    { name: 'animationDuration', label: 'Animation Duration', type: 'number', default: 400 },
    { name: 'slideshowDelay', label: 'Slideshow Delay', type: 'number', default: 0 },
    { name: 'wrapAround', label: 'Wrap Around', type: 'bool', default: false },
  ],

  // ─── EDITORS ──────────────────────────────────────────────────────────────
  TextBox: [
    { name: 'placeholder', label: 'Placeholder', type: 'string', default: '' },
    { name: 'showClearButton', label: 'Clear Button', type: 'bool', default: false },
    { name: 'mode', label: 'Mode', type: 'enum', options: ['text','password','email','search','tel','url'], default: 'text' },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['outlined','filled','underlined'], default: 'outlined' },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
    { name: 'label', label: 'Label', type: 'string', default: '' },
    { name: 'labelMode', label: 'Label Mode', type: 'enum', options: ['static','floating','hidden','outside'], default: 'static' },
    { name: 'maxLength', label: 'Max Length', type: 'number', default: 0 },
    { name: 'spellcheck', label: 'Spellcheck', type: 'bool', default: false },
  ],
  TextArea: [
    { name: 'placeholder', label: 'Placeholder', type: 'string', default: '' },
    { name: 'showClearButton', label: 'Clear Button', type: 'bool', default: false },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['outlined','filled','underlined'], default: 'outlined' },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
    { name: 'label', label: 'Label', type: 'string', default: '' },
    { name: 'autoResizeEnabled', label: 'Auto Resize', type: 'bool', default: false },
    { name: 'maxLength', label: 'Max Length', type: 'number', default: 0 },
    { name: 'spellcheck', label: 'Spellcheck', type: 'bool', default: false },
  ],
  NumberBox: [
    { name: 'placeholder', label: 'Placeholder', type: 'string', default: '' },
    { name: 'showClearButton', label: 'Clear Button', type: 'bool', default: false },
    { name: 'showSpinButtons', label: 'Spin Buttons', type: 'bool', default: false },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['outlined','filled','underlined'], default: 'outlined' },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
    { name: 'label', label: 'Label', type: 'string', default: '' },
    { name: 'min', label: 'Min', type: 'number', default: 0 },
    { name: 'max', label: 'Max', type: 'number', default: 100 },
    { name: 'step', label: 'Step', type: 'number', default: 1 },
    { name: 'format', label: 'Format', type: 'string', default: '' },
  ],
  CheckBox: [
    { name: 'text', label: 'Text', type: 'string', default: '' },
    { name: 'enableThreeStateBehavior', label: 'Three State', type: 'bool', default: false },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
    { name: 'value', label: 'Default Value', type: 'bool', default: false },
  ],
  SelectBox: [
    { name: 'placeholder', label: 'Placeholder', type: 'string', default: 'Select...' },
    { name: 'showClearButton', label: 'Clear Button', type: 'bool', default: false },
    { name: 'searchEnabled', label: 'Search Enabled', type: 'bool', default: false },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['outlined','filled','underlined'], default: 'outlined' },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
    { name: 'label', label: 'Label', type: 'string', default: '' },
    { name: 'labelMode', label: 'Label Mode', type: 'enum', options: ['static','floating','hidden','outside'], default: 'static' },
    { name: 'acceptCustomValue', label: 'Accept Custom', type: 'bool', default: false },
    { name: 'grouped', label: 'Grouped', type: 'bool', default: false },
    { name: 'openOnFieldClick', label: 'Open On Click', type: 'bool', default: false },
  ],
  TagBox: [
    { name: 'placeholder', label: 'Placeholder', type: 'string', default: '' },
    { name: 'showClearButton', label: 'Clear Button', type: 'bool', default: false },
    { name: 'searchEnabled', label: 'Search Enabled', type: 'bool', default: true },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['outlined','filled','underlined'], default: 'outlined' },
    { name: 'showSelectionControls', label: 'Selection Controls', type: 'bool', default: false },
    { name: 'multiline', label: 'Multiline', type: 'bool', default: true },
    { name: 'selectAllMode', label: 'Select All Mode', type: 'enum', options: ['page','allPages'], default: 'page' },
    { name: 'applyValueMode', label: 'Apply Value Mode', type: 'enum', options: ['instantly','useButtons'], default: 'instantly' },
    { name: 'hideSelectedItems', label: 'Hide Selected', type: 'bool', default: false },
    { name: 'maxDisplayedTags', label: 'Max Tags Shown', type: 'number', default: 0 },
  ],
  Lookup: [
    { name: 'placeholder', label: 'Placeholder', type: 'string', default: 'Select...' },
    { name: 'showClearButton', label: 'Clear Button', type: 'bool', default: false },
    { name: 'searchEnabled', label: 'Search Enabled', type: 'bool', default: true },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['outlined','filled','underlined'], default: 'outlined' },
    { name: 'showCancelButton', label: 'Cancel Button', type: 'bool', default: true },
    { name: 'fullScreen', label: 'Full Screen', type: 'bool', default: false },
    { name: 'usePopover', label: 'Use Popover', type: 'bool', default: false },
    { name: 'applyValueMode', label: 'Apply Value Mode', type: 'enum', options: ['instantly','useButtons'], default: 'instantly' },
    { name: 'pageLoadMode', label: 'Page Load Mode', type: 'enum', options: ['scrollBottom','nextButton'], default: 'scrollBottom' },
    { name: 'pullRefreshEnabled', label: 'Pull to Refresh', type: 'bool', default: false },
  ],
  Autocomplete: [
    { name: 'placeholder', label: 'Placeholder', type: 'string', default: '' },
    { name: 'showClearButton', label: 'Clear Button', type: 'bool', default: false },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['outlined','filled','underlined'], default: 'outlined' },
    { name: 'minSearchLength', label: 'Min Search Length', type: 'number', default: 1 },
    { name: 'maxItemCount', label: 'Max Items', type: 'number', default: 10 },
    { name: 'searchMode', label: 'Search Mode', type: 'enum', options: ['startswith','contains'], default: 'startswith' },
    { name: 'searchTimeout', label: 'Search Timeout', type: 'number', default: 200 },
  ],
  DropDownBox: [
    { name: 'placeholder', label: 'Placeholder', type: 'string', default: '' },
    { name: 'showClearButton', label: 'Clear Button', type: 'bool', default: false },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['outlined','filled','underlined'], default: 'outlined' },
    { name: 'openOnFieldClick', label: 'Open On Click', type: 'bool', default: false },
    { name: 'acceptCustomValue', label: 'Accept Custom', type: 'bool', default: false },
    { name: 'deferRendering', label: 'Defer Rendering', type: 'bool', default: true },
  ],
  DateBox: [
    { name: 'placeholder', label: 'Placeholder', type: 'string', default: '' },
    { name: 'type', label: 'Type', type: 'enum', options: ['date','time','datetime'], default: 'date' },
    { name: 'pickerType', label: 'Picker Type', type: 'enum', options: ['calendar','list','native','rollers'], default: 'calendar' },
    { name: 'showClearButton', label: 'Clear Button', type: 'bool', default: false },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['outlined','filled','underlined'], default: 'outlined' },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
    { name: 'label', label: 'Label', type: 'string', default: '' },
    { name: 'showTodayButton', label: 'Today Button', type: 'bool', default: false },
    { name: 'useMaskBehavior', label: 'Mask Behavior', type: 'bool', default: false },
    { name: 'displayFormat', label: 'Display Format', type: 'string', default: '' },
    { name: 'openOnFieldClick', label: 'Open On Click', type: 'bool', default: true },
    { name: 'applyValueMode', label: 'Apply Value Mode', type: 'enum', options: ['instantly','useButtons'], default: 'instantly' },
  ],
  DateRangeBox: [
    { name: 'startDateLabel', label: 'Start Label', type: 'string', default: 'Start Date' },
    { name: 'endDateLabel', label: 'End Label', type: 'string', default: 'End Date' },
    { name: 'showClearButton', label: 'Clear Button', type: 'bool', default: false },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['outlined','filled','underlined'], default: 'outlined' },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
    { name: 'multiView', label: 'Multi View', type: 'bool', default: true },
    { name: 'showTodayButton', label: 'Today Button', type: 'bool', default: false },
    { name: 'openOnFieldClick', label: 'Open On Click', type: 'bool', default: true },
    { name: 'applyValueMode', label: 'Apply Value Mode', type: 'enum', options: ['instantly','useButtons'], default: 'instantly' },
    { name: 'useMaskBehavior', label: 'Mask Behavior', type: 'bool', default: false },
  ],
  ColorBox: [
    { name: 'placeholder', label: 'Placeholder', type: 'string', default: '' },
    { name: 'showClearButton', label: 'Clear Button', type: 'bool', default: false },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['outlined','filled','underlined'], default: 'outlined' },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
    { name: 'editAlphaChannel', label: 'Alpha Channel', type: 'bool', default: false },
    { name: 'applyValueMode', label: 'Apply Value Mode', type: 'enum', options: ['instantly','useButtons'], default: 'instantly' },
    { name: 'openOnFieldClick', label: 'Open On Click', type: 'bool', default: true },
  ],
  Slider: [
    { name: 'min', label: 'Min', type: 'number', default: 0 },
    { name: 'max', label: 'Max', type: 'number', default: 100 },
    { name: 'step', label: 'Step', type: 'number', default: 1 },
    { name: 'showRange', label: 'Show Range', type: 'bool', default: true },
    { name: 'tooltip.enabled', label: 'Tooltip', type: 'bool', default: false },
    { name: 'tooltip.position', label: 'Tooltip Position', type: 'enum', options: ['top','bottom'], default: 'top' },
    { name: 'tooltip.showMode', label: 'Tooltip Show Mode', type: 'enum', options: ['onHover','always'], default: 'onHover' },
    { name: 'label.visible', label: 'Labels Visible', type: 'bool', default: false },
    { name: 'label.position', label: 'Label Position', type: 'enum', options: ['top','bottom'], default: 'bottom' },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['outlined','filled','underlined'], default: 'outlined' },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
  ],
  RangeSlider: [
    { name: 'min', label: 'Min', type: 'number', default: 0 },
    { name: 'max', label: 'Max', type: 'number', default: 100 },
    { name: 'step', label: 'Step', type: 'number', default: 1 },
    { name: 'tooltip.enabled', label: 'Tooltip', type: 'bool', default: false },
    { name: 'tooltip.position', label: 'Tooltip Position', type: 'enum', options: ['top','bottom'], default: 'top' },
    { name: 'tooltip.showMode', label: 'Tooltip Show Mode', type: 'enum', options: ['onHover','always'], default: 'onHover' },
    { name: 'label.visible', label: 'Labels Visible', type: 'bool', default: false },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['outlined','filled','underlined'], default: 'outlined' },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
  ],
  Switch: [
    { name: 'switchedOnText', label: 'On Text', type: 'string', default: 'ON' },
    { name: 'switchedOffText', label: 'Off Text', type: 'string', default: 'OFF' },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
    { name: 'value', label: 'Default Value', type: 'bool', default: false },
  ],
  RadioGroup: [
    { name: 'layout', label: 'Layout', type: 'enum', options: ['vertical','horizontal'], default: 'vertical' },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
    { name: 'displayExpr', label: 'Display Expr', type: 'string', default: '' },
    { name: 'valueExpr', label: 'Value Expr', type: 'string', default: '' },
  ],
  ButtonGroup: [
    { name: 'selectionMode', label: 'Selection Mode', type: 'enum', options: ['none','single','multiple'], default: 'single' },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['contained','outlined','text'], default: 'contained' },
  ],
  Calendar: [
    { name: 'firstDayOfWeek', label: 'First Day of Week', type: 'enum', options: ['0','1','2','3','4','5','6'], default: '0' },
    { name: 'showTodayButton', label: 'Today Button', type: 'bool', default: false },
    { name: 'showOtherMonthDays', label: 'Other Month Days', type: 'bool', default: true },
    { name: 'showWeekNumbers', label: 'Week Numbers', type: 'bool', default: false },
    { name: 'zoomLevel', label: 'Zoom Level', type: 'enum', options: ['month','year','decade','century'], default: 'month' },
    { name: 'maxZoomLevel', label: 'Max Zoom Level', type: 'enum', options: ['month','year','decade','century'], default: 'month' },
    { name: 'minZoomLevel', label: 'Min Zoom Level', type: 'enum', options: ['month','year','decade','century'], default: 'century' },
    { name: 'selectionMode', label: 'Selection Mode', type: 'enum', options: ['single','multiple','range','week','month'], default: 'single' },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
  ],
  HtmlEditor: [
    { name: 'placeholder', label: 'Placeholder', type: 'string', default: '' },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['outlined','filled','underlined'], default: 'outlined' },
    { name: 'valueType', label: 'Value Type', type: 'enum', options: ['html','markdown'], default: 'html' },
    { name: 'allowSoftLineBreak', label: 'Soft Line Break', type: 'bool', default: false },
    { name: 'mediaResizing.enabled', label: 'Media Resizing', type: 'bool', default: false },
    { name: 'tableResizing.enabled', label: 'Table Resizing', type: 'bool', default: false },
    { name: 'tableContextMenu.enabled', label: 'Table Context Menu', type: 'bool', default: false },
  ],
  FileUploader: [
    { name: 'multiple', label: 'Multiple Files', type: 'bool', default: false },
    { name: 'uploadMode', label: 'Upload Mode', type: 'enum', options: ['instantly','useButtons','useForm'], default: 'instantly' },
    { name: 'uploadMethod', label: 'Upload Method', type: 'enum', options: ['POST','PUT'], default: 'POST' },
    { name: 'showFileList', label: 'Show File List', type: 'bool', default: true },
    { name: 'allowCanceling', label: 'Allow Canceling', type: 'bool', default: true },
    { name: 'selectButtonText', label: 'Select Button Text', type: 'string', default: 'Select File' },
    { name: 'labelText', label: 'Label Text', type: 'string', default: 'or Drop file here' },
    { name: 'accept', label: 'Accept', type: 'string', default: '' },
    { name: 'maxFileSize', label: 'Max File Size', type: 'number', default: 0 },
    { name: 'chunkSize', label: 'Chunk Size', type: 'number', default: 0 },
  ],
  Form: [
    { name: 'colCount', label: 'Column Count', type: 'enum', options: ['1','2','3','4','auto'], default: '1' },
    { name: 'labelLocation', label: 'Label Location', type: 'enum', options: ['left','top','right'], default: 'left' },
    { name: 'labelMode', label: 'Label Mode', type: 'enum', options: ['outside','static','floating','hidden'], default: 'outside' },
    { name: 'readOnly', label: 'Read Only', type: 'bool', default: false },
    { name: 'showColonAfterLabel', label: 'Colon After Label', type: 'bool', default: true },
    { name: 'showRequiredMark', label: 'Required Mark', type: 'bool', default: true },
    { name: 'showOptionalMark', label: 'Optional Mark', type: 'bool', default: false },
    { name: 'showValidationSummary', label: 'Validation Summary', type: 'bool', default: false },
    { name: 'scrollingEnabled', label: 'Scrolling', type: 'bool', default: false },
    { name: 'alignItemLabels', label: 'Align Labels', type: 'bool', default: true },
  ],

  // ─── CHARTS & VISUALIZATION (existing) ───────────────────────────────────
  Chart: [
    { name: 'palette', label: 'Palette', type: 'enum', options: ['Material','Soft Pastel','Harmony Light','Office','Vintage','Violet','Carmine','Dark Moon','Soft Blue','Dark Violet','Green Mist'], default: 'Material' },
    { name: 'legend.visible', label: 'Legend Visible', type: 'bool', default: true },
    { name: 'legend.position', label: 'Legend Position', type: 'enum', options: ['inside','outside'], default: 'outside' },
    { name: 'tooltip.enabled', label: 'Tooltip Enabled', type: 'bool', default: false },
    { name: 'commonSeriesSettings.type', label: 'Series Type', type: 'enum', options: ['line','bar','area','spline','scatter','stepLine','fullStackedBar','stackedBar'], default: 'line' },
    { name: 'scrollBar.visible', label: 'Scroll Bar', type: 'bool', default: false },
    { name: 'zoomAndPan.argumentAxis', label: 'Zoom Argument Axis', type: 'enum', options: ['none','zoom','pan','both'], default: 'none' },
  ],
  PieChart: [
    { name: 'palette', label: 'Palette', type: 'enum', options: ['Material','Soft Pastel','Harmony Light','Office','Vintage','Violet'], default: 'Material' },
    { name: 'legend.visible', label: 'Legend Visible', type: 'bool', default: true },
    { name: 'tooltip.enabled', label: 'Tooltip Enabled', type: 'bool', default: false },
    { name: 'type', label: 'Type', type: 'enum', options: ['pie','donut'], default: 'pie' },
    { name: 'innerRadius', label: 'Inner Radius', type: 'number', default: 0.5 },
  ],
  Scheduler: [
    { name: 'currentView', label: 'Current View', type: 'enum', options: ['day','week','workWeek','month','timelineDay','timelineWeek','timelineWorkWeek','timelineMonth','agenda'], default: 'week' },
    { name: 'firstDayOfWeek', label: 'First Day', type: 'enum', options: ['0','1','2','3','4','5','6'], default: '0' },
    { name: 'showAllDayPanel', label: 'All Day Panel', type: 'bool', default: true },
    { name: 'crossScrollingEnabled', label: 'Cross Scrolling', type: 'bool', default: false },
    { name: 'editing.allowAdding', label: 'Allow Adding', type: 'bool', default: true },
    { name: 'editing.allowDeleting', label: 'Allow Deleting', type: 'bool', default: true },
  ],
  Gantt: [
    { name: 'taskListWidth', label: 'Task List Width', type: 'number', default: 300 },
    { name: 'showResources', label: 'Show Resources', type: 'bool', default: true },
    { name: 'scaleType', label: 'Scale Type', type: 'enum', options: ['auto','minutes','hours','days','weeks','months','quarters','years'], default: 'auto' },
    { name: 'editing.enabled', label: 'Editing Enabled', type: 'bool', default: false },
  ],
  Popup: [
    { name: 'title', label: 'Title', type: 'string', default: 'Popup' },
    { name: 'showTitle', label: 'Show Title', type: 'bool', default: true },
    { name: 'showCloseButton', label: 'Close Button', type: 'bool', default: true },
    { name: 'dragEnabled', label: 'Drag Enabled', type: 'bool', default: true },
    { name: 'resizeEnabled', label: 'Resize Enabled', type: 'bool', default: false },
    { name: 'fullScreen', label: 'Full Screen', type: 'bool', default: false },
  ],
  Button: [
    { name: 'text', label: 'Text', type: 'string', default: 'Button' },
    { name: 'type', label: 'Type', type: 'enum', options: ['normal','default','back','danger','success'], default: 'normal' },
    { name: 'stylingMode', label: 'Styling Mode', type: 'enum', options: ['contained','outlined','text'], default: 'contained' },
    { name: 'icon', label: 'Icon', type: 'string', default: '' },
    { name: 'disabled', label: 'Disabled', type: 'bool', default: false },
  ],
  PolarChart: [
    { name: 'palette', label: 'Palette', type: 'enum', options: ['Material','Soft Pastel','Harmony Light','Office','Vintage','Violet'], default: 'Material' },
    { name: 'useSpiderWeb', label: 'Spider Web', type: 'bool', default: false },
    { name: 'commonSeriesSettings.type', label: 'Series Type', type: 'enum', options: ['line','area','bar','scatter','stackedLine','stackedArea','fullStackedLine','fullStackedArea'], default: 'scatter' },
    { name: 'legend.visible', label: 'Legend Visible', type: 'bool', default: true },
    { name: 'tooltip.enabled', label: 'Tooltip Enabled', type: 'bool', default: false },
    { name: 'commonSeriesSettings.closed', label: 'Closed Series', type: 'bool', default: true },
  ],
  Funnel: [
    { name: 'algorithm', label: 'Algorithm', type: 'enum', options: ['dynamicSlope','dynamicHeight'], default: 'dynamicSlope' },
    { name: 'palette', label: 'Palette', type: 'enum', options: ['Material','Soft Pastel','Harmony Light','Office','Vintage','Violet'], default: 'Material' },
    { name: 'inverted', label: 'Inverted', type: 'bool', default: false },
    { name: 'sortData', label: 'Sort Data', type: 'bool', default: true },
    { name: 'label.visible', label: 'Labels Visible', type: 'bool', default: true },
    { name: 'label.position', label: 'Label Position', type: 'enum', options: ['inside','outside','columns'], default: 'columns' },
    { name: 'tooltip.enabled', label: 'Tooltip Enabled', type: 'bool', default: false },
    { name: 'resolveLabelOverlapping', label: 'Overlap Mode', type: 'enum', options: ['shift','hide','none'], default: 'shift' },
  ],
  Sankey: [
    { name: 'palette', label: 'Palette', type: 'enum', options: ['Material','Soft Pastel','Harmony Light','Office','Vintage','Violet'], default: 'Material' },
    { name: 'alignment', label: 'Alignment', type: 'enum', options: ['top','center','bottom'], default: 'center' },
    { name: 'label.visible', label: 'Labels Visible', type: 'bool', default: true },
    { name: 'link.colorMode', label: 'Link Color Mode', type: 'enum', options: ['none','source','target','gradient'], default: 'none' },
    { name: 'link.opacity', label: 'Link Opacity', type: 'number', default: 0.3 },
    { name: 'node.width', label: 'Node Width', type: 'number', default: 30 },
    { name: 'node.padding', label: 'Node Padding', type: 'number', default: 30 },
    { name: 'tooltip.enabled', label: 'Tooltip Enabled', type: 'bool', default: false },
  ],
  TreeMap: [
    { name: 'palette', label: 'Palette', type: 'enum', options: ['Material','Soft Pastel','Harmony Light','Office','Vintage','Violet'], default: 'Material' },
    { name: 'layoutAlgorithm', label: 'Layout Algorithm', type: 'enum', options: ['squarified','strip','sliceanddice'], default: 'squarified' },
    { name: 'layoutDirection', label: 'Layout Direction', type: 'enum', options: ['leftTopRightBottom','leftBottomRightTop','rightTopLeftBottom','rightBottomLeftTop'], default: 'leftTopRightBottom' },
    { name: 'colorizer.type', label: 'Colorizer Type', type: 'enum', options: ['none','gradient','range','discrete'], default: 'none' },
    { name: 'colorizer.colorizeGroups', label: 'Colorize Groups', type: 'bool', default: false },
    { name: 'tooltip.enabled', label: 'Tooltip Enabled', type: 'bool', default: false },
    { name: 'maxDepth', label: 'Max Depth', type: 'number', default: 2 },
    { name: 'resolveLabelOverlapping', label: 'Label Overlap', type: 'enum', options: ['hide','none'], default: 'hide' },
  ],
  VectorMap: [
    { name: 'projection', label: 'Projection', type: 'enum', options: ['mercator','equirectangular','lambert','miller'], default: 'mercator' },
    { name: 'panningEnabled', label: 'Panning', type: 'bool', default: true },
    { name: 'zoomingEnabled', label: 'Zooming', type: 'bool', default: true },
    { name: 'wheelEnabled', label: 'Mouse Wheel', type: 'bool', default: true },
    { name: 'touchEnabled', label: 'Touch', type: 'bool', default: true },
    { name: 'maxZoomFactor', label: 'Max Zoom', type: 'number', default: 256 },
    { name: 'tooltip.enabled', label: 'Tooltip Enabled', type: 'bool', default: false },
    { name: 'controlBar.enabled', label: 'Control Bar', type: 'bool', default: true },
    { name: 'controlBar.position', label: 'Control Bar Pos', type: 'enum', options: ['top-left','top-right','bottom-left','bottom-right'], default: 'top-left' },
  ],
  Sparkline: [
    { name: 'type', label: 'Type', type: 'enum', options: ['line','bar','spline','stepLine','area','splineArea','stepArea','winloss'], default: 'line' },
    { name: 'lineColor', label: 'Line Color', type: 'string', default: '#666666' },
    { name: 'lineWidth', label: 'Line Width', type: 'number', default: 2 },
    { name: 'showFirstLast', label: 'Show First/Last', type: 'bool', default: true },
    { name: 'showMinMax', label: 'Show Min/Max', type: 'bool', default: false },
    { name: 'tooltip.enabled', label: 'Tooltip Enabled', type: 'bool', default: true },
    { name: 'pointSymbol', label: 'Point Symbol', type: 'enum', options: ['circle','square','polygon','triangle','triangleDown'], default: 'circle' },
    { name: 'pointSize', label: 'Point Size', type: 'number', default: 4 },
  ],
  Bullet: [
    { name: 'color', label: 'Bar Color', type: 'string', default: '#e8c267' },
    { name: 'targetColor', label: 'Target Color', type: 'string', default: '#666666' },
    { name: 'targetWidth', label: 'Target Width', type: 'number', default: 4 },
    { name: 'showTarget', label: 'Show Target', type: 'bool', default: true },
    { name: 'showZeroLevel', label: 'Show Zero Level', type: 'bool', default: true },
    { name: 'startScaleValue', label: 'Scale Start', type: 'number', default: 0 },
    { name: 'tooltip.enabled', label: 'Tooltip Enabled', type: 'bool', default: true },
  ],
  BarGauge: [
    { name: 'palette', label: 'Palette', type: 'enum', options: ['Material','Soft Pastel','Harmony Light','Office','Vintage','Violet'], default: 'Material' },
    { name: 'startValue', label: 'Start Value', type: 'number', default: 0 },
    { name: 'endValue', label: 'End Value', type: 'number', default: 100 },
    { name: 'barSpacing', label: 'Bar Spacing', type: 'number', default: 4 },
    { name: 'relativeInnerRadius', label: 'Inner Radius', type: 'number', default: 0.3 },
    { name: 'label.visible', label: 'Labels Visible', type: 'bool', default: true },
    { name: 'tooltip.enabled', label: 'Tooltip Enabled', type: 'bool', default: false },
    { name: 'resolveLabelOverlapping', label: 'Label Overlap', type: 'enum', options: ['hide','none'], default: 'hide' },
  ],
  LinearGauge: [
    { name: 'geometry.orientation', label: 'Orientation', type: 'enum', options: ['vertical','horizontal'], default: 'vertical' },
    { name: 'scale.startValue', label: 'Scale Start', type: 'number', default: 0 },
    { name: 'scale.endValue', label: 'Scale End', type: 'number', default: 100 },
    { name: 'rangeContainer.width', label: 'Range Width', type: 'number', default: 5 },
    { name: 'rangeContainer.offset', label: 'Range Offset', type: 'number', default: 0 },
    { name: 'tooltip.enabled', label: 'Tooltip Enabled', type: 'bool', default: false },
  ],
  CircularGauge: [
    { name: 'geometry.startAngle', label: 'Start Angle', type: 'number', default: 135 },
    { name: 'geometry.endAngle', label: 'End Angle', type: 'number', default: 405 },
    { name: 'scale.startValue', label: 'Scale Start', type: 'number', default: 0 },
    { name: 'scale.endValue', label: 'Scale End', type: 'number', default: 100 },
    { name: 'rangeContainer.width', label: 'Range Width', type: 'number', default: 5 },
    { name: 'rangeContainer.orientation', label: 'Range Orientation', type: 'enum', options: ['inside','outside','center'], default: 'outside' },
    { name: 'tooltip.enabled', label: 'Tooltip Enabled', type: 'bool', default: false },
  ],
  RangeSelector: [
    { name: 'selectedRangeColor', label: 'Selection Color', type: 'string', default: '#729ab4' },
    { name: 'selectedRangeUpdateMode', label: 'Update Mode', type: 'enum', options: ['reset','shift','keep'], default: 'reset' },
    { name: 'behavior.snapToTicks', label: 'Snap to Ticks', type: 'bool', default: true },
    { name: 'behavior.animationEnabled', label: 'Animation', type: 'bool', default: true },
    { name: 'behavior.allowSlidersSwap', label: 'Allow Swap', type: 'bool', default: true },
    { name: 'background.visible', label: 'Background Visible', type: 'bool', default: true },
  ],
  PivotGrid: [
    { name: 'showBorders', label: 'Show Borders', type: 'bool', default: false },
    { name: 'showColumnGrandTotals', label: 'Col Grand Totals', type: 'bool', default: true },
    { name: 'showRowGrandTotals', label: 'Row Grand Totals', type: 'bool', default: true },
    { name: 'showColumnTotals', label: 'Col Totals', type: 'bool', default: true },
    { name: 'showRowTotals', label: 'Row Totals', type: 'bool', default: true },
    { name: 'allowSorting', label: 'Allow Sorting', type: 'bool', default: false },
    { name: 'allowFiltering', label: 'Allow Filtering', type: 'bool', default: false },
    { name: 'allowExpandAll', label: 'Allow Expand All', type: 'bool', default: false },
    { name: 'fieldPanel.visible', label: 'Field Panel', type: 'bool', default: false },
    { name: 'fieldChooser.enabled', label: 'Field Chooser', type: 'bool', default: true },
    { name: 'scrolling.mode', label: 'Scrolling Mode', type: 'enum', options: ['standard','virtual'], default: 'standard' },
    { name: 'wordWrapEnabled', label: 'Word Wrap', type: 'bool', default: false },
  ],
};

function WidgetTreeItemTemplate(item, onDblClick) {
  const isWidget = item.assetLevel === 'widget';
  return (
    <div
      className={`tree-item${isWidget ? ' tree-item--widget' : ''}`}
      draggable={isWidget}
      onDoubleClick={isWidget && onDblClick ? (e) => { e.stopPropagation(); onDblClick(item); } : undefined}
      onDragStart={isWidget ? (e) => {
        e.dataTransfer.setData('dx-widget-name', item.name);
        e.dataTransfer.setData('dx-widget-id', item.id);
        e.dataTransfer.effectAllowed = 'copy';
      } : undefined}
    >
      <span className="tree-item-name">{item.name}</span>
    </div>
  );
}

function AssetTreeItemTemplate(item) {
  if (item.nodeType === 'tag') {
    return (
      <div className="tree-item">
        <span className="tree-item-name">{item.name}</span>
        <span className="tree-item-badge tree-item-badge--tag">{item.tagDomain.toLowerCase()}</span>
      </div>
    );
  }
  return (
    <div className="tree-item">
      <span className="tree-item-name">{item.name}</span>
      <span className="tree-item-badge">{item.assetType}</span>
    </div>
  );
}

function getAncestorBreadcrumb(assetId) {
  const crumbs = [];
  let current = ASSET_MAP[assetId];
  // Walk up but exclude the asset itself — we want the path to the parent
  current = current?.parentId ? ASSET_MAP[current.parentId] : null;
  while (current) {
    crumbs.unshift(current.name);
    current = current.parentId ? ASSET_MAP[current.parentId] : null;
  }
  return crumbs;
}

function StepSelectAsset({ selectedAssetIds, onAssetsSelected }) {
  const [searchValue, setSearchValue] = useState('');

  const handleSelectionChanged = (e) => {
    const item = e.itemData;
    if (!item) return;
    if (e.node.selected) {
      const asset = ASSET_MAP[item.id];
      if (asset) onAssetsSelected([...selectedAssetIds.filter(a => a.id !== asset.id), asset]);
    } else {
      onAssetsSelected(selectedAssetIds.filter(a => a.id !== item.id));
    }
  };

  return (
    <div className="step-select-asset">
      <div className="step-data-selection">
        <div className="data-selection-left">
          <p className="step-instructions">Select one or more assets.</p>
          <div className="treeview-container">
            <TreeView
              dataSource={ASSET_DATA}
              dataStructure="plain"
              keyExpr="id"
              parentIdExpr="parentId"
              displayExpr="name"
              itemRender={AssetTreeItemTemplate}
              selectionMode="multiple"
              selectByClick={true}
              selectNodesRecursive={false}
              expandAllEnabled={true}
              defaultExpandAll={true}
              searchEnabled={true}
              searchValue={searchValue}
              onOptionChanged={(e) => {
                if (e.name === 'searchValue') setSearchValue(e.value);
              }}
              selectedItemKeys={selectedAssetIds.map(a => a.id)}
              onItemSelectionChanged={handleSelectionChanged}
            />
          </div>
        </div>
        <div className="data-selection-right">
          <div className="selected-tags-header">
            <p className="panel-label">Selected</p>
            <span className="selected-count">{selectedAssetIds.length}</span>
          </div>
          <div className="selected-tags-list">
            {selectedAssetIds.length === 0 ? (
              <p className="step-instructions">Click an asset in the tree to select it.</p>
            ) : (
              selectedAssetIds.map(asset => {
                const crumbs = getAncestorBreadcrumb(asset.id);
                return (
                  <div key={asset.id} className="selected-tag-item selected-asset-compact">
                    <span className="selected-asset-compact-name">{asset.name}</span>
                    {crumbs.length > 0 && (
                      <span className="selected-asset-compact-crumb">› {crumbs.join(' › ')}</span>
                    )}
                    <span className="tree-item-badge" style={{ flexShrink: 0 }}>{asset.assetType}</span>
                    <button
                      className="selected-tag-remove"
                      onClick={() => onAssetsSelected(selectedAssetIds.filter(a => a.id !== asset.id))}
                      title="Remove"
                    >×</button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function StepDataSelection({ selectedAssetId, onAssetSelected, selectedAssets, selectedTags, onTagsChanged }) {
  const setSelectedTags = onTagsChanged;
  const [groupBy, setGroupBy] = useState('asset');
  const [viewMode, setViewMode] = useState('tree');
  const [focusedAssetId, setFocusedAssetId] = useState(null);
  const [domainFilter, setDomainFilter] = useState('all');

  const TAG_DOMAINS = [
    'all',
    'common',
    'production',
    'derived metrics',
    'operations / control',
    'flow / wip',
    'quality',
    'events / losses',
    'stability',
    'risk / delivery',
    'diagnostics / accuracy',
  ];

  const toggleTag = (item) => {
    setSelectedTags(prev => {
      const exists = prev.find(t => t.id === item.id);
      if (exists) return prev.filter(t => t.id !== item.id);
      return [...prev, item];
    });
  };

  const treeData = groupBy === 'asset'
    ? buildSelectedAssetTree(selectedAssets || [])
    : ASSET_DATA;

  // Unique types from selected assets
  const uniqueTypes = [...new Set((selectedAssets || []).map(a => a.assetType))].sort();
  const [focusedType, setFocusedType] = useState(null);

  const focusedAsset = focusedAssetId ? ASSET_MAP[focusedAssetId] : null;

  // In type mode, derive the asset level from any asset matching the focused type
  const focusedTypeAssets = focusedType
    ? (selectedAssets || []).filter(a => a.assetType === focusedType)
    : [];
  const focusedTypeLevel = focusedTypeAssets.length > 0 ? focusedTypeAssets[0].assetLevel : null;

  // Tags shown in center depend on mode
  const centerAssetLevel = groupBy === 'type' ? focusedTypeLevel : focusedAsset?.assetLevel;
  const allFocusedTags = centerAssetLevel ? (TAGS_BY_LEVEL[centerAssetLevel] || []) : [];
  const focusedTags = domainFilter === 'all'
    ? allFocusedTags
    : allFocusedTags.filter(t => t.tagDomain === domainFilter);

  // In type mode, a tag is "selected" if ALL matching assets have that tag selected
  const isTagSelectedForType = (tagName) =>
    focusedTypeAssets.length > 0 &&
    focusedTypeAssets.every(a => !!selectedTags.find(t => t.id === `${a.id}__tag__${tagName}`));

  const toggleTagForType = (tag) => {
    const allSelected = isTagSelectedForType(tag.tagName);
    setSelectedTags(prev => {
      let result = [...prev];
      focusedTypeAssets.forEach(asset => {
        const tagId = `${asset.id}__tag__${tag.tagName}`;
        if (allSelected) {
          result = result.filter(t => t.id !== tagId);
        } else {
          if (!result.find(t => t.id === tagId)) {
            result.push({
              id: tagId,
              name: tag.tagName,
              tagDomain: tag.tagDomain,
              tagCategory: tag.tagCategory,
              nodeType: 'tag',
            });
          }
        }
      });
      return result;
    });
  };

  const centerIsFocused = groupBy === 'type' ? !!focusedType : !!focusedAsset;

  const assetItemRender = (item) => (
    <div className={`tree-item tree-item--asset${item.isPlaceholder ? ' tree-item--placeholder' : ''}`}>
      <span className="tree-item-name">{item.name}</span>
      <span className={`tree-item-badge${item.isPlaceholder ? ' tree-item-badge--placeholder' : ''}`}>
        {item.assetType}
      </span>
    </div>
  );

  return (
    <div className="step-data-selection">

      {/* Left: asset tree */}
      <div className="data-selection-left">
        <div className="step2-toolbar">
          <SelectBox
            dataSource={[
              { value: 'asset', label: 'Asset' },
              { value: 'type', label: 'Type' },
            ]}
            displayExpr="label"
            valueExpr="value"
            value={groupBy}
            onValueChanged={(e) => setGroupBy(e.value)}
            width={140}
            stylingMode="outlined"
          />
          {groupBy === 'asset' && (
            <SelectBox
              dataSource={[
                { value: 'tree', label: 'Tree' },
                { value: 'flat', label: 'Flat' },
              ]}
              displayExpr="label"
              valueExpr="value"
              value={viewMode}
              onValueChanged={(e) => setViewMode(e.value)}
              width={120}
              stylingMode="outlined"
            />
          )}
        </div>
        {groupBy === 'asset' && viewMode === 'flat' ? (
          <div className="selected-tags-list">
            {(selectedAssets || []).length === 0 ? (
              <p className="step-instructions">No assets selected on the previous step.</p>
            ) : (
              (selectedAssets || []).map(asset => {
                const crumbs = getAncestorBreadcrumb(asset.id);
                const isActive = focusedAssetId === asset.id;
                return (
                  <div
                    key={asset.id}
                    className={`selected-tag-item selected-asset-item${isActive ? ' center-tag-item--selected' : ''}`}
                    onClick={() => setFocusedAssetId(asset.id)}
                    style={{ cursor: 'pointer' }}
                  >
                    <div className="selected-asset-info">
                      <span className="selected-tag-name">{asset.name}</span>
                      {crumbs.length > 0 && (
                        <span className="selected-asset-breadcrumb">{crumbs.join(' › ')}</span>
                      )}
                    </div>
                    <span className="tree-item-badge">{asset.assetType}</span>
                  </div>
                );
              })
            )}
          </div>
        ) : groupBy === 'type' ? (
          <div className="selected-tags-list">
            {uniqueTypes.length === 0 ? (
              <p className="step-instructions">No assets selected on the previous step.</p>
            ) : (
              uniqueTypes.map(type => {
                const isActive = focusedType === type;
                return (
                  <div
                    key={type}
                    className={`selected-tag-item${isActive ? ' center-tag-item--selected' : ''}`}
                    onClick={() => setFocusedType(type)}
                    style={{ cursor: 'pointer' }}
                  >
                    <span className="selected-tag-name">{type}</span>
                  </div>
                );
              })
            )}
          </div>
        ) : (
          <div className="treeview-container">
            <TreeView
              dataSource={treeData}
              dataStructure="plain"
              keyExpr="id"
              parentIdExpr="parentId"
              displayExpr="name"
              itemRender={assetItemRender}
              selectionMode="single"
              selectByClick={true}
              expandAllEnabled={true}
              defaultExpandAll={true}
              selectedItemKeys={focusedAssetId ? [focusedAssetId] : []}
              onItemSelectionChanged={(e) => {
                const selected = e.component.getSelectedNodes();
                const id = selected.length > 0 ? selected[0].key : null;
                const asset = id ? ASSET_MAP[id] : null;
                if (asset && !asset.isPlaceholder) setFocusedAssetId(id);
              }}
            />
          </div>
        )}
      </div>

      {/* Center: properties for focused asset or type */}
      <div className="data-selection-center">
        <div className="step2-toolbar">
          <SelectBox
            dataSource={TAG_DOMAINS}
            value={domainFilter}
            onValueChanged={(e) => setDomainFilter(e.value)}
            width={200}
            stylingMode="outlined"
            disabled={!centerIsFocused}
          />
        </div>
        {centerIsFocused ? (
          <div className="selected-tags-list">
            {focusedTags.map(tag => {
              const isSelected = groupBy === 'type'
                ? isTagSelectedForType(tag.tagName)
                : !!selectedTags.find(t => t.id === `${focusedAssetId}__tag__${tag.tagName}`);

              const handleClick = groupBy === 'type'
                ? () => toggleTagForType(tag)
                : () => toggleTag({
                    id: `${focusedAssetId}__tag__${tag.tagName}`,
                    name: tag.tagName,
                    tagDomain: tag.tagDomain,
                    tagCategory: tag.tagCategory,
                    nodeType: 'tag',
                  });

              return (
                <div
                  key={tag.tagName}
                  className={`selected-tag-item center-tag-item${isSelected ? ' center-tag-item--selected' : ''}`}
                  onClick={handleClick}
                >
                  <input
                    type="checkbox"
                    className="tree-item-checkbox"
                    checked={isSelected}
                    onChange={() => {}}
                    onClick={(e) => e.stopPropagation()}
                  />
                  <span className="selected-tag-name">{tag.tagName}</span>
                  <span className="tree-item-badge tree-item-badge--tag">{tag.tagDomain.toLowerCase()}</span>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="step-instructions">
            {groupBy === 'type'
              ? 'Click a type in the list to view its properties.'
              : 'Click an asset in the tree to view its properties.'}
          </p>
        )}
      </div>

      {/* Right: selected tags */}
      <div className="data-selection-right">
        <div className="selected-tags-header">
          <p className="panel-label">Selected</p>
          <span className="selected-count">{selectedTags.length}</span>
        </div>
        <div className="selected-tags-list">
          {selectedTags.length === 0 ? (
            <p className="step-instructions">Check a tag in the tree to select it.</p>
          ) : (
            selectedTags.map(tag => {
              const assetId = tag.id.split('__tag__')[0];
              const crumbs = getAncestorBreadcrumb(assetId);
              const asset = ASSET_MAP[assetId];
              const fullCrumbs = asset ? [...crumbs, asset.name] : crumbs;
              return (
                <div key={tag.id} className="selected-tag-item selected-asset-item">
                  <div className="selected-asset-info">
                    <span className="selected-tag-name">{tag.name}</span>
                    {fullCrumbs.length > 0 && (
                      <span className="selected-asset-breadcrumb">{fullCrumbs.join(' › ')}</span>
                    )}
                  </div>
                  <span className="tree-item-badge tree-item-badge--tag">{tag.tagDomain.toLowerCase()}</span>
                  <button
                    className="selected-tag-remove"
                    onClick={() => setSelectedTags(prev => prev.filter(t => t.id !== tag.id))}
                    title="Remove"
                  >×</button>
                </div>
              );
            })
          )}
        </div>
      </div>

    </div>
  );
}

function StepGrouping({ selectedTags, selectedAssets }) {
  const [groupMode, setGroupMode] = useState('asset');
  const [customGroups, setCustomGroups] = useState([]);
  const [draggedTag, setDraggedTag] = useState(null);
  const [newGroupName, setNewGroupName] = useState('');

  // --- Asset mode: group tags by their asset ---
  const groupsByAsset = useMemo(() => {
    const map = {};
    selectedTags.forEach(tag => {
      const assetId = tag.id.split('__tag__')[0];
      const asset = ASSET_MAP[assetId];
      if (!asset) return;
      if (!map[assetId]) map[assetId] = { asset, tags: [] };
      map[assetId].tags.push(tag);
    });
    return Object.values(map);
  }, [selectedTags]);

  // --- Category mode: group tags by tagDomain ---
  const groupsByCategory = useMemo(() => {
    const map = {};
    selectedTags.forEach(tag => {
      const domain = tag.tagDomain || 'uncategorized';
      if (!map[domain]) map[domain] = [];
      map[domain].push(tag);
    });
    return Object.entries(map).sort(([a], [b]) => a.localeCompare(b));
  }, [selectedTags]);

  // --- Custom mode helpers ---
  const assignedTagIds = new Set(customGroups.flatMap(g => g.tagIds));
  const unassignedTags = selectedTags.filter(t => !assignedTagIds.has(t.id));

  const addGroup = () => {
    const name = newGroupName.trim();
    if (!name) return;
    setCustomGroups(prev => [...prev, { id: Date.now(), name, tagIds: [] }]);
    setNewGroupName('');
  };

  const removeGroup = (groupId) => {
    setCustomGroups(prev => prev.filter(g => g.id !== groupId));
  };

  const handleDragStart = (tag) => setDraggedTag(tag);
  const handleDragEnd = () => setDraggedTag(null);

  const handleDropOnGroup = (groupId) => {
    if (!draggedTag) return;
    setCustomGroups(prev => prev.map(g => {
      // Remove from any existing group first
      const withoutTag = { ...g, tagIds: g.tagIds.filter(id => id !== draggedTag.id) };
      if (withoutTag.id === groupId) {
        return { ...withoutTag, tagIds: [...withoutTag.tagIds, draggedTag.id] };
      }
      return withoutTag;
    }));
    setDraggedTag(null);
  };

  const handleDropOnUnassigned = () => {
    if (!draggedTag) return;
    setCustomGroups(prev => prev.map(g => ({
      ...g, tagIds: g.tagIds.filter(id => id !== draggedTag.id),
    })));
    setDraggedTag(null);
  };

  const getTagById = (id) => selectedTags.find(t => t.id === id);

  const renderTagPill = (tag, draggable = false) => {
    const assetId = tag.id.split('__tag__')[0];
    const asset = ASSET_MAP[assetId];
    return (
      <div
        key={tag.id}
        className="grouping-tag-pill"
        draggable={draggable}
        onDragStart={draggable ? () => handleDragStart(tag) : undefined}
        onDragEnd={draggable ? handleDragEnd : undefined}
      >
        <span className="grouping-tag-name">{tag.name}</span>
        {asset && <span className="grouping-tag-asset">{asset.name}</span>}
      </div>
    );
  };

  const renderGroupCard = (title, tags, groupId = null) => (
    <div
      key={title}
      className="grouping-card"
      onDragOver={groupId !== null ? (e) => e.preventDefault() : undefined}
      onDrop={groupId !== null ? () => handleDropOnGroup(groupId) : undefined}
    >
      <div className="grouping-card-header">
        <span className="grouping-card-title">{title}</span>
        <span className="selected-count">{tags.length}</span>
        {groupId !== null && (
          <button className="selected-tag-remove" onClick={() => removeGroup(groupId)} title="Delete group">×</button>
        )}
      </div>
      <div className="grouping-card-body">
        {tags.length === 0
          ? <p className="grouping-empty">Drop properties here</p>
          : tags.map(tag => renderTagPill(tag, groupId !== null))}
      </div>
    </div>
  );

  return (
    <div className="step-grouping">
      {/* Mode toggle */}
      <div className="step2-toolbar" style={{ marginBottom: 12 }}>
        {['asset', 'category', 'custom'].map(mode => (
          <button
            key={mode}
            className={`grouping-mode-btn${groupMode === mode ? ' grouping-mode-btn--active' : ''}`}
            onClick={() => setGroupMode(mode)}
          >
            {mode.charAt(0).toUpperCase() + mode.slice(1)}
          </button>
        ))}
      </div>

      {/* Asset mode */}
      {groupMode === 'asset' && (
        <div className="grouping-grid">
          {groupsByAsset.length === 0
            ? <p className="step-instructions">No properties selected yet.</p>
            : groupsByAsset.map(({ asset, tags }) => {
                const crumbs = getAncestorBreadcrumb(asset.id);
                const title = crumbs.length > 0 ? `${crumbs.join(' › ')} › ${asset.name}` : asset.name;
                return renderGroupCard(title, tags);
              })}
        </div>
      )}

      {/* Category mode */}
      {groupMode === 'category' && (
        <div className="grouping-grid">
          {groupsByCategory.length === 0
            ? <p className="step-instructions">No properties selected yet.</p>
            : groupsByCategory.map(([domain, tags]) => renderGroupCard(domain, tags))}
        </div>
      )}

      {/* Custom mode */}
      {groupMode === 'custom' && (
        <div className="grouping-custom">
          <div className="grouping-custom-left">
            <div className="selected-tags-header">
              <p className="panel-label">Unassigned</p>
              <span className="selected-count">{unassignedTags.length}</span>
            </div>
            <div
              className="grouping-unassigned"
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleDropOnUnassigned}
            >
              {unassignedTags.length === 0
                ? <p className="grouping-empty">All properties assigned!</p>
                : unassignedTags.map(tag => renderTagPill(tag, true))}
            </div>
          </div>
          <div className="grouping-custom-right">
            <div className="grouping-add-row">
              <input
                className="grouping-name-input"
                placeholder="New group name..."
                value={newGroupName}
                onChange={(e) => setNewGroupName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addGroup()}
              />
              <button className="grouping-add-btn" onClick={addGroup}>+</button>
            </div>
            <div className="grouping-grid">
              {customGroups.length === 0
                ? <p className="step-instructions">Create a group to get started.</p>
                : customGroups.map(group => {
                    const tags = group.tagIds.map(getTagById).filter(Boolean);
                    return renderGroupCard(group.name, tags, group.id);
                  })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}


function StepPlaceholder({ step }) {
  return (
    <div className="step-placeholder">
      <p className="step-instructions">{STEPS[step].title} content goes here.</p>
    </div>
  );
}

function WizardContent({ currentStep, selectedAssetIds, onAssetsSelected, selectedTags, onTagsChanged }) {
  return (
    <div className="wizard-content">
      <div className="wizard-progress">
        <span className="wizard-step-label">Step {currentStep + 1} of {STEPS.length}</span>
        <div className="wizard-pips">
          {STEPS.map((_, i) => (
            <div key={i} className={`wizard-pip ${i <= currentStep ? 'active' : ''}`} />
          ))}
        </div>
      </div>
      <h3 className="wizard-title">{STEPS[currentStep].title}</h3>
      {currentStep === 0 && (
        <StepSelectAsset
          selectedAssetIds={selectedAssetIds}
          onAssetsSelected={onAssetsSelected}
        />
      )}
      {currentStep === 1 && (
        <StepDataSelection
          selectedAssetId={selectedAssetIds[0]?.id || null}
          onAssetSelected={(id) => onAssetsSelected(id ? [ASSET_MAP[id]] : [])}
          selectedAssets={selectedAssetIds}
          selectedTags={selectedTags}
          onTagsChanged={onTagsChanged}
        />
      )}
      {currentStep === 2 && (
        <StepGrouping
          selectedTags={selectedTags}
          selectedAssets={selectedAssetIds}
        />
      )}
      {currentStep > 2 && <StepPlaceholder step={currentStep} />}
    </div>
  );
}

function PageVisualsTreeItem({ item }) {
  return (
    <span className="tree-inline-label">{item.title}</span>
  );
}

function flattenContainers(containers, parentId = null) {
  const result = [];
  containers.forEach(c => {
    result.push({ id: c.id, title: c.title, parentId });
    if (c.children.length > 0) {
      result.push(...flattenContainers(c.children, c.id));
    }
  });
  return result;
}

const DEFAULT_LAYOUT = {
  layoutType: 'flex',
  flexDirection: 'row',
  flexWrap: 'no wrap',
  justifyContent: 'flex-start',
  alignItems: 'stretch',
  gridColumns: 2,
  gridRows: 2,
  gridGap: '8px',
  gridCells: null,
  gridMergeDirection: 'horizontal', // 'horizontal' = merge side-by-side only, 'vertical' = merge top-bottom only
};

const DEFAULT_SLOT = {
  flexGrow: 0,
  flexShrink: 0,
  flexBasis: 'auto',
  alignSelf: 'auto',
  order: 0,
  width: '200px',
  height: '150px',
  minWidth: '',
  maxWidth: '',
  minHeight: '',
  maxHeight: '',
  // Box model
  paddingTop: '',
  paddingBottom: '',
  paddingLeft: '',
  paddingRight: '',
  marginTop: '',
  marginBottom: '',
  marginLeft: '',
  marginRight: '',
  borderWidth: '',
  borderStyle: '',
  borderColor: '',
  borderRadius: '',
  // Background
  backgroundColor: '',
  backgroundImage: '',
  backgroundSize: '',
  backgroundPosition: '',
  backgroundRepeat: '',
  // Typography
  color: '',
  fontSize: '',
  fontWeight: '',
  fontFamily: '',
  lineHeight: '',
  textAlign: '',
  letterSpacing: '',
};

// Compact default sizes per widget — swap out to taste
// Format: { width, height } in px
const WIDGET_DEFAULT_SIZES = {
  // Grids & Lists — need more height to show rows
  DataGrid:      { width: '400px', height: '250px' },
  TreeList:      { width: '400px', height: '250px' },
  List:          { width: '200px', height: '200px' },
  TreeView:      { width: '200px', height: '200px' },
  Gallery:       { width: '300px', height: '200px' },

  // Charts — square-ish by default
  Chart:         { width: '300px', height: '200px' },
  PieChart:      { width: '250px', height: '200px' },
  PolarChart:    { width: '250px', height: '200px' },
  Funnel:        { width: '250px', height: '200px' },
  Sankey:        { width: '300px', height: '200px' },
  TreeMap:       { width: '300px', height: '200px' },
  VectorMap:     { width: '300px', height: '200px' },
  Sparkline:     { width: '250px', height:  '60px' },
  Bullet:        { width: '250px', height:  '60px' },
  BarGauge:      { width: '250px', height: '200px' },
  LinearGauge:   { width: '100px', height: '220px' },
  CircularGauge: { width: '250px', height: '200px' },
  RangeSelector: { width: '300px', height: '200px' },
  PivotGrid:     { width: '400px', height: '250px' },

  // Editors — compact, inline-friendly
  TextBox:       { width: '250px', height:  '30px' },
  TextArea:      { width: '250px', height:  '80px' },
  NumberBox:     { width: '250px', height:  '30px' },
  CheckBox:      { width: '250px', height:  '30px' },
  SelectBox:     { width: '250px', height:  '30px' },
  TagBox:        { width: '250px', height:  '30px' },
  Lookup:        { width: '250px', height:  '30px' },
  Autocomplete:  { width: '250px', height:  '30px' },
  DropDownBox:   { width: '250px', height:  '30px' },
  DateBox:       { width: '250px', height:  '30px' },
  DateRangeBox:  { width: '300px', height:  '40px' },
  ColorBox:      { width: '250px', height:  '30px' },
  Slider:        { width: '250px', height:  '30px' },
  RangeSlider:   { width: '250px', height:  '30px' },
  Switch:        { width: '100px', height:  '36px' },
  RadioGroup:    { width: '250px', height: '100px' },
  ButtonGroup:   { width: '250px', height:  '36px' },
  Calendar:      { width: '260px', height: '240px' },
  HtmlEditor:    { width: '300px', height: '200px' },
  FileUploader:  { width: '300px', height: '100px' },
  Form:          { width: '300px', height: '200px' },

  // Scheduling
  Scheduler:     { width: '480px', height: '320px' },
  Gantt:         { width: '480px', height: '280px' },

  // Misc
  Button:        { width: '120px', height:  '36px' },
  Popup:         { width: '300px', height: '200px' },
};

const DEFAULT_WIDGET_SIZE = { width: '200px', height: '150px' };

function getWidgetDefaultSlot(widgetName) {
  const size = WIDGET_DEFAULT_SIZES[widgetName] || DEFAULT_WIDGET_SIZE;
  return { ...DEFAULT_SLOT, ...size, flexBasis: 'auto', flexGrow: 0, flexShrink: 0 };
}

const DEFAULT_COORD = {
  left: 0,
  top: 0,
  right: '',
  bottom: '',
  width: 150,
  height: 100,
  minWidth: '',
  maxWidth: '',
  minHeight: '',
  maxHeight: '',
  unit: 'px',
};

const CONTAINER_BASE_NAME = 'Container';

function getNextContainerName(containers) {
  // Collect all titles in the entire tree
  const allTitles = new Set();
  const collect = (nodes) => nodes.forEach(c => {
    allTitles.add(c.title);
    collect(c.children);
  });
  collect(containers);

  // Find the lowest available number
  let i = 1;
  while (true) {
    const candidate = `${CONTAINER_BASE_NAME}${String(i).padStart(2, '0')}`;
    if (!allTitles.has(candidate)) return candidate;
    i++;
  }
}

let nextContainerId = 2; // 1 is reserved for root
const ROOT_CONTAINER_ID = 1;

function makeContainer(parentId = null, name = 'Container') {
  return {
    id: nextContainerId++,
    title: name,
    parentId,
    children: [],
    layout: { ...DEFAULT_LAYOUT },
    slot: { ...DEFAULT_SLOT, flexGrow: 1, flexShrink: 1, width: '', height: '', flexBasis: '0' },    coord: { ...DEFAULT_COORD },
  };
}

function makeRootContainer() {
  return {
    id: ROOT_CONTAINER_ID,
    title: 'Page',
    parentId: null,
    children: [],
    layout: { ...DEFAULT_LAYOUT },
    slot: { ...DEFAULT_SLOT },
    coord: { ...DEFAULT_COORD },
    pageType: 'fit',
  };
}

function getLayoutStyle(layout) {
  if (!layout) return {};
  if (layout.layoutType === 'coordinate') {
    return { position: 'relative' };
  }
  if (layout.layoutType === 'grid') {
    return {
      display: 'grid',
      gridTemplateColumns: `repeat(${layout.gridColumns || 2}, 1fr)`,
      gridTemplateRows: `repeat(${layout.gridRows || 2}, 1fr)`,
      gap: layout.gridGap || '8px',
    };
  }
  return {
    display: 'flex',
    flexDirection: layout.flexDirection || 'row',
    flexWrap: layout.flexWrap === 'no wrap' ? 'nowrap' : (layout.flexWrap || 'nowrap'),
    justifyContent: layout.justifyContent || 'flex-start',
    alignItems: layout.alignItems || 'stretch',
  };
}

function getCoordStyle(coord) {
  if (!coord) return {};
  const u = coord.unit || 'px';
  const style = { position: 'absolute' };
  if (coord.left !== '' && coord.left !== undefined) style.left = `${coord.left}${u}`;
  if (coord.top !== '' && coord.top !== undefined) style.top = `${coord.top}${u}`;
  if (coord.right !== '' && coord.right !== undefined) style.right = `${coord.right}${u}`;
  if (coord.bottom !== '' && coord.bottom !== undefined) style.bottom = `${coord.bottom}${u}`;
  if (coord.width !== '' && coord.width !== undefined) style.width = `${coord.width}${u}`;
  if (coord.height !== '' && coord.height !== undefined) style.height = `${coord.height}${u}`;
  if (coord.minWidth !== '') style.minWidth = `${coord.minWidth}${u}`;
  if (coord.maxWidth !== '') style.maxWidth = `${coord.maxWidth}${u}`;
  if (coord.minHeight !== '') style.minHeight = `${coord.minHeight}${u}`;
  if (coord.maxHeight !== '') style.maxHeight = `${coord.maxHeight}${u}`;
  return style;
}

function getSlotStyle(slot) {
  if (!slot) return { card: {}, body: {} };
  const card = {
    flexGrow: slot.flexGrow ?? 0,
    flexShrink: slot.flexShrink ?? 1,
    flexBasis: slot.flexBasis || 'auto',
    alignSelf: slot.alignSelf || 'auto',
    order: slot.order || 0,
  };
  if (slot.width) card.width = slot.width;
  if (slot.minWidth) card.minWidth = slot.minWidth;
  if (slot.maxWidth) card.maxWidth = slot.maxWidth;
  if (slot.height) card.height = slot.height;
  if (slot.minHeight) card.minHeight = slot.minHeight;
  if (slot.maxHeight) card.maxHeight = slot.maxHeight;
  // Margin and border on the card (outer)
  if (slot.marginTop) card.marginTop = slot.marginTop;
  if (slot.marginBottom) card.marginBottom = slot.marginBottom;
  if (slot.marginLeft) card.marginLeft = slot.marginLeft;
  if (slot.marginRight) card.marginRight = slot.marginRight;
  if (slot.borderWidth) card.borderWidth = slot.borderWidth;
  if (slot.borderStyle) card.borderStyle = slot.borderStyle;
  if (slot.borderColor) card.borderColor = slot.borderColor;
  if (slot.borderRadius) card.borderRadius = slot.borderRadius;
  // Background on the card
  if (slot.backgroundColor) card.backgroundColor = slot.backgroundColor;
  if (slot.backgroundImage) card.backgroundImage = slot.backgroundImage;
  if (slot.backgroundSize) card.backgroundSize = slot.backgroundSize;
  if (slot.backgroundPosition) card.backgroundPosition = slot.backgroundPosition;
  if (slot.backgroundRepeat) card.backgroundRepeat = slot.backgroundRepeat;
  // Typography on the body (applies to content)
  const body = {};
  if (slot.paddingTop) body.paddingTop = slot.paddingTop;
  if (slot.paddingBottom) body.paddingBottom = slot.paddingBottom;
  if (slot.paddingLeft) body.paddingLeft = slot.paddingLeft;
  if (slot.paddingRight) body.paddingRight = slot.paddingRight;
  if (slot.color) body.color = slot.color;
  if (slot.fontSize) body.fontSize = slot.fontSize;
  if (slot.fontWeight) body.fontWeight = slot.fontWeight;
  if (slot.fontFamily) body.fontFamily = slot.fontFamily;
  if (slot.lineHeight) body.lineHeight = slot.lineHeight;
  if (slot.textAlign) body.textAlign = slot.textAlign;
  if (slot.letterSpacing) body.letterSpacing = slot.letterSpacing;
  return { card, body };
}

function getPageTypeStyle(pageType) {
  switch (pageType) {
    case 'fit':
      return { width: '100%', height: '100%', overflow: 'hidden', flexShrink: 0 };
    case 'fixed':
      return { overflow: 'auto' };
    case 'vertical fixed':
      return { width: '100%', overflowX: 'hidden', overflowY: 'auto' };
    case 'horizontal fixed':
      return { height: '100%', overflowY: 'hidden', overflowX: 'auto' };
    default:
      return { width: '100%', height: '100%', overflow: 'hidden' };
  }
}

function DropZone({ beforeId, parentId, dragState, onDragOver, onDrop, isDragging }) {
  const isActive = dragState.beforeId === beforeId && dragState.overParentId === parentId;
  return (
    <div
      className={`canvas-drop-zone${isActive ? ' canvas-drop-zone--active' : ''}`}
      onDragEnter={(e) => { e.preventDefault(); e.stopPropagation(); onDragOver(null, beforeId, parentId); }}
      onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); onDragOver(null, beforeId, parentId); }}
      onDrop={(e) => { e.preventDefault(); e.stopPropagation(); onDrop(null, beforeId); }}
    />
  );
}

function toHtmlId(title) {
  return title
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

function useResizeEdge(containerId, onUpdate, edge, isCoord) {
  return React.useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    const card = e.currentTarget.closest('.container-card');
    if (!card) return;
    const rect = card.getBoundingClientRect();
    const parentRect = card.parentElement?.getBoundingClientRect() || rect;
    const start = {
      x: e.clientX,
      y: e.clientY,
      w: rect.width,
      h: rect.height,
      left: rect.left - parentRect.left,
      top: rect.top - parentRect.top,
    };

    const onMouseMove = (e) => {
      const dx = e.clientX - start.x;
      const dy = e.clientY - start.y;
      const update = isCoord ? {} : { flexGrow: 0, flexShrink: 0 };

      if (edge === 'se') {
        isCoord
          ? Object.assign(update, { width: Math.max(40, Math.round(start.w + dx)), height: Math.max(40, Math.round(start.h + dy)) })
          : Object.assign(update, { width: `${Math.max(40, Math.round(start.w + dx))}px`, height: `${Math.max(40, Math.round(start.h + dy))}px` });
      } else if (edge === 'sw') {
        const newW = Math.max(40, Math.round(start.w - dx));
        const newH = Math.max(40, Math.round(start.h + dy));
        isCoord
          ? Object.assign(update, { width: newW, height: newH, left: Math.max(0, Math.round(start.left + dx)) })
          : Object.assign(update, { width: `${newW}px`, height: `${newH}px` });
      } else if (edge === 'ne') {
        const newW = Math.max(40, Math.round(start.w + dx));
        const newH = Math.max(40, Math.round(start.h - dy));
        isCoord
          ? Object.assign(update, { width: newW, height: newH, top: Math.max(0, Math.round(start.top + dy)) })
          : Object.assign(update, { width: `${newW}px`, height: `${newH}px` });
      } else if (edge === 'nw') {
        const newW = Math.max(40, Math.round(start.w - dx));
        const newH = Math.max(40, Math.round(start.h - dy));
        isCoord
          ? Object.assign(update, { width: newW, height: newH, left: Math.max(0, Math.round(start.left + dx)), top: Math.max(0, Math.round(start.top + dy)) })
          : Object.assign(update, { width: `${newW}px`, height: `${newH}px` });
      } else if (edge === 'e') {
        isCoord ? (update.width = Math.max(40, Math.round(start.w + dx))) : (update.width = `${Math.max(40, Math.round(start.w + dx))}px`);
      } else if (edge === 'w') {
        const newW = Math.max(40, Math.round(start.w - dx));
        isCoord
          ? Object.assign(update, { width: newW, left: Math.max(0, Math.round(start.left + dx)) })
          : (update.width = `${newW}px`);
      } else if (edge === 's') {
        isCoord ? (update.height = Math.max(40, Math.round(start.h + dy))) : (update.height = `${Math.max(40, Math.round(start.h + dy))}px`);
      } else if (edge === 'n') {
        const newH = Math.max(40, Math.round(start.h - dy));
        isCoord
          ? Object.assign(update, { height: newH, top: Math.max(0, Math.round(start.top + dy)) })
          : (update.height = `${newH}px`);
      }
      onUpdate(containerId, update);
    };

    const onMouseUp = () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  }, [containerId, onUpdate, edge, isCoord]);
}

function ContainerCard({ container, selectedIds, onSelect, onDelete, onDragStart, onDragOver, onDrop, onWidgetDrop, onUpdateLayout, onUpdateSlot, onUpdateCoord, onGridCellDrop, onSetSelectedGridCell, onMergeCellContainers, selectedGridCell, parentLayout, childIndex, dragState, draggingId, isDragging, coordMode, activeTierId, depth = 0 }) {
  const isSelected = selectedIds ? selectedIds.includes(container.id) : false;
  const isMultiSelected = selectedIds && selectedIds.length > 1 && isSelected;
  const isRoot = container.id === ROOT_CONTAINER_ID;
  const isDragOver = dragState.overId === container.id;
  const htmlId = toHtmlId(container.title);
  const isCoordChild = parentLayout?.layoutType === 'coordinate';

  // Apply breakpoint visibility override
  const isHiddenAtTier = activeTierId && activeTierId !== BASE_TIER_ID
    && (container.breakpointOverrides?.[activeTierId]?.hidden ?? false);

  // Coord drag state — must be declared before any conditional return
  const coordDragRef = React.useRef(null);

  const onCoordMouseDown = React.useCallback((e) => {
    if (!isCoordChild) return;
    if (e.target.closest('.resize-handle')) return;
    // If the mousedown came from a nested child card, let it handle itself
    const targetCard = e.target.closest('.container-card');
    if (targetCard && targetCard !== e.currentTarget) return;

    // Alt key OR reparent mode = skip reposition, let drag handle it
    if (e.altKey || coordMode === 'reparent') return;
    e.preventDefault();
    e.stopPropagation();
    const coord = container.coord || DEFAULT_COORD;
    coordDragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      origLeft: coord.left,
      origTop: coord.top,
    };
    const onMouseMove = (e) => {
      if (!coordDragRef.current) return;
      const dx = e.clientX - coordDragRef.current.startX;
      const dy = e.clientY - coordDragRef.current.startY;
      onUpdateCoord(container.id, {
        left: Math.max(0, Math.round(coordDragRef.current.origLeft + dx)),
        top: Math.max(0, Math.round(coordDragRef.current.origTop + dy)),
      });
    };
    const onMouseUp = () => {
      coordDragRef.current = null;
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  }, [isCoordChild, container, onUpdateCoord]);

  // Apply breakpoint slot overrides for preview
  const effectiveSlot = (activeTierId && activeTierId !== BASE_TIER_ID && container.breakpointOverrides?.[activeTierId]?.slot)
    ? { ...container.slot, ...container.breakpointOverrides[activeTierId].slot }
    : container.slot;

  const coordStyle = isCoordChild
    ? { ...getCoordStyle(container.coord || DEFAULT_COORD), zIndex: (childIndex ?? 0) + 1 }
    : null;

  const slotStyles = isRoot
    ? { card: getPageTypeStyle(container.pageType || 'fit'), body: {} }
    : isCoordChild
      ? { card: coordStyle, body: {} }
      : getSlotStyle(effectiveSlot);

  const cardStyle = slotStyles.card;
  const bodyPaddingStyle = slotStyles.body;
  const layoutStyle = getLayoutStyle(container.layout);
  const onUpdate = isCoordChild ? onUpdateCoord : onUpdateSlot;
  const rNW = useResizeEdge(container.id, onUpdate, 'nw', isCoordChild);
  const rNE = useResizeEdge(container.id, onUpdate, 'ne', isCoordChild);
  const rSW = useResizeEdge(container.id, onUpdate, 'sw', isCoordChild);
  const rSE = useResizeEdge(container.id, onUpdate, 'se', isCoordChild);
  const rN  = useResizeEdge(container.id, onUpdate, 'n',  isCoordChild);
  const rS  = useResizeEdge(container.id, onUpdate, 's',  isCoordChild);
  const rW  = useResizeEdge(container.id, onUpdate, 'w',  isCoordChild);
  const rE  = useResizeEdge(container.id, onUpdate, 'e',  isCoordChild);

  // Early return AFTER all hooks
  if (isHiddenAtTier && !isSelected) return null;

  return (
    <div
      id={htmlId}
      className={`container-card${isSelected && !isMultiSelected ? ' container-card--selected' : ''}${isMultiSelected ? ' container-card--multi-selected' : ''}${isDragOver ? ' container-card--drag-over' : ''}${container.isWidget ? ' container-card--widget' : ''}${isCoordChild ? ' container-card--coord' : ''}`}
      style={cardStyle}
      draggable={!isRoot}
      onDragStart={!isRoot ? (e) => {
        // Only drag this card if the drag started on THIS card, not a nested child
        if (e.target.closest('.container-card') !== e.currentTarget) return;
        // In coord mode, only allow reparent drag when Alt is held or reparent mode is active
        if (isCoordChild && !e.altKey && coordMode !== 'reparent') { e.preventDefault(); return; }
        e.stopPropagation();
        onDragStart(container.id, container.parentId);
      } : undefined}
      onMouseDown={isCoordChild ? onCoordMouseDown : undefined}
      onClick={(e) => { e.stopPropagation(); onSelect(container.id, e); }}
      onDragOver={!container.isWidget ? (e) => { e.preventDefault(); e.stopPropagation(); onDragOver(container.id, null, null); } : undefined}
      onDrop={!container.isWidget ? (e) => {
        e.preventDefault(); e.stopPropagation();
        const widgetName = e.dataTransfer.getData('dx-widget-name');
        if (widgetName) {
          onWidgetDrop(container.id, widgetName);
        } else {
          onDrop(container.id, null);
        }
      } : undefined}
      onDragLeave={(e) => { e.stopPropagation(); }}
    >
      <div className="container-card-body" style={{ ...layoutStyle, ...bodyPaddingStyle, minHeight: 0, flex: 1, overflow: 'auto', position: 'relative' }}>
        {container.layout?.layoutType === 'grid' ? (() => {
          const cols = container.layout.gridColumns || 2;
          const rows = container.layout.gridRows || 2;
          const cells = container.layout.gridCells || buildDefaultCells(cols, rows);
          return (
            <>
              <GridEditor layout={container.layout} onUpdateLayout={(update) => onUpdateLayout(container.id, update)} onMergeCellContainers={onMergeCellContainers} />
              {cells.map((cell, cellIdx) => {
                const cellChildIds = cell.childIds || (cell.childId != null ? [cell.childId] : []);
                const cellChildren = cellChildIds.map(id => container.children.find(c => c.id === id)).filter(Boolean);
                const isEmpty = cellChildren.length === 0;
                return (
                  <div
                    key={cell.id}
                    className={`grid-cell-slot${selectedGridCell?.containerId === container.id && selectedGridCell?.cellIdx === cellIdx ? ' grid-cell-slot--selected' : ''}`}
                    style={{ gridColumn: `${cell.colStart} / ${cell.colEnd}`, gridRow: `${cell.rowStart} / ${cell.rowEnd}`, position: 'relative', minHeight: 0, minWidth: 0, overflow: cellChildren.length > 1 ? 'auto' : 'hidden', display: 'flex', flexDirection: 'column' }}
                    onClick={(e) => {
                      if (isEmpty) {
                        e.stopPropagation();
                        onSelect(null, e); // clear container selection
                        if (onSetSelectedGridCell) onSetSelectedGridCell({ containerId: container.id, cellIdx });
                      }
                    }}
                    onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); e.currentTarget.classList.add('grid-cell-slot--over'); }}
                    onDragLeave={(e) => { e.currentTarget.classList.remove('grid-cell-slot--over'); }}
                    onDrop={(e) => {
                      e.preventDefault(); e.stopPropagation();
                      e.currentTarget.classList.remove('grid-cell-slot--over');
                      const wName = e.dataTransfer.getData('dx-widget-name');
                      if (onGridCellDrop) onGridCellDrop(container.id, cellIdx, wName || null, draggingId, cellChildIds);
                    }}
                  >
                    {cellChildren.map((child, ci) => (
                      <ContainerCard
                        key={child.id}
                        container={child}
                        selectedIds={selectedIds}
                        onSelect={onSelect}
                        onDelete={onDelete}
                        onDragStart={onDragStart}
                        onDragOver={onDragOver}
                        onDrop={onDrop}
                        onWidgetDrop={onWidgetDrop}
                        onUpdateLayout={onUpdateLayout}
                        onUpdateSlot={onUpdateSlot}
                        onUpdateCoord={onUpdateCoord}
                        onGridCellDrop={onGridCellDrop}
                        onSetSelectedGridCell={onSetSelectedGridCell}
                        onMergeCellContainers={onMergeCellContainers}
                        selectedGridCell={selectedGridCell}
                        parentLayout={container.layout}
                        childIndex={ci}
                        dragState={dragState}
                        draggingId={draggingId}
                        isDragging={isDragging}
                        coordMode={coordMode}
                        activeTierId={activeTierId}
                        depth={depth + 1}
                      />
                    ))}
                  </div>
                );
              })}
            </>
          );
        })() : container.isWidget && container.children.length === 0 ? (
          <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
            <WidgetPreview
              widgetName={container.widgetName || container.title}
              widgetProps={container.widgetProps || {}}
            />
          </div>
        ) : container.children.length === 0 ? (
          <>
            {container.layout?.layoutType !== 'coordinate' && container.layout?.layoutType !== 'grid' && (
              <DropZone beforeId={null} parentId={container.id} dragState={dragState} onDragOver={onDragOver} onDrop={onDrop} isDragging={isDragging} />
            )}
            <div className="widget-placeholder">
              <i className="dx-icon-dropzone widget-placeholder-icon" />
            </div>
          </>
        ) : (
          <>
            {container.layout?.layoutType !== 'coordinate' && container.layout?.layoutType !== 'grid' && (
              <DropZone beforeId={container.children[0].id} parentId={container.id} dragState={dragState} onDragOver={onDragOver} onDrop={onDrop} isDragging={isDragging} />
            )}
            {container.children.map((child, idx) => (
              <React.Fragment key={child.id}>
                <ContainerCard
                  container={child}
                  selectedIds={selectedIds}
                  onSelect={onSelect}
                  onDelete={onDelete}
                  onDragStart={onDragStart}
                  onDragOver={onDragOver}
                  onDrop={onDrop}
                  onWidgetDrop={onWidgetDrop}
                  onUpdateLayout={onUpdateLayout}
                  onUpdateSlot={onUpdateSlot}
                  onUpdateCoord={onUpdateCoord}
                  onGridCellDrop={onGridCellDrop}
                  onSetSelectedGridCell={onSetSelectedGridCell}
                  onMergeCellContainers={onMergeCellContainers}
                  selectedGridCell={selectedGridCell}
                  parentLayout={container.layout}
                  childIndex={idx}
                  dragState={dragState}
                  draggingId={draggingId}
                  isDragging={isDragging}
                  coordMode={coordMode}
                  activeTierId={activeTierId}
                  depth={depth + 1}
                />
                {container.layout?.layoutType !== 'coordinate' && container.layout?.layoutType !== 'grid' && (
                  <DropZone
                    beforeId={idx < container.children.length - 1 ? container.children[idx + 1].id : null}
                    parentId={container.id}
                    dragState={dragState}
                    onDragOver={onDragOver}
                    onDrop={onDrop}
                    isDragging={isDragging}
                  />
                )}
              </React.Fragment>
            ))}
          </>
        )}
      </div>
      {isSelected && !isRoot && (
        <>
          <div className="resize-handle resize-handle--nw" onMouseDown={rNW} />
          <div className="resize-handle resize-handle--ne" onMouseDown={rNE} />
          <div className="resize-handle resize-handle--sw" onMouseDown={rSW} />
          <div className="resize-handle resize-handle--se" onMouseDown={rSE} />
          <div className="resize-handle resize-handle--n" onMouseDown={rN} />
          <div className="resize-handle resize-handle--s" onMouseDown={rS} />
          <div className="resize-handle resize-handle--w" onMouseDown={rW} />
          <div className="resize-handle resize-handle--e" onMouseDown={rE} />
        </>
      )}
    </div>
  );
}
function isDescendant(containers, ancestorId, potentialDescendantId) {
  const ancestor = findContainerById(containers, ancestorId);
  if (!ancestor) return false;
  if (ancestor.id === potentialDescendantId) return true;
  return ancestor.children.some(child =>
    child.id === potentialDescendantId ||
    isDescendant(ancestor.children, child.id, potentialDescendantId)
  );
}

// Remove a container from the tree and return it + the modified tree
function extractFromTree(containers, id) {
  let extracted = null;
  const remaining = containers
    .filter(c => {
      if (c.id === id) { extracted = c; return false; }
      return true;
    })
    .map(c => {
      if (!extracted) {
        const result = extractFromTree(c.children, id);
        extracted = result.extracted;
        return { ...c, children: result.remaining };
      }
      return c;
    });
  return { extracted, remaining };
}

function addChildToTree(containers, parentId, newContainer) {
  return containers.map(c => {
    if (c.id === parentId) return { ...c, children: [...c.children, { ...newContainer, parentId }] };
    return { ...c, children: addChildToTree(c.children, parentId, newContainer) };
  });
}

function findContainerById(containers, id) {
  for (const c of containers) {
    if (c.id === id) return c;
    const found = findContainerById(c.children, id);
    if (found) return found;
  }
  return null;
}

function updatePageTypeInTree(containers, id, pageType) {
  return containers.map(c => {
    if (c.id === id) return { ...c, pageType };
    return { ...c, children: updatePageTypeInTree(c.children, id, pageType) };
  });
}

function updateWidgetPropsInTree(containers, id, widgetProps) {
  return containers.map(c => {
    if (c.id === id) return { ...c, widgetProps: { ...c.widgetProps, ...widgetProps } };
    return { ...c, children: updateWidgetPropsInTree(c.children, id, widgetProps) };
  });
}

function deepCloneWithNewIds(container, newParentId) {
  const newId = nextContainerId++;
  const clonedChildren = container.children.map(child => deepCloneWithNewIds(child, newId));

  // Remap gridCells childIds to the new cloned children IDs
  let newLayout = { ...container.layout };
  if (container.layout?.gridCells) {
    const oldToNew = {};
    container.children.forEach((child, i) => { oldToNew[child.id] = clonedChildren[i].id; });
    newLayout.gridCells = container.layout.gridCells.map(cell => ({
      ...cell,
      childIds: (cell.childIds || (cell.childId != null ? [cell.childId] : [])).map(id => oldToNew[id]).filter(Boolean),
    }));
  }

  return {
    ...container,
    id: newId,
    parentId: newParentId,
    layout: newLayout,
    slot: { ...container.slot },
    coord: { ...container.coord },
    widgetProps: container.widgetProps ? { ...container.widgetProps } : undefined,
    children: clonedChildren,
  };
}

function updateCoordInTree(containers, id, coord) {
  return containers.map(c => {
    if (c.id === id) return { ...c, coord: { ...c.coord, ...coord } };
    return { ...c, children: updateCoordInTree(c.children, id, coord) };
  });
}

function updateSlotInTree(containers, id, slot) {
  return containers.map(c => {
    if (c.id === id) return { ...c, slot: { ...c.slot, ...slot } };
    return { ...c, children: updateSlotInTree(c.children, id, slot) };
  });
}

function updateLayoutInTree(containers, id, layout) {
  return containers.map(c => {
    if (c.id === id) return { ...c, layout: { ...c.layout, ...layout } };
    return { ...c, children: updateLayoutInTree(c.children, id, layout) };
  });
}

function renameInTree(containers, id, title) {
  return containers.map(c => {
    if (c.id === id) return { ...c, title };
    return { ...c, children: renameInTree(c.children, id, title) };
  });
}

function deleteFromTree(containers, id) {
  return containers
    .filter(c => c.id !== id)
    .map(c => ({ ...c, children: deleteFromTree(c.children, id) }));
}


function PageVisualsTreeNode({ node, depth, selectedId, onSelect, dragState, onDragStart, onDragOver, onDrop, onDragEnd, parentLayout, childIndex }) {
  const [expanded, setExpanded] = useState(true);
  const isSelected = selectedId === node.id;
  const isDragOver = dragState.overId === node.id;
  const isDragBefore = dragState.beforeId === node.id;
  const isRoot = node.id === ROOT_CONTAINER_ID;
  const indent = depth * 16;
  const isCoordChild = parentLayout?.layoutType === 'coordinate';

  return (
    <div className="pvt-node-wrapper">
      {/* Drop zone: before this node */}
      {!isRoot && (
        <div
          className={`pvt-drop-between${isDragBefore ? ' pvt-drop-between--active' : ''}`}
          style={{ marginLeft: indent }}
          onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); onDragOver(null, node.id); }}
          onDrop={(e) => { e.preventDefault(); e.stopPropagation(); onDrop(null, node.id); }}
        />
      )}

      {/* The node row */}
      <div
        className={`pvt-node${isSelected ? ' pvt-node--selected' : ''}${isDragOver ? ' pvt-node--drag-over' : ''}`}
        style={{ paddingLeft: indent + 4 }}
        onClick={(e) => { e.stopPropagation(); onSelect(node.id); }}
        onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); if (!node.isWidget) onDragOver(node.id, null); }}
        onDrop={(e) => { e.preventDefault(); e.stopPropagation(); if (!node.isWidget) onDrop(node.id, null); }}
      >
        {/* Expand/collapse arrow */}
        <span
          className="pvt-arrow"
          onClick={(e) => { e.stopPropagation(); setExpanded(x => !x); }}
          style={{ visibility: node.children?.length > 0 ? 'visible' : 'hidden' }}
        >
          {expanded ? '▾' : '▸'}
        </span>

        {/* Drag handle */}
        {!isRoot && (
          <span
            className="pvt-drag-handle"
            draggable
            onDragStart={(e) => { e.stopPropagation(); onDragStart(node.id); }}
            onDragEnd={onDragEnd}
          >⠿</span>
        )}

        <span className="pvt-label">{node.title}</span>
        {isCoordChild && (
          <span className="pvt-z-badge" title="Z-order (drag to reorder)">z{childIndex + 1}</span>
        )}
      </div>

      {/* Children */}
      {expanded && node.children?.length > 0 && (
        <div className="pvt-children">
          {node.children.map((child, cidx) => (
            <PageVisualsTreeNode
              key={child.id}
              node={child}
              depth={depth + 1}
              selectedId={selectedId}
              onSelect={onSelect}
              dragState={dragState}
              onDragStart={onDragStart}
              onDragOver={onDragOver}
              onDrop={onDrop}
              onDragEnd={onDragEnd}
              parentLayout={node.layout}
              childIndex={cidx}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function PageVisualsTabWrapper({ containers, selectedContainerId, onSelect, onReparent }) {
  const [dragState, setDragState] = useState({ draggingId: null, overId: null, beforeId: null });

  const handleDragStart = (id) => {
    setDragState({ draggingId: id, overId: null, beforeId: null });
  };

  const handleDragOver = (overId, beforeId) => {
    const { draggingId } = dragState;
    if (!draggingId) return;
    if (overId && (overId === draggingId || isDescendant(containers, draggingId, overId))) return;
    // Block dropping onto a widget
    if (overId) {
      const target = findContainerById(containers, overId);
      if (target?.isWidget) return;
    }
    setDragState(s => ({ ...s, overId, beforeId }));
  };

  const handleDrop = (overId, beforeId) => {
    const { draggingId } = dragState;
    setDragState({ draggingId: null, overId: null, beforeId: null });
    if (!draggingId) return;
    if (overId && (overId === draggingId || isDescendant(containers, draggingId, overId))) return;
    // Block dropping onto a widget
    if (overId) {
      const target = findContainerById(containers, overId);
      if (target?.isWidget) return;
    }
    onReparent(draggingId, overId, beforeId);
  };

  const handleDragEnd = () => {
    setDragState({ draggingId: null, overId: null, beforeId: null });
  };

  return (
    <div className="pvt-root">
      {containers.map(node => (
        <PageVisualsTreeNode
          key={node.id}
          node={node}
          depth={0}
          selectedId={selectedContainerId}
          onSelect={onSelect}
          dragState={dragState}
          onDragStart={handleDragStart}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          onDragEnd={handleDragEnd}
        />
      ))}
    </div>
  );
}

function HierarchyTree({ dataSource, keyExpr = 'id', parentIdExpr = 'parentId', displayExpr = 'name', itemRender, selectedId, onSelect, onItemDblClick }) {
  const [internalSelectedId, setInternalSelectedId] = useState(selectedId ?? null);
  const treeRef = React.useRef(null);

  React.useEffect(() => {
    if (selectedId !== undefined) {
      setInternalSelectedId(selectedId);
      const instance = treeRef.current?.instance?.();
      if (instance) {
        instance.unselectAll();
        if (selectedId) instance.selectItem(selectedId);
      }
    }
  }, [selectedId]);

  const effectiveOnSelect = (id) => {
    setInternalSelectedId(id);
    if (onSelect) onSelect(id);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <TreeView
        ref={treeRef}
        dataSource={dataSource}
        dataStructure="plain"
        keyExpr={keyExpr}
        parentIdExpr={parentIdExpr}
        displayExpr={displayExpr}
        itemRender={itemRender}
        selectionMode="single"
        selectByClick={true}
        selectNodesRecursive={false}
        expandAllEnabled={true}
        defaultExpandAll={true}
        selectedItemKeys={internalSelectedId ? [internalSelectedId] : []}
        onItemSelectionChanged={(e) => {
          const selected = e.component.getSelectedNodes();
          effectiveOnSelect(selected.length > 0 ? selected[0].key : null);
        }}
        onItemDblClick={onItemDblClick ? (e) => onItemDblClick(e.itemData) : undefined}
      />
    </div>
  );
}

// Map widget names to their components and sample data
// To swap sample data: update widgetSampleData.js
const WIDGET_COMPONENT_MAP = {
  DataGrid:      (props) => <DataGrid {...props} />,
  TreeList:      (props) => <TreeList {...props} />,
  List:          (props) => <List {...props} />,
  TreeView:      (props) => <TreeView {...props} />,
  Gallery:       (props) => <Gallery {...props} />,
  Chart:         (props) => <Chart {...props} />,
  PieChart:      (props) => <PieChart {...props} />,
  PolarChart:    (props) => <PolarChart {...props} />,
  Funnel:        (props) => <Funnel {...props} />,
  Sankey:        (props) => <Sankey {...props} />,
  TreeMap:       (props) => <TreeMap {...props} />,
  Sparkline:     (props) => <Sparkline {...props} />,
  Bullet:        (props) => <Bullet {...props} />,
  BarGauge:      (props) => <BarGauge {...props} />,
  LinearGauge:   (props) => <LinearGauge {...props} />,
  CircularGauge: (props) => <CircularGauge {...props} />,
  RangeSelector: (props) => <RangeSelector {...props} />,
  PivotGrid:     (props) => <PivotGrid {...props} />,
  TextBox:       (props) => <TextBox {...props} />,
  TextArea:      (props) => <TextArea {...props} />,
  NumberBox:     (props) => <NumberBox {...props} />,
  CheckBox:      (props) => <CheckBox {...props} />,
  SelectBox:     (props) => <SelectBox {...props} />,
  TagBox:        (props) => <TagBox {...props} />,
  Lookup:        (props) => <Lookup {...props} />,
  Autocomplete:  (props) => <Autocomplete {...props} />,
  DropDownBox:   (props) => <DropDownBox {...props} />,
  DateBox:       (props) => <DateBox {...props} />,
  DateRangeBox:  (props) => <DateRangeBox {...props} />,
  ColorBox:      (props) => <ColorBox {...props} />,
  Slider:        (props) => <Slider {...props} />,
  RangeSlider:   (props) => <RangeSlider {...props} />,
  Switch:        (props) => <Switch {...props} />,
  RadioGroup:    (props) => <RadioGroup {...props} />,
  ButtonGroup:   (props) => <ButtonGroup {...props} />,
  Calendar:      (props) => <Calendar {...props} />,
  HtmlEditor:    (props) => <HtmlEditor {...props} />,
  FileUploader:  (props) => <FileUploader {...props} />,
  Form:          (props) => <Form {...props} />,
  Scheduler:     (props) => <Scheduler {...props} />,
  Gantt:         (props) => <Gantt {...props} />,
};

function WidgetPreview({ widgetName, widgetProps, style }) {
  const renderFn = WIDGET_COMPONENT_MAP[widgetName];
  if (!renderFn) {
    return (
      <div className="widget-placeholder">
        <i className="dx-icon-datapie widget-placeholder-icon" />
      </div>
    );
  }
  const sampleData = WIDGET_SAMPLE_DATA[widgetName] || {};
  const mergedProps = { ...sampleData, ...widgetProps, width: '100%', height: '100%' };
  return (
    <div style={{ display: 'flex', flexDirection: 'column', width: '100%', height: '100%', minHeight: 0, flex: 1, ...style }}>
      {renderFn(mergedProps)}
    </div>
  );
}

function migrateGridCells(oldCells, oldCols, oldRows, newCols, newRows) {
  const newCells = buildDefaultCells(newCols, newRows);

  // For each old cell, find the best matching new cell and transfer childIds
  oldCells.forEach(oldCell => {
    const childIds = oldCell.childIds || (oldCell.childId != null ? [oldCell.childId] : []);
    if (childIds.length === 0) return;

    // Clamp the old cell's position to the new grid bounds
    const clampedColStart = Math.min(oldCell.colStart, newCols);
    const clampedRowStart = Math.min(oldCell.rowStart, newRows);

    // Find the new cell that contains this position
    const targetCell = newCells.find(c =>
      c.colStart <= clampedColStart && c.colEnd > clampedColStart &&
      c.rowStart <= clampedRowStart && c.rowEnd > clampedRowStart
    );

    if (targetCell) {
      targetCell.childIds = [...(targetCell.childIds || []), ...childIds];
    } else {
      // Fallback: add to last cell if position is completely out of bounds
      if (newCells.length > 0) {
        newCells[newCells.length - 1].childIds = [
          ...(newCells[newCells.length - 1].childIds || []),
          ...childIds
        ];
      }
    }
  });

  return newCells;
}

function buildDefaultCells(cols, rows) {
  const cells = [];
  for (let r = 1; r <= rows; r++) {
    for (let c = 1; c <= cols; c++) {
      cells.push({ id: `${r}-${c}`, colStart: c, colEnd: c + 1, rowStart: r, rowEnd: r + 1, childIds: [] });
    }
  }
  return cells;
}

function GridEditor({ layout, onUpdateLayout, onMergeCellContainers }) {
  const cols = layout.gridColumns || 2;
  const rows = layout.gridRows || 2;
  const cells = layout.gridCells || buildDefaultCells(cols, rows);
  const mergeDir = layout.gridMergeDirection || 'horizontal';

  const mergeAtPoint = (axis, colLine, rowLine) => {
    const updated = cells.map(c => ({ ...c }));
    if (axis === 'col') {
      const lc = updated.find(c => c.colEnd === colLine && c.rowStart === rowLine);
      const rc = lc ? updated.find(c => c.colStart === colLine && c.rowStart === lc.rowStart && c.rowEnd === lc.rowEnd) : null;
      if (lc && rc) {
        const absorbedIds = rc.childIds || [];
        lc.colEnd = rc.colEnd;
        lc.childIds = [...(lc.childIds||[]), ...absorbedIds];
        updated.splice(updated.indexOf(rc), 1);
        onUpdateLayout({ gridCells: updated });
        if (onMergeCellContainers && absorbedIds.length > 0) {
          const survivingIds = lc.childIds.filter(id => !absorbedIds.includes(id));
          if (survivingIds.length > 0) onMergeCellContainers(survivingIds[0], absorbedIds);
        }
      }
    } else {
      const tc = updated.find(c => c.rowEnd === rowLine && c.colStart === colLine);
      const bc = tc ? updated.find(c => c.rowStart === rowLine && c.colStart === tc.colStart && c.colEnd === tc.colEnd) : null;
      if (tc && bc) {
        const absorbedIds = bc.childIds || [];
        tc.rowEnd = bc.rowEnd;
        tc.childIds = [...(tc.childIds||[]), ...absorbedIds];
        updated.splice(updated.indexOf(bc), 1);
        onUpdateLayout({ gridCells: updated });
        if (onMergeCellContainers && absorbedIds.length > 0) {
          const survivingIds = tc.childIds.filter(id => !absorbedIds.includes(id));
          if (survivingIds.length > 0) onMergeCellContainers(survivingIds[0], absorbedIds);
        }
      }
    }
  };

  const resetCells = () => onUpdateLayout({ gridCells: null });

  const colBoundaryExists = (colLine, rowStart) => cells.some(c => c.colEnd === colLine && c.rowStart === rowStart);
  const rowBoundaryExists = (rowLine, colStart) => cells.some(c => c.rowEnd === rowLine && c.colStart === colStart);
  const SOLID = '1px solid rgba(180,180,180,0.5)';
  const DASH_COLOR = 'rgba(160,160,160,0.6)';
  const DASH_HOVER = '#0078d4';

  // Renders one divider segment — solid if not mergeable in current direction, dashed if it is
  const VSegment = ({ ci, ri }) => {
    const colLine = ci + 2;
    const rowStart = ri + 1;
    const exists = colBoundaryExists(colLine, rowStart);
    if (!exists) return null;
    const canMerge = mergeDir === 'horizontal';
    const colPct = ((ci + 1) / cols) * 100;
    const rowPct = (ri / rows) * 100;
    const heightPct = (1 / rows) * 100;
    if (!canMerge) {
      return (
        <div key={`vd-${ci}-${ri}`} style={{ position: 'absolute', top: `${rowPct}%`, height: `${heightPct}%`, left: `calc(${colPct}% - 0.5px)`, width: 1, background: 'rgba(180,180,180,0.5)', pointerEvents: 'none', zIndex: 1 }} />
      );
    }
    return (
      <div key={`vd-${ci}-${ri}`} title="Click to merge"
        style={{ position: 'absolute', top: `${rowPct}%`, height: `${heightPct}%`, left: `calc(${colPct}% - 4px)`, width: 8, cursor: 'col-resize', zIndex: 2, pointerEvents: 'all', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
        onClick={(e) => { e.stopPropagation(); mergeAtPoint('col', colLine, rowStart); }}
      >
        <div className="grid-divider-v"
          style={{ width: 1, height: '100%', backgroundImage: `repeating-linear-gradient(to bottom, ${DASH_COLOR} 0px, ${DASH_COLOR} 4px, transparent 4px, transparent 8px)`, transition: 'background-image 0.12s' }}
          onMouseEnter={e => { e.currentTarget.style.backgroundImage = `repeating-linear-gradient(to bottom, ${DASH_HOVER} 0px, ${DASH_HOVER} 4px, transparent 4px, transparent 8px)`; e.currentTarget.style.width = '2px'; }}
          onMouseLeave={e => { e.currentTarget.style.backgroundImage = `repeating-linear-gradient(to bottom, ${DASH_COLOR} 0px, ${DASH_COLOR} 4px, transparent 4px, transparent 8px)`; e.currentTarget.style.width = '1px'; }}
        />
      </div>
    );
  };

  const HSegment = ({ ci, ri }) => {
    const rowLine = ri + 2;
    const colStart = ci + 1;
    const exists = rowBoundaryExists(rowLine, colStart);
    if (!exists) return null;
    const canMerge = mergeDir === 'vertical';
    const rowPct = ((ri + 1) / rows) * 100;
    const colPct = (ci / cols) * 100;
    const widthPct = (1 / cols) * 100;
    if (!canMerge) {
      return (
        <div key={`hd-${ri}-${ci}`} style={{ position: 'absolute', left: `${colPct}%`, width: `${widthPct}%`, top: `calc(${rowPct}% - 0.5px)`, height: 1, background: 'rgba(180,180,180,0.5)', pointerEvents: 'none', zIndex: 1 }} />
      );
    }
    return (
      <div key={`hd-${ri}-${ci}`} title="Click to merge"
        style={{ position: 'absolute', left: `${colPct}%`, width: `${widthPct}%`, top: `calc(${rowPct}% - 4px)`, height: 8, cursor: 'row-resize', zIndex: 2, pointerEvents: 'all', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
        onClick={(e) => { e.stopPropagation(); mergeAtPoint('row', colStart, rowLine); }}
      >
        <div className="grid-divider-h"
          style={{ height: 1, width: '100%', backgroundImage: `repeating-linear-gradient(to right, ${DASH_COLOR} 0px, ${DASH_COLOR} 4px, transparent 4px, transparent 8px)`, transition: 'background-image 0.12s' }}
          onMouseEnter={e => { e.currentTarget.style.backgroundImage = `repeating-linear-gradient(to right, ${DASH_HOVER} 0px, ${DASH_HOVER} 4px, transparent 4px, transparent 8px)`; e.currentTarget.style.height = '2px'; }}
          onMouseLeave={e => { e.currentTarget.style.backgroundImage = `repeating-linear-gradient(to right, ${DASH_COLOR} 0px, ${DASH_COLOR} 4px, transparent 4px, transparent 8px)`; e.currentTarget.style.height = '1px'; }}
        />
      </div>
    );
  };

  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 1 }}>
      {/* All vertical dividers */}
      {Array.from({ length: cols - 1 }, (_, ci) =>
        Array.from({ length: rows }, (_, ri) => <VSegment key={`v-${ci}-${ri}`} ci={ci} ri={ri} />)
      )}
      {/* All horizontal dividers */}
      {Array.from({ length: rows - 1 }, (_, ri) =>
        Array.from({ length: cols }, (_, ci) => <HSegment key={`h-${ri}-${ci}`} ci={ci} ri={ri} />)
      )}
      {layout.gridCells && (
        <div title="Reset all merges" onClick={(e) => { e.stopPropagation(); resetCells(); }}
          style={{ position: 'absolute', top: 4, right: 4, fontSize: 10, color: '#0078d4', cursor: 'pointer', background: 'rgba(255,255,255,0.85)', padding: '1px 5px', borderRadius: 3, border: '1px solid #0078d4', zIndex: 3, pointerEvents: 'all' }}>
          reset
        </div>
      )}
    </div>
  );
}

function DevicePicker({ activeDeviceId, activeTierId, customWidth, customHeight, onDeviceSelect, onCustomChange, open, onToggle }) {
  const activeDevice = getDeviceById(activeDeviceId);
  const activeTier = getTierById(activeTierId);

  return (
    <div style={{ position: 'relative', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
      {/* Tier badge */}
      {activeTier && (
        <span style={{ fontSize: 10, padding: '2px 6px', borderRadius: 10, background: activeTier.color, color: '#fff', fontWeight: 600, whiteSpace: 'nowrap' }}>
          {activeTier.icon} {activeTier.label}
        </span>
      )}

      {/* Device button */}
      <button
        className="focus-mode-btn"
        onClick={onToggle}
        style={{ display: 'flex', alignItems: 'center', gap: 4, minWidth: 120 }}
      >
        <span>{activeDevice?.label || 'Select Device'}</span>
        <span style={{ fontSize: 10, color: '#999' }}>
          {activeDeviceId === 'custom'
            ? `${customWidth}×${customHeight}`
            : activeDevice?.width ? `${activeDevice.width}×${activeDevice.height}` : ''}
        </span>
        <span>▾</span>
      </button>

      {/* Custom dimensions inline if custom selected */}
      {activeDeviceId === 'custom' && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          <input type="number" value={customWidth} onChange={e => onCustomChange(parseInt(e.target.value)||800, customHeight)}
            style={{ width: 56, fontSize: 11, padding: '2px 4px', border: '1px solid #ccc', borderRadius: 3 }} />
          <span style={{ fontSize: 11, color: '#999' }}>×</span>
          <input type="number" value={customHeight} onChange={e => onCustomChange(customWidth, parseInt(e.target.value)||600)}
            style={{ width: 56, fontSize: 11, padding: '2px 4px', border: '1px solid #ccc', borderRadius: 3 }} />
        </div>
      )}

      {/* Dropdown */}
      {open && (
        <div style={{
          position: 'absolute', top: '100%', left: 0, zIndex: 1000,
          background: '#fff', border: '1px solid #e0e0e0', borderRadius: 6,
          boxShadow: '0 4px 16px rgba(0,0,0,0.12)', minWidth: 240, maxHeight: 400, overflowY: 'auto',
          marginTop: 4,
        }}>
          {/* Special presets */}
          <div style={{ padding: '4px 0', borderBottom: '1px solid #f0f0f0' }}>
            {SPECIAL_PRESETS.map(preset => (
              <div key={preset.id}
                onClick={() => onDeviceSelect(preset)}
                style={{ padding: '6px 12px', cursor: 'pointer', fontSize: 12, fontWeight: activeDeviceId === preset.id ? 600 : 400, background: activeDeviceId === preset.id ? '#f0f7ff' : 'transparent' }}
                onMouseEnter={e => e.currentTarget.style.background = '#f5f5f5'}
                onMouseLeave={e => e.currentTarget.style.background = activeDeviceId === preset.id ? '#f0f7ff' : 'transparent'}
              >
                {preset.label}
              </div>
            ))}
          </div>

          {/* Device categories */}
          {DEVICE_CATEGORIES.map(cat => (
            <div key={cat.id}>
              <div style={{ padding: '6px 12px 2px', fontSize: 10, fontWeight: 700, color: '#999', textTransform: 'uppercase', letterSpacing: 0.5 }}>
                {cat.label}
              </div>
              {cat.devices.map(device => {
                const tier = getTierById(device.tier);
                return (
                  <div key={device.id}
                    onClick={() => onDeviceSelect(device)}
                    style={{ padding: '5px 12px', cursor: 'pointer', fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: activeDeviceId === device.id ? '#f0f7ff' : 'transparent' }}
                    onMouseEnter={e => e.currentTarget.style.background = '#f5f5f5'}
                    onMouseLeave={e => e.currentTarget.style.background = activeDeviceId === device.id ? '#f0f7ff' : 'transparent'}
                  >
                    <span style={{ fontWeight: activeDeviceId === device.id ? 600 : 400 }}>{device.label}</span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span style={{ fontSize: 10, color: '#999' }}>{device.width}×{device.height}</span>
                      {tier && <span style={{ fontSize: 9, padding: '1px 5px', borderRadius: 8, background: tier.color, color: '#fff', fontWeight: 600 }}>{tier.label}</span>}
                    </span>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function WidgetConfigPanel({ widgetName }) {
  const config = WIDGET_CONFIGS[widgetName];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      <div style={{ padding: '10px 16px', borderBottom: '1px solid #e0e0e0', flexShrink: 0 }}>
        <span style={{ fontSize: 13, fontWeight: 600 }}>{widgetName} — Full Configuration</span>
      </div>
      <div style={{ flex: 1, overflow: 'auto', padding: 16 }}>
        {config ? (
          <pre style={{ fontSize: 11, color: '#333', whiteSpace: 'pre-wrap', wordBreak: 'break-word', margin: 0 }}>
            {JSON.stringify(config, null, 2)}
          </pre>
        ) : (
          <p style={{ fontSize: 12, color: '#999', fontStyle: 'italic' }}>No Entry</p>
        )}
      </div>
    </div>
  );
}

export default function App() {
  const [popupVisible, setPopupVisible] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedAssetIds, setSelectedAssetIds] = useState([]);
  const [selectedTags, setSelectedTags] = useState([]);
  const [containers, setContainers] = useState([makeRootContainer()]);
  const [selectedContainerId, setSelectedContainerId] = useState(null);
  const [selectedContainerIds, setSelectedContainerIds] = useState([]);
  const [detailsTabIndex, setDetailsTabIndex] = useState(0);
  const [clipboard, setClipboard] = useState(null);
  const [selectedGridCell, setSelectedGridCell] = useState(null); // { containerId, cellIdx } // deep-cloned container subtree

  // Helper to handle selection with shift/ctrl multi-select
  const handleContainerSelect = (id, e) => {
    setSelectedGridCell(null); // always clear grid cell selection when selecting a container
    if (id === null) {
      setSelectedContainerId(null);
      setSelectedContainerIds([]);
      return;
    }
    if (e && (e.shiftKey || e.ctrlKey || e.metaKey)) {
      setSelectedContainerIds(prev => {
        const next = prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id];
        setSelectedContainerId(next.length === 1 ? next[0] : next[next.length - 1]);
        return next;
      });
    } else {
      setSelectedContainerId(id);
      setSelectedContainerIds([id]);
    }
  };
  const [draggingId, setDraggingId] = useState(null);
  const [dragState, setDragState] = useState({ overId: null, beforeId: null, overParentId: null });
  const [focusMode, setFocusMode] = useState('follow');
  const [showGap, setShowGap] = useState(true);
  const [coordMode, setCoordMode] = useState('reposition');
  const [currentView, setCurrentView] = useState('screens'); // 'screens' | 'widgets'
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedWidgetName, setSelectedWidgetName] = useState(null);
  // Breakpoint / device preview
  const [activeDeviceId, setActiveDeviceId] = useState('desktop_xl');
  const [activeTierId, setActiveTierId] = useState(BASE_TIER_ID);
  const [customWidth, setCustomWidth] = useState(1280);
  const [customHeight, setCustomHeight] = useState(800);
  const [devicePickerOpen, setDevicePickerOpen] = useState(false);

  React.useEffect(() => {
    const onKeyDown = (e) => {
      const mod = e.ctrlKey || e.metaKey;
      if (!mod) return;
      if (e.key === 'c' || e.key === 'C') { e.preventDefault(); handleCopy(); }
      if (e.key === 'v' || e.key === 'V') { e.preventDefault(); handlePaste(); }
    };
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [selectedContainerId, clipboard, containers]);

  const handleDragStart = (id) => {
    setDraggingId(id);
    setDragState({ overId: null, beforeId: null, overParentId: null });
  };

  const handleDragOver = (overId, beforeId, overParentId) => {
    if (!draggingId) return;
    if (overId && (overId === draggingId || isDescendant(containers, draggingId, overId))) return;
    // If we have a beforeId, this is a between-zone — clear overId
    if (beforeId !== null && beforeId !== undefined) {
      setDragState({ overId: null, beforeId, overParentId: overParentId || overId });
    } else {
      setDragState({ overId: overId || null, beforeId: null, overParentId: null });
    }
  };

  const resetPropertiesForParent = (item, newParentId, tree) => {
    const parent = findContainerById(tree, newParentId);
    const isCoord = parent?.layout?.layoutType === 'coordinate';
    return isCoord
      ? { ...item, parentId: newParentId, coord: { ...DEFAULT_COORD }, slot: { ...DEFAULT_SLOT } }
      : { ...item, parentId: newParentId, slot: { ...DEFAULT_SLOT }, coord: { ...DEFAULT_COORD } };
  };

  const handleDrop = (overId, beforeId) => {
    const id = draggingId;
    setDraggingId(null);
    setDragState({ overId: null, beforeId: null, overParentId: null });
    if (!id) return;
    if (overId && (overId === id || isDescendant(containers, id, overId))) return;
    // Block reparenting to current parent
    const dragging = findContainerById(containers, id);
    if (overId && dragging?.parentId === overId) return;

    setContainers(prev => {
      const { extracted, remaining } = extractFromTree(prev, id);
      if (!extracted) return prev;
      if (beforeId) {
        const findParentOf = (id, nodes) => {
          for (const c of nodes) {
            if (c.children.some(ch => ch.id === id)) return c;
            const found = findParentOf(id, c.children);
            if (found) return found;
          }
          return null;
        };
        const newParent = findParentOf(beforeId, remaining);
        const newParentId = newParent?.id ?? ROOT_CONTAINER_ID;
        const item = extracted.parentId === newParentId
          ? extracted
          : resetPropertiesForParent(extracted, newParentId, remaining);
        const insertBefore = (containers) => containers.reduce((acc, c) => {
          if (c.id === beforeId) acc.push(item);
          acc.push({ ...c, children: insertBefore(c.children) });
          return acc;
        }, []);
        return insertBefore(remaining);
      } else if (overId) {
        const reset = resetPropertiesForParent(extracted, overId, remaining);
        return addChildToTree(remaining, overId, reset);
      }
      return prev;
    });
  };

  const handleDeviceSelect = (device) => {
    setActiveDeviceId(device.id);
    if (device.tier) setActiveTierId(device.tier);
    else setActiveTierId(BASE_TIER_ID);
    setDevicePickerOpen(false);
  };

  const activeDevice = getDeviceById(activeDeviceId);
  const previewWidth = activeDeviceId === 'custom' ? customWidth
    : activeDeviceId === 'responsive' ? null
    : activeDevice?.width || null;
  const previewHeight = activeDeviceId === 'custom' ? customHeight
    : activeDeviceId === 'responsive' ? null
    : activeDevice?.height || null;

  const handleAddContainer = () => {
    const targetId = selectedContainerId || ROOT_CONTAINER_ID;
    const name = getNextContainerName(containers);
    const c = makeContainer(targetId, name);
    setContainers(prev => addChildToTree(prev, targetId, c));
    if (focusMode === 'follow') setSelectedContainerId(c.id);
  };

  const handleAddChildContainer = (parentId) => {
    const name = getNextContainerName(containers);
    const c = makeContainer(parentId, name);
    setContainers(prev => addChildToTree(prev, parentId, c));
    setSelectedContainerId(c.id);
  };

  const handleDeleteContainer = (id) => {
    if (id === ROOT_CONTAINER_ID) return; // root is undeletable
    setContainers(prev => deleteFromTree(prev, id));
    setSelectedContainerId(prev => prev === id ? null : prev);
  };

  const handleRenameContainer = (id, title) => {
    setContainers(prev => renameInTree(prev, id, title));
  };

  const handleTreeReparent = (draggingId, overId, beforeId) => {
    setContainers(prev => {
      const { extracted, remaining } = extractFromTree(prev, draggingId);
      if (!extracted) return prev;
      if (overId) {
        const target = findContainerById(prev, overId);
        if (target?.isWidget) return prev;
        // Block reparenting to current parent
        if (extracted.parentId === overId) return prev;
        const reset = resetPropertiesForParent(extracted, overId, remaining);
        return addChildToTree(remaining, overId, reset);
      } else if (beforeId) {
        const findParentOf = (id, nodes) => {
          for (const c of nodes) {
            if (c.children.some(ch => ch.id === id)) return c;
            const found = findParentOf(id, c.children);
            if (found) return found;
          }
          return null;
        };
        const newParent = findParentOf(beforeId, remaining);
        const newParentId = newParent?.id ?? ROOT_CONTAINER_ID;
        const item = extracted.parentId === newParentId
          ? extracted
          : resetPropertiesForParent(extracted, newParentId, remaining);
        const insertBefore = (containers) => containers.reduce((acc, c) => {
          if (c.id === beforeId) acc.push(item);
          acc.push({ ...c, children: insertBefore(c.children) });
          return acc;
        }, []);
        return insertBefore(remaining);
      }
      return prev;
    });
  };

  const handleWidgetDrop = (containerId, widgetName) => {
    const defaultProps = {};
    (WIDGET_PROPERTIES[widgetName] || []).forEach(p => { defaultProps[p.name] = p.default; });
    const c = {
      ...makeContainer(containerId, widgetName),
      isWidget: true,
      widgetName,
      widgetProps: defaultProps,
      slot: getWidgetDefaultSlot(widgetName),
    };
    setContainers(prev => addChildToTree(prev, containerId, c));
    setSelectedContainerId(c.id);
  };

  const handleGridCellDrop = (containerId, cellIdx, widgetName, draggedId, existingCellChildIds, prebuiltClone) => {
    setContainers(prev => {
      const gridContainer = findContainerById(prev, containerId);
      if (!gridContainer) return prev;

      const cells = gridContainer.layout.gridCells || buildDefaultCells(
        gridContainer.layout.gridColumns || 2,
        gridContainer.layout.gridRows || 2
      );

      // Helper to normalize cell childIds
      const getCellChildIds = (cell) => cell.childIds || (cell.childId != null ? [cell.childId] : []);

      const addToCell = (newChild, newCells) => prev.map(function ins(c) {
        if (c.id === containerId) return {
          ...c,
          children: [...c.children, newChild],
          layout: { ...c.layout, gridCells: newCells },
        };
        return { ...c, children: c.children.map(ins) };
      });

      if (prebuiltClone) {
        // Paste — apply resetPropertiesForParent for cross-layout compatibility
        const reset = resetPropertiesForParent(prebuiltClone, containerId, prev);
        const newCells = cells.map((c, i) => i === cellIdx ? { ...c, childIds: [...getCellChildIds(c), reset.id] } : c);
        return addToCell(reset, newCells);

      } else if (widgetName) {
        const defaultProps = {};
        (WIDGET_PROPERTIES[widgetName] || []).forEach(p => { defaultProps[p.name] = p.default; });
        const newWidget = { ...makeContainer(containerId, widgetName), isWidget: true, widgetName, widgetProps: defaultProps, slot: getWidgetDefaultSlot(widgetName), parentId: containerId };
        const newCells = cells.map((c, i) => i === cellIdx ? { ...c, childIds: [...getCellChildIds(c), newWidget.id] } : c);
        return addToCell(newWidget, newCells);

      } else if (draggedId && draggedId !== containerId) {
        const isFromSameGrid = findContainerById(prev, draggedId)?.parentId === containerId;
        const { extracted, remaining } = extractFromTree(prev, draggedId);
        if (!extracted) return prev;

        const reset = resetPropertiesForParent(extracted, containerId, remaining);
        const resetWithParent = { ...reset, parentId: containerId };

        // Remove from old cell, add to new cell
        const sourceCellIdx = cells.findIndex(c => getCellChildIds(c).includes(draggedId));
        const newCells = cells.map((c, i) => {
          let ids = getCellChildIds(c).filter(id => id !== draggedId);
          if (i === cellIdx) ids = [...ids, resetWithParent.id];
          return { ...c, childIds: ids };
        });

        if (isFromSameGrid) {
          return prev.map(function upd(c) {
            if (c.id === containerId) return {
              ...c,
              children: c.children.map(ch => ch.id === draggedId ? resetWithParent : ch),
              layout: { ...c.layout, gridCells: newCells },
            };
            return { ...c, children: c.children.map(upd) };
          });
        } else {
          return remaining.map(function ins(c) {
            if (c.id === containerId) return { ...c, children: [...c.children, resetWithParent], layout: { ...c.layout, gridCells: newCells } };
            return { ...c, children: c.children.map(ins) };
          });
        }
      }
      return prev;
    });
    setDraggingId(null);
    setDragState({ overId: null, beforeId: null, overParentId: null });
  };

  const handleCopy = () => {
    if (!selectedContainerId) return;
    const found = findContainerById(containers, selectedContainerId);
    if (!found || found.id === ROOT_CONTAINER_ID) return;
    setClipboard(found);
    // Don't clear selectedGridCell on copy — user may want to paste back into same cell
  };

  const handlePaste = () => {
    if (!clipboard) return;

    // If a grid cell is selected, paste into that specific cell
    if (selectedGridCell) {
      const cloned = deepCloneWithNewIds(clipboard, selectedGridCell.containerId);
      handleGridCellDrop(selectedGridCell.containerId, selectedGridCell.cellIdx, null, null, null, cloned);
      setSelectedGridCell(null); // clear after paste
      return;
    }

    // Determine paste target
    const sel = selectedContainerId ? findContainerById(containers, selectedContainerId) : null;
    const targetParentId = sel
      ? (sel.isWidget ? (sel.parentId ?? ROOT_CONTAINER_ID) : sel.id)
      : ROOT_CONTAINER_ID;

    const cloned = deepCloneWithNewIds(clipboard, targetParentId);
    const reset = resetPropertiesForParent(cloned, targetParentId, containers);
    setContainers(prev => addChildToTree(prev, targetParentId, reset));
    setSelectedContainerId(reset.id);
    setSelectedContainerIds([reset.id]);
    setSelectedGridCell(null);
  };

  const handleUpdateWidgetProps = (id, props) => {
    setContainers(prev => updateWidgetPropsInTree(prev, id, props));
  };

  // Create a fresh cell container for a grid cell
  const makeCellContainer = (parentId) => ({
    ...makeContainer(parentId, getNextContainerName(containers)),
    slot: { ...DEFAULT_SLOT, flexGrow: 1, flexShrink: 1, width: '', height: '', flexBasis: '0' },
  });

  // Build gridCells with one container per cell, adding children to the tree
  const buildCellContainers = (parentId, cols, rows, prevContainers) => {
    const cells = buildDefaultCells(cols, rows);
    const newContainers = [];
    const filledCells = cells.map((cell) => {
      const cc = { ...makeContainer(parentId, getNextContainerName([...prevContainers, ...newContainers])), slot: { ...DEFAULT_SLOT, flexGrow: 1, flexShrink: 1, width: '', height: '', flexBasis: '0' } };
      newContainers.push(cc);
      return { ...cell, childIds: [cc.id] };
    });
    return { filledCells, newContainers };
  };

  const handleUpdateLayout = (id, layoutUpdate) => {
    setContainers(prev => {
      const container = findContainerById(prev, id);
      if (!container) return updateLayoutInTree(prev, id, layoutUpdate);

      const oldLayout = container.layout || {};
      const newLayout = { ...oldLayout, ...layoutUpdate };

      // Switching TO grid — auto-create cell containers
      if (layoutUpdate.layoutType === 'grid' && oldLayout.layoutType !== 'grid') {
        const cols = newLayout.gridColumns || 2;
        const rows = newLayout.gridRows || 2;
        const { filledCells, newContainers } = buildCellContainers(id, cols, rows, prev);

        // Move any existing children into the first cell container
        const existingChildren = container.children;
        let updatedContainers = prev;
        if (existingChildren.length > 0 && newContainers.length > 0) {
          existingChildren.forEach(child => {
            newContainers[0].children = [...(newContainers[0].children || []), { ...child, parentId: newContainers[0].id }];
          });
        }

        return updatedContainers.map(function upd(c) {
          if (c.id === id) return {
            ...c,
            layout: { ...newLayout, gridCells: filledCells },
            children: newContainers,
          };
          return { ...c, children: c.children.map(upd) };
        });
      }

      // Changing grid columns or rows — migrate cell containers
      if (oldLayout.layoutType === 'grid' && (layoutUpdate.gridColumns !== undefined || layoutUpdate.gridRows !== undefined)) {
        const oldCols = oldLayout.gridColumns || 2;
        const oldRows = oldLayout.gridRows || 2;
        const newCols = newLayout.gridColumns || 2;
        const newRows = newLayout.gridRows || 2;
        const oldCells = oldLayout.gridCells || buildDefaultCells(oldCols, oldRows);

        // Build new cells
        const newBaseCells = buildDefaultCells(newCols, newRows);
        const newContainersToAdd = [];

        const newFilledCells = newBaseCells.map((newCell) => {
          // Find the old cell that best matches this position
          const oldCell = oldCells.find(oc =>
            oc.colStart === newCell.colStart && oc.rowStart === newCell.rowStart
          );

          if (oldCell) {
            // Reuse existing cell container(s)
            const existingIds = oldCell.childIds || (oldCell.childId != null ? [oldCell.childId] : []);
            return { ...newCell, childIds: existingIds };
          } else {
            // New cell — create a fresh container
            const cc = { ...makeContainer(id, getNextContainerName([...prev, ...newContainersToAdd])), slot: { ...DEFAULT_SLOT, flexGrow: 1, flexShrink: 1, width: '', height: '', flexBasis: '0' } };
            newContainersToAdd.push(cc);
            return { ...newCell, childIds: [cc.id] };
          }
        });

        // Collect childIds that are no longer referenced and merge their contents into last cell
        const referencedIds = new Set(newFilledCells.flatMap(c => c.childIds || []));
        const orphanedCellIds = oldCells
          .flatMap(c => c.childIds || (c.childId != null ? [c.childId] : []))
          .filter(id => !referencedIds.has(id));

        // Move orphaned container children into the last referenced cell container
        if (orphanedCellIds.length > 0 && newFilledCells.length > 0) {
          const lastCell = newFilledCells[newFilledCells.length - 1];
          lastCell.childIds = [...(lastCell.childIds || []), ...orphanedCellIds];
          // Reparent orphaned containers
          orphanedCellIds.forEach(oid => {
            const lastCellContainerId = lastCell.childIds[0];
            // Move orphaned container's children into the last cell container
          });
        }

        return prev.map(function upd(c) {
          if (c.id === id) return {
            ...c,
            layout: { ...newLayout, gridCells: newFilledCells },
            children: [...c.children, ...newContainersToAdd],
          };
          return { ...c, children: c.children.map(upd) };
        });
      }

      return updateLayoutInTree(prev, id, layoutUpdate);
    });
  };

  // When cells merge, move absorbed container's children into surviving container
  const handleMergeCellContainers = (survivingId, absorbedIds) => {
    setContainers(prev => {
      let updated = prev;
      absorbedIds.forEach(absorbedId => {
        const absorbed = findContainerById(updated, absorbedId);
        if (!absorbed || absorbed.children.length === 0) return;
        // Move absorbed children into surviving container
        absorbed.children.forEach(child => {
          const reparented = { ...child, parentId: survivingId };
          updated = addChildToTree(updated, survivingId, reparented);
        });
        // Remove absorbed container (now empty)
        const { remaining } = extractFromTree(updated, absorbedId);
        updated = remaining;
      });
      return updated;
    });
  };

  const handleUpdateSlot = (id, slot) => {
    if (activeTierId !== BASE_TIER_ID) {
      // Save to breakpoint override instead of base
      setContainers(prev => prev.map(function upd(c) {
        if (c.id === id) {
          const existing = c.breakpointOverrides?.[activeTierId]?.slot || {};
          return { ...c, breakpointOverrides: { ...c.breakpointOverrides, [activeTierId]: { ...c.breakpointOverrides?.[activeTierId], slot: { ...existing, ...slot } } } };
        }
        return { ...c, children: c.children.map(upd) };
      }));
    } else {
      setContainers(prev => updateSlotInTree(prev, id, slot));
    }
  };

  const handleUpdateWidgetPropsForBreakpoint = (id, props) => {
    if (activeTierId !== BASE_TIER_ID) {
      setContainers(prev => prev.map(function upd(c) {
        if (c.id === id) {
          const existing = c.breakpointOverrides?.[activeTierId]?.widgetProps || {};
          return { ...c, breakpointOverrides: { ...c.breakpointOverrides, [activeTierId]: { ...c.breakpointOverrides?.[activeTierId], widgetProps: { ...existing, ...props } } } };
        }
        return { ...c, children: c.children.map(upd) };
      }));
    } else {
      handleUpdateWidgetProps(id, props);
    }
  };

  const handleToggleVisibility = (id, tierId) => {
    setContainers(prev => prev.map(function upd(c) {
      if (c.id === id) {
        const currentlyHidden = c.breakpointOverrides?.[tierId]?.hidden ?? false;
        return { ...c, breakpointOverrides: { ...c.breakpointOverrides, [tierId]: { ...c.breakpointOverrides?.[tierId], hidden: !currentlyHidden } } };
      }
      return { ...c, children: c.children.map(upd) };
    }));
  };

  const handleClearBreakpointOverrides = (id, tierId) => {
    setContainers(prev => prev.map(function upd(c) {
      if (c.id === id) {
        const newOverrides = { ...c.breakpointOverrides };
        delete newOverrides[tierId];
        return { ...c, breakpointOverrides: newOverrides };
      }
      return { ...c, children: c.children.map(upd) };
    }));
  };

  const handleUpdateCoord = (id, coord) => {
    setContainers(prev => updateCoordInTree(prev, id, coord));
  };

  const handleUpdatePageType = (id, pageType) => {
    setContainers(prev => updatePageTypeInTree(prev, id, pageType));
  };

  const openWizard = () => {
    setCurrentStep(0);
    setSelectedAssetIds([]);
    setSelectedTags([]);
    setPopupVisible(true);
  };

  const closeWizard = () => setPopupVisible(false);

  const handleNext = () => {
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(s => s + 1);
    } else {
      closeWizard();
    }
  };

  const handleBack = () => {
    if (currentStep > 0) setCurrentStep(s => s - 1);
  };

  const isLastStep = currentStep === STEPS.length - 1;

  return (
    <div className="app-shell">

      {/* Title bar */}
      <div className="app-titlebar">
        <div className="app-titlebar-menu" ref={menuRef => {
          if (menuRef) {
            menuRef.onmouseleave = () => setMenuOpen(false);
          }
        }}>
          <span
            className="app-titlebar-title"
            onClick={() => setMenuOpen(o => !o)}
            style={{ cursor: 'pointer', userSelect: 'none' }}
          >
            Aetherium ▾
          </span>
          {menuOpen && (
            <div className="app-titlebar-dropdown">
              <div
                className={`app-titlebar-dropdown-item${currentView === 'screens' ? ' active' : ''}`}
                onClick={() => { setCurrentView('screens'); setMenuOpen(false); }}
              >
                Screens
              </div>
              <div
                className={`app-titlebar-dropdown-item${currentView === 'widgets' ? ' active' : ''}`}
                onClick={() => { setCurrentView('widgets'); setMenuOpen(false); }}
              >
                Widgets
              </div>
            </div>
          )}
        </div>
        <div className="app-titlebar-profile" title="Profile">
          <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="14" cy="10" r="5" stroke="white" strokeWidth="1.5" fill="none"/>
            <path d="M4 24c0-5.523 4.477-10 10-10s10 4.477 10 10" stroke="white" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
          </svg>
        </div>
      </div>

      {/* Main content area */}
      <div className="app-body">
        {currentView === 'widgets' ? (
          <Splitter orientation="horizontal" style={{ height: '100%' }}>
            <SplitterItem size="220px" minSize="120px" resizable={true}>
              <div className="app-panel">
                <TabPanel
                  height="100%"
                  animationEnabled={false}
                  swipeEnabled={false}
                >
                  <TabPanelItem title="Widgets">
                    <div className="left-panel-tab-content">
                      <HierarchyTree
                        dataSource={DX_WIDGET_DATA}
                        displayExpr="name"
                        itemRender={(item) => WidgetTreeItemTemplate(item, null)}
                        selectedId={selectedWidgetName}
                        onSelect={(id) => {
                          const item = DX_WIDGET_DATA.find(w => w.id === id);
                          setSelectedWidgetName(item?.assetLevel === 'widget' ? item.name : null);
                        }}
                      />
                    </div>
                  </TabPanelItem>
                </TabPanel>
              </div>
            </SplitterItem>
            <SplitterItem resizable={true}>
              <div className="app-panel app-panel--center" style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
                {selectedWidgetName ? (
                  <WidgetConfigPanel widgetName={selectedWidgetName} />
                ) : (
                  <p className="step-instructions" style={{ padding: 16 }}>Select a widget to view its full configuration.</p>
                )}
              </div>
            </SplitterItem>
            <SplitterItem size="220px" minSize="120px" resizable={true}>
              <div className="app-panel details-panel">
                <p className="panel-label">Details</p>
                {selectedWidgetName ? (
                  <>
                    <p style={{ fontSize: 13, fontWeight: 600, margin: '8px 0 4px' }}>{selectedWidgetName}</p>
                    {WIDGET_PROPERTIES[selectedWidgetName] ? (
                      <pre style={{ fontSize: 11, color: '#333', whiteSpace: 'pre-wrap', wordBreak: 'break-word', background: '#f5f5f5', padding: 8, borderRadius: 4, margin: 0 }}>
                        {JSON.stringify(WIDGET_PROPERTIES[selectedWidgetName], null, 2)}
                      </pre>
                    ) : (
                      <p style={{ fontSize: 12, color: '#999', fontStyle: 'italic' }}>No Entry</p>
                    )}
                  </>
                ) : (
                  <p className="step-instructions">Select a widget to view its properties.</p>
                )}
              </div>
            </SplitterItem>
          </Splitter>
        ) : (
          <Splitter orientation="horizontal" style={{ height: '100%' }}>
            <SplitterItem size="220px" minSize="120px" resizable={true}>
            <div className="app-panel">
              <TabPanel
                height="100%"
                animationEnabled={false}
                swipeEnabled={false}
              >
                <TabPanelItem title="Visuals">
                  <div className="left-panel-tab-content">
                    <HierarchyTree
                      dataSource={DX_WIDGET_DATA}
                      displayExpr="name"
                      itemRender={(item) => WidgetTreeItemTemplate(item, (item) => {
                        const selected = selectedContainerId
                          ? findContainerById(containers, selectedContainerId)
                          : null;
                        const targetId = selected?.isWidget
                          ? (selected.parentId || ROOT_CONTAINER_ID)
                          : (selectedContainerId || ROOT_CONTAINER_ID);
                        handleWidgetDrop(targetId, item.name);
                      })}
                    />
                  </div>
                </TabPanelItem>
                <TabPanelItem title="Data">
                  <div className="left-panel-tab-content">
                    <HierarchyTree
                      dataSource={ASSET_DATA}
                      displayExpr="name"
                      itemRender={AssetTreeItemTemplate}
                    />
                  </div>
                </TabPanelItem>
                <TabPanelItem title="Page Visuals">
                  <div className="left-panel-tab-content">
                    <p className="panel-label" style={{ padding: '4px 0', marginBottom: 4 }}>
                      Selected: {selectedContainerId
                        ? (findContainerById(containers, selectedContainerId)?.title || 'none')
                        : 'none'}
                    </p>
                    <PageVisualsTabWrapper
                      containers={containers}
                      selectedContainerId={selectedContainerId}
                      onSelect={(id) => {
                        setSelectedContainerId(id);
                        setSelectedContainerIds(id ? [id] : []);
                      }}
                      onReparent={handleTreeReparent}
                    />
                  </div>
                </TabPanelItem>
                <TabPanelItem title="Page Data">
                  <div className="left-panel-tab-content">
                    <HierarchyTree
                      dataSource={ASSET_DATA}
                      displayExpr="name"
                      itemRender={AssetTreeItemTemplate}
                    />
                  </div>
                </TabPanelItem>
              </TabPanel>
            </div>
          </SplitterItem>
          <SplitterItem resizable={true}>
            <div className="app-panel app-panel--center">
              <div className="center-toolbar">
                {/* Device picker — always visible */}
                <DevicePicker
                  activeDeviceId={activeDeviceId}
                  activeTierId={activeTierId}
                  customWidth={customWidth}
                  customHeight={customHeight}
                  onDeviceSelect={handleDeviceSelect}
                  onCustomChange={(w, h) => { setCustomWidth(w); setCustomHeight(h); }}
                  open={devicePickerOpen}
                  onToggle={() => setDevicePickerOpen(o => !o)}
                />
                <div style={{ width: 1, height: 20, background: '#e0e0e0', margin: '0 4px', flexShrink: 0 }} />
                {selectedContainerId && (
                  <>
                    <Button
                      text="+ Add Container"
                      type="default"
                      stylingMode="outlined"
                      onClick={handleAddContainer}
                    />
                    <button
                      className={`focus-mode-btn${focusMode === 'stay' ? ' focus-mode-btn--active' : ''}`}
                      onClick={() => setFocusMode(m => m === 'follow' ? 'stay' : 'follow')}
                      title={focusMode === 'follow' ? 'Follow mode: focus moves to new container' : 'Stay mode: focus stays on parent'}
                    >
                      {focusMode === 'follow' ? '⤵ Follow' : '📌 Stay'}
                    </button>
                    {(() => {
                      const sel = findContainerById(containers, selectedContainerId);
                      if (!sel || sel.isWidget) return null;
                      const dir = sel.layout?.flexDirection || 'row';
                      return (
                        <button
                          className={`focus-mode-btn${dir === 'column' ? ' focus-mode-btn--active' : ''}`}
                          title={`Direction: ${dir} — click to toggle`}
                          onClick={() => handleUpdateLayout(selectedContainerId, { flexDirection: dir === 'row' ? 'column' : 'row' })}
                        >
                          <i className={dir === 'row' ? 'dx-icon-deleterow' : 'dx-icon-deletecolumn'} style={{ marginRight: 4 }} />
                          {dir}
                        </button>
                      );
                    })()}
                    <button
                      className={`focus-mode-btn${!showGap ? ' focus-mode-btn--active' : ''}`}
                      onClick={() => setShowGap(g => !g)}
                      title={showGap ? 'Gap on — click to remove spacing' : 'Gap off — click to restore spacing'}
                    >
                      {showGap ? '⬜ Gap' : '▣ Gap'}
                    </button>
                    {(() => {
                      const sel = selectedContainerId ? findContainerById(containers, selectedContainerId) : null;
                      const selParent = sel?.parentId ? findContainerById(containers, sel.parentId) : null;
                      const isCoordChild = selParent?.layout?.layoutType === 'coordinate';
                      return (
                        <>
                          {/* Copy button — any non-root selected item */}
                          {sel && sel.id !== ROOT_CONTAINER_ID && (
                            <button
                              className="focus-mode-btn"
                              title="Copy selected (Ctrl/Cmd+C)"
                              onClick={handleCopy}
                            >
                              ⎘ Copy
                            </button>
                          )}
                          {/* Paste button — when clipboard has content */}
                          {clipboard && (
                            <button
                              className="focus-mode-btn focus-mode-btn--active"
                              title="Paste (Ctrl/Cmd+V)"
                              onClick={handlePaste}
                            >
                              ⊕ Paste
                            </button>
                          )}
                          {/* Delete button — for any non-root selected item */}
                          {sel && sel.id !== ROOT_CONTAINER_ID && (
                            <button
                              className="focus-mode-btn"
                              style={{ color: '#d00', borderColor: '#d00' }}
                              title="Delete selected container"
                              onClick={() => handleDeleteContainer(selectedContainerId)}
                            >
                              × Delete
                            </button>
                          )}
                          {/* Move/Reparent toggle — only for coord children */}
                          {isCoordChild && (
                            <button
                              className={`focus-mode-btn${coordMode === 'reparent' ? ' focus-mode-btn--active' : ''}`}
                              onClick={() => setCoordMode(m => m === 'reposition' ? 'reparent' : 'reposition')}
                              title={coordMode === 'reposition' ? 'Drag moves item — click to switch to reparent' : 'Drag reparents item — click to switch to reposition'}
                            >
                              {coordMode === 'reposition' ? '⤢ Move' : '⇄ Reparent'}
                            </button>
                          )}
                        </>
                      );
                    })()}
                  </>
                )}
              </div>
              <div
                className="center-content"
                onClick={() => { setSelectedContainerId(null); setSelectedContainerIds([]); setSelectedGridCell(null); setDevicePickerOpen(false); }}
              >
                {/* Device preview wrapper */}
                <div style={{
                  width: '100%', height: '100%',
                  overflow: 'auto',
                  display: 'flex',
                  alignItems: previewWidth ? 'flex-start' : 'stretch',
                  justifyContent: previewWidth ? 'center' : 'stretch',
                  padding: previewWidth ? 24 : 0,
                  boxSizing: 'border-box',
                  background: previewWidth ? '#e8e8e8' : 'transparent',
                }}>
                  <div style={{
                    width: previewWidth ? previewWidth : '100%',
                    height: previewHeight ? previewHeight : '100%',
                    flexShrink: 0,
                    background: '#fff',
                    boxShadow: previewWidth ? '0 2px 16px rgba(0,0,0,0.15)' : 'none',
                    overflow: 'hidden',
                    position: 'relative',
                  }}>
                    <div className={`container-canvas${showGap ? '' : ' canvas-no-gap'}`} style={{ padding: 0, height: '100%', boxSizing: 'border-box' }}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={(e) => { e.preventDefault(); setDraggingId(null); setDragState({ overId: null, beforeId: null, overParentId: null }); }}
                    >
                  {containers.map(c => (
                    <ContainerCard
                      key={c.id}
                      container={c}
                      selectedIds={selectedContainerIds}
                      onSelect={handleContainerSelect}
                      onDelete={handleDeleteContainer}
                      onDragStart={handleDragStart}
                      onDragOver={(overId, beforeId, overParentId) => handleDragOver(overId, beforeId, overParentId)}
                      onDrop={handleDrop}
                      onWidgetDrop={handleWidgetDrop}
                      onUpdateLayout={handleUpdateLayout}
                      onUpdateSlot={handleUpdateSlot}
                      onUpdateCoord={handleUpdateCoord}
                      onGridCellDrop={handleGridCellDrop}
                      onSetSelectedGridCell={setSelectedGridCell}
                      onMergeCellContainers={handleMergeCellContainers}
                      selectedGridCell={selectedGridCell}
                      dragState={dragState}
                      draggingId={draggingId}
                      isDragging={!!draggingId}
                      coordMode={coordMode}
                      activeTierId={activeTierId}
                    />
                  ))}
                </div>
                  </div>
                </div>
              </div>
            </div>
          </SplitterItem>
          <SplitterItem size="220px" minSize="120px" resizable={true}>
            <div className="app-panel details-panel">
              {(() => {
                const isBase = activeTierId === BASE_TIER_ID;
                const tier = getTierById(activeTierId);
                return (
                  <div className="details-panel-header" style={{
                    background: isBase ? undefined : tier?.color,
                    color: isBase ? undefined : '#fff',
                    transition: 'background 0.2s',
                  }}>
                    <span className="panel-label" style={{ color: isBase ? undefined : '#fff', margin: 0 }}>
                      {isBase ? 'Details' : `${tier?.icon} ${tier?.label} Overrides`}
                    </span>
                    <Button
                      text="Create"
                      type={isBase ? 'default' : 'normal'}
                      stylingMode="outlined"
                      onClick={openWizard}
                      style={{ marginLeft: 'auto' }}
                    />
                  </div>
                );
              })()}

              {/* Multi-select panel */}
              {selectedContainerIds.length > 1 && (() => {
                const selected = selectedContainerIds
                  .map(id => findContainerById(containers, id))
                  .filter(Boolean);

                const sb = (ds, val, fn) => (
                  <SelectBox
                    dataSource={ds}
                    value={val}
                    onValueChanged={(e) => fn(e.value)}
                    stylingMode="outlined"
                    width="100%"
                    height={24}
                  />
                );
                const ti = (val, placeholder, fn, type = 'text') => (
                  <input
                    className="details-input"
                    type={type}
                    value={val ?? ''}
                    placeholder={placeholder}
                    onChange={(e) => fn(type === 'number' ? (parseFloat(e.target.value) || 0) : e.target.value)}
                  />
                );

                // Helper: get shared value or null if values differ
                const shared = (getter) => {
                  const vals = selected.map(getter);
                  return vals.every(v => v === vals[0]) ? vals[0] : undefined;
                };

                // Update all selected
                const updateAllSlot = (slot) => selected.forEach(c => handleUpdateSlot(c.id, slot));
                const updateAllLayout = (layout) => selected.forEach(c => handleUpdateLayout(c.id, layout));
                const updateAllWidgetProps = (props) => selected.forEach(c => c.isWidget && handleUpdateWidgetProps(c.id, props));

                // Shared slot values
                const allHaveParent = selected.every(c => c.parentId !== null);
                const sharedWidth = shared(c => c.slot?.width);
                const sharedHeight = shared(c => c.slot?.height);
                const sharedGrow = shared(c => c.slot?.flexGrow);
                const sharedShrink = shared(c => c.slot?.flexShrink);

                // Shared widget props — intersect by property NAME across all selected widgets
                const allWidgets = selected.every(c => c.isWidget);
                const sharedWidgetName = shared(c => c.widgetName);

                // Build intersection of property definitions by name
                const sharedPropDefs = (() => {
                  if (!allWidgets) return [];
                  const propMaps = selected.map(c => {
                    const defs = WIDGET_PROPERTIES[c.widgetName] || [];
                    return new Map(defs.map(p => [p.name, p]));
                  });
                  if (propMaps.length === 0) return [];
                  // Start with first widget's props, keep only those present in ALL others
                  return [...propMaps[0].values()].filter(p =>
                    propMaps.every(m => m.has(p.name))
                  );
                })();

                return (
                  <div key={selectedContainerIds.join(',')}>
                    <div className="details-section">
                      <div className="details-grid">
                        <span className="details-section-title">{selected.length} items selected</span>
                      </div>
                    </div>

                    {allHaveParent && (
                      <div className="details-section">
                        <div className="details-grid">
                          <span className="details-section-title">Slot</span>
                          <span className="details-grid-label">Width</span>
                          <div className="details-grid-control">{ti(sharedWidth, '—', v => updateAllSlot({ width: v }))}</div>
                          <span className="details-grid-label">Height</span>
                          <div className="details-grid-control">{ti(sharedHeight, '—', v => updateAllSlot({ height: v }))}</div>
                          <span className="details-grid-label">Grow</span>
                          <div className="details-grid-control">{sb([0,1,2,3], sharedGrow, v => updateAllSlot({ flexGrow: v }))}</div>
                          <span className="details-grid-label">Shrink</span>
                          <div className="details-grid-control">{sb([0,1,2,3], sharedShrink, v => updateAllSlot({ flexShrink: v }))}</div>
                        </div>
                      </div>
                    )}

                    {allHaveParent && (
                      <div className="details-section">
                        <div className="details-grid">
                          <span className="details-section-title">Box</span>
                          <span className="details-grid-label">Pad Top</span>
                          <div className="details-grid-control">{ti(shared(c => c.slot?.paddingTop), '—', v => updateAllSlot({ paddingTop: v }))}</div>
                          <span className="details-grid-label">Pad Bottom</span>
                          <div className="details-grid-control">{ti(shared(c => c.slot?.paddingBottom), '—', v => updateAllSlot({ paddingBottom: v }))}</div>
                          <span className="details-grid-label">Pad Left</span>
                          <div className="details-grid-control">{ti(shared(c => c.slot?.paddingLeft), '—', v => updateAllSlot({ paddingLeft: v }))}</div>
                          <span className="details-grid-label">Pad Right</span>
                          <div className="details-grid-control">{ti(shared(c => c.slot?.paddingRight), '—', v => updateAllSlot({ paddingRight: v }))}</div>
                          <span className="details-grid-label">Margin Top</span>
                          <div className="details-grid-control">{ti(shared(c => c.slot?.marginTop), '—', v => updateAllSlot({ marginTop: v }))}</div>
                          <span className="details-grid-label">Margin Bottom</span>
                          <div className="details-grid-control">{ti(shared(c => c.slot?.marginBottom), '—', v => updateAllSlot({ marginBottom: v }))}</div>
                          <span className="details-grid-label">Margin Left</span>
                          <div className="details-grid-control">{ti(shared(c => c.slot?.marginLeft), '—', v => updateAllSlot({ marginLeft: v }))}</div>
                          <span className="details-grid-label">Margin Right</span>
                          <div className="details-grid-control">{ti(shared(c => c.slot?.marginRight), '—', v => updateAllSlot({ marginRight: v }))}</div>
                          <span className="details-grid-label">Border Width</span>
                          <div className="details-grid-control">{ti(shared(c => c.slot?.borderWidth), '—', v => updateAllSlot({ borderWidth: v }))}</div>
                          <span className="details-grid-label">Border Style</span>
                          <div className="details-grid-control">{sb(['','solid','dashed','dotted','double','none'], shared(c => c.slot?.borderStyle), v => updateAllSlot({ borderStyle: v }))}</div>
                          <span className="details-grid-label">Border Color</span>
                          <div className="details-grid-control">{ti(shared(c => c.slot?.borderColor), '—', v => updateAllSlot({ borderColor: v }))}</div>
                          <span className="details-grid-label">Border Radius</span>
                          <div className="details-grid-control">{ti(shared(c => c.slot?.borderRadius), '—', v => updateAllSlot({ borderRadius: v }))}</div>
                          <span className="details-grid-label">Bg Color</span>
                          <div className="details-grid-control">{ti(shared(c => c.slot?.backgroundColor), '—', v => updateAllSlot({ backgroundColor: v }))}</div>
                          <span className="details-grid-label">Text Color</span>
                          <div className="details-grid-control">{ti(shared(c => c.slot?.color), '—', v => updateAllSlot({ color: v }))}</div>
                          <span className="details-grid-label">Font Size</span>
                          <div className="details-grid-control">{ti(shared(c => c.slot?.fontSize), '—', v => updateAllSlot({ fontSize: v }))}</div>
                          <span className="details-grid-label">Font Weight</span>
                          <div className="details-grid-control">{sb(['','normal','bold','300','400','500','600','700'], shared(c => c.slot?.fontWeight), v => updateAllSlot({ fontWeight: v }))}</div>
                          <span className="details-grid-label">Text Align</span>
                          <div className="details-grid-control">{sb(['','left','center','right','justify'], shared(c => c.slot?.textAlign), v => updateAllSlot({ textAlign: v }))}</div>
                        </div>
                      </div>
                    )}

                    {sharedPropDefs.length > 0 && (
                      <div className="details-section">
                        <div className="details-grid">
                          <span className="details-section-title">{sharedWidgetName ? `${sharedWidgetName} Properties` : 'Shared Widget Properties'}</span>
                          {sharedPropDefs.map(p => {
                            const sharedVal = shared(c => c.widgetProps?.[p.name]);
                            return (
                              <React.Fragment key={p.name}>
                                <span className="details-grid-label">{p.label}</span>
                                <div className="details-grid-control">
                                  {p.type === 'bool' && sb(
                                    [{ v: true, l: 'true' }, { v: false, l: 'false' }],
                                    sharedVal,
                                    v => updateAllWidgetProps({ [p.name]: v }),
                                  )}
                                  {p.type === 'enum' && sb(p.options, sharedVal, v => updateAllWidgetProps({ [p.name]: v }))}
                                  {p.type === 'string' && ti(sharedVal, '—', v => updateAllWidgetProps({ [p.name]: v }))}
                                  {p.type === 'number' && ti(sharedVal, '—', v => updateAllWidgetProps({ [p.name]: v }), 'number')}
                                </div>
                              </React.Fragment>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}

              {selectedContainerIds.length <= 1 && selectedContainerId && (() => {
                const flat = flattenContainers(containers);
                const found = flat.find(c => c.id === selectedContainerId);
                const fullContainer = found ? findContainerById(containers, selectedContainerId) : null;
                if (!found || !fullContainer) return null;

                // Override-aware values
                const isBase = activeTierId === BASE_TIER_ID;
                const tier = getTierById(activeTierId);
                const overrides = fullContainer.breakpointOverrides?.[activeTierId] || {};
                const isHidden = overrides.hidden ?? false;
                const hasOverrides = Object.keys(fullContainer.breakpointOverrides || {}).some(t => {
                  const o = fullContainer.breakpointOverrides[t];
                  return Object.keys(o).length > 0;
                });

                const layout = fullContainer.layout || DEFAULT_LAYOUT;
                // Merge slot with breakpoint override for display
                const baseSlot = fullContainer.slot || DEFAULT_SLOT;
                const slot = isBase ? baseSlot : { ...baseSlot, ...(overrides.slot || {}) };

                const parentContainer = fullContainer.parentId !== null
                  ? findContainerById(containers, fullContainer.parentId)
                  : null;

                const sb = (ds, val, fn) => (
                  <SelectBox
                    dataSource={ds}
                    value={val}
                    onValueChanged={(e) => fn(e.value)}
                    stylingMode="outlined"
                    width="100%"
                    height={24}
                  />
                );

                const ti = (val, placeholder, fn, type = 'text') => (
                  <input
                    className="details-input"
                    type={type}
                    value={val}
                    placeholder={placeholder}
                    onChange={(e) => fn(type === 'number' ? (parseInt(e.target.value) || 0) : e.target.value)}
                  />
                );

                return (
                  <div key={selectedContainerId} style={{ height: '100%', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
                    <TabPanel
                      height="100%"
                      animationEnabled={false}
                      swipeEnabled={false}
                      selectedIndex={detailsTabIndex}
                      onSelectedIndexChange={setDetailsTabIndex}
                    >

                      {/* Tab: Widget — DevExtreme widget properties */}
                      {fullContainer.isWidget && fullContainer.widgetName && (() => {
                        const propDefs = WIDGET_PROPERTIES[fullContainer.widgetName];
                        if (!propDefs || propDefs.length === 0) return null;
                        const props = fullContainer.widgetProps || {};
                        return (
                          <TabPanelItem title={fullContainer.widgetName}>
                            <div className="details-tab-content">
                              <div className="details-section">
                                <div className="details-grid">
                                  <span className="details-section-title">{fullContainer.widgetName}</span>
                                  {propDefs.map(p => (
                                    <React.Fragment key={p.name}>
                                      <span className="details-grid-label">{p.label}</span>
                                      <div className="details-grid-control">
                                        {p.type === 'bool' && <SelectBox dataSource={[{v:true,l:'true'},{v:false,l:'false'}]} displayExpr="l" valueExpr="v" value={props[p.name] ?? p.default} onValueChanged={(e) => handleUpdateWidgetProps(selectedContainerId, {[p.name]: e.value})} stylingMode="outlined" width="100%" height={24} />}
                                        {p.type === 'enum' && <SelectBox dataSource={p.options} value={props[p.name] ?? p.default} onValueChanged={(e) => handleUpdateWidgetProps(selectedContainerId, {[p.name]: e.value})} stylingMode="outlined" width="100%" height={24} />}
                                        {p.type === 'string' && <input className="details-input" value={props[p.name] ?? p.default} onChange={(e) => handleUpdateWidgetProps(selectedContainerId, {[p.name]: e.target.value})} />}
                                        {p.type === 'number' && <input className="details-input" type="number" value={props[p.name] ?? p.default} onChange={(e) => handleUpdateWidgetProps(selectedContainerId, {[p.name]: parseFloat(e.target.value) || 0})} />}
                                      </div>
                                    </React.Fragment>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </TabPanelItem>
                        );
                      })()}

                      {/* Tab: Layout — container config, shown as "Widget" tab for containers */}
                      {!fullContainer.isWidget && fullContainer.id !== ROOT_CONTAINER_ID && (
                        <TabPanelItem title="Layout">
                          <div className="details-tab-content">
                            <div className="details-section"><div className="details-grid">
                              <span className="details-section-title">Layout</span>
                              <span className="details-grid-label">Type</span><div className="details-grid-control">{sb(['flex','coordinate','grid'],layout.layoutType,v=>handleUpdateLayout(selectedContainerId,{layoutType:v}))}</div>
                              {layout.layoutType === 'grid' ? (<>
                                <span className="details-grid-label">Columns</span><div className="details-grid-control">{ti(layout.gridColumns, '2', v => {
                                  const newCols = Math.max(1, parseInt(v)||2);
                                  const oldCells = layout.gridCells || buildDefaultCells(layout.gridColumns||2, layout.gridRows||2);
                                  handleUpdateLayout(selectedContainerId, { gridColumns: newCols, gridCells: migrateGridCells(oldCells, layout.gridColumns||2, layout.gridRows||2, newCols, layout.gridRows||2) });
                                }, 'number')}</div>
                                <span className="details-grid-label">Rows</span><div className="details-grid-control">{ti(layout.gridRows, '2', v => {
                                  const newRows = Math.max(1, parseInt(v)||2);
                                  const oldCells = layout.gridCells || buildDefaultCells(layout.gridColumns||2, layout.gridRows||2);
                                  handleUpdateLayout(selectedContainerId, { gridRows: newRows, gridCells: migrateGridCells(oldCells, layout.gridColumns||2, layout.gridRows||2, layout.gridColumns||2, newRows) });
                                }, 'number')}</div>
                                <span className="details-grid-label">Gap</span><div className="details-grid-control">{ti(layout.gridGap,'8px',v=>handleUpdateLayout(selectedContainerId,{gridGap:v}))}</div>
                                <span className="details-grid-label">Direction</span><div className="details-grid-control">{sb(['horizontal','vertical'], layout.gridMergeDirection || 'horizontal', v => handleUpdateLayout(selectedContainerId, { gridMergeDirection: v }))}</div>
                              </>) : layout.layoutType === 'flex' ? (<>
                                <span className="details-grid-label">Direction</span><div className="details-grid-control">{sb(['row','column','row-reverse','column-reverse'],layout.flexDirection,v=>handleUpdateLayout(selectedContainerId,{flexDirection:v}))}</div>
                                <span className="details-grid-label">Wrap</span><div className="details-grid-control">{sb(['no wrap','wrap','wrap-reverse'],layout.flexWrap,v=>handleUpdateLayout(selectedContainerId,{flexWrap:v}))}</div>
                                <span className="details-grid-label">Justify</span><div className="details-grid-control">{sb(['flex-start','flex-end','center','space-between','space-around'],layout.justifyContent,v=>handleUpdateLayout(selectedContainerId,{justifyContent:v}))}</div>
                                <span className="details-grid-label">Align</span><div className="details-grid-control">{sb(['flex-start','flex-end','center','baseline','stretch'],layout.alignItems,v=>handleUpdateLayout(selectedContainerId,{alignItems:v}))}</div>
                              </>) : null}
                            </div></div>
                          </div>
                        </TabPanelItem>
                      )}

                      {/* Tab: Slot */}
                      {parentContainer && (
                        <TabPanelItem title="Slot">
                          <div className="details-tab-content">
                            {!isBase && overrides.slot && Object.keys(overrides.slot).length > 0 && (
                              <div style={{ padding: '4px 8px', fontSize: 10, background: tier?.color, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                <span>{tier?.icon} {tier?.label} size overrides active</span>
                                <span style={{ cursor: 'pointer', textDecoration: 'underline' }} onClick={() => handleClearBreakpointOverrides(selectedContainerId, activeTierId)}>clear</span>
                              </div>
                            )}
                            {parentContainer.layout?.layoutType === 'coordinate' ? (
                              <div className="details-section"><div className="details-grid">
                                <span className="details-section-title">Coordinate</span>
                                <span className="details-grid-label">Unit</span><div className="details-grid-control">{sb(['px','%'], (fullContainer.coord||DEFAULT_COORD).unit, v => handleUpdateCoord(selectedContainerId, {unit:v}))}</div>
                                <span className="details-grid-label">Left</span><div className="details-grid-control">{ti((fullContainer.coord||DEFAULT_COORD).left,'—',v=>handleUpdateCoord(selectedContainerId,{left:v===''?'':Number(v)}),'number')}</div>
                                <span className="details-grid-label">Right</span><div className="details-grid-control">{ti((fullContainer.coord||DEFAULT_COORD).right,'—',v=>handleUpdateCoord(selectedContainerId,{right:v===''?'':Number(v)}),'number')}</div>
                                <span className="details-grid-label">Top</span><div className="details-grid-control">{ti((fullContainer.coord||DEFAULT_COORD).top,'—',v=>handleUpdateCoord(selectedContainerId,{top:v===''?'':Number(v)}),'number')}</div>
                                <span className="details-grid-label">Bottom</span><div className="details-grid-control">{ti((fullContainer.coord||DEFAULT_COORD).bottom,'—',v=>handleUpdateCoord(selectedContainerId,{bottom:v===''?'':Number(v)}),'number')}</div>
                                <span className="details-grid-label">Width</span><div className="details-grid-control">{ti((fullContainer.coord||DEFAULT_COORD).width,'—',v=>handleUpdateCoord(selectedContainerId,{width:v===''?'':Number(v)}),'number')}</div>
                                <span className="details-grid-label">Height</span><div className="details-grid-control">{ti((fullContainer.coord||DEFAULT_COORD).height,'—',v=>handleUpdateCoord(selectedContainerId,{height:v===''?'':Number(v)}),'number')}</div>
                                <span className="details-grid-label">Min W</span><div className="details-grid-control">{ti((fullContainer.coord||DEFAULT_COORD).minWidth,'—',v=>handleUpdateCoord(selectedContainerId,{minWidth:v}))}</div>
                                <span className="details-grid-label">Max W</span><div className="details-grid-control">{ti((fullContainer.coord||DEFAULT_COORD).maxWidth,'—',v=>handleUpdateCoord(selectedContainerId,{maxWidth:v}))}</div>
                                <span className="details-grid-label">Min H</span><div className="details-grid-control">{ti((fullContainer.coord||DEFAULT_COORD).minHeight,'—',v=>handleUpdateCoord(selectedContainerId,{minHeight:v}))}</div>
                                <span className="details-grid-label">Max H</span><div className="details-grid-control">{ti((fullContainer.coord||DEFAULT_COORD).maxHeight,'—',v=>handleUpdateCoord(selectedContainerId,{maxHeight:v}))}</div>
                              </div></div>
                            ) : (
                              <div className="details-section"><div className="details-grid">
                                <span className="details-section-title">Slot</span>
                                <span className="details-grid-label">Grow</span><div className="details-grid-control">{sb([0,1,2,3],slot.flexGrow,v=>handleUpdateSlot(selectedContainerId,{flexGrow:v}))}</div>
                                <span className="details-grid-label">Shrink</span><div className="details-grid-control">{sb([0,1,2,3],slot.flexShrink,v=>handleUpdateSlot(selectedContainerId,{flexShrink:v}))}</div>
                                <span className="details-grid-label">Basis</span><div className="details-grid-control">{ti(slot.flexBasis,'auto',v=>handleUpdateSlot(selectedContainerId,{flexBasis:v}))}</div>
                                <span className="details-grid-label">Align Self</span><div className="details-grid-control">{sb(['auto','flex-start','flex-end','center','baseline','stretch'],slot.alignSelf,v=>handleUpdateSlot(selectedContainerId,{alignSelf:v}))}</div>
                                <span className="details-grid-label">Order</span><div className="details-grid-control">{ti(slot.order,'0',v=>handleUpdateSlot(selectedContainerId,{order:v}),'number')}</div>
                                <span className="details-grid-label">Width</span><div className="details-grid-control">{ti(slot.width,'auto',v=>handleUpdateSlot(selectedContainerId,{width:v}))}</div>
                                <span className="details-grid-label">Min W</span><div className="details-grid-control">{ti(slot.minWidth,'0',v=>handleUpdateSlot(selectedContainerId,{minWidth:v}))}</div>
                                <span className="details-grid-label">Max W</span><div className="details-grid-control">{ti(slot.maxWidth,'none',v=>handleUpdateSlot(selectedContainerId,{maxWidth:v}))}</div>
                                <span className="details-grid-label">Height</span><div className="details-grid-control">{ti(slot.height,'auto',v=>handleUpdateSlot(selectedContainerId,{height:v}))}</div>
                                <span className="details-grid-label">Min H</span><div className="details-grid-control">{ti(slot.minHeight,'0',v=>handleUpdateSlot(selectedContainerId,{minHeight:v}))}</div>
                                <span className="details-grid-label">Max H</span><div className="details-grid-control">{ti(slot.maxHeight,'none',v=>handleUpdateSlot(selectedContainerId,{maxHeight:v}))}</div>
                              </div></div>
                            )}
                          </div>
                        </TabPanelItem>
                      )}

                      {/* Tab: Box */}
                      {fullContainer.id !== ROOT_CONTAINER_ID && (
                        <TabPanelItem title="Box">
                          <div className="details-tab-content">
                            <div className="details-section"><div className="details-grid">
                              <span className="details-section-title">Padding</span>
                              <span className="details-grid-label">Top</span><div className="details-grid-control">{ti(slot.paddingTop,'0',v=>handleUpdateSlot(selectedContainerId,{paddingTop:v}))}</div>
                              <span className="details-grid-label">Bottom</span><div className="details-grid-control">{ti(slot.paddingBottom,'0',v=>handleUpdateSlot(selectedContainerId,{paddingBottom:v}))}</div>
                              <span className="details-grid-label">Left</span><div className="details-grid-control">{ti(slot.paddingLeft,'0',v=>handleUpdateSlot(selectedContainerId,{paddingLeft:v}))}</div>
                              <span className="details-grid-label">Right</span><div className="details-grid-control">{ti(slot.paddingRight,'0',v=>handleUpdateSlot(selectedContainerId,{paddingRight:v}))}</div>
                            </div></div>
                            <div className="details-section"><div className="details-grid">
                              <span className="details-section-title">Margin</span>
                              <span className="details-grid-label">Top</span><div className="details-grid-control">{ti(slot.marginTop,'0',v=>handleUpdateSlot(selectedContainerId,{marginTop:v}))}</div>
                              <span className="details-grid-label">Bottom</span><div className="details-grid-control">{ti(slot.marginBottom,'0',v=>handleUpdateSlot(selectedContainerId,{marginBottom:v}))}</div>
                              <span className="details-grid-label">Left</span><div className="details-grid-control">{ti(slot.marginLeft,'0',v=>handleUpdateSlot(selectedContainerId,{marginLeft:v}))}</div>
                              <span className="details-grid-label">Right</span><div className="details-grid-control">{ti(slot.marginRight,'0',v=>handleUpdateSlot(selectedContainerId,{marginRight:v}))}</div>
                            </div></div>
                            <div className="details-section"><div className="details-grid">
                              <span className="details-section-title">Border</span>
                              <span className="details-grid-label">Width</span><div className="details-grid-control">{ti(slot.borderWidth,'1px',v=>handleUpdateSlot(selectedContainerId,{borderWidth:v}))}</div>
                              <span className="details-grid-label">Style</span><div className="details-grid-control">{sb(['','solid','dashed','dotted','double','none'],slot.borderStyle,v=>handleUpdateSlot(selectedContainerId,{borderStyle:v}))}</div>
                              <span className="details-grid-label">Color</span><div className="details-grid-control">{ti(slot.borderColor,'#e0e0e0',v=>handleUpdateSlot(selectedContainerId,{borderColor:v}))}</div>
                              <span className="details-grid-label">Radius</span><div className="details-grid-control">{ti(slot.borderRadius,'0',v=>handleUpdateSlot(selectedContainerId,{borderRadius:v}))}</div>
                            </div></div>
                            <div className="details-section"><div className="details-grid">
                              <span className="details-section-title">Background</span>
                              <span className="details-grid-label">Color</span><div className="details-grid-control">{ti(slot.backgroundColor,'',v=>handleUpdateSlot(selectedContainerId,{backgroundColor:v}))}</div>
                              <span className="details-grid-label">Image</span><div className="details-grid-control">{ti(slot.backgroundImage,'url(...)',v=>handleUpdateSlot(selectedContainerId,{backgroundImage:v}))}</div>
                              <span className="details-grid-label">Size</span><div className="details-grid-control">{sb(['','cover','contain','auto','100% 100%'],slot.backgroundSize,v=>handleUpdateSlot(selectedContainerId,{backgroundSize:v}))}</div>
                              <span className="details-grid-label">Position</span><div className="details-grid-control">{sb(['','center','top','bottom','left','right','top left','top right','bottom left','bottom right'],slot.backgroundPosition,v=>handleUpdateSlot(selectedContainerId,{backgroundPosition:v}))}</div>
                              <span className="details-grid-label">Repeat</span><div className="details-grid-control">{sb(['','no-repeat','repeat','repeat-x','repeat-y'],slot.backgroundRepeat,v=>handleUpdateSlot(selectedContainerId,{backgroundRepeat:v}))}</div>
                            </div></div>
                            <div className="details-section"><div className="details-grid">
                              <span className="details-section-title">Typography</span>
                              <span className="details-grid-label">Color</span><div className="details-grid-control">{ti(slot.color,'inherit',v=>handleUpdateSlot(selectedContainerId,{color:v}))}</div>
                              <span className="details-grid-label">Font Size</span><div className="details-grid-control">{ti(slot.fontSize,'',v=>handleUpdateSlot(selectedContainerId,{fontSize:v}))}</div>
                              <span className="details-grid-label">Font Weight</span><div className="details-grid-control">{sb(['','normal','bold','100','200','300','400','500','600','700','800','900'],slot.fontWeight,v=>handleUpdateSlot(selectedContainerId,{fontWeight:v}))}</div>
                              <span className="details-grid-label">Font Family</span><div className="details-grid-control">{ti(slot.fontFamily,'',v=>handleUpdateSlot(selectedContainerId,{fontFamily:v}))}</div>
                              <span className="details-grid-label">Line Height</span><div className="details-grid-control">{ti(slot.lineHeight,'',v=>handleUpdateSlot(selectedContainerId,{lineHeight:v}))}</div>
                              <span className="details-grid-label">Text Align</span><div className="details-grid-control">{sb(['','left','center','right','justify'],slot.textAlign,v=>handleUpdateSlot(selectedContainerId,{textAlign:v}))}</div>
                              <span className="details-grid-label">Letter Spacing</span><div className="details-grid-control">{ti(slot.letterSpacing,'',v=>handleUpdateSlot(selectedContainerId,{letterSpacing:v}))}</div>
                            </div></div>
                          </div>
                        </TabPanelItem>
                      )}

                      {/* Tab: General — always last */}
                      <TabPanelItem title="General">
                        <div className="details-tab-content">
                          {/* Visibility — shown in non-base tiers */}
                          {!isBase && (
                            <div className="details-section">
                              <div className="details-grid">
                                <span className="details-section-title" style={{ color: tier?.color }}>
                                  {tier?.icon} {tier?.label} Visibility
                                </span>
                                <span className="details-grid-label">Visible</span>
                                <div className="details-grid-control">
                                  <button
                                    className={`focus-mode-btn${isHidden ? '' : ' focus-mode-btn--active'}`}
                                    style={{ width: '100%', justifyContent: 'center' }}
                                    onClick={() => handleToggleVisibility(selectedContainerId, activeTierId)}
                                  >
                                    {isHidden ? '👁 Hidden' : '👁 Visible'}
                                  </button>
                                </div>
                                {hasOverrides && (
                                  <>
                                    <span className="details-grid-label">Overrides</span>
                                    <div className="details-grid-control">
                                      <button className="focus-mode-btn" style={{ color: '#d00', borderColor: '#d00', width: '100%', fontSize: 10 }}
                                        onClick={() => handleClearBreakpointOverrides(selectedContainerId, activeTierId)}>
                                        Clear {tier?.label} overrides
                                      </button>
                                    </div>
                                  </>
                                )}
                              </div>
                            </div>
                          )}
                          <div className="details-section">
                            <div className="details-grid">
                              <span className="details-section-title">Identity</span>
                              <span className="details-grid-label">Name</span>
                              <div className="details-grid-control">
                                <input className="details-input" value={found.title} onChange={(e) => { const s = toHtmlId(e.target.value); if (s) handleRenameContainer(selectedContainerId, s); }} />
                              </div>
                              {parentContainer && (<>
                                <span className="details-grid-label">Parent</span>
                                <div className="details-grid-control"><span style={{ fontSize: 11, color: '#555' }}>{parentContainer.title}</span></div>
                                <span className="details-grid-label">Parent Layout</span>
                                <div className="details-grid-control"><span style={{ fontSize: 11, color: parentContainer.layout?.layoutType === 'coordinate' ? '#0078d4' : '#555', fontWeight: 600 }}>{parentContainer.layout?.layoutType || 'flex'}</span></div>
                              </>)}
                            </div>
                          </div>
                          {fullContainer.id === ROOT_CONTAINER_ID && (
                            <div className="details-section">
                              <div className="details-grid">
                                <span className="details-section-title">Page</span>
                                <span className="details-grid-label">Type</span>
                                <div className="details-grid-control">{sb(['fit','fixed','vertical fixed','horizontal fixed'], fullContainer.pageType || 'fit', v => setContainers(prev => updatePageTypeInTree(prev, selectedContainerId, v)))}</div>
                              </div>
                            </div>
                          )}
                        </div>
                      </TabPanelItem>

                    </TabPanel>
                  </div>
                );
              })()}
            </div>
          </SplitterItem>
        </Splitter>
        )}
      </div>

      <Popup
        visible={popupVisible}
        onHiding={closeWizard}
        title="Create"
        width="90vw"
        height="90vh"
        showCloseButton={false}
        hideOnOutsideClick={false}
        dragEnabled={false}
        contentRender={() => (
          <WizardContent
            currentStep={currentStep}
            selectedAssetIds={selectedAssetIds}
            onAssetsSelected={setSelectedAssetIds}
            selectedTags={selectedTags}
            onTagsChanged={setSelectedTags}
          />
        )}
      >
        <ToolbarItem
          widget="dxButton"
          toolbar="bottom"
          location="before"
          options={{ text: 'Cancel', stylingMode: 'outlined', onClick: closeWizard }}
        />
        {currentStep > 0 && (
          <ToolbarItem
            widget="dxButton"
            toolbar="bottom"
            location="after"
            options={{ text: 'Back', stylingMode: 'outlined', onClick: handleBack }}
          />
        )}
        <ToolbarItem
          widget="dxButton"
          toolbar="bottom"
          location="after"
          options={{
            text: isLastStep ? 'Save' : 'Next',
            type: isLastStep ? 'success' : 'default',
            stylingMode: 'contained',
            onClick: handleNext,
          }}
        />
      </Popup>
    </div>
  );
}
