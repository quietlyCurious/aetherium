(function () {
  "use strict";

  var element = EMBED.getRootElement();

  var setColor = function(value, defaultColor) {
    var color;
    if (value && value.hasOwnProperty('hex')) { color = value; }
    else { color = value ? JSON.parse(value) : defaultColor; }
    var opacity = Math.round(parseFloat(color.rgb.a) * 255);
    opacity = ('00' + opacity.toString(16)).slice(-2);
    return color.hex + opacity;
  };

  // Custom Formatter to enforce "MM/DD/YYYY HH:mm:ss"
  var formatDateTime = function(dateObj, displayMode) {
    var pad = function(num) { return (num < 10 ? '0' : '') + num; };
    
    var MM = pad(dateObj.getMonth() + 1);
    var DD = pad(dateObj.getDate());
    var YYYY = dateObj.getFullYear();
    
    var HH = pad(dateObj.getHours()); // 24-hour clock
    var mm = pad(dateObj.getMinutes());
    var ss = pad(dateObj.getSeconds());

    if (displayMode === 'Time') {
      return HH + ":" + mm + ":" + ss;
    }
    return MM + "/" + DD + "/" + YYYY + " " + HH + ":" + mm + ":" + ss;
  };

  // State Trackers to prevent global state flooding
  var lastStartVal = null;
  var lastEndVal = null;

  var updateTimes = function() {
    // 1. Memory Leak Prevention
    if (!document.body.contains(element[0])) {
      if (element[0].customTimerId) clearInterval(element[0].customTimerId);
      return;
    }

    // 2. Fetch latest config dynamically so it never goes stale when edited
    var data = EMBED.getComponent().schema.data;
    var timeConfig = data.timeConfig || {};
    var outputs = data.outputs || {};
    var styling = data.styling || {};
    
    // 3. UI Styling
    var containerElem = element.find("#iTimeDisplay");
    containerElem[0].style.color = setColor(styling.fontColor, {hex:"#000000",rgb:{a:1}});
    containerElem[0].style.backgroundColor = setColor(styling.backgroundColor, {hex:"#FFFFFF",rgb:{a:1}});
    containerElem[0].style.fontSize = (styling.fontSize || 14) + "px";

    var displayMode = timeConfig.displayMode || 'DateTime';
    var rangeValue = timeConfig.rangeValue || 1;
    var rangeInterval = timeConfig.rangeInterval || 'Hours';

    // 4. Calculate Times
    var endTime = new Date();
    var startTime = new Date(endTime.getTime());

    if (rangeInterval === 'Hours') {
      startTime.setHours(startTime.getHours() - rangeValue);
    } else if (rangeInterval === 'Minutes') {
      startTime.setMinutes(startTime.getMinutes() - rangeValue);
    } else if (rangeInterval === 'Seconds') {
      startTime.setSeconds(startTime.getSeconds() - rangeValue);
    }

    // 5. Generate Specifically Formatted Strings
    var startUiStr = formatDateTime(startTime, displayMode);
    var endUiStr = formatDateTime(endTime, displayMode);
    
    // 6. Update Widget UI
    element.find("#iStart").text(startUiStr);
    element.find("#iEnd").text(endUiStr);

    // Helper to push data using the correct platform method
    var pushOutput = function(targetField, val) {
      if (!targetField) return;
      
      if (typeof EMBED.submitTarget === "function") {
        EMBED.submitTarget(targetField, val);
      } else if (EMBED.fieldTypeIsGlobal && EMBED.fieldTypeIsGlobal(targetField)) {
        EMBED.setGlobalData(targetField, val);
      } else if (typeof EMBED.writeData === "function") {
        EMBED.writeData(targetField, val);
      }
    };

    // 7. Throttled Global Pushes (Only push if the exact second changed)
    if (lastStartVal !== startUiStr) {
      pushOutput(outputs.startTarget, startUiStr);
      lastStartVal = startUiStr;
    }

    if (lastEndVal !== endUiStr) {
      // Small 50ms buffer to safely separate the dispatches
      setTimeout(function() { 
        pushOutput(outputs.endTarget, endUiStr); 
      }, 50);
      lastEndVal = endUiStr;
    }
  };

  // Initialization & Cleanup
  if (element[0].customTimerId) {
    clearInterval(element[0].customTimerId);
  }

  var initialData = EMBED.getComponent().schema.data;
  var refreshInterval = (initialData.timeConfig && initialData.timeConfig.refreshInterval) ? initialData.timeConfig.refreshInterval : 1000;

  updateTimes(); // Run once immediately
  element[0].customTimerId = setInterval(updateTimes, refreshInterval);

})();