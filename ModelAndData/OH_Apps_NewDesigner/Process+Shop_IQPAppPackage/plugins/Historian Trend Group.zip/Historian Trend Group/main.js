(function () {
  /*jshint multistr: true */
  "use strict";

  console.log('HistorianTrendGroup plugin');

  var element = EMBED.getRootElement(),
      data    = EMBED.getComponent().schema.data;

  var setColor = function(value, defaultColor)
  {
    var color;
    if (value && value.hasOwnProperty('hex'))
    {
      color = value;
    }
    else
    {
      color = value ? JSON.parse(value) : defaultColor;
    }
    var opacity = Math.round(parseFloat(color.rgb.a) * 255);
    opacity = opacity.toString(16);
    opacity = ('00' + opacity).slice(-2);

    return color.hex + opacity;
  };

  const BLACK  = {hex:"#000000",rgb:{a:1}},
        GRAY   = {hex:"#9b9b9b",rgb:{a:1}},
        DARK   = {hex:"#333333",rgb:{a:1}},
        YELLOW = {hex:"#FFFF00",rgb:{a:1}},
        WHITE  = {hex:"#FFFFFF",rgb:{a:1}},
        CLEAR  = {hex:"#FFFFFF00",rgb:{a:0}};

  var SVG_NS = 'http://www.w3.org/2000/svg';

  var TIMESTAMP_FIELD_CANDIDATES = ['timestamp','t_stamp','tstamp','ts','time','datetime','Timestamp','TStamp','DateTime'];

  var filterRowsByDuration = function(rows, durationMinutes)
  {
    if (!durationMinutes || durationMinutes <= 0 || !rows.length) { return rows; }

    var tsField = TIMESTAMP_FIELD_CANDIDATES.filter(function(name) { return rows[0].hasOwnProperty(name); })[0];
    if (!tsField) { return rows; }

    var cutoff = Date.now() - (durationMinutes * 60000);
    var filtered = rows.filter(function(row)
    {
      var t = new Date(row[tsField]).getTime();
      return !isNaN(t) && t >= cutoff;
    });

    return filtered.length ? filtered : rows;
  };

  var containerElem       = element.find("#iContainer");
  var trendsContainerElem = element.find("#trendsContainer");

  var trends = data.trends || [];
  var layout = data.layout || {};
  var stackDirection  = layout.stackDirection || 'horizontal';
  var gap             = (typeof layout.gap === 'number') ? layout.gap : 2;
  var decimalPlaces   = (typeof layout.decimalPlaces === 'number') ? layout.decimalPlaces : 1;

  var styling = data.styling || {};
  var backgroundColor       = setColor(styling.backgroundColor, CLEAR);
  var normalColor            = setColor(styling.chartBackgroundColor, GRAY);
  var outerColor             = setColor(styling.outerColor, WHITE);
  var outOfRangeColor        = setColor(styling.outOfRangeColor, YELLOW);
  var lineColor                 = setColor(styling.lineColor, DARK);
  var fontColor                  = setColor(styling.fontColor, BLACK);
  var fontSize                       = styling.fontSize || 12;
  var fontFamily                     = styling.fontFamily || 'Arial';

  containerElem[0].style.width = "100%";
  containerElem[0].style.height = "100%";
  containerElem[0].style.color = fontColor;
  containerElem[0].style.backgroundColor = backgroundColor;
  containerElem[0].style.fontSize = fontSize.toString() + "pt";
  containerElem[0].style.fontFamily = fontFamily;

  trendsContainerElem[0].style.width = "100%";
  trendsContainerElem[0].style.height = "100%";
  trendsContainerElem[0].style.flexWrap = "nowrap"; 
  trendsContainerElem[0].style.flexDirection = (stackDirection === 'vertical') ? "column" : "row";

  var VIEWBOX_W = 1000;
  var VIEWBOX_H = 1000;

  var renderSparkline = function(svgElem, values, scaleMin, scaleMax, lowerLimit, upperLimit)
  {
    while (svgElem.firstChild) { svgElem.removeChild(svgElem.firstChild); }

    if (!values.length) { return; }

    var axisMin = (typeof scaleMin === 'number') ? scaleMin : Math.min.apply(null, values);
    var axisMax = (typeof scaleMax === 'number') ? scaleMax : Math.max.apply(null, values);
    axisMin = Math.min(axisMin, Math.min.apply(null, values));
    axisMax = Math.max(axisMax, Math.max.apply(null, values));
    if (typeof lowerLimit === 'number') { axisMin = Math.min(axisMin, lowerLimit); }
    if (typeof upperLimit === 'number') { axisMax = Math.max(axisMax, upperLimit); }
    if (axisMin === axisMax) { axisMin -= 1; axisMax += 1; }

    var toX = function(i) { return (values.length === 1) ? 0 : (i / (values.length - 1)) * VIEWBOX_W; };
    var toY = function(v) { return VIEWBOX_H - ((v - axisMin) / (axisMax - axisMin)) * VIEWBOX_H; };

    var drawBand = function(y1, y2, color)
    {
      if (y2 <= y1) { return; }
      var rect = document.createElementNS(SVG_NS, 'rect');
      rect.setAttribute('x', 0);
      rect.setAttribute('y', y1);
      rect.setAttribute('width', VIEWBOX_W);
      rect.setAttribute('height', y2 - y1);
      rect.setAttribute('fill', color);
      svgElem.appendChild(rect);
    };

    var hasLower = (typeof lowerLimit === 'number');
    var hasUpper = (typeof upperLimit === 'number');

    // Trigger full warning state if ANY point violates either limit
    var isBreached = false;
    for (var k = 0; k < values.length; k++) {
      if ((hasLower && values[k] < lowerLimit) || (hasUpper && values[k] > upperLimit)) {
        isBreached = true;
        break;
      }
    }

    if (hasLower || hasUpper)
    {
      var lowerBound = hasLower ? lowerLimit : axisMin;
      var upperBound = hasUpper ? upperLimit : axisMax;

      // Both outer bands show warning color if breached
      drawBand(0, toY(upperBound), isBreached ? outOfRangeColor : outerColor);
      drawBand(toY(upperBound), toY(lowerBound), normalColor);
      drawBand(toY(lowerBound), VIEWBOX_H, isBreached ? outOfRangeColor : outerColor);
    }
    else
    {
      drawBand(0, VIEWBOX_H, normalColor);
    }

    var points = values.map(function(v, i) { return toX(i) + ',' + toY(v); }).join(' ');
    var polyline = document.createElementNS(SVG_NS, 'polyline');
    polyline.setAttribute('points', points);
    polyline.setAttribute('fill', 'none');
    polyline.setAttribute('stroke', lineColor);
    // Adjusted thickness to 2 physical screen pixels to prevent giant lines
    polyline.setAttribute('stroke-width', '2'); 
    polyline.setAttribute('vector-effect', 'non-scaling-stroke'); 
    svgElem.appendChild(polyline);
  };

  var buildTrend = function(trendConfig)
  {
    var title      = (typeof trendConfig.title === 'string') ? trendConfig.title : 'Tag';
    var units       = (typeof trendConfig.units === 'string') ? trendConfig.units : '';
    var scaleMin     = (typeof trendConfig.scaleMin === 'number') ? trendConfig.scaleMin : 0;
    var scaleMax      = (typeof trendConfig.scaleMax === 'number') ? trendConfig.scaleMax : 100;
    var lowerLimit     = (typeof trendConfig.lowerLimit === 'number') ? trendConfig.lowerLimit : undefined;
    var upperLimit      = (typeof trendConfig.upperLimit === 'number') ? trendConfig.upperLimit : undefined;
    var durationMinutes  = (typeof trendConfig.durationMinutes === 'number') ? trendConfig.durationMinutes : 0;

    var unit       = $('<div class="i_trendUnit"></div>');
    var titleElem  = $('<div class="i_trendTitle" style="overflow:hidden; text-overflow:ellipsis;"></div>');
    var chartBox    = $('<div class="i_trendChartBox"></div>');

    unit.append(titleElem, chartBox);
    unit[0].style.flex = "1 1 0"; 
    
    // Apply layout direction margins and constraints
    if (stackDirection === 'vertical') {
      unit[0].style.marginBottom = gap + "%";
      unit[0].style.minHeight = "0"; 
      unit[0].style.width = "100%"; 
    } else {
      unit[0].style.marginRight = gap + "%";
      unit[0].style.minWidth = "0"; 
    }

    trendsContainerElem.append(unit);

    chartBox[0].style.width  = "100%";
    chartBox[0].style.flex = "1 1 auto"; 
    chartBox[0].style.backgroundColor = outerColor;
    chartBox[0].style.position = "relative"; 

    var svgElem = document.createElementNS(SVG_NS, 'svg');
    svgElem.setAttribute('viewBox', '0 0 ' + VIEWBOX_W + ' ' + VIEWBOX_H);
    svgElem.setAttribute('preserveAspectRatio', 'none');
    svgElem.style.position = "absolute";
    svgElem.style.top = "0";
    svgElem.style.left = "0";
    svgElem.style.width = "100%";
    svgElem.style.height = "100%";
    chartBox[0].appendChild(svgElem);

    var setTitle = function(currentValue)
    {
      var valueStr = (typeof currentValue === 'number' && !isNaN(currentValue)) ? currentValue.toFixed(decimalPlaces) : '--';
      titleElem.text(title + (valueStr !== '--' ? (' ' + valueStr + (units ? (' ' + units) : '')) : ''));
      titleElem.attr('title', titleElem.text()); 
    };

    var updateFromSeries = function(values)
    {
      renderSparkline(svgElem, values, scaleMin, scaleMax, lowerLimit, upperLimit);
      setTitle(values.length ? values[values.length - 1] : NaN);
    };

    var updateFromScalar = function(rawValue)
    {
      var value = parseFloat(rawValue);
      renderSparkline(svgElem, isNaN(value) ? [] : [value, value], scaleMin, scaleMax, lowerLimit, upperLimit);
      setTitle(value);
    };

    var seriesTag = trendConfig.seriesTag;
    if (!seriesTag) { setTitle(NaN); return; }

    var formulaFirstTime = true;
    if ((seriesTag.type === 'formula') && formulaFirstTime)
    {
      updateFromScalar(seriesTag.formula.data.value[0].value);
      formulaFirstTime = false;
    }

    if (seriesTag.type === 'manual')
    {
      updateFromScalar(seriesTag.manual);
    }
    else if (EMBED.fieldTypeIsGlobal(seriesTag))
    {
      var value = EMBED.getGlobalData(seriesTag);
      updateFromScalar(value);

      EMBED.subscribeFieldToGlobalChange(seriesTag, function(d)
      {
        updateFromScalar(d);
      });
    }
    else if (EMBED.fieldTypeIsQuery(seriesTag))
    {
      EMBED.subscribeFieldToQueryChange(seriesTag, function(rows)
      {
        var windowedRows = filterRowsByDuration(rows, durationMinutes);
        var fieldName = EMBED.getQueryOutput(seriesTag)[0].fieldName;
        var values = windowedRows.map(function(row) { return parseFloat(row[fieldName]); }).filter(function(v) { return !isNaN(v); });
        updateFromSeries(values);
      });
    }
    else if (EMBED.fieldTypeIsFormula(seriesTag))
    {
      var fVal = EMBED.getFormulaData(seriesTag);
      updateFromScalar(fVal);
      EMBED.subscribeFieldToFormulaChange(seriesTag, function(d)
      {
        updateFromScalar(d);
      });
    }
  };

  trends.forEach(function(trendConfig)
  {
    buildTrend(trendConfig);
  });
})();