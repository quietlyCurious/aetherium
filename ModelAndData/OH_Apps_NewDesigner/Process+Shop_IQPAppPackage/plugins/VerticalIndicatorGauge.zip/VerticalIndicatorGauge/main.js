(function () {
    /*jshint multistr: true */
    "use strict";

    var element = EMBED.getRootElement();
    var data = EMBED.getComponent().schema.data;
    var containerElem = element.find("#multi-gauge-container");
    
    if (containerElem.length === 0) {
        element.append('<div id="multi-gauge-container" class="multi-gauge-container"></div>');
        containerElem = element.find("#multi-gauge-container");
    }
    var container = containerElem[0];

    function parseColor(colorObj, defaultHex) {
        if (!colorObj) return defaultHex;
        if (typeof colorObj === 'string') {
            try {
                var parsed = JSON.parse(colorObj);
                return parsed.hex || defaultHex;
            } catch (e) { return defaultHex; }
        }
        return colorObj.hex || defaultHex;
    }

    class IndicatorModule {
        constructor(parentContainer, configObj, globalFontConfig, layoutConfig) {
            this.config = configObj || {};
            this.globalFontConfig = globalFontConfig || {};
            this.layoutConfig = layoutConfig || {};
            this.name = this.config.name || "TAG";
            this.state = { val: null, min: null, max: null, fh: null, ah: null, ch: null, cl: null, al: null, fl: null };
            
            this.colors = {
                fault: parseColor(this.config.faultColor, "#ef4444"),
                alarm: parseColor(this.config.alarmColor, "#eab308"),
                warn: parseColor(this.config.warnColor, "#e2e2e2"),
                normal: parseColor(this.config.normalColor, "#e2e2e2"),
                track: parseColor(this.config.trackColor, "#bfbfbf"),
                arrowNormal: "#475569"
            };

            this.wrapper = document.createElement('div');
            this.wrapper.className = 'indicator-wrapper';
            
            this.svgContainer = document.createElement('div');
            this.svgContainer.style.width = "100%";
            this.svgContainer.style.height = "100%";
            this.svgContainer.style.position = "relative"; 
            this.svgContainer.style.display = "flex";
            this.svgContainer.style.justifyContent = "center";
            
            this.wrapper.appendChild(this.svgContainer);
            parentContainer.appendChild(this.wrapper);

            this.resizePending = false;
            this.resizeObserver = new ResizeObserver(() => {
                if (!this.resizePending) {
                    this.resizePending = true;
                    requestAnimationFrame(() => {
                        this.render();
                        this.resizePending = false;
                    });
                }
            });
            this.resizeObserver.observe(this.wrapper);

            this.initBindings();
        }

        getActiveColor() {
            let color = this.colors.arrowNormal;
            if (this.state.ah !== null && this.state.val > this.state.ah) color = this.colors.alarm;
            if (this.state.fh !== null && this.state.val > this.state.fh) color = this.colors.fault;
            if (this.state.al !== null && this.state.val < this.state.al) color = this.colors.alarm;
            if (this.state.fl !== null && this.state.val < this.state.fl) color = this.colors.fault;
            return color;
        }

        render() {
            const rect = this.wrapper.getBoundingClientRect();
            const w = Math.max(rect.width || 60, 40); 
            const h = Math.max(rect.height || 400, 200);

            const fontFamily = this.globalFontConfig.fontFamily || "Helvetica, Arial, sans-serif";
            const typoStyle = (this.globalFontConfig.typographyStyle || "bold").toLowerCase();
            const fontWeight = typoStyle.includes("bold") ? "bold" : "normal"; 
            const fontStyle = typoStyle.includes("italic") ? "italic" : "normal";
            const orientation = this.layoutConfig.labelOrientation || "vertical";

            const trackWidth = Math.max(10, Math.min(24, w * 0.22));

            // Increased base font bounds slightly for better readability on small screens
            const valFontSize = Math.max(13, Math.min(18, trackWidth * 1.1));

            // Slightly reduced arrow/icon proportions (was 1.2 / 0.8 of trackWidth)
            const aw = Math.max(8, trackWidth * 0.95);
            const ah = Math.max(6, trackWidth * 0.65);

            // Label font now scales with widget width (bounded) instead of staying fixed/tiny
            const averageCharAspectRatio = 0.60;
            const configuredLabelFontSize = parseInt(this.globalFontConfig.fontSize, 10) || 11;
            const labelFontSize = Math.max(configuredLabelFontSize, Math.min(15, w * 0.16));

            // Dynamically scale top padding so the text doesn't clip when the arrow is at maximum height
            const padTop = Math.max(valFontSize + (ah / 2) + 4, Math.min(30, h * 0.1));

            // Baseline 20% label / 80% gauge split (issue #7), but grows (capped at 35%) only
            // when the rotated label genuinely needs more room, so long names never get clipped.
            let padBottom;
            if (orientation === "vertical") {
                const estLabelPixelLength = (this.name ? this.name.length : 0) * labelFontSize * averageCharAspectRatio + (ah / 2) + 10;
                padBottom = Math.min(h * 0.35, Math.max(h * 0.20, estLabelPixelLength));
            } else {
                padBottom = h * 0.20;
            }
            const trackHeight = h - padTop - padBottom;
            const trackX = w * 0.55; 
            const botY = h - padBottom;
            const topY = padTop;

            const safeMin = this.state.min !== null ? this.state.min : 0;
            const safeMax = this.state.max !== null ? this.state.max : 100;
            const range = (safeMax - safeMin === 0) ? 1 : (safeMax - safeMin);

            const getY = (val) => {
                const ratio = Math.max(0, Math.min(1, (val - safeMin) / range));
                return botY - (ratio * trackHeight); 
            };

            let fhC = this.colors.track, ahC = this.colors.track, chC = this.colors.normal, clC = this.colors.normal, calC = this.colors.normal, alC = this.colors.track, flC = this.colors.track;
            let arrowC = this.getActiveColor();

            if (this.state.ah !== null && this.state.val !== null && this.state.val > this.state.ah) ahC = this.colors.alarm;
            if (this.state.fh !== null && this.state.val !== null && this.state.val > this.state.fh) { fhC = this.colors.fault; ahC = this.colors.alarm; }
            if (this.state.al !== null && this.state.val !== null && this.state.val < this.state.al) alC = this.colors.alarm;
            if (this.state.fl !== null && this.state.val !== null && this.state.val < this.state.fl) { flC = this.colors.fault; alC = this.colors.alarm; }

            const fhY = this.state.fh !== null ? getY(this.state.fh) : topY;
            const ahY = this.state.ah !== null ? getY(this.state.ah) : fhY;
            const chY = this.state.ch !== null ? getY(this.state.ch) : ahY; 
            const clY = this.state.cl !== null ? getY(this.state.cl) : chY; 
            const alY = this.state.al !== null ? getY(this.state.al) : clY;
            const flY = this.state.fl !== null ? getY(this.state.fl) : alY;

            let svg = `<svg viewBox="0 0 ${w} ${h}" width="100%" height="100%" style="overflow: visible; text-rendering: optimizeLegibility;">`;

            const drawSeg = (startY, endY, color) => {
                if (endY > startY) svg += `<rect x="${trackX}" y="${startY}" width="${trackWidth}" height="${endY - startY}" fill="${color}" stroke="#1e293b" stroke-width="1" />`;
            };

            drawSeg(topY, fhY, fhC); 
            drawSeg(fhY, ahY, ahC); 
            drawSeg(ahY, chY, chC); 
            drawSeg(chY, clY, clC); 
            drawSeg(clY, alY, calC); 
            drawSeg(alY, flY, alC); 
            drawSeg(flY, botY, flC);

            [fhY, ahY, chY, clY, alY, flY].forEach(yPos => {
                if(yPos > topY && yPos < botY) svg += `<line x1="${trackX}" y1="${yPos}" x2="${trackX + trackWidth}" y2="${yPos}" stroke="#0f172a" stroke-width="1.5" />`;
            });

            const hasValue = this.state.val !== null;
            let arrowY = botY; 
            let displayVal = "";
            
            if (hasValue) {
                arrowY = Math.max(topY, Math.min(botY, getY(this.state.val)));
                displayVal = Number.isInteger(this.state.val) ? this.state.val : this.state.val.toFixed(1);
            }
            
            const centerX = trackX + (trackWidth / 2);
            
            // Text is now positioned above the arrow (-Y offset) instead of beside it
            const valSVG = hasValue 
                ? `<text x="-4" y="-${(ah/2) + 4}" font-family="${fontFamily}" fill="#334155" font-size="${valFontSize}px" font-weight="${fontWeight}" text-anchor="end">${displayVal}</text>` 
                : ``;

            const labelStartY = botY + (ah / 2) + 4; 
            let labelGroup = '';

            const availableLabelSpaceY = Math.max(0, padBottom - (ah / 2) - 4);
            const availableLabelSpaceX = Math.max(0, w - 4);

            let lines = [];

            if (orientation === "vertical") {
                lines = [this.name];
            } else {
                let maxSpace = availableLabelSpaceX;
                let maxCharsPerLine = Math.max(1, Math.floor(maxSpace / (labelFontSize * averageCharAspectRatio)));

                const wrapText = (text, maxChars) => {
                    if (!text) return [""];
                    const splitWords = text.split(' ');
                    const linesArr = [];
                    let currentLine = '';

                    for (let word of splitWords) {
                        if (word.length > maxChars) {
                            if (currentLine) {
                                linesArr.push(currentLine.trim());
                                currentLine = '';
                            }
                            let remaining = word;
                            while (remaining.length > maxChars) {
                                linesArr.push(remaining.substring(0, maxChars));
                                remaining = remaining.substring(maxChars);
                            }
                            currentLine = remaining;
                        } 
                        else if ((currentLine + ' ' + word).trim().length > maxChars && currentLine.length > 0) {
                            linesArr.push(currentLine.trim());
                            currentLine = word;
                        } else {
                            currentLine = currentLine ? currentLine + ' ' + word : word;
                        }
                    }
                    if (currentLine) linesArr.push(currentLine.trim());
                    return linesArr;
                };
                
                lines = wrapText(this.name, maxCharsPerLine);
            }

            const lineHeight = labelFontSize * 1.15;
            let tspans = '';

            if (orientation === "vertical") {
                lines.forEach((line, index) => {
                    let yOffset = ( - (lines.length - 1) / 2 + index ) * lineHeight;
                    tspans += `<tspan x="0" y="${yOffset}">${line}</tspan>`;
                });
                labelGroup = `
                <g transform="translate(${centerX}, ${labelStartY}) rotate(90)">
                    <text font-family="${fontFamily}" fill="#1e293b" font-size="${labelFontSize}px" font-weight="${fontWeight}" font-style="${fontStyle}" letter-spacing="0.5" text-anchor="start" dominant-baseline="central">${tspans}</text>
                </g>`;
            } else {
                lines.forEach((line, index) => {
                    let yOffset = index * lineHeight;
                    tspans += `<tspan x="0" y="${yOffset}">${line}</tspan>`;
                });
                labelGroup = `
                <g transform="translate(${centerX}, ${labelStartY})">
                    <text font-family="${fontFamily}" fill="#1e293b" font-size="${labelFontSize}px" font-weight="${fontWeight}" font-style="${fontStyle}" letter-spacing="0.5" text-anchor="middle" dominant-baseline="hanging">${tspans}</text>
                </g>`;
            }

            svg += `
            <g transform="translate(${trackX}, ${arrowY})">
                <polygon points="-${aw},-${ah/2} 0,0 -${aw},${ah/2}" fill="${arrowC}" stroke="#475569" stroke-width="1"/>
                ${valSVG}
            </g>
            ${labelGroup}
            </svg>`;

            this.svgContainer.innerHTML = svg;
        }

        initBindings() {
            let renderPending = false;
            const handleUpdate = (key, val) => {
                let parsed = parseFloat(val);
                this.state[key] = isNaN(parsed) ? null : parsed;
                if (!renderPending) {
                    renderPending = true;
                    requestAnimationFrame(() => {
                        this.render();
                        renderPending = false;
                    });
                }
            };

            const bindDS = (field, key) => {
                if (field !== undefined && field !== null && (typeof field === 'number' || typeof field === 'string')) {
                    handleUpdate(key, field);
                    return;
                }

                if (!field || typeof field !== 'object') return;

                try {
                    if (field.type === 'manual') {
                        handleUpdate(key, field.manual);
                    } else if (EMBED.fieldTypeIsGlobal(field)) {
                        handleUpdate(key, EMBED.getGlobalData(field));
                        EMBED.subscribeFieldToGlobalChange(field, (v) => handleUpdate(key, v));
                    } else if (EMBED.fieldTypeIsQuery(field)) {
                        EMBED.subscribeFieldToQueryChange(field, (rows) => {
                            if (rows && rows.length > 0) {
                                var out = EMBED.getQueryOutput(field);
                                if (out && out.length > 0) handleUpdate(key, rows[0][out[0].fieldName]);
                            }
                        });
                    } else if (EMBED.fieldTypeIsFormula(field)) {
                        handleUpdate(key, field.formula && field.formula.data ? field.formula.data.value[0].value : EMBED.getFormulaData(field));
                        EMBED.subscribeFieldToFormulaChange(field, (v) => handleUpdate(key, v));
                    }
                } catch (err) { console.error("Binding Error: " + key, err); }
            };

            bindDS(this.config.value, 'val');
            bindDS(this.config.min, 'min');
            bindDS(this.config.max, 'max');
            bindDS(this.config.faultHigh, 'fh');
            bindDS(this.config.alarmHigh, 'ah');
            bindDS(this.config.controlLimitHigh, 'ch');
            bindDS(this.config.controlLimitLow, 'cl');
            bindDS(this.config.alarmLow, 'al');
            bindDS(this.config.faultLow, 'fl');
            this.render();
        }
    }

    if (data) {
        var layout = data.layout || {};
        var stackDirection = layout.stackDirection || "horizontal";
        var gap = layout.gap !== undefined ? layout.gap : 2; 
        
        if (stackDirection === "vertical") {
            container.style.flexDirection = "column";
        } else {
            container.style.flexDirection = "row";
        }
        
        container.style.gap = gap + "%";

        var indicatorsList = [];
        var fontConfig = data.fontConfig || {};
        
        if (data.indicators && Array.isArray(data.indicators)) {
            indicatorsList = data.indicators;
        } else {
            Object.keys(data).forEach(key => {
                if (key.startsWith('indicator') && typeof data[key] === 'object') {
                    indicatorsList.push(data[key]);
                }
            });
        }

        indicatorsList.forEach(configObj => {
            new IndicatorModule(container, configObj, fontConfig, layout);
        });
    }

})();