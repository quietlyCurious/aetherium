/**
 * File: CC_GetURLParameterValue.js
 *
 * Copyright 2010 by GE Intelligent Platforms, Inc. 
 * All rights reserved.
 *
 ** This notice must remain in the software.
 * algorithm taken from http://www.netlobo.com/url_query_string_javascript.html
 * used with permission
 *
 * jss012910 - added "i" flag to regexp constructor to make it case-insensitive
 **/

function CC_GetURLParameterValue( name )
{  
    name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
    var regexS = "[\\?&]"+name+"=([^&#]*)";
    var regex = new RegExp( regexS, "i" );
    var results = regex.exec( window.location.href );
    
    if( results == null )
        return "";
    else
        return results[1];
}