// pcv.js - facilitates communication between
// the OFC dashboard and hosted content.

window.pcv = window.pcv || {};

(function () {
	var callbacks = {},
		timeouts = {},
		index = 0;

    pcv.timeout = 3000;
    pcv.EXCEPTION = "pcv_exception";
    pcv.origins = new Array();
    pcv.eventHandlers = {};
    pcv.Language = window.navigator.userLanguage || window.navigator.language;

    if (!Array.prototype.indexOf) {
        Array.prototype.indexOf = function (needle) {
            for (var i = 0; i < this.length; i++) {
                if (this[i] === needle) {
                    return i;
                }
            }
            return -1;
        };
    }

    function receiveMessage(event) {

        origin = event.origin;
        // trim / at the end of origin if present - this happens when getting messages through chrome frame
        if (origin[origin.length - 1] === '/')
            origin = origin.substring(0, origin.length - 1);

        if (pcv.origins.indexOf(origin) === -1 && pcv.origins.indexOf('*') === -1) {
            ///* NOLOG >> console.log("discarding message from origin " + event.origin); << NOLOG */
            ///* NOLOG >> console.log(pcv.origins); << NOLOG */
            return;
        }
        ///* NOLOG >> console.log("pcv using received message"); << NOLOG */
        var f = {};

        try {
            f = JSON.parse(event.data);

            // If no origin, this is an attach callback, save the origin.
            if (!pcv.Container_Origin)
                pcv.Container_Origin = event.origin;

            // If this is a callback, stop and remove the timer.
            if (callbacks[f.Name]) {
                clearTimeout(timeouts[f.Name]);
                delete timeouts[f.Name];
            }

            // Call the function, if it exists.
            if (pcv[f.Name]) {
                pcv[f.Name](f.Parameters);

                // If this is a callback, delete the pointer and the function.
                if (callbacks[f.Name]) {
                    delete callbacks[f.Name];
                    delete pcv[f.Name];
                }
            }
        } catch (e) {
            // If there is a callback, respond with the exception.
            if (typeof f.Parameters != 'undefined') {
                if (f.Parameters["callbackId"]) {
                    callbackEx(f.Parameters["callbackId"], e);
                }
            }
        }
    }

    function callbackEx(callbackId, description) {
        try {
            pcv[callbackId]({
                "pcv_exception": { "description": description }
            });
        }
        finally {
            if (timeouts[callbackId]) {
                clearTimeout(timeouts[callbackId]);
                delete timeouts[callbackId];
            }
            if (callbacks[callbackId])
                delete callbacks[callbackId];
            if (pcv[callbackId])
                delete pcv[callbackId];
        }
    }

    // Outbound
    // Calls the function at the SL ViewModel. Sets a timeout for calls with a callback.
    function callFunction(name, parameters, callback) {
        var origin = null;

        // Attach does not transmit sensitive data, PostMessage to *. Otherwise, only PostMessage to 
        // the attached container origin.
        if (name == "Attach") {
            origin = "*";
        }
        else if (pcv.Container_Origin) {
            origin = pcv.Container_Origin;
        }

        if (!origin) {
            if (callback) {
                callbackEx(parameters['callbackId'], "Invalid container origin.");
            }
            return;
        }

        if (callback) {
            var callbackId = "callback" + index;
            callbacks[callbackId] = callback;
            pcv[callbackId] = callback;
            parameters['callbackId'] = callbackId;
            index++;

            timeouts[callbackId] = setTimeout(function () {
                try {
                    callbackEx(callbackId, "Request has timed out.");
                }
                finally {
                    delete timeouts[callbackId];
                }
            }, pcv.timeout);
        }

        // are we in chrome frame?
        if (window.externalHost != null) {
            ///* NOLOG >> console.log("running in chrome frame"); << NOLOG */			
            try {
                var message = JSON.stringify({
                    id: "my-special-placeholder",
                    name: name,
                    parameters: parameters
                });
                window.externalHost.postMessage(message, origin);
            } catch (e) {
                if (callback) {
                    callbackEx(parameters['callbackId'], e);
                }
            }
        }
        else {
            ///* NOLOG >> console.log("running native"); << NOLOG */
            try {
                var message = JSON.stringify({
                    id: window.name,
                    name: name,
                    parameters: parameters
                });
                parent.postMessage(message, origin);
            } catch (e) {
                if (callback) {
                    callbackEx(parameters['callbackId'], e);
                }
            }
        }
    }

    pcv.callFunction = function (name, parameters) {
        callFunction(name, parameters, null);
    };

    pcv.callFunctionAsync = function (name, parameters, callback) {
        callFunction(name, parameters, callback);

    };

    pcv.attach = function (origins, callback) {
        pcv.origins = origins;

        // if we're not running in chrome frame
        if (!window.externalHost) {
            if (window.addEventListener) {
                window.addEventListener('message', receiveMessage, false);
            }
            else {
                window.attachEvent('onmessage', receiveMessage);
            }
        }
        else {
            // attach messaging callback to chrome frame 
            window.externalHost.onmessage = receiveMessage;
        }

        pcv["attachCallback"] = callback;

        pcv.callFunctionAsync("Attach", {}, function (parameters) {
            if (!parameters[pcv.EXCEPTION]) {
                pcv.Proficy_User = parameters.Proficy_User;
                pcv.Proficy_CurrentNavSelection = parameters.Proficy_CurrentNavSelection;
                pcv.Proficy_CurrentContext = parameters.Proficy_CurrentContext;
                pcv.Proficy_WebApiHomeUrl = parameters.Proficy_WebApiHomeUrl;
                pcv.Proficy_Token = parameters.Proficy_Token;
                pcv.Proficy_TabModules = parameters.Proficy_TabModules;
                pcv.Proficy_Time = null;
                pcv.Proficy_Location = null;
                pcv.Proficy_NLS = null;
                pcv.IsMaximized = parameters.IsMaximized;
                pcv.IsFullScreen = parameters.IsFullScreen;
                pcv.Claims = parameters.Claims;
                pcv.Initializer = parameters.Initializer;
            }

            try {
                pcv["attachCallback"](parameters);
            }
            finally {
                delete pcv["attachCallback"];
            }
        });
    };

    pcv.requestNavigate = function (equipmentId, changeContext) {
        callFunction("RequestNavigate", {
            "equipmentId": equipmentId,
            "changeContext": changeContext
        });
    };

    pcv.selectTab = function (moduleName, initializer) {
        // in case initializer not provided, set it to empty string
        if (!initializer) {
            initializer = "";
        }
        callFunction("SelectTab", {
            "moduleName": moduleName,
            "initializer": initializer
        });
    };

    pcv.logMessageEx = function (msg, category, priority, callback) {

        pcv["logCallback"] = callback;

        pcv.callFunctionAsync("LogMessage", {
            "message": msg,
            "category": category,
            "priority": priority
        }, function (parameters) {
            try {
                pcv["logCallback"](parameters);
            }
            finally {
                delete pcv["logCallback"];
            }
        });
    };

    pcv.logMessage = function (msg, category, priority) {
        pcv.callFunctionAsync("LogMessage", {
            "message": msg,
            "category": category,
            "priority": priority
        });
    };

    pcv.publishEvent = function (eventName, eventArguments) {
        pcv.callFunction("PublishEvent", {
            "eventName": eventName,
            "eventArguments": eventArguments
        });
    };

    pcv.subscribeToEvent = function (eventName, handler) {
        pcv.eventHandlers["SubscribeToEvent" + eventName + "Handler"] = handler;
        pcv.callFunction("SubscribeToEvent", {
            eventName: eventName
        });
    };

    pcv.unSubscribeFromEvent = function (eventName) {
        pcv.callFunction("UnSubscribeFromEvent", { eventName: eventName });
        delete pcv.eventHandlers["SubscribeToEvent" + eventName + "Handler"];
    };

    // Inbound
    pcv.asyncSlJs = function (parameters) {
        //callFunction(parameters.callbackId, {});
    };

    pcv.navigate = function (parameters) {
        pcv.Proficy_CurrentNavSelection = {
            name: parameters.name,
            equipmentId: parameters.equipmentId,
            ldap: parameters.ldap
        };

        if (pcv.onNavigate)
            pcv.onNavigate(parameters.equipmentId);
    };

    pcv.equipmentDropped = function (parameters) {
        if (pcv.onEquipmentDropped)
            pcv.onEquipmentDropped(parameters);
    };

    pcv.contextChanged = function (parameters) {
        pcv.Proficy_CurrentContext = {
            name: parameters.name,
            equipmentId: parameters.equipmentId,
            ldap: parameters.ldap
        };

        if (pcv.onContextChanged)
            pcv.onContextChanged(parameters);
    };

    pcv.equipmentSelected = function (parameters) {
        pcv.Proficy_CurrentNavSelection = {
            name: parameters.name,
            equipmentId: parameters.equipmentId,
            ldap: parameters.ldap
        };

        if (pcv.onEquipmentSelected)
            pcv.onEquipmentSelected(parameters);
    };

    pcv.equipmentSelectedAtLoad = function (parameters) {
        pcv.Proficy_CurrentNavSelection = {
            name: parameters.name,
            equipmentId: parameters.equipmentId,
            ldap: parameters.ldap
        };
    };

    pcv.disposed = function (parameters) {
        if (pcv.onDisposed)
            pcv.onDisposed();
    };

    pcv.maximized = function (parameters) {
        pcv.IsMaximized = true;
        if (pcv.onMaximized)
            pcv.onMaximized();
    };

    pcv.minimized = function (parameters) {
        pcv.IsMaximized = false;
        if (pcv.onMinimized)
            pcv.onMinimized();
    };

    pcv.fullScreenOpened = function (parameters) {
        pcv.IsFullScreen = true;
        if (pcv.onFullScreenOpened)
            pcv.onFullScreenOpened();
    };

    pcv.fullScreenClosed = function (parameters) {
        pcv.IsFullScreen = false;
        if (pcv.onFullScreenClosed)
            pcv.onFullScreenClosed();
    };

    pcv.logout = function (parameters) {
        if (pcv.onLogout)
            pcv.onLogout();
    };

    pcv.favoriteDropped = function (parameters) {
        if (pcv.onFavoriteDropped)
            pcv.onFavoriteDropped(parameters.favorite);
    };

    pcv.refresh = function (parameters) {
        if (pcv.onRefresh)
            pcv.onRefresh();
    };

    pcv.getTree = function (parameters, callback) {

        pcv["getTreeCallback"] = callback;

        pcv.callFunctionAsync("GetTree", {}, function (parameters) {
            try {
                pcv["getTreeCallback"](parameters);
            }
            finally {
                delete pcv["getTreeCallback"];
            }
        });
    };

    pcv.eventRaised = function (parameters) {
        var handlerName = "SubscribeToEvent" + parameters.eventName + "Handler";
        if (pcv.eventHandlers[handlerName])
            pcv.eventHandlers[handlerName](parameters.eventArguments);
    };

    return pcv;
} ());