$(document).ready(function () {
	myApp.onLoad();
});

var myApp = {
	onLoad: function () {
		pcv.timeout = 5000;

		pcv.onEquipmentDropped = function (equipment) {
			myApp.printEquipment(equipment);
			myApp.withApiHomeUrl(function(apiHome) {
				myApp.getGeoLocation(equipment, apiHome);
			});
		};

		pcv.attach(
			[
			'https://localhost',
			'https://your-dvs-server'
			],
			function (parameters) {
				if (parameters[pcv.EXCEPTION]) {
					alert("Error attaching: " + parameters[pcv.EXCEPTION].description);
				}
				else {
					myApp.printEquipment(pcv.Proficy_CurrentNavSelection);
					myApp.withApiHomeUrl(function(apiHome) {
						myApp.getGeoLocation(pcv.Proficy_CurrentNavSelection, apiHome);
					});
				}
			}
		);
	},

	printEquipment: function (equipment) {
		myApp.updateLabel("#equipmentName", equipment.name);
		myApp.updateLabel("#equipmentId", equipment.equipmentId);
		myApp.updateLabel("#equipmentLdap", equipment.ldap);
	},

	updateLabel: function (id, text) {
		$(id).html(text);
	},

	printGeoLocation: function (latitude, longitude) {
		myApp.updateLabel("#equipmentLatLong", "(" + latitude + ", " + longitude + ")");
	},
	
	withApiHomeUrl: function(functionToRun) {
		if(myApp.apiHomeLinks != null) {
			functionToRun(myApp.apiHomeLinks);
			return;
		}
	
		$.ajax({
			url: pcv.Proficy_WebApiHomeUrl,
			type: 'GET',
			contentType: 'application/json',
			dataType: 'json',
			beforeSend: function (xhr) {
				xhr.setRequestHeader("Authorization", "Bearer " + pcv.Proficy_Token);
			},
			success: function (response, opts) {
				if (opts === "success") {
					if (response == null) {
						var message = 'server-side failure with status : ' + response.status;
						message += 'response' + response;
						message += 'opts' + opts;
						myApp.updateStatusMessage(message);
					} else {
						myApp.apiHomeLinks = response;
						functionToRun(myApp.apiHomeLinks);
					}
				}
			},
			failure: function (response, opts) {
				var message = 'server-side failure with status : ' + response.status;
				message += 'response' + response;
				message += 'opts' + opts;
				myApp.updateStatusMessage(message);
			},
			error: function (response, opts) {
				var message = 'server-side failure with status : ' + response.status;
				message += 'response' + response;
				message += 'opts' + opts;
				myApp.updateStatusMessage(message);
			}
		});
	},

	getEquipmentLink: function (apiHome) {
		for(link in apiHome) {
			if(apiHome[link].Rel == "Equipment") {
				return apiHome[link];
			}
		}
	},

	getGeoLocation: function (equipment, apiHome) {
		// Use token from pcv bridge.
		var soaToken = pcv.Proficy_Token;
		
		if(apiHome == null) {
			myApp.printGeoLocation("NA", "NA");
			return;
		}

		// Find the Equipment link in apiHome
		var equipmentLink = myApp.getEquipmentLink(apiHome);
		
		if(equipmentLink == null) {
			// No equipment link in apiHome.
			myApp.printGeoLocation("NA", "NA");
			return;
		}

		var url = equipmentLink.Href + '/' + equipment.equipmentId;		

		$.ajax({
			url: url,
			type: 'GET', // It's GET by default, just being explicit here.
			contentType: 'application/json',
			dataType: 'json',
			beforeSend: function (xhr) {
				xhr.setRequestHeader("Authorization", "Bearer " + soaToken);
			},
			success: function (response, opts) {
				if (opts === "success") {
					if (response == null) {
						myApp.updateOnFailure(equipment);
					} else {
						myApp.updateStatusMessage("returned properties for " + response.DisplayName);
						var latitude = response.Latitude;
						var longitude = response.Longitude;
						myApp.printGeoLocation(latitude, longitude);
					}
				}
			},
			failure: function (response, opts) {
				var message = 'server-side failure with status : ' + response.status;
				message += 'response' + response;
				message += 'opts' + opts;
				myApp.updateStatusMessage(message);
				myApp.printGeoLocation("NA", "NA");
			},
			error: function (response, opts) {
				myApp.updateOnFailure(equipment);
			}
		});
	},

	updateStatusMessage: function (message) {
		$('#statusMessage').text(message);
	},

	updateOnFailure: function (equipment) {
		myApp.updateStatusMessage("Could not get properties for " + equipment.name);
		myApp.printGeoLocation("NA", "NA");
	}
};