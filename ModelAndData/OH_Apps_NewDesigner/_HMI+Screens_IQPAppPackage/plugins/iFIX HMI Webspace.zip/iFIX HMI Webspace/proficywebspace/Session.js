var myclientid;
var browser = new GetPlatform();
var mySessionId;
var myAuthority;
var myCredentials;
var appEnum = {"undefined":0, "iFIX":1, "CimLayout":2, "CimView":3, "PlantApps":4};
var appSession = appEnum.undefined;

var startTime;
var endTime;

function S4() {
    return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
}

function Generateclientid(newsession) {
	var myclientid = sessionStorage.getItem('thisclientid');
	if(newsession == true)
	{
		myclientid = null;
	}
    if (myclientid == null || myclientid == "") {
        myclientid = (S4() + S4() + "-" + S4() + "-4" + S4().substr(0, 3) + "-" + S4() + "-" + S4() + S4() + S4()).toLowerCase();
        sessionStorage.setItem('thisclientid', myclientid);       
    }
 return myclientid;
}

var launchSessionEntries = 0;
var launchSessionXmlHttp;

function LaunchSession() {
    myclientid = Generateclientid(true);
    try {
        launchSessionXmlHttp = new XMLHttpRequest();
    }
    catch (err) {
        document.getElementById('debugoutput').write('<p>xmlHttp creation error ' + err.message + '<p>');
    }

    var url = "ProficyWebSpace.svc/ProficyWebClientEndpoint/CreateSession";
    var body = '{"originate":"' + myclientid + '","application":"' + app + '","args":"' + commandLineParameters + '","username":"' + user + '","password":"' + password + '"}';
    try {
        // Send the HTTP request
        launchSessionXmlHttp.open("POST", url, true);

        // Create result handler 
        launchSessionXmlHttp.onprogress = function () { };
        launchSessionXmlHttp.onreadystatechange = LaunchSessionCallback;
        launchSessionXmlHttp.setRequestHeader("Content-type", "application/json");
        //launchSessionXmlHttp.setOption(2, 13056);
        launchSessionXmlHttp.send(body);
        if (!browser.msie) {
            var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
            if (!isIE11) {
                document.getElementById('debugoutput').innerHTML = "<p>Sent the body<p>";
            }
        }

        startTime = new Date();
    }
    catch (err) {
        if (!browser.msie) {
            var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
            if (!isIE11) {
                document.getElementById('debugoutput').innerHTML += "<p>xmlHttp usage error " + err.message + "<p>";
            }
        }
    }
}



function LaunchSessionCallback() {

    launchSessionEntries++;
    if (!browser.msie) {
        var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
        if (!isIE11) {
            document.getElementById('debugoutput').innerHTML += "<p>In LAUNCHSESSIONCALLBACK()<p>";
        }
    }
    if (launchSessionXmlHttp.readyState == 4) {
        try {
            if (launchSessionXmlHttp.status != null && launchSessionXmlHttp.status == 404) {
                var checkReturnType = createSessionResult.d.__type.toString();
                if (!browser.msie) {
                    var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
                    if (!isIE11) {
                        document.getElementById('debugoutput').innerHTML += "<p>Session Creation Got Result<p>" + checkReturnType;
                    }
                }
                if (checkReturnType == "CreateSessionResult:#ProficyWebSpace") {
                    if (!browser.msie) {
                        var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
                        if (!isIE11) {
                            document.getElementById('debugoutput').innerHTML += "<p>Session Creation Got Result<p>";
                        }
                    }
                }
            }
            if (launchSessionXmlHttp.status != null && launchSessionXmlHttp.status == 200) {

                endTime = new Date();

                var elapsedTime = endTime - startTime;
                if (!browser.msie) {
                    var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
                    if (!isIE11) {
                        document.getElementById('debugoutput').innerHTML += "<p>Session Creation took " + elapsedTime.toString() + "<p>";
                    }
                }
                var createSessionResult = JSON.parse(launchSessionXmlHttp.responseText);

                if (!browser.msie) {
                    var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
                    if (!isIE11) {
                        document.getElementById('debugoutput').innerHTML += "<p>Session Creation result extracted<p>";
                    }
                }
                if (createSessionResult != null && createSessionResult.d != null) {
                    if (!browser.msie) {
                        var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
                        if (!isIE11) {
                            document.getElementById('debugoutput').innerHTML += "<p>Session Creation result exists<p>";
                        }
                    }
                    var checkReturnType = createSessionResult.d.__type.toString();
                    if (!browser.msie) {
                        var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
                        if (!isIE11) {
                            document.getElementById('debugoutput').innerHTML += "<p>Session Creation Got Result<p>" + checkReturnType;
                        }
                    }
                    if (checkReturnType == "CreateSessionResult:#ProficyWebSpace") {
                        if (!browser.msie) {
                            var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
                            if (!isIE11) {
                                document.getElementById('debugoutput').innerHTML += "<p>Session Creation Got Result<p>";
                            }
                        } mySessionId = createSessionResult.d.SessionId;
                        myAuthority = createSessionResult.d.Authority;
                        myCredentials = createSessionResult.d.Credentials;

                        // We can go ahead and do another call.
                    }
                    else {
                        if (!browser.msie) {
                            var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
                            if (!isIE11) {
                                document.getElementById('debugoutput').innerHTML += "<p>Session Creation incorrect return type<p>";
                            }
                        }
                    }
                }
                else {
                    if (!browser.msie) {
                        var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
                        if (!isIE11) {
                            document.getElementById('debugoutput').innerHTML += "<p>Session Creation incorrect return value<p>";
                        }
                    }
                }
            }
        }
        catch (err) {
            if (!browser.msie) {
                var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
                if (!isIE11) {
                    document.getElementById('debugoutput').innerHTML += "<p>LaunchSessionCallback Errored while parsing result " + err.Message + "<p>";
                }
            }
        }

        if (!browser.msie) {
            var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
            if (!isIE11) {
                document.getElementById('debugoutput').innerHTML += "<p>sentclientid = " + myclientid.toString() + "<p>";
                document.getElementById('debugoutput').innerHTML += "<p>ResultCalback Status 1= " + launchSessionXmlHttp.status + "<p>";
                document.getElementById('debugoutput').innerHTML += "<p>ResultCalback StatusText = " + launchSessionXmlHttp.statusText + "<p>";
                document.getElementById('debugoutput').innerHTML += "<p>ResultCalback Response = " + launchSessionXmlHttp.response + "<p>";
                document.getElementById('debugoutput').innerHTML += "<p>ResultCalback ResponseText = " + launchSessionXmlHttp.responseText + "<p>";
                document.getElementById('debugoutput').innerHTML += "<p>ResultCalback ResponseType = " + launchSessionXmlHttp.responseType + "<p>";
                document.getElementById('debugoutput').innerHTML += "<p>ResultCalback ResponseXML = " + launchSessionXmlHttp.responseXML + "<p>";
                document.getElementById('debugoutput').innerHTML += "<p>LaunchSessionCallback entries = " + launchSessionEntries + "<p>";
            }
        }
        var a = document.URL;
        var tempstr = a.indexOf("launchsession.htm");
        var truncstr = a.substring(0, tempstr);
        if (appSession == appEnum.iFIX) {
        	truncstr += "iFIX.html?embed=true&sessionid=";
        } else if (appSession == appEnum.CimLayout) {
        	//truncstr += "CimLayout.html?embed=true&sessionid=";
        } else if (appSession == appEnum.CimView) {
        	//truncstr += "CimView.html?embed=true&sessionid=";
        } else if (appSession == appEnum.PlantApps) {
        	truncstr += "PlantApplications.html?embed=true&sessionid=";
        }
        window.open(truncstr + mySessionId.toString() + '&authority=' + encodeURIComponent(myAuthority) + '&credentials=' + encodeURIComponent(myCredentials) + '&created=true&vision=' + vision + '&clientid=' + myclientid, "_self");
    }
}

var launchApplicationXmlHttpRequest;
var launchApplicationEntries = 0;

function LaunchApplication(app, params) {
    try {
        launchApplicationXmlHttpRequest = new XMLHttpRequest();
        var url = "ProficyWebSpace.svc/ProficyWebClientEndpoint/LaunchApplication";
        var body = '{"originate":"' + myclientid + '","application":"' + app + '","args":"' + params + '"}';
        if (!browser.msie) {
            var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
            if (!isIE11) {
                document.getElementById('debugoutput').innerHTML += "<p>LaunchApplication Url = " + url + "<p>";
                document.getElementById('debugoutput').innerHTML += "<p>LaunchApplication Body = " + body + "<p>";
            }
        }
        launchApplicationXmlHttpRequest.open("POST", url, true);
        if (!browser.msie) {
            var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
            if (!isIE11) {
                document.getElementById('debugoutput').innerHTML += "<p>LaunchApplication Opening Post<p>";
            }
        }
        // Create result handler 
        launchApplicationXmlHttpRequest.onreadystatechange = LaunchApplicationCallback;
        launchApplicationXmlHttpRequest.setRequestHeader("Content-type", "application/json");
        if (!browser.msie) {
            var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
            if (!isIE11)
            { document.getElementById('debugoutput').innerHTML += "<p>LaunchApplication Sending body<p>"; }
        }
        launchApplicationXmlHttpRequest.send(body);
        if (!browser.msie) {
            var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
            if (!isIE11)
            { document.getElementById('debugoutput').innerHTML += "<p>LaunchApplication Body Sent<p>"; }
        }
    }
    catch (err) {
        if (!browser.msie) {
            var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
            if (!isIE11) {
                document.getElementById('debugoutput').innerHTML += "<p>LaunchApplication Errored " + err.Message + "<p>";
            }
        }
    }
}



function LaunchApplicationCallback() {
    launchApplicationEntries++;
    if (!browser.msie) {
        var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
        if (!isIE11) {
            document.getElementById('debugoutput').innerHTML += "<p>Entered launchapplication callback<p>";
        }
    }
    var goAheadAndLaunch = false;
    if (launchApplicationXmlHttpRequest.readyState == 4) {
        try {

            if (launchApplicationXmlHttpRequest.status != null && launchApplicationXmlHttpRequest.status == 200) {

                endTime = new Date();

                var elapsedTime = endTime - startTime;
                if (!browser.msie) {
                    var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
                    if (!isIE11) {
                        document.getElementById('debugoutput').innerHTML += "<p>Launch Application took " + elapsedTime.toString() + "<p>";
                    }
                }
                var launchApplicationReturn = JSON.parse(launchApplicationXmlHttpRequest.responseText);

                if (launchApplicationReturn != null && launchApplicationReturn.d != null) {
                    var result = launchApplicationReturn.d;

                    if (result == true) {
                        // In business.  Can go ahead an launch the Active X.
                        goAheadAndLaunch = true;
                    }
                }
            }
        }
        catch (err) {
            if (!browser.msie) {
                var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
                if (!isIE11) {
                    document.getElementById('debugoutput').innerHTML += "<p>LaunchApplicationCallback Errored while parsing result " + err.Message + "<p>";
                }
            }
        }

        if (!browser.msie) {
            var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
            if (!isIE11) {
                document.getElementById('debugoutput').innerHTML += "<p>ResultCalback Status 2= " + launchApplicationXmlHttpRequest.status + "<p>";
                document.getElementById('debugoutput').innerHTML += "<p>ResultCalback StatusText = " + launchApplicationXmlHttpRequest.statusText + "<p>";
                document.getElementById('debugoutput').innerHTML += "<p>ResultCalback Response = " + launchApplicationXmlHttpRequest.response + "<p>";
                document.getElementById('debugoutput').innerHTML += "<p>ResultCalback ResponseText = " + launchApplicationXmlHttpRequest.responseText + "<p>";
                document.getElementById('debugoutput').innerHTML += "<p>ResultCalback ResponseType = " + launchApplicationXmlHttpRequest.responseType + "<p>";
                document.getElementById('debugoutput').innerHTML += "<p>ResultCalback ResponseXML = " + launchApplicationXmlHttpRequest.responseXML + "<p>";
                document.getElementById('debugoutput').innerHTML += "<p>LaunchSessionCallback entries = " + launchSessionEntries + "<p>";
            }
        }
    }

    if (!browser.msie) {
        var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
        if (!isIE11) {
            document.getElementById('debugoutput').innerHTML += "<p>goAheadAndLaunch = " + goAheadAndLaunch.toString() + "<p>";
        }
    }
    if (goAheadAndLaunch == true) {
        document.getElementById('debugoutput').innerHTML += "<p>Possible link = http://" + location.hostname + "/OFClogon.html" +
                "?sessionid=" + mySessionId.toString() +
                "&authority=" + myAuthority.toString() +
                "&credentials=" + myCredentials.toString() +
                "&clientid=" + myclientid.toString() + "<p>";
    }
}

//open display in current session
function OpenDisplayInCurrentSession(clientid, strpic, strtgd) {


    try {
        OpenPicInSessionXmlHttp = new XMLHttpRequest();
    }
    catch (err) {
        document.getElementById('debugoutput').write('<p>xmlHttp creation error ' + err.message + '<p>');
    }

    var url = "ProficyWebSpace.svc/ProficyWebClientEndpoint/OpenDisplayInSession";

    var body = '{"clientid":"' + clientid + '","pic":"' + strpic + '","tgd":"' + strtgd + '"}';


    try {
        // Send the HTTP request
        OpenPicInSessionXmlHttp.open("POST", url, true);

        // Create result handler 
        OpenPicInSessionXmlHttp.onreadystatechange = OpenDisplayCallback;
        OpenPicInSessionXmlHttp.setRequestHeader("Content-type", "application/json");
        OpenPicInSessionXmlHttp.send(body);
        document.getElementById('debugoutput').innerHTML += "<p>Sent the body<p>";

        startTime = new Date();
    }
    catch (err) {
        document.getElementById('debugoutput').innerHTML += "<p>xmlHttp usage error " + err.message + "<p>";
    }
}

function OpenDisplayCallback() {
    return "OpenDisplayCallback completed";
}



function LaunchSessionForEquipment(myclientid, ldapstring) {
    if (!browser.msie) {
        var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
        if (!isIE11) {
            document.getElementById('debugoutput').innerHTML = "<p>LaunchSessionForEquipment " + ldapstring + "<p>";
        }
    }
    //myclientid = Generateclientid();
    if (!browser.msie) {
        var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
        if (!isIE11) {
            document.getElementById('debugoutput').innerHTML = "<p>Launching Session ID: " + myclientid + "<p>";
        }
    }
    try {
        launchSessionXmlHttp = new XMLHttpRequest();
    }
    catch (err) {
        if (!browser.msie) {
            var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
            if (!isIE11) {
                document.getElementById('debugoutput').write('<p>xmlHttp creation error ' + err.message + '<p>');
            }
        }
    }

    var url = "ProficyWebSpace.svc/ProficyWebClientEndpoint/OpenEquipmentDisplay";
    if (!browser.msie) {
        var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
        if (!isIE11) {
            document.getElementById('debugoutput').innerHTML = "<p>url=" + url + "<p>";
            document.getElementById('debugoutput').innerHTML = "<p>clientid= " + myclientid + "<p>";
            document.getElementById('debugoutput').innerHTML = "<p>ldapstring= " + ldapstring + "<p>";
        }
    }
    var body = '{"clientid":"' + myclientid + '","equipment":"' + ldapstring + '"}';

    if (!browser.msie) {
        var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
        if (!isIE11) {
            document.getElementById('debugoutput').innerHTML += "<p>body=" + body + "<p>";
        }
    }
    try {
        // Send the HTTP request
        launchSessionXmlHttp.open("POST", url, true);

        // Create result handler 
        launchSessionXmlHttp.onprogress = function () { };
        launchSessionXmlHttp.onreadystatechange = LaunchSessionForEquipmentCallback;
        launchSessionXmlHttp.setRequestHeader("Content-type", "application/json");
        //launchSessionXmlHttp.setOption(2, 13056);
        launchSessionXmlHttp.send(body);
        if (!browser.msie) {
            var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
            if (!isIE11) {
                document.getElementById('debugoutput').innerHTML += "<p>Sent the body<p>";
            }
        }

        startTime = new Date();
    }
    catch (err) {
        if (!browser.msie) {
            var isIE11 = !!navigator.userAgent.match(/Trident.*rv\:11\./);
            if (!isIE11) {
                document.getElementById('debugoutput').innerHTML += "<p>xmlHttp usage error " + err.message + "<p>";
            }
        }
    }
}

function LaunchSessionForEquipmentCallback() {
    return "LaunchSessionForEquipmentCallback completed";
}