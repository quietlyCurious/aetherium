var BRAND_ELEMENT_LIST = [
//"BRAND_NAME_INSTALLER",
//"BRAND_NAME_COMPANY", 
//"BRAND_NAME_PRODUCT",
"BRAND_INSTALL_INSTRUCTIONS"
];

var BRAND_IMG_LIST = [
"BRAND_IMG_LOGO",
"BRAND_IMG_BACKGROUND"];

var DEFAULT_ELEMENT_STRINGS = [
//"Proficy WebSpace.",
//"Proficy",
//"Proficy WebSpace",
"*"];

function BrandContents() {
	/* NOLOG >> console.log("BrandContents()"); << NOLOG */
	BrandText();
	BrandImages();
}

function BrandImages() {
	var backgroundSet = 0;
	
	for (x = 0; x < BRAND_IMG_LIST.length; x++) {		
		var containerList = document.getElementsByClassName(BRAND_IMG_LIST[x]);
		
		if (containerList) {
			var storedImage = JSON.parse(localStorage.getItem(BRAND_IMG_LIST[x]));
			
			if (storedImage) {
				for (i = 0; i < containerList.length; i++) {
					var image = new Image();
					image.src = storedImage.imagedata;
					image.style.cssText = storedImage.imageStyle;
					
					occurance = containerList[i];

					if (occurance) {
						if (BRAND_IMG_LIST[x] == "BRAND_IMG_BACKGROUND") {
							occurance.style.cssText = storedImage.containerStyle;
							occurance.style.backgroundImage = "url('"+ storedImage.imagedata + "')";
							backgroundSet = 1;
						}
						else {
							occurance.style.cssText = storedImage.containerStyle;
							occurance.style.display = "block";
							
							numChildren = occurance.childNodes.length;
							
							for (j = 0; j < numChildren; j++) {
								occurance.removeChild(occurance.childNodes[0]);
							}
							
							occurance.appendChild(image);
						}
					}
				}
			}
		}
	}
	
	if (backgroundSet == 0) {
		var container = document.getElementById('mainbody');
	
		if (container) {
			if (container.style) {
				if (container.style.backgroundImage == "") {
					container.style.backgroundImage = 'url("background.jpg")';
					container.style.backgroundSize = "cover";
				}
			}
		}
	}
}

function BrandText() {
	for (x = 0; x < BRAND_ELEMENT_LIST.length; x++) {		
		var elementList = document.getElementsByClassName(BRAND_ELEMENT_LIST[x]);
		
		if (elementList) {
			for (i = 0; i < elementList.length; i++) {
				occurance = elementList[i];
				
				if (occurance) {
					var storedElement = localStorage.getItem(BRAND_ELEMENT_LIST[x]);
					
					if (storedElement) {
						if (DEFAULT_ELEMENT_STRINGS[x] == "*") {
							occurance.innerHTML = storedElement;
						}
						else {
							occurance.innerHTML = occurance.innerHTML.replace(DEFAULT_ELEMENT_STRINGS[x], storedElement);
							occurance.innerHTML = occurance.innerHTML.replace(DEFAULT_ELEMENT_STRINGS[x], storedElement);
						}
					}
				}
			}
		}
	}

	var elementList = document.getElementsByClassName("BRAND");
					
	if (elementList) {
		for (i = 0; i < elementList.length; i++) {
			occurance = elementList[i];
			
			if (occurance) {
				if (!occurance.classList.contains("INSTALL_STEP2") && !occurance.classList.contains("INSTALL_STEP3"))
				{
					occurance.style.visibility = "visible";
				}
			}
		}
	}
}

function GetProtocolString() {
	var retVal = DEFAULT_ELEMENT_STRINGS[BRAND_ELEMENT_LIST.indexOf("BRAND_NAME_PROTOCOL")];
	
	var storedElement = localStorage.getItem("BRAND_NAME_PROTOCOL");
	
	if (storedElement) {
		retVal = storedElement;
	}
	
	return retVal;
}