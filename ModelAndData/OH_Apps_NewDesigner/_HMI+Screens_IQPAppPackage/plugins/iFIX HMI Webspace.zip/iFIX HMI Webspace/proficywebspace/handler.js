window.onload = init;

var hasStartedInstallingApp = false;
var isInstallingApp = false;
var approvedInstaller = false;
var defaultHelpPage = "quickstart.html"
var defaultSection = "AC_Startup";
var currentHelpPage = ""
var isShowingReconnectMessage = false;
var successCallbackCalled = false;

function init() {
	/* NOLOG >> console.log("init %s", window.location.toString()); << NOLOG */
	var loc = window.location.toString();
	var hash = window.location.hash.toString()
	var urlParams = loc.split('?')[1];
		
	var iFL = document.getElementById('iFrameLogon');
	if (iFL != null)
	{
		if (controlArguments)
		{
			if (!(controlArguments.hasOwnProperty("useApp") && controlArguments["useApp"] == "false"))
			{
				iFL.style.visibility = "hidden";
			}
		}
		
		if (urlParams)
		{
			if ((!(urlParams.indexOf("useApp=false") >= 0)) && (!(urlParams.indexOf("help=ac") >= 0)))
			{
				iFL.style.visibility = "hidden";
			}
			else
			{
				iFL.style.visibility = "visible";
			}
		}
		
		if (urlParams == undefined)
		{
			iFL.src = "webapp.html" + hash;
		}
		else {		
			iFL.src = "webapp.html?" + urlParams;
		}
	}
	
	if (urlParams && (urlParams.indexOf("help=") >= 0))
	{
		var n = urlParams.indexOf("help=");		
		var helpFile = urlParams.substring(n);
		
		helpFile = helpFile.split('=')[1];
		helpFile = helpFile.split('&')[0];
		
		setPage(helpFile);
	}
}

function AddInstallAppLink() {
    var modal = document.getElementById('installApp');
    var notify = document.getElementById('notificationFrame');
    notify.innerHTML = '<a href="#" class="bright" id="getApp">Get the App</a>';

    var btn = document.getElementById("getApp");
    btn.onclick = InitiateNativeAppInstall;
    return 0; // success
}

function AddUpgradeAppLink() {
    var modal = document.getElementById('installApp');
    var notify = document.getElementById('notificationFrame');
    notify.innerHTML = '<a href="#" class="bright" id="getApp">Upgrade the App</a>';

    var btn = document.getElementById("getApp");
    btn.onclick = InitiateNativeAppInstall;
    return 0; // success
}

function RemoveInstallAppLink() {
    var modal = document.getElementById('installApp');
    var notify = document.getElementById('notificationFrame');
    notify.innerHTML = '';
}

function ApproveNativeApp() {
	//var modal = document.getElementById('installApp');
	//modal.style.display = "block";
		
	//var dlFrame = document.getElementById("dialogFrame");
	//dlFrame.innerHTML = '<iframe id="approveFrame" width="100%" height="100%" border-style="hidden" src="handlerHelp.html"><iframe>';
	return 0; // success
}

function InitiateNativeAppInstall() {
    var logonDocument = document.getElementById('iFrameLogon').contentDocument;
    var webappWindow = logonDocument.getElementById('iFrameWebApp').contentWindow;
    webappWindow.InitiateAppInstall();
}

function InstallNativeApp() {
    /* NOLOG >> console.log("InstallNativeApp"); << NOLOG */

	if (browser.android) {
		var state = window.localStorage.getItem('INSTALLED_STATE');
		if (state != 'installed') {				
			var modal = document.getElementById('installAndroid');
			modal.style.display = "inline-block";	
		}
	}
	else if (browser.ios) {		
		var state = window.localStorage.getItem('INSTALLED_STATE');
		if (state != 'installed') {	
			var modal = document.getElementById('installiOS');
			modal.style.display = "inline-block";	
		}
	}
	else if (browser.firefox || browser.chrome) {
		var state = window.localStorage.getItem('INSTALLED_STATE');
		if (state == 'installed'){
			document.getElementById('msgFrame').innerHTML = '<div class="buttonWrapper"><a href="#" onclick="window.parent.location.reload()">Click to connect to ' + location.hostname + '</a><br>Do not use the browser\'s reload button</div>';

			return;
		}
		else if (state == 'running') {
			window.localStorage.setItem('INSTALLED_STATE', 'installed');
			return;
		}
		else if (state == 'unknown') {
		}
	}

    // IE and Chrome interpret focus lost events as indicators that
    // the native app has been launched. But when the app is installed,
    // the browser loses the focus twice before the native app is 
    // launched: once when user clicks to download the app's installer
    // and again when the installer starts. If the host is trying to 
    // launch the app when either of these focus lost events occurs,
    // the browser will erroneously notify the host that the app has
    // been launched. To prevent this from occurring, the following
    // code prevents the browser from trying to launch the native app 
    // until the browser has lost and regained the focus twice.
    var target = window;
    while (target != target.parent) {
        target = target.parent;
    }

    isInstallingApp = true
    hasStartedInstallingApp = true;

    target.focus();
    var focusEvent = registerEvent(target, "focus", onFocus);

    function onFocus() {
        if (approvedInstaller == true || browser.mac) 
            isInstallingApp = false;
        else
            approvedInstaller = true
    }

    var focusTimeout = setTimeout(function () {
        focusEvent.remove();
        isInstallingApp = false;
    }, 25000);


	var modal = document.getElementById('installApp');
	modal.style.display = "inline-block";
	
	//var dlFrame = document.getElementById("dialogFrame");
	//dlFrame.innerHTML = '<iframe id="installFrame" width="400" height="200" border-style="hidden" src="install.html"><iframe>';
	
	return 0; //success
}

function LaunchNativeApp(credentials) {
	/* NOLOG >> console.log("LaunchNativeApp"); << NOLOG */
	return testForHandler(credentials, successCallbackNativeAppIsInstalled, failCallbackNativeAppIsNotInstalled);
}
function CloseNativeAppDialogs() {
    closeDialog();
    return 0; // success
}
function cancelDialog() {
	var logonDocument = parent.document.getElementById('iFrameLogon').contentDocument;
	var webappWindow = logonDocument.getElementById('iFrameWebApp').contentWindow;
	webappWindow.UseWebApp();
	closeDialog();
}

function closeDialog() {
	var modal = document.getElementById('installApp');
	
	if (modal == null) {
		modal = parent.document.getElementById('installApp');
	}

	if (modal != null) {
	    modal.style.display = "none";
	}
	
	var iFL = document.getElementById('iFrameLogon');
	if (iFL != null)
	{
		iFL.style.visibility = "visible";
	}
}

function ReloadPage()
{
	var storedURLPart = localStorage.getItem('OIDCURLPART');
	if (storedURLPart !== undefined &&
		storedURLPart !== null)
		window.location.href = storedURLPart;
	else
		location.reload()
}

function NativeAppConnectedNotification(isEmbedded) {
    /* NOLOG >> console.log("NativeAppConnectedNotification"); << NOLOG */
	
    closeDialog();
		
	if (isEmbedded == "false") {
		var startSession = document.getElementById('startingSession');
		if (startSession != undefined) {
			startSession.innerHTML = null;
		}

        ShowReconnectLink();
    }

    if ((browser.firefox || browser.chrome) && successCallbackCalled == false ) {
        window.localStorage.setItem('INSTALLED_STATE', 'running');
    } else if (browser.chrome) {
        window.localStorage.setItem('INSTALLED_STATE', 'installed');		
    }
}

function WebAppConnectedNotification() {
    /* NOLOG >> console.log("WebAppConnectedNotification"); << NOLOG */
	
	closeDialog();
}

function successCallbackNativeAppIsInstalled () {
    /* NOLOG >> console.log("successCallbackNativeAppIsInstalled"); << NOLOG */

    successCallbackCalled = true;

    RemoveInstallAppLink();

    var logonDocument = document.getElementById('iFrameLogon').contentDocument;
    var webappWindow = logonDocument.getElementById('iFrameWebApp').contentWindow;
    webappWindow.NativeAppIsInstalled();

    if (browser.firefox) {
        window.localStorage.setItem('INSTALLED_STATE', 'installed');
    }
}

function failCallbackInstallFullVersion () {
	/* NOLOG >> console.log("failCallbackInstallFullVersion"); << NOLOG */
	AddInstallAppLink();
}

function failCallbackNativeAppIsNotInstalled () {
    /* NOLOG >> console.log("failCallbackNativeAppIsNotInstalled"); << NOLOG */

    successCallbackCalled = false;

	var logonDocument = document.getElementById('iFrameLogon').contentDocument;
	
	if (logonDocument) {
		var webappWindow = logonDocument.getElementById('iFrameWebApp').contentWindow;
		
		if (webappWindow) {
			webappWindow.NativeAppIsNotInstalled();
		}
	}
}

function convertCommandLine(commandLine) {	
	var url = "";
	var data = commandLine.split(" ");
	var previousParam = false;
	
	for (var i = 0; i < data.length; i++) {		
		if ((data[i] == undefined) || (data[i] == " ") || (data[i] == "")) {			
			// do nothing
		}		
		else if (data[i].charAt(0) == "-") {			
			if (previousParam == true) {
				url += "=true&";
				previousParam = false;
			}
			else {			
				previousParam = true;
			}
			
			url += data[i].substr(1);
		}
		else {
			previousParam = false;
			url += "=";
			url += data[i];
			
			if (i < (data.length - 2)) {
				url += "&";
			}
		}		
	}	
	
	return url;
}

function testForHandler(credentials, successCb, failCb) {
    var result = 0;
	/* NOLOG >> console.log("testForHandler"); << NOLOG */

	var commandLine = credentials + " " + buildCommandLine(0);

	if (commandLine.indexOf(" -h ") == -1) {
	    // Connect to the host from which the page was downloaded:
	    commandLine = " -h " + location.hostname + commandLine;
	}
	
	var handlerAddress = "proficy://?" + commandLine;
	/* NOLOG >> console.log(handlerAddress); << NOLOG */

	var state = window.localStorage.getItem('INSTALLED_STATE');		
	if (state == undefined && hasStartedInstallingApp == false)	{
		var logonDocument = document.getElementById('iFrameLogon').contentDocument;
		if (logonDocument) {
			var webappWindow = logonDocument.getElementById('iFrameWebApp').contentWindow;				
			if (webappWindow) {
				webappWindow.NativeAppIsNotInstalled();
				return;
			}
		}		
	}

	if (navigator.msLaunchUri) {
		/* NOLOG >> console.log("edge/IE detected"); << NOLOG */
		navigator.msLaunchUri(handlerAddress, successCb, failCb);
	}
	else if ((browser.android) || (browser.ios) || (browser.cros)) {
		
		var url = convertCommandLine(commandLine);		
		handlerAddress = "proficy://?" + url;
		
		if (browser.android) {
			/* NOLOG >> console.log("Android detected"); << NOLOG */			
			var linkAndroid = document.getElementById("linkAndroid");
			
			if (linkAndroid) {
				linkAndroid.href = handlerAddress;
			}

			var install = document.getElementById('installAndroid');
			
			if (install) {
				install.style.display = "inline-block";
			}				
		
			var launch = document.getElementById('launchAndroid');

			if (launch) {
				launch.style.display = "inline-block";	
			}
			
			var appDlg = document.getElementById('installApp');
			
			if (appDlg) {
				appDlg.style.display = "inline-block";
			}	
		}
		else if (browser.ios) {
			var linkIOS = document.getElementById("linkIOS");
			
			if (linkIOS) {
				linkIOS.href = handlerAddress;
			}

			var install = document.getElementById('installiOS');
			
			if (install) {
				install.style.display = "inline-block";
			}	
			
			var launch = document.getElementById('launchiOS');

			if (launch) {
				launch.style.display = "inline-block";	
			}	
			
			var appDlg = document.getElementById('installApp');
			
			if (appDlg) {
				appDlg.style.display = "inline-block";
			}				
		}
		else if (browser.cros) {
            /* NOLOG >> console.log("cros detected"); << NOLOG */
			var linkChrome = document.getElementById("linkChrome");
			
			if (linkChrome) {
				linkChrome.href = handlerAddress;
			}

			var install = document.getElementById('installChrome');
			
			if (install) {
				install.style.display = "inline-block";
			}	
			
			var launch = document.getElementById('launchChrome');

			if (launch) {
				launch.style.display = "inline-block";	
			}	
			
			var appDlg = document.getElementById('installApp');
			
			if (appDlg) {
				appDlg.style.display = "inline-block";
			}				
		}			
		
		var logonDocument = document.getElementById('iFrameLogon').contentDocument;

		if (logonDocument) {
			var webappWindow = logonDocument.getElementById('iFrameWebApp').contentWindow;		
		}
		
		state = window.localStorage.getItem('INSTALLED_STATE');
		
		if (state == undefined)	{
			if (webappWindow) {
				webappWindow.NativeAppIsNotInstalled();
			}
		}
		else if ((state == 'installed') || (state == 'running') || (state == 'unknown')) {
			if (webappWindow) {
				webappWindow.NativeAppIsInstalled();
			}
		}
	}
	else if (browser.msie) {
		/* NOLOG >> console.log("msie detected"); << NOLOG */
		openUriWithHiddenFrame(handlerAddress, successCb, failCb, 2000);
	}
	else if (browser.firefox) {
		/* NOLOG >> console.log("firefox detected"); << NOLOG */
		openUriUsingFirefox(handlerAddress, successCb, failCb);
	}
	else if (browser.chrome) {
		/* NOLOG >> console.log("chrome detected"); << NOLOG */
		openUriWithTimeout(handlerAddress, successCb, failCb, 3000);
	}
	else if (browser.cros) {
		/* NOLOG >> console.log("cros detected"); << NOLOG */
		//Nothing to do here
		result = 1;
    }
	else if (browser.safari) {
		/* NOLOG >> console.log("safari detected"); << NOLOG */	
		openUriWithHiddenFrame(handlerAddress, successCb, failCb, 2000);
	}
	else {
	    /* NOLOG >> console.log("no browser detected"); << NOLOG */
	    result = 2;
	}

	return result;
}

//Used by Windows 7 IE 11
function openUriWithHiddenFrame(uri, successCb, failCb, msTimeout) {
	/* NOLOG >> console.log("openUriWithHiddenFrame"); << NOLOG */

	var timeout = setTimeout(function () {
        failCb();
        blurEvent.remove();
	}, msTimeout);

	    var iframe = document.querySelector('#hiddenIframeUriHandler');
	    if (!iframe) {
	        iframe = createHiddenIframe(document.body, "about:blank");
	    }

	    window.focus();
	    var blurEvent = registerEvent(window, "blur", onBlur);

	    function onBlur() {
	        clearTimeout(timeout);
	        blurEvent.remove();
	        successCb();
	    }

	iframe.contentWindow.location.href = uri;
}

//Used by Chrome
function openUriWithTimeout(uri, successCb, failCb, msTimeout) {
	/* NOLOG >> console.log("openUriWithTimeout"); << NOLOG */

	//handle page running in an iframe (blur must be registered with top level window)
	var target = window;
	while (target != target.parent) {
		target = target.parent;
	} 

	if (!isInstallingApp) {

	    target.focus();
	    var blurEvent = registerEvent(target, "blur", onBlur);

	    function onBlur() {
	        clearTimeout(timeout);
	        blurEvent.remove();
	        successCb();
	    }

	    var timeout = setTimeout(function () {
	        failCb();
	        blurEvent.remove();
	    }, msTimeout);

	window.location = uri;
}
	else {
	    failCb();
	}
}

//Used by FireFox
function openUriUsingFirefox (uri, successCb, failCb) {
    /* NOLOG >> console.log("openUriUsingFirefox"); << NOLOG */

	var iframe = document.querySelector('#hiddenIframeUriHandler');
	if (!iframe) {
	    iframe = createHiddenIframe(document.body, 'about:blank');
	}

	if (browser.firefoxversion >= 64) {

	    var timeout = setTimeout(function () {
	        failCb();
	        blurEvent.remove();
	    }, 1000);

	    function onBlur() {
	        clearTimeout(timeout);
	        blurEvent.remove();
	        successCb();
	    }

	    // Register the blur event on the webappWindow because it won't fire 
	    // if it's set on the root window when the WebApp is loaded:
	    var logonDocument = document.getElementById('iFrameLogon').contentDocument;
	    var webappWindow = logonDocument.getElementById('iFrameWebApp').contentWindow;
	    webappWindow.focus();
	    var blurEvent = registerEvent(webappWindow, "blur", onBlur);

	    iframe.contentWindow.location.href = uri;

	}
	else {

	    try {
	        iframe.contentWindow.location.href = uri;
	        successCb();
	    }
	    catch (e) {
	        if (e.name === 'NS_ERROR_UNKNOWN_PROTOCOL') {
	            failCb();
	        }
	    }
	}
}

//Used by Safari
function openUriUsingIE10InWindows7(uri, successCb, failCb, msTimeout) {
	/* NOLOG >> console.log("openUriUsingIE10InWindows7"); << NOLOG */
	var timeout = setTimeout(failCb, msTimeout);
	window.addEventListener("blur", function () {
		clearTimeout(timeout);
		successCb();
	});

	var iframe = document.querySelector('#hiddenIframeUriHandler');
	if (!iframe) {
		iframe = createHiddenIframe(document.body, "about:blank");
	}
	try {
		iframe.contentWindow.location.href = uri;
	} catch (e) {
		failCb();
		clearTimeout(timeout);
	}
}

function openUriInNewWindow(uri, successCb, failCb, msTimeout) {
	/* NOLOG >> console.log("openUriInNewWindow"); << NOLOG */
	var myWindow = window.open('', '', 'width=0,height=0');

	myWindow.document.write("<iframe src='" + uri + "'></iframe>");

	setTimeout(function () {
		try {
			myWindow.location.href;
			myWindow.setTimeout("window.close()", msTimeout);
			successCb();
		} catch (e) {
			myWindow.close();
			failCb();
		}
	}, msTimeout);
}

function createHiddenIframe (target, uri) {
	/* NOLOG >> console.log("createHiddenIframe"); << NOLOG */
	var iframe = document.createElement('iframe');
	iframe.src = uri;
	iframe.id = 'hiddenIframeUriHandler';
	iframe.style.display = 'none';
	target.appendChild(iframe);

	return iframe;
}

function registerEvent(target, eventType, cb) {
	/* NOLOG >> console.log("registerEvent " + eventType); << NOLOG */
	if (target.addEventListener) {
		target.addEventListener(eventType, cb);
		return {
			remove: function () {
				target.removeEventListener(eventType, cb);
			}
		};
	} else {
		target.attachEvent(eventType, cb);
		return {
			remove: function () {
				target.detachEvent(eventType, cb);
			}
		};
	}
}

function hideSections()
{	
	var sections = document.getElementsByClassName("helpSection");
	
	for (var i = 0; i < sections.length; i++) {		
		sections[i].style.display = "none";
	}
}

function displaySection(id)
{	
	hideSections();

	var sections = document.getElementsByClassName("helpSection");
	
	for (var i = 0; i < sections.length; i++) {		
		if (sections[i].id == id) {
			sections[i].style.display = "block";			
		}
	}
}

function setPage(page, section)
{
	section = section || "";
	
	if (((typeof page) != "string") || (page == "ac"))
	{
		page = defaultHelpPage;
	}
	
	if (section == "")
	{
		section = defaultSection;
	}	
	
	if (currentHelpPage != page)
	{	
		currentHelpPage = page;
		helpPage = "help\\" + page;
		help = document.getElementById("helpContainer");

		help.setAttribute("title", helpPage);
		
		includeHTML();
		openNav();
	}
	
	if (section != "")
	{
		setTimeout(function () {displaySection(section);}, 500);
	}
}

function openNav()
{	
	document.getElementById("mySidenav").style.width = "35%";
	document.getElementById("mySidenav").style.display = "block";
	document.getElementById("main").style.marginLeft = "35%";
	document.getElementById("copyClipboardModal").style.width = "65%";
	
	var help = document.getElementById('helpButton');
	if (help != null)
	{
		help.onclick = closeNav;
	}	
}

function closeNav() {
	document.getElementById("mySidenav").style.width = "0";
	document.getElementById("mySidenav").style.display = "none";
	document.getElementById("main").style.marginLeft = "0";
	document.getElementById("copyClipboardModal").style.width = "100%";
	
	var help = document.getElementById('helpButton');
	if (help != null)
	{
		help.onclick = openNav;
	}	
}

function includeHTML() {
	elmnt = document.getElementById("helpContainer");
	file = elmnt.getAttribute("title");
	
    if (file) {
		xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4) {
				if (this.status == 200) {
					elmnt.innerHTML = this.responseText;
				}

				if (this.status == 404) {
					setPage(defaultHelpPage);
				}
			}
		}

		xhttp.open("GET", file, true);
		xhttp.send();

		return;
	}
}

function showReconnectMessageBox(message)
{
    /* NOLOG >> console.log("showReconnectMessage"); << NOLOG */
    
    document.getElementById('msgFrame').innerHTML = '<h2 align="center">' + message + '</h2>\
    <div class="buttonWrapper"><a href="#" onclick="cancelReconnect()">Cancel</a></div>';
    
    isShowingReconnectMessage = true;
}

function hideReconnectMessageBox()
{
    if(isShowingReconnectMessage)
    {
        /* NOLOG >> console.log("hideReconnectMessage"); << NOLOG */
        
        isShowingReconnectMessage = false;
        
        document.getElementById('msgFrame').innerHTML = '';
    }
}

function cancelReconnect() {
    /* NOLOG >> console.log("cancelReconnect"); << NOLOG */
    
    var logonDocument = document.getElementById('iFrameLogon').contentDocument;
    var webappWindow = logonDocument.getElementById('iFrameWebApp').contentWindow;
    webappWindow.CancelReconnect();
}

function ResetBrand() {
    /* NOLOG >> console.log("ResetBrand"); << NOLOG */	
	
	try {BRAND_ELEMENT_LIST;}
	catch(e) {
		/* NOLOG >> console.log("Include brand.js to remove the following message:"); << NOLOG */
		/* NOLOG >> console.log(e); << NOLOG */
		return;
	}
	
	for (x = 0; x < BRAND_ELEMENT_LIST.length; x++) {		
		localStorage.removeItem(BRAND_ELEMENT_LIST[x]);
	}
	
	for (x = 0; x < BRAND_IMG_LIST.length; x++) {		
		localStorage.removeItem(BRAND_IMG_LIST[x]);
	}
}

function SetBrandedText(elementID, elementText) {
    /* NOLOG >> console.log("SetBrandedText"); << NOLOG */	
	
	try {BRAND_ELEMENT_LIST;}
	catch(e) {
		/* NOLOG >> console.log("Include brand.js to remove the following message:"); << NOLOG */
		/* NOLOG >> console.log(e); << NOLOG */
		return;
	}
	
	if (BRAND_ELEMENT_LIST.includes(elementID)) {
		localStorage.setItem(elementID, elementText);
	}
}

function SetBrandedImage(imageID, imageStyle, containerStyle, imgBase64) {
    /* NOLOG >> console.log("SetBrandedImage"); << NOLOG */
	
	try {BRAND_IMG_LIST;}
	catch(e) {
		/* NOLOG >> console.log("Include brand.js to remove the following message:"); << NOLOG */
		/* NOLOG >> console.log(e); << NOLOG */
		return;
	}
	
	if (BRAND_IMG_LIST.includes(imageID)) {
		var storedImage = JSON.parse(localStorage.getItem(imageID));
		
		if (storedImage) {			
			localStorage.setItem(imageID, JSON.stringify({
				imageStyle: imageStyle,
				containerStyle: containerStyle,
				imagedata: (storedImage.imagedata + imgBase64)
			}));	
		}
		else {
			var imageStr = 'data:image/png;base64,' + imgBase64;

			localStorage.setItem(imageID, JSON.stringify({
				imageStyle: imageStyle,
				containerStyle: containerStyle,
				imagedata: imageStr
			}));	
		}		
	}
}

function ApplyBrand() {
    /* NOLOG >> console.log("ApplyBrand"); << NOLOG */	
	
	try {BRAND_ELEMENT_LIST;}
	catch(e) {
		/* NOLOG >> console.log("Include brand.js to remove the following message:"); << NOLOG */
		/* NOLOG >> console.log(e); << NOLOG */
		return;
	}
	
	BrandContents();
}

function GetBrandToken() {
    /* NOLOG >> console.log("GetBrandToken"); << NOLOG */	
	var brandToken = JSON.parse(localStorage.getItem("BRAND_TOKEN"));
	
	if (brandToken == null)
	{
		brandToken = "0";
	}
	
	return brandToken;
}

function SetBrandToken(brandToken) {
	localStorage.setItem("BRAND_TOKEN", brandToken);
}

function StartOpenIDConnectAuthentication(URI) {
	localStorage.setItem('OIDCURLPART', window.location.href);
	window.location.replace(URI);
}

function ShowHideStartingSessionProgressMessage(bShow) {
	var startSession = document.getElementById('startingSession');
	if (startSession != undefined) {
		startSession.innerHTML = null;
			
		if (bShow == "true")
			startSession.innerHTML = '<h2 align="center">Starting session...</h2>';
		else
			startSession.innerHTML = '';		
	}
}

function ShowReconnectLink()
{
	/* NOLOG >> console.log("ShowReconnectLink"); << NOLOG */	
	document.getElementById('msgFrame').innerHTML = '<div class="buttonWrapper"><br/><a href="#" id="reconnectLink" onclick="ReloadPage()">Click to connect to ' + location.hostname + '</a><br>Do not use the browser\'s reload button</div>';
	document.getElementById('iFrameLogon').remove();
}

Array.prototype.includes = function (str) {
	var returnValue = false;

	if (this.indexOf(str) !== -1) {
		returnValue = true;
	}

	return returnValue;
}

// Create Element.remove() function if not exist
if (!('remove' in Element.prototype)) {
    Element.prototype.remove = function() {
        if (this.parentNode) {
            this.parentNode.removeChild(this);
        }
    };
}
