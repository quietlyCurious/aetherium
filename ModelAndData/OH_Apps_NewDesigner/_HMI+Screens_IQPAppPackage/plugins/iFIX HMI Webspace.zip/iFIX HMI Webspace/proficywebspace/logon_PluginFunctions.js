DEBUG = false;
Proficy_WebSpace_CONTROL_NAME = "Proficy_WebSpaceControl";
Proficy_WebSpace_PLUGIN_NAME = "Proficy WebSpace Browser Add-On";
Proficy_WebSpace_PLUGIN_TYPE = "application/x-proficy-plugin";
Proficy_WebSpace_PLUGIN_CODEBASE = "plugins/proficy-activex.cab";
Proficy_WebSpace_PLUGIN_CLASS_ID = "CLSID:1241F20B-0688-45A5-ADB2-208AFE4A5DDC";
Proficy_WebSpace_ROOT_ID = "Ieg.IEGCtrl";

function DebugMsg(message)
{
    if (DEBUG)
    {
        alert (message);
    }
}

function isActiveXControlInstalled(){
    axobj = null;
	
    try {
        axobj = new ActiveXObject(Proficy_WebSpace_ROOT_ID);
    }
    catch(e) {}
	
    if (axobj) {
		axobj = null;
        return true;
    }
	
    return false;
}
function GetPlatform()
{
	// Browser name string, major version, and agent string
	var name     = navigator.appName;
	var ver      = parseInt(navigator.appVersion);
	var agent    = navigator.userAgent;
	var platform = navigator.platform;

	// Microsoft Internet Explorer and version
	this.msie     = (agent.indexOf("MSIE") != -1);
	if(!this.msie){
	 this.msie = ((agent.indexOf("Windows NT") != -1) && (agent.indexOf("rv:11.0") != -1));
	}
	//alert(this.msie);
	this.msie4up  = (this.msie && (ver >= 4));  
	this.msie6up  = (agent.indexOf("MSIE 6") != -1);

	// Netscape Navigator and version
	this.ns = (name.indexOf("Netscape") != -1);
	this.ns4up = (this.ns && (ver >= 4));

	// Netscape 6 version is actually version 5.0 when getting the appVersion property.	
	this.ns6up = (this.ns && (ver >= 5));

	this.ff3     = (agent.toLowerCase().indexOf("firefox/3") != -1);
	this.ff4     = (agent.toLowerCase().indexOf("firefox/4") != -1);
	this.firefox = (agent.toLowerCase().indexOf("firefox") != -1);

	this.chrome  = (agent.toLowerCase().indexOf("chrome") != -1);

	this.safari = (agent.toLowerCase().indexOf("safari") != -1);

	// Operating system, test both Netscape agent or MSIE agent strings.
	this.win95 = ((agent.indexOf("Win95")!=-1) || (agent.indexOf("Windows 95")!=-1));
	this.win98 = ((agent.indexOf("Win98")!=-1) || (agent.indexOf("Windows 98")!=-1));
	this.winnt = ((agent.indexOf("WinNT")!=-1) || (agent.indexOf("Windows NT")!=-1));
	this.win   = (agent.indexOf("Win") != -1);
	this.mac   = (agent.indexOf("Mac") != -1);
	this.sun   = (agent.indexOf("SunOS") != -1);
	this.linux = (agent.indexOf("Linux") != -1);
	this.os2   = (agent.indexOf("OS2") != -1) || (agent.indexOf("OS/2") != -1);
	this.ce    = (platform.indexOf("CE") != -1);
	this.ppc   = (agent.indexOf("PPC") != -1);
	this.arm   = (agent.indexOf("Linux arm") != -1);
}


function IsInstalled()
{
	var pluginFound = false;

	if (navigator.plugins && navigator.plugins.length > 0) 
	{
		var pluginsArrayLength = navigator.plugins.length;

		for (pluginsArrayCounter=0; pluginFound != true && pluginsArrayCounter < pluginsArrayLength; pluginsArrayCounter++ )
		{
			var plugin=navigator.plugins[pluginsArrayCounter];
		
			for (type = 0; type < plugin.length; type++)
			{	
				if (plugin[type].type != null)
				{
					if (plugin[type].type.toLowerCase().indexOf(Proficy_WebSpace_PLUGIN_TYPE) != -1)
					{
						
						var browser = new GetPlatform();
						if ( browser.arm )
						{
							pluginFound = true;
							break;
						}
						var currentPluginStr = plugin.version;   //4.7.0.20203
						var latestPluginStr = GG_VERSION_PERIOD; //4.8.2.22186
						var currentPluginRes = currentPluginStr.replace(/\./g,''); //4.7.0.20203 --> 47020203
						var latestPluginRes =   latestPluginStr.replace(/\./g,''); //4.8.2.22186 --> 48222186
						var currentPluginNum = Number(currentPluginRes);
						var latestPluginNum =  Number(latestPluginRes);
						//window.alert(currentPluginNum);
						//window.alert(latestPluginNum);
						if (latestPluginNum <= currentPluginNum)
						{
							pluginFound = true;
							break;
						}
					}	
				}
			}
		}
	}
	return pluginFound;
}

function InstallXPI()
{
    var browser = new GetPlatform();
	
    if (browser.firefox)
    {
        if (!IsInstalled())
        {
            var xpi = {'Proficy_WebSpace Firefox Plugin':'plugins/proficy-nsplugin_ff3.windows.xpi'};  // default
            if ( browser.linux )
            {
                xpi = {'Proficy_WebSpace Firefox Plugin':'plugins/proficy-nsplugin_ff3.linux.xpi'};
            }
            if ( browser.arm )
            {
                xpi = {'Proficy_WebSpace Firefox Plugin':'plugins/proficy-nsplugin_ff3.arm.xpi'};
            }
            InstallTrigger.install(xpi);
        }
    }
    else
    {
       document.write("<p>Your browser is not currently supported.</p>");
    }
} 

function GetSearchString()
{
	return_value = '';
	get_string = document.location.search;

	if (get_string != '')
	{
		question_index = get_string.indexOf('?');
		return_value = get_string.substr(question_index + 1, get_string.length - 1);
	}

	return (return_value);  
}

function GetVarDecoded(name)
{
    var result = GetVar(name);
    return decodeURIComponent(result);
}

function GetVar(name)
{
	get_string = document.location.search;         
	return_value = '';
	
	do 
	{
		name_index = get_string.indexOf(name + '=');
		
		if (name_index != -1)
		{
			get_string = get_string.substr(name_index + name.length + 1, get_string.length - name_index);
			
			end_of_value = get_string.indexOf('&');

			if (end_of_value != -1)     
			{           
				value = get_string.substr(0, end_of_value);       
			}         
			else                
			{
				value = get_string;        
			}        
			
			if (return_value == '' || value == '')
			{
				return_value += value;
			}
			else
			{
				return_value += ', ' + value;
			}
		}
	} 
	while (name_index != -1)
	
	space = return_value.indexOf('+');

	while (space != -1)
	{ 
		return_value = return_value.substr(0, space) + ' ' + 
		return_value.substr(space + 1, return_value.length);
		space = return_value.indexOf('+');
	}

	return (return_value);
}

function InstallXPISilent()
{
	var browser = new GetPlatform();

	if (browser.firefox || browser.safari)
	{
		if (!IsInstalled())
		{
			InstallXPI();
		}
	}
}

function GetDocumentTitle()
{
    var title = "Proficy WebSpace";

    // TODO: Develop code to query the browser URL for host and workspace
    //       names and append those names to the document title.

    return title;
}
function DisplayInstallationInstructions()
{
		var browser = new GetPlatform();
		if (browser.msie)
		{
			document.getElementById('msgFrame').innerHTML = '<p><ul><li><b>WebSpace</b> requires a browser Add-on to run:<li>\
				<li>&nbsp;</li>\
				<li><a href="clients/proficy-client.ie.exe"><b>Download</b></a> the WebSpace Add-on installer.</li>\
				<li><b>Install</b></a> the WebSpace Add-on.</li>\
				<li><b>Restart</b> your browser to complete the installation.</li></ul></p>';
		}
		else if (browser.firefox)
		{
			document.getElementById('msgFrame').innerHTML = '<p><ul><li><b>WebSpace</b> requires a browser Add-on to run:<li>\
				<li>&nbsp;</li>\
				<li><a href="clients/proficy-client.firefox.exe"><b>Download</b></a> the WebSpace Add-on installer.</li>\
				<li><b>Install</b></a> the WebSpace Add-on.</li>\
				<li><b>Restart</b> the browser to complete the installation.</li></ul></p>';
		}
		else if (browser.safari && !browser.chrome)
		{
			document.getElementById('msgFrame').innerHTML = '<p><ul><li><b>WebSpace</b> requires a browser Add-on to run:<li>\
				<li>&nbsp;</li>\
				<li><a href="clients/proficy-client.mac.dmg"><b>Download</b></a> the Mac OS X Client installer.</li>\
				<li><b>Open</b> <i>proficy-client.mac.dmg</i>.</li>\
				<li><b>Double-click</b> <i>proficy-client.mac.pkg</i>.</li>\
				<li><b>Run</b> the installation wizard using the default settings.</li>\
				<li><b>Run</b> Applications | WebSpace from the dock.</li>\
				<li><b>Restart</b> your browser to access the WebSpace Add-On.</li></ul></p>';
		}
		else if (browser.chrome)
		{
			document.getElementById('msgFrame').innerHTML = '<p><ul><li><b>WebSpace</b> requires a browser Add-on to run:<li>\
				<li>&nbsp;</li>\
				<li><a href="clients/proficy-client.chrome.exe"><b>Download</b></a> the WebSpace Add-on installer.</li>\
				<li><b>Install</b></a> the WebSpace Add-on.</li>\
				<li><a href="https://chrome.google.com/webstore/detail/dehpdfcoohknpmeeojmfkgkgkkpkkcbp" target="_blank"><b>Install</b></a> the Chrome Extension from the Chrome Web Store.</li>\
				<li><b>Reload</b> the page to complete the installation.</li></ul></p>';
		}
}