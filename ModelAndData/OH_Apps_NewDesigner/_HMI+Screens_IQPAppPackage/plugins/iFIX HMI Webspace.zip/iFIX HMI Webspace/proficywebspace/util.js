HTML5_CLIENT = false;
NATIVE_CLIENT = false;

checkEnvironment();

window.onload = init;
var browser = new GetPlatform();
var controlArguments = window.parent.controlArguments || new Object;
var forceClient = GetVar("force");
var installOnly = GetVar("installOnly");
var allUsers = GetVar("allusers");
var printJob = undefined;
var pdfData = undefined;

var printFrame = document.getElementById("printFrame");

if (printFrame) {
	PDFJS.workerSrc = 'print/build/pdf.worker.js?v=32205';
}

determineClient();

var controlArgs = controlArgs || (function(){
    return { set : function(Args) { controlArguments[Args[0]] = Args[1]; } };
}());

function init() {

	if (controlArguments.hasOwnProperty("showTitle") &&
		controlArguments["showTitle"] == "true")
	{
		var bar = parent.document.getElementById('barFrame');
		if (bar)
		{
			bar.style.display = "block";
		}
	}

	var data = document.location.search.split("?");
	
	if (data[1] == "help=ac")
	{
		window.location.search = "?host=127.0.0.1&useApp=false&adminWithArgs=true&app=adminconsole&args=-eventNotifications&help=quickstart.html&noscale=true";
		return;
	}
	
//	if (installOnly == "true")
//	{	
//		window.location.replace("clients.html");
//		return;
//	}
	
	if ((NATIVE_CLIENT == true) && (BROWSER_INTERFACE == true))
	{
		CallbackLoop();
	}
}

function determineClient() {
	
	if ((forceClient == "HTML5") || (browser.cros))
	{
		HTML5_CLIENT = true;
		NATIVE_CLIENT = false;
	}
	else if ((forceClient == "NATIVE") || IsInstalled())
	{
		NATIVE_CLIENT = true;
		HTML5_CLIENT = false;
	}
	else
	{
		HTML5_CLIENT = true;
		NATIVE_CLIENT = false;
	}
}
	
function writeURLVars(control, type) {

	var width = 0;
	var height = 0;
	var isEmbedded = false;
	var query = location.search.substr(1);	
	var data = query.split("&");
	
	// Process any arguments added in logon.html
	for (var property in controlArguments) {
		if (controlArguments.hasOwnProperty(property)) {
			if (data[0] == "")
			{
				data[0] = property + "=" + controlArguments[property];
			}
			else
			{
				data[data.length] = property + "=" + controlArguments[property];
			}
		}
	}

	if (data[0] == "")
	{
		// No URL or arguments to process
		control.setAttribute("width", "0");
		control.setAttribute("height", "0");
		return;
	}

    try
	{ 	
		for (var i = 0; i < data.length; i++)
		{		
			var item = data[i].split("=");
			
			var name = item[0];
			var value = decodeURIComponent(item[1]);
			
			switch (name) {	
				case "app":
					name = "application";
					break;
				case "embed":
					name = "isembeddedwin";
					isEmbedded = true;
					break;
				case "port":
					name = "hostport";
					break;				
				case "printerconfig":
					name = "autoconfigprinters";
					break;			
				case "width":
					width = value;
					break;			
				case "height":
					height = value;
					break;
				default:
					// supported by default: user, password, host, compression, clientframe, multimonitor, noscale,
					// authority, credentials, sessionid, autoreconnect, maxbpp, keyboard, args
					break;
			}
			
			if (type == "embed")
			{
				control.setAttribute(name, value);
			}
			else if (type = "object")
			{
				switch (name)
				{	
					case "width":
					case "height":
						control.setAttribute(name, value);
						break;
					default:
						var param = document.createElement("param");
						param.setAttribute("name", name);
						param.setAttribute("value", value);
						control.appendChild(param);
						break;
				}			
			}
		}
		
		if (isEmbedded == true)
		{				
			if (width == 0)
			{
				control.setAttribute("width", "100%");
			}
			
			if (height == 0)
			{
				control.setAttribute("height", "100%");
			}
		}
		else
		{		
			if (width == 0)
			{
				control.setAttribute("width", "0");
			}
			
			if (height == 0)
			{
				control.setAttribute("height", "0");
			}		
		}
    }
	catch(err)
	{
		/* NOLOG >> console.log("writeURLVars(): " + err); << NOLOG */
	}
    console.log();
}

function NextStep(step)
{
	var instructionList = document.getElementsByClassName(step);
		
	if (instructionList) {
		for (i = 0; i < instructionList.length; i++) {
			occurance = instructionList[i];
			occurance.style.visibility = "visible";
		}
	}	
	
	return true;
}

function TailorForOS()
{
	if (!browser) {
		browser = new GetPlatform();
	}
	
	var os = "OS_UNKNOWN";
	
	if (browser.win)
	{
		if (allUsers == "true")
		{
			os = "OS_WINDOWS_ALLUSERS";			
		}
		else
		{
			os = "OS_WINDOWS";
		}
	}
	else if (browser.ios)
	{
		os = "OS_IOS";
	}
	else if (browser.cros)
	{
		os = "OS_CHROME";
	}
	else if (browser.android)
	{
		os = "OS_ANDROID";
	}
	else if (browser.mac)
	{
		os = "OS_MAC";
	}
	else if (browser.linux)
	{
		if ((browser.redhat) || (browser.suse))
		{
			os = "OS_LINUX_REDHAT";			
		}
		else if (browser.ubuntu)
		{
			os = "OS_LINUX_DEBIAN";			
		}
		else
		{
			os = "OS_LINUX_UNKNOWN";
		}
	}
		
	var elementList = document.getElementsByClassName("OS");
		
	if (elementList) {
		for (i = 0; i < elementList.length;) {
			occurance = elementList[i];
			
			if (occurance.classList.contains(os))
			{
				occurance.style.visibility = "visible";
				i++;
			}
			else
			{
				occurance.parentNode.removeChild(occurance);
			}
		}
	}	
}

function TailorForBrowser()
{
	if (!browser) {
		browser = new GetPlatform();
	}
	
	if (!browser.chrome)
	{
		var elementList = document.getElementsByClassName("browserChrome");
			
		if (elementList) {
			for (i = 0; i < elementList.length; i++) {
				occurance = elementList[i];
				occurance.style.display = "none";
			}
		}
	}		
	
	if (!browser.firefox)
	{
		var elementList = document.getElementsByClassName("browserFirefox");
			
		if (elementList) {
			for (i = 0; i < elementList.length; i++) {
				occurance = elementList[i];
				occurance.style.display = "none";
			}
		}
	}
	
	if (!browser.msie)
	{
		var elementList = document.getElementsByClassName("browserMSIE");
			
		if (elementList) {
			for (i = 0; i < elementList.length; i++) {
				occurance = elementList[i];
				occurance.style.display = "none";
			}
		}
	}		
	
	if (!browser.edge)
	{
		var elementList = document.getElementsByClassName("browserEdge");
			
		if (elementList) {
			for (i = 0; i < elementList.length; i++) {
				occurance = elementList[i];
				occurance.style.display = "none";
			}
		}
	}
}

function isTouchDevice() {
    return (('ontouchstart' in window) ||
            (navigator.maxTouchPoints > 0) ||
            (navigator.msMaxTouchPoints > 0));
}

function GetPlatform()
{
	// Browser name string, major version, and agent string
	var name     = navigator.appName;
	var ver      = parseInt(navigator.appVersion);
	var agent    = navigator.userAgent;
	var platform = navigator.platform;

	// Microsoft Internet Explorer and version
	this.msie     = (document.documentMode != undefined);
	this.msie4up  = (document.documentMode >= 4);  
	this.msie6up  = (document.documentMode >= 6);
	this.msie7up  = (document.documentMode >= 7);
	this.msie10orlower  = (document.documentMode <= 10);

	this.edge = (agent.toLowerCase().indexOf("edge/") != -1);
	
	// Netscape Navigator and version
	this.ns = (name.indexOf("Netscape") != -1);
	this.ns4up = (this.ns && (ver >= 4));

	// Netscape 6 version is actually version 5.0 when getting the appVersion property.	
	this.ns6up = (this.ns && (ver >= 5));

	this.ff3     = (agent.toLowerCase().indexOf("firefox/3") != -1);
	this.ff4     = (agent.toLowerCase().indexOf("firefox/4") != -1);
	this.firefox = (agent.toLowerCase().indexOf("firefox") != -1);
	this.firefoxversion = (parseInt(agent.toLowerCase().substr((agent.toLowerCase().indexOf("firefox") + 8), 4)));

	this.chrome  = (agent.toLowerCase().indexOf("chrome") != -1);
	this.cros    = (agent.toLowerCase().indexOf("cros") != -1);
	
	if (this.cros == true)
	{
		this.chrome = false;
		this.safari = false;		
	}
	
	if (this.edge == true)
	{
		this.chrome = false;
		this.safari = false;
	}	
	else if (this.chrome == true)
	{
		this.safari = false;
	}
	else if (this.cros == false)
	{
		this.safari = (agent.toLowerCase().indexOf("safari") != -1);
	}
	
	if (this.safari)
	{
		this.safari10 = (agent.toLowerCase().indexOf("version/1") != -1);		
	}

	// Operating system, test both Netscape agent or MSIE agent strings.
	this.win95 = ((agent.indexOf("Win95")!=-1) || (agent.indexOf("Windows 95")!=-1));
	this.win98 = ((agent.indexOf("Win98")!=-1) || (agent.indexOf("Windows 98")!=-1));
	this.winnt = ((agent.indexOf("WinNT")!=-1) || (agent.indexOf("Windows NT")!=-1));
    if(this.winnt == true)
    {
        this.surface = isTouchDevice();
    }
	this.win   = (agent.indexOf("Win") != -1);
	this.mac   = (agent.indexOf("Mac") != -1);
	this.sun   = (agent.indexOf("SunOS") != -1);
	this.linux = (agent.indexOf("Linux") != -1);
	this.os2   = (agent.indexOf("OS2") != -1) || (agent.indexOf("OS/2") != -1);
	this.ce    = (platform.indexOf("CE") != -1);
	this.ppc   = (agent.indexOf("PPC") != -1);
	this.ios   = /iPad|iPhone|iPod/.test(agent) && !window.MSStream;
	this.android = (agent.toLowerCase().indexOf("android") != -1);
	this.ubuntu = (agent.toLowerCase().indexOf("ubuntu") != -1);
	this.redhat = (agent.toLowerCase().indexOf("red hat") != -1);
	this.suse = (agent.toLowerCase().indexOf("suse") != -1);
	
	this.softkeyboard = ((this.android == true) || (this.ios == true) || (this.surface == true));
}

function IsInstalled()
{	
	// TODO: determine if the native client is installed
	return false;
}

function GetSearchString()
{
	return_value = '';
	get_string = document.location.search;

	if (get_string != '')
	{
		question_index = get_string.indexOf('?');
		return_value = get_string.substr(question_index + 1, get_string.length - 1);
	}

	return (return_value);  
}

function GetVarDecoded(name)
{
    var result = GetVar(name);
    return decodeURIComponent(result);
}

function GetVar(name)
{
	get_string = document.location.search;         
	return_value = '';
	
	do 
	{
		name_index = get_string.indexOf(name + '=');
		
		if (name_index != -1)
		{
			get_string = get_string.substr(name_index + name.length + 1, get_string.length - name_index);
			
			end_of_value = get_string.indexOf('&');

			if (end_of_value != -1)     
			{           
				value = get_string.substr(0, end_of_value);       
			}         
			else                
			{
				value = get_string;        
			}        
			
			if (return_value == '' || value == '')
			{
				return_value += value;
			}
			else
			{
				return_value += ', ' + value;
			}
		}
	} 
	while (name_index != -1)
	
	space = return_value.indexOf('+');

	while (space != -1)
	{ 
		return_value = return_value.substr(0, space) + ' ' + 
		return_value.substr(space + 1, return_value.length);
		space = return_value.indexOf('+');
	}

	return (return_value);
}

function buildCommandLine(useOIDC) {
	var query = location.search.substr(1);
	var data = query.split("&");
	var appArgs = false;
	var fullCommandLine = "";
	var websocketDefined = false;
	var host = location.hostname;
	var port = "491";

	if (useOIDC === 1)
	{
		var hash = window.location.hash.split("#");
		if (hash[1] !== undefined) {
			fullCommandLine += writeCommandLineParameter("OIDC", decodeURIComponent(hash[1])) + " ";
		}
	}

	// Process any arguments added in logon.html
	for (var property in controlArguments) {
		if (controlArguments.hasOwnProperty(property)) {
			if (data[0] == "")
			{
				data[0] = property + "=" + controlArguments[property];
			}
			else
			{
				data[data.length] = property + "=" + controlArguments[property];
			}
		}
	}
	
	for (var i = 0; i < data.length; i++)
	{		
		var item = data[i].split("=");
		
		if (item[0] == "WebSocketURL")
		{
			websocketDefined = true;
		}
		else if (item[0] == "host")
		{
		    host = item[1];
		}
		else if (item[0] == "port")
		{
		    port = item[1];
		}
		else if ((item[0] == "r") || (item[0] == "args"))
		{
			// make sure any app-bound arguments are put at the end of the command line
			appArgs = true;
			appArgsValue = item[1];
			continue;		
		}
		
		if (item[0] != "" && item[0] != "host")
		{
			fullCommandLine += writeCommandLineParameter(item[0], decodeURIComponent(item[1])) + " ";
		}
	}
	
	if ((location.protocol == "https:") && (websocketDefined == false))
	{
		host = "wss://" + host;
	}
	
	fullCommandLine += writeCommandLineParameter("host", host) + " ";

	if (appArgs == true)
	{
		fullCommandLine += writeCommandLineParameter("r", decodeURIComponent(appArgsValue)) + " ";
	}
	
	return fullCommandLine;
}

function writeCommandLineParameter(param, value) {
	var retVal = "";
	var iframeElement = document.getElementById("iFrameWebApp");
	
	if (value && (value.length > 0))
	{
		if (value == "true")
		{
			value = "1";
		}
		else if (value == "false")
		{
			value = "0";
		}
	
		switch (param) {
			case "host":
				if (iframeElement) {
					iframeElement.contentWindow.Module['arguments'].push('-h');
					iframeElement.contentWindow.Module['arguments'].push(value);
				}

				var address = value.split('//');
				if (address[1] != undefined)
				{
					value = address[1];
				}

				retVal = "-h " + value;
				break;
			case "user":
				if (iframeElement) {
					iframeElement.contentWindow.Module['arguments'].push('-u');
					iframeElement.contentWindow.Module['arguments'].push(value);
				}
				retVal = "-u " + value;
				break;
			case "password":
				if (iframeElement) {
					iframeElement.contentWindow.Module['arguments'].push('-p');
					iframeElement.contentWindow.Module['arguments'].push(value);
				}
				retVal = "-p " + value;
				break;
			case "app":
				if (iframeElement) {
					iframeElement.contentWindow.Module['arguments'].push('-a');
					iframeElement.contentWindow.Module['arguments'].push(value);
				}
				retVal = "-a " + value;
				break;
			case "port":
				if (iframeElement) {
					iframeElement.contentWindow.Module['arguments'].push('-hp');
					iframeElement.contentWindow.Module['arguments'].push(value);
				}
				retVal = "-hp " + value;
				break;			
			case "printerconfig":
				if (iframeElement) {
					iframeElement.contentWindow.Module['arguments'].push('-ac');
					iframeElement.contentWindow.Module['arguments'].push(value);
				}
				retVal = "-ac " + value;
				break;					
			case "keyboard":
				if (iframeElement) {
					iframeElement.contentWindow.Module['arguments'].push('-kb');
					iframeElement.contentWindow.Module['arguments'].push(value);
				}
				retVal = "-kb " + value;
				break;			
			case "args":
				if (iframeElement) {
					iframeElement.contentWindow.Module['arguments'].push('-r');
					iframeElement.contentWindow.Module['arguments'].push(value);
				}
				retVal = "-r " + value;
				break;
			case "multimonitor":
				if (iframeElement) {
					iframeElement.contentWindow.Module['arguments'].push('-mm');
					iframeElement.contentWindow.Module['arguments'].push(value);
				}
				retVal = "-mm " + value;
				break;
            case "showlogon":
                if (iframeElement) {
                    iframeElement.contentWindow.Module['arguments'].push('-showlogon');
                    iframeElement.contentWindow.Module['arguments'].push(value);
                }
                retVal = "-showlogon " + value;
                break;
			case "video":
				
				if (value == 1)
				{
					if (iframeElement) 
					{
						iframeElement.contentWindow.Module['arguments'].push('-video');
					}			
					retVal = "-video";
				}
				else if(value == 2)
				{
					if (iframeElement) 
					{
						iframeElement.contentWindow.Module['arguments'].push('-fullvideo');
					}
					retVal = "-fullvideo";
				}
				else if(value == 3)
				{
					if (iframeElement) 
					{
						iframeElement.contentWindow.Module['arguments'].push('-video');
						iframeElement.contentWindow.Module['arguments'].push('-testvideo');
					}
					retVal = "-video -testvideo";
				}
				else if(value == 4)
				{
					if (iframeElement) 
					{
						iframeElement.contentWindow.Module['arguments'].push('-fullvideo');
						iframeElement.contentWindow.Module['arguments'].push('-testvideo');
					}
					retVal = "-fullvideo -testvideo";
				}
				else // (value == 0)
				{
					if (iframeElement) 
					{
						iframeElement.contentWindow.Module['arguments'].push('-novideo');
					}
					retVal = "-novideo";
				}
				
				break;
            case "keyreportingmethod":
                if (iframeElement) {
                    iframeElement.contentWindow.Module['arguments'].push('-krm');
                    iframeElement.contentWindow.Module['arguments'].push(value);
                }
                retVal = "-krm " + value;
                break;
			case "maxbpp":
				if (iframeElement) {
					iframeElement.contentWindow.Module['arguments'].push('-mx');
					iframeElement.contentWindow.Module['arguments'].push(value);
				}
				retVal = "-mx " + value;
				break;
            case "computerName":
                if (iframeElement) {
                    iframeElement.contentWindow.Module['arguments'].push('-cn');
                    iframeElement.contentWindow.Module['arguments'].push(value);
                }
                retVal = "-cn " + value;
                break;
			case "clientframe":
			case "f":
				if (iframeElement) {
					iframeElement.contentWindow.Module['arguments'].push('-f');
				}
				retVal = "-f " + value;
				break;
			case "compression":	
			case "c":
				if (value == 1)
				{
					if (iframeElement) {
						iframeElement.contentWindow.Module['arguments'].push('-c');
					}
					retVal = "-c";
				}
				else
				{
					if (iframeElement) {
						iframeElement.contentWindow.Module['arguments'].push('-nc');
					}
					retVal = "-nc";
				}					
				break;
			case "nc":
				if (value == 1)
				{
					if (iframeElement) {
						iframeElement.contentWindow.Module['arguments'].push('-nc');
					}
					retVal = "-nc";
				}
				else
				{
					if (iframeElement) {
						iframeElement.contentWindow.Module['arguments'].push('-c');
					}
					retVal = "-c";
				}					
				break;
			case "WebSocketURL":
			    if (iframeElement && iframeElement.contentWindow.Module)
				{
					var ws = new WebSocket(value, 'binary');
					if (iframeElement) {
						iframeElement.contentWindow.Module['websocket'] = ws;
					}
					retVal = "-websocket " + ws;
				}
				break;
			case "gateway":
				if (value == 1)
				{
					gateway = 1;
				}
				// fall through
			default:
				// supported by default: -h, -u, -p, -a, -hp, -ac, -kb, -r, -mm, -mx, -f,
				// -bc, -st, -fb, -lz, -cbs, -md, -qt, -so, -ss, -cw, -width, -height
				// -authorityKey, -credentialsKey, -sessionID, -autoreconnect, 
				if (iframeElement) {
					iframeElement.contentWindow.Module['arguments'].push('-' + param);
					iframeElement.contentWindow.Module['arguments'].push(value);
				}
				retVal = "-" + param + " " + value;
				break;
		}
	}	
	
	return(retVal);
}

var PrintJob = function(filename) {
	this.parts = [];
	this.filename = filename;
}

PrintJob.prototype.append = function(filename, part) {
	if (this.filename == filename)
	{
		this.parts.push(part);
	}
	else
	{
		console.error("Error occurred while appending print job data: " + filename);
	}
};

PrintJob.prototype.getData = function(filename) {
	var baLength = 0;
	var raw = [];
	
	try
	{
		if (this.filename == filename)
		{
			for (var i = 0; i < this.parts.length; i++)
			{
				raw[i] = atob(this.parts[i]);
				baLength += raw[i].length;
			}
			
			var uint8Array = new Uint8Array(new ArrayBuffer(baLength));
			var uintPos = 0;
			
			for (var i = 0; i < raw.length; i++)
			{
				for (var j = 0; j < raw[i].length; j++)
				{
					uint8Array[uintPos] = raw[i].charCodeAt(j);
					uintPos++;
				}	
			}
		}
		else
		{
			console.error("Error occurred while getting print job data: " + filename);
		}
	}
	catch(err)
	{
		console.error("Error occurred while displaying print job: " + filename + " " + err.message);
	}
	
	return uint8Array;
};

function writePrintJob(filename, data) {	
	if ((printJob) && (printJob.filename != filename))
	{
		printJob = undefined;
	}
	
	if (!printJob) 
	{
		printJob = new PrintJob(filename);
	}
	
	printJob.append(filename, data);
}

function UnloadPdfDocument() {
	var iframeElement = document.getElementById("iFrameWebApp");

	if (iframeElement) {
		iframeElement.contentWindow.Module.ccall('PaintRootWindowCallback', 'null', ['null']);
	}
}

function LoadPdfDocument() {
	var printiFrame = document.getElementById('pdfViewer');
	
	printiFrame.addEventListener("unload", UnloadPdfDocument);	
	printiFrame.contentWindow.PDFViewerApplication.open(pdfData);
}

function displayFile(filename, type) {
	try
	{
		var frameDoc = document.getElementById('iFrameWebApp').contentDocument;
		var canvasFrame = frameDoc.getElementById('canvas');
		
		pdfData = printJob.getData(filename);
		
		var printiFrame = document.createElement("iframe");
		printiFrame.id = "pdfViewer";
		printiFrame.src = "print/web/viewer.html";
		printiFrame.style = "width: 100%; height: 100%;";	
		printiFrame.width = canvasFrame.width;
		printiFrame.height = canvasFrame.height;			
		printiFrame.onload = function() {
			LoadPdfDocument();
		};
		
		var printFrame = document.getElementById('printFrame');
		printFrame.style.display = "block";
		printFrame.width = canvasFrame.width;
		printFrame.height = canvasFrame.height;		
		printFrame.appendChild(printiFrame);	
	}
	catch(err)
	{
		console.error("Error occurred while displaying print job: " + filename + " " + err.message);
	}
}

function checkEnvironment()
{
	// Define and methods that are undefined as noops
	var methods = ["assert", "cd", "clear", "count", "countReset", "debug", "dir", "dirxml", "error", "exception", "group", "groupCollapsed",
		"groupEnd", "info", "log", "markTimeline", "profile", "profileEnd", "select", "table", "time", "timeEnd", "timeStamp", "timeline", "timelineEnd", "trace", "warn"];
	var length = methods.length;
	var console = (window.console = window.console || {});
	var method;
	var noop = function() {};
	while (length--) {
		method = methods[length];
		if (!console[method])
			console[method] = noop;
	}
}

//Clipboard 'Copy Link' related functions
function startCopyLinkToClipboard(text) {
    document.getElementById("copy_link_text").value = text;
    document.getElementById("copyLinkClipboardModal").style.display = "block";
}

function copyLinkToClipboard(copyButton) {
    // find copy target element
    var
	copyTarget = copyButton.dataset.copytarget,
	inp = (copyTarget ? document.querySelector(copyTarget) : null);

    // is element selectable?
    if (inp && inp.select) {
        // select text
        inp.select();
        var success = false;

        try {
            // copy text
            success = document.execCommand('copy');
        }
        catch (err) {
            success = false;
        }

        if (success) {
            closeCopyLinkClipboardDialog();
        }
        else {
            alert('please press Ctrl/Cmd+C to copy');
        }
    }
}

// When the user clicks on <span> (x), close the copy clipboard dialog
function closeCopyLinkClipboardDialog() {
    document.getElementById("copyLinkClipboardModal").style.display = "none";
    setPage("quickstart.html", "AC_GetLinkClose");
}

// When the user clicks anywhere outside of the copy clipboard dialog, close it
window.onclick = function (event)
{
	var modalLink = document.getElementById("copyLinkClipboardModal");
	if (event.target == modalLink)
	{
		closeCopyLinkClipboardDialog();
	}
	var modal = document.getElementById("copyClipboardModal");
	if (event.target == modal)
	{
		closeCopyClipboardDialog();
	}
}

//Clipboard MENU copy related functions
function startCopyToClipboard(text) {
	document.getElementById("copy_text").value = text;
	document.getElementById("copyClipboardModal").style.display = "block";
}

function copyToClipboard(copyButton) {
	// find copy target element
	var
	copyTarget = copyButton.dataset.copytarget,
	inp = (copyTarget ? document.querySelector(copyTarget) : null);

	// is element selectable?
	if (inp && inp.select) {
		// select text
		inp.select();
		var success = false;

		try {
			// copy text
			success = document.execCommand('copy');
		}
		catch (err) {
			success = false;
		}

		if (success) {
			closeCopyClipboardDialog();
		}
		else {
			alert('please press Ctrl/Cmd+C to copy');
		}
	}
}

// When the user clicks on <span> (x), close the copy clipboard dialog
function closeCopyClipboardDialog() {
	document.getElementById("copyClipboardModal").style.display = "none";
}

