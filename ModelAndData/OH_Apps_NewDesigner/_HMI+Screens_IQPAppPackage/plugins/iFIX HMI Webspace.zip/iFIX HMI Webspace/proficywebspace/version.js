// This file is modified during the build process. 
// Other files (html, js, etc.) include this file to get this version specific string

var GG_VERSION_COMMA="6,2,2,32205";
var GG_VERSION_PERIOD="6.2.2.32205";

VERSION_MAJ=6;
VERSION_MIN=2;
VERSION_REV=2;
VERSION_BLD=32205;

