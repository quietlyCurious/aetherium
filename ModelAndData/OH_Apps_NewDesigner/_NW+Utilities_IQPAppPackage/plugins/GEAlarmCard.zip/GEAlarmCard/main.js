
/* global EMBED, console, jQuery, $, _, Event, handlePluginData, formatSubscriptionData, getInputValue */

let ASSET_CONTEXT = 'EquipmentContext';
let assetContextSubscribeKey = null;
let assetContextValue = null;
// let assetNameOverrideValue = null;
let rootElement = EMBED.getRootElement();
let pluginElement = rootElement.parents('.coordinated_container.plug-in-component');
let elementZindex = pluginElement ? pluginElement.css('zIndex') : '';
let mainElement = EMBED.getRootElement().find('.geAlarmCard');
let alarmGridElement = null;
let DEFAULT_PAGESIZE = 10; /* number of alarms to show in a page */

const restDataUrl = window.location.origin;

let previouslyLoadedData = null;
const pluginOptions = EMBED.getElementOptions();



function init(data) {
	'use strict';

	data = data || EMBED.getComponent();
	// data = data || component.schema.data;
	var pluginInputNames = ['AssetName', 'DataSource'];
	handlePluginData(EMBED, data, pluginInputNames, function(values) {
		var newValues = {};
		$.extend(newValues, previouslyLoadedData, values);
		
		// if data hasn't changed since last init() call, don't reload chart
		if(values && values.schema && values.schema.data && previouslyLoadedData && _.isEqual(values.schema.data, previouslyLoadedData)) {
			return;
		}

		var valuesData = (values && values.schema && values.schema.data) || {};  

		// don't change this to logger.log. Otherwise there's no statement to latch onto open main.js from dev console
		// console.log(`init: data = ${JSON.stringify(data)}`);
	
		previouslyLoadedData = JSON.parse(JSON.stringify(valuesData));
		assetContextValue = formatSubscriptionData(getInputValue(newValues, 'AssetName'),data.schema.data, 'AssetName');
		const dataSource = formatSubscriptionData(getInputValue(newValues, 'DataSource'),data.schema.data, 'DataSource', true);
		const updatedDatasource = (dataSource && Array.isArray(dataSource) && dataSource.length) ? [...new Set(dataSource.filter(Boolean))] : [];
		
		console.log(assetContextValue, ' - assetContextValue:: Asset value from manifest data source widget');

		console.log('restDataUrl = ' + restDataUrl);
		let { data: originalData } = data.schema || {};
		const { Language = '', PageSize = 10, UseAllAsDefault,  ...alarmProps } = originalData || {};
		
		const getGridAttributes = ({AutoHideColumns = false, ...rest } = {}) => {
			if (AutoHideColumns){
				return `${'AutoHideColumns'.toLowerCase()}`;
			}
			let result = '';
			for (const [key, value] of Object.entries(rest)) {
				if(value){
					result += ` ${getAttribute(key)}`;
				}
			}
			return result;
		};
		
		const getAttribute = (key = '') => {
			if (key === 'HideAcknowledge') {
				return 'hideack';
			}
			if (key === 'HideStartTime') {
				return 'hidetime';
			}
			return `${key.toLowerCase()}`;
		};

		const gridAttributes = getGridAttributes(alarmProps);
		let useallasdefault = UseAllAsDefault ? 'useallasdefault' : '';
		console.log(UseAllAsDefault, ' - should use all as default value when page loaded (when context is available', !!useallasdefault);
		
		if (alarmGridElement) {
			alarmGridElement.defaultdatasource = updatedDatasource;
		} else {
			let gridDom = `<ge-alarm-grid id='geAlarmGrid' serverurl='${restDataUrl}' pagesize='${PageSize}' language='${Language}' assetcontext='${assetContextValue}' ${gridAttributes} ${useallasdefault}></ge-alarm-grid>`;
			let gridDiv = mainElement.find('#geAlarmGridDiv');
			if (pluginOptions.isClassicApp) {
				setCardInitialHeight(gridDiv, PageSize);
			}
			jQuery(gridDiv).html(gridDom);
			alarmGridElement = EMBED.getRootElement().find('#geAlarmGrid')[0];
			alarmGridElement.defaultdatasource = updatedDatasource;
			addEventListenerForAlarmFilterDialog();
		}
	});
}




// Subscribe to AssetContext
assetContextSubscribeKey = EMBED.subscribe(ASSET_CONTEXT, assetContextChanged);

//'$' causes issue when put plugins on same page. jQuery can solve the problem but 'remove' event
//cannot received. using jQuery instead of '$' when IQP solves the issue
//jQuery(mainElement).on('remove', function () {
$(mainElement).on('remove', function () {
	'use strict';
		EMBED.unsubscribe(ASSET_CONTEXT, assetContextSubscribeKey);
		alarmGridElement.closeSubscriptionSessions();
});


function setCardInitialHeight(card, requestedPageSize) {
	'use strict';
	let titleBarHeight = 50;
	let headerRowHeight = 40;
	let rowHeight = 51;
	let tableMargin = 1;
	let pageDivHeight = 44;
	let targetPageSize = requestedPageSize || DEFAULT_PAGESIZE;

	let pageSizeVal = parseInt(targetPageSize);
	if (isNaN(pageSizeVal) || pageSizeVal < 1) {
		pageSizeVal = parseInt(DEFAULT_PAGESIZE);
	}

	let heightInPixels = titleBarHeight + headerRowHeight + (pageSizeVal * rowHeight) + tableMargin + pageDivHeight;

	jQuery(card).height(heightInPixels);
}

function assetContextChanged(topic, value) {
	'use strict';
	//console.log('assetContextChanged was triggered for topic: %s, its value is: %s', topic, value);
	if(!assetContextValue) {
		// assetContextValue = value;
		//update asset context
		alarmGridElement.setAttribute('assetContext', value);
		console.log('asset context changed to: ' + value);

	} else {
		console.log('\tuser overriding context, ignoring asset context change');
	}
}

// Dynamically insert vendor libraries in to the end app 
// as multiple instances of vendors will not work with polymer components

function loadScripts() {
  'use strict';
  const head = document.head;
  const isVendorsLoaded = [...document.querySelectorAll('script')].some((i) => /shared.plugin.vendors.js/.test(i.src));
  if (!isVendorsLoaded) {
	window.loadingSharedVendors = true;
    const sharedPluginVendors = document.createElement('script');
    sharedPluginVendors.setAttribute('src', 'custom/default/GEAlarmCard/scripts/ge-alarms/shared.plugin.vendors.js');
    head.insertBefore(sharedPluginVendors, head.firstElementChild);
    sharedPluginVendors.onload = function () {
		window.loadingSharedVendors = false;
		document.dispatchEvent(new Event('sharedVendorsLoaded'));
    };
  } 
  if(window.loadingSharedVendors){
		document.addEventListener('sharedVendorsLoaded', loadPolymerComponents);
	} else {
		loadPolymerComponents();
	}
}

function loadPolymerComponents() {
  'use strict';
  const head = document.head;
  const scripts = [...document.querySelectorAll('script')];
  const isPolymerComponentsLoaded = scripts.some((i) => /ge-alarms.js/.test(i.src));
  if(!isPolymerComponentsLoaded){
	  const polymerComponents = document.createElement('script');
	  polymerComponents.setAttribute('src','custom/default/GEAlarmCard/scripts/ge-alarms/ge-alarms.js');
	  head.appendChild(polymerComponents);
	  polymerComponents.onload = function () {
		init();
	  };
	  document.removeEventListener('sharedVendorsLoaded', loadPolymerComponents);
  } else {
	init();
  }
}

loadScripts();
function addEventListenerForAlarmFilterDialog(){
	'use strict';
	window.setTimeout(() => {
		const element = EMBED.getRootElement().find('#geAlarmGrid')[0];
		let alarmShadowRoot = element ? element.shadowRoot : null;
		if(alarmShadowRoot && pluginElement){
			$($(alarmShadowRoot).find('#filterButton')).on('click',function(){
				pluginElement.css('zIndex','99');
				// changes for config popup to work with gridster in new end app
				const enableFixedBoxModel = EMBED.getElementOptions().enableFixedBoxModel;
				if (enableFixedBoxModel) {
					enableFixedBoxModel('alarmCard');
				}
			});

			$($(alarmShadowRoot).find('.filterClose')).on('click',function(){
				pluginElement.css('zIndex',elementZindex);
				// changes for config popup to work with gridster in new end app
				const disableFixedBoxModel = EMBED.getElementOptions().disableFixedBoxModel;
				if (disableFixedBoxModel) {
					disableFixedBoxModel('alarmCard');
				}
			});
		}
	}, 300);
}
document.addEventListener('click',function(e){
	'use strict';
	let clickTargetAlarmCard = $(e.target).closest('.web-hmi-plugin');
		if (clickTargetAlarmCard && clickTargetAlarmCard[0]) {
			let alarmGridShadow = alarmGridElement ? alarmGridElement.shadowRoot : null;
			let isFilterHidden = alarmGridShadow ? $(alarmGridShadow).find('#alarmFilterDialog').is(':visible') : false;
			if (isFilterHidden && (rootElement.prop('id') !== clickTargetAlarmCard.parent().prop('id')) && pluginElement) {
				alarmGridElement.__closeAlarmFilterDialog();
				pluginElement.css('zIndex',elementZindex);
				// changes for config popup to work with gridster in new end app
				const disableFixedBoxModel = EMBED.getElementOptions().disableFixedBoxModel;
				if (disableFixedBoxModel) {
					disableFixedBoxModel('alarmCard');
				}
			}
		}
});


