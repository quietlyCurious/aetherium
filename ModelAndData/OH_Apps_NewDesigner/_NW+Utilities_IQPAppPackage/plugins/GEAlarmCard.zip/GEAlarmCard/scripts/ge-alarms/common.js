
/**
 * if values contains the key valueName, return the values[valueName], otherwise return the default value specified or ""
 * @param {object} values 
 * @param {string} valueName 
 * @param {string} defaultReturnValue 
 * @returns 
 */
function getInputValue(values, valueName, defaultReturnValue = "") {
	if(values && values.hasOwnProperty(valueName)) {
		return values[valueName];
	}
	return defaultReturnValue;
}

/**
 * Subscribe to data changes for the input properties specified in pluginInputNames
 * Typical usage: 
 *   function init(data) {
 *     var data = data || EMBED.getComponent();
 *     var pluginInputNames = ["AssetName", "Height", "MimicName"];
 *     handlePluginData(EMBED, data, pluginInputNames, function(values) {
 *       // do what is needed with values
 *     });
 * @param {object} pluginEMBED 
 * @param {object} data 
 * @param {array} pluginInputNames 
 * @param {function} callback 
 */
function handlePluginData(pluginEMBED, data, pluginInputNames, callback) {
	if(data && data.schema) {
		let newValues = {};

		let setInputValue = function(field, value) {
			newValues[field] = value;
		}
		let sendNewValuesToPlugin = function() {
			if(callback) {
				try {
					// send all values back.  for any that haven't changed, send back last value
					let returnValues = {};
					$.extend(returnValues, {}, newValues);

					callback(returnValues);
				} catch (e) {
					console.error(e);
				}
			}
		}

		for ( let i=0; i<pluginInputNames.length; i++ ) {
			let inputName = pluginInputNames[i];
			if ( data.schema.data && data.schema.data.hasOwnProperty(inputName) ) {
				let inputValue = data.schema.data[inputName];

				if ( inputValue.type === 'manual' )
				{
					setInputValue(inputName, inputValue.manual);
				} else if ( pluginEMBED.fieldTypeIsGlobal(inputValue) ) {
					let value = pluginEMBED.getGlobalData(inputValue);
					setInputValue(inputName, value);
					
					pluginEMBED.subscribeFieldToGlobalChange(inputValue, function(value)
					{
						setInputValue(inputName, value);
						sendNewValuesToPlugin();
					});
				} else if ( pluginEMBED.fieldTypeIsQuery(inputValue) ) {
					pluginEMBED.subscribeFieldToQueryChange(inputValue, function(rows)
					{
						if(rows.length){
							var value = rows[0][pluginEMBED.getQueryOutput(inputValue)[0].inputName] || rows;
							setInputValue(inputName, value);
							sendNewValuesToPlugin();
						}
					});
				} else if ( pluginEMBED.fieldTypeIsFormula(inputValue) ) {

					let value = pluginEMBED.getFormulaData(inputValue);
					setInputValue(inputName, value);
					
					pluginEMBED.subscribeFieldToFormulaChange(inputValue, function(value)
					{
						setInputValue(inputName, value);
						sendNewValuesToPlugin();
					});
				}
			}
		}

		// initial load
		sendNewValuesToPlugin();
	}
}

/**
 * formatSubscriptionData - helper function to correctly read subscription values
 * 
 * @param {any} newValue 
 * @param {any} schemaData 
 * @param {any} fieldToRetreive 
 * @returns 
 */
function formatSubscriptionData (newValue, schemaData, fieldToRetreive, isMultiValue = false) {
	var newData = null;
	var type = typeof(newValue);

		switch(true) {
			case Array.isArray(newValue): {
				let field = schemaData[fieldToRetreive] && schemaData[fieldToRetreive].query && schemaData[fieldToRetreive].query.outputFields && schemaData[fieldToRetreive].query.outputFields[0] && schemaData[fieldToRetreive].query.outputFields[0].fieldName;
				if(isMultiValue) {
					newData = newValue.map((o) => (o && typeof(o) === "object") ? o[field] : o );
				} else {
					newData = newValue[0];
					if (typeof(newData) === "object") {
						newData = newData && newData[field];
					}
				}
				break;
			}
			case type === "string" :
				newData =  newValue;
				break;
			case type === "boolean" :
				newData = newValue;
				break;
			case type === "object" :
				let field = schemaData[fieldToRetreive] && schemaData[fieldToRetreive].query && schemaData[fieldToRetreive].query.outputFields && schemaData[fieldToRetreive].query.outputFields[0] && schemaData[fieldToRetreive].query.outputFields[0].fieldName;
				newData = newData && newData[field];
				break;
			default :
				newData = null;
				break;
		}
		// If the data is not an array and we expect multiple values, split the string into an array;
		// otherwise, wrap the data in an array.

		if(isMultiValue && !Array.isArray(newData)) {
			if(typeof newData === 'string') {
				newData = newData.split(',');
			} else {
				newData = [newData];
			}
		}
		
		return newData;
}