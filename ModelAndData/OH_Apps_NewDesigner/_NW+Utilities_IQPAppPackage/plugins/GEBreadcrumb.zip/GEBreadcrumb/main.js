//
// We only want 1 breadcrumb on a page, but currently have no way to stop a user
// from placing more then one, so we check for more then one and delete all but
// the first one.
//
var breadcrumbs = document.getElementsByClassName("geBreadcrumb");
if (breadcrumbs.length > 1) {
	for (let x=1; x<breadcrumbs.length; x++) {
		breadcrumbs[x].parentNode.removeChild(breadcrumbs[x]);
	}
} else {
	// console.log('breadCrumb')
	var PANEL_WIDTH_OPEN = "395px";
	var PANEL_WIDTH_CLOSED = "0px";
	var PANEL_LEFT_OPEN = "0px";
	var PANEL_LEFT_CLOSED = "-395px";
	var panelOpen = false; 
	var navigationPanel;
	var breadcrumbPanel;
	var template = '<div class="geNavigation">\
					<div id="navPanelContent">\
						<div class="wrap" style="height:100%; width:100%;">\
							<div id="navigation_panel" class="demo-container"></div>\
						</div>\
					</div>\
				</div>'
	function parseHTML(html) {
		var t = document.createElement('template');
		t.innerHTML = html;
		return t.content;
	}
	
	var navHTML = parseHTML(template);
	var body = document.querySelector('body')
	var bNavigation = document.querySelector('.geNavigation')
	if(bNavigation) {
		bNavigation.remove()
	}
	body.appendChild(navHTML)
	var tempElement = EMBED.getRootElement().find('.geBreadcrumb');
	var content = tempElement.find('#breadcrumbContent').get(0);
	var mainElement = tempElement[0];
	var navElement =  document.querySelector('.geNavigation') //EMBED.getRootElement().find('.geNavigation').get(0);
	var PANEL_WIDTH_OPEN = "395px";
	
	// set BreadCrumb top position based application Header element height
	var header = document.querySelector("#main-header");
	var BREADCRUMB_TOP_POSITION = (header.offsetHeight || 45) + 'px';
	mainElement.style.top = BREADCRUMB_TOP_POSITION
	
	// set navigation z index to 200 in new end app
	const isNewEndApp = EMBED.getElementOptions().isNewEndApp
	if(isNewEndApp) {
		var navigationElement = document.querySelector('#main-nav')
		navigationElement.style.setProperty('--ged-navigation-z-index', 200);
	}
	
	let comp = EMBED.getComponent();
	let output_assetContext = {};
	let output_contextProperties = {};
	let input = {};

	if ('schema' in comp) {
		if ('data' in comp.schema) {
			if ('AssetContextOutput' in comp.schema.data) {
				output_assetContext = comp.schema.data.AssetContextOutput;
			}
			if ('AssetContextPropertiesQueryOutput' in comp.schema.data) {
				output_contextProperties = comp.schema.data.AssetContextPropertiesQueryOutput;
			}
			if ('AssetContextInput' in comp.schema.data) {
				input = comp.schema.data.AssetContextInput;
			}

			// Make sure if target and source are both defined, they are not using the same global
			if (output_assetContext && input) {
				if (('type' in output_assetContext) && ('type' in input)) {
					if ((output_assetContext.type === "global") && (input.type === "global")) {
						if (output_assetContext.global.id === input.global.id) {
							console.error('Breadcrumb: target and source global appear to be the same, disabling source');
							input = {};
						}
					}
				}
			}
		}
	}


	// Get the current language and load the translation file
	var i18n = pluginLocalizer.getInstance("GEBreadcrumb"); 

	var language = [];
	var lang = window.navigator.userLanguage || window.navigator.language;
	if (lang.length >= 2) {
		language.push(lang.substr(0, 2));
	}

	i18n.setPreferredLanguages(language);
	i18n.loadLanguages(function() {

		var fontHtml = `@font-face {font-family: geip-iconography-webfont;
						src: url("custom/default/GEBreadcrumb/fonts/geip-iconography-webfont.woff") format("woff"),
							url("custom/default/GEBreadcrumb/fonts/geip-iconography-webfont.woff2") format("woff2");
						font-style: normal;
						font-weight: normal;}`;
		insertFontFamily('geip-iconography-webfont', fontHtml);

		breadcrumbPanel = new BreadcrumbRuntime();
		breadcrumbPanel.init(i18n, EMBED, output_assetContext);


		navigationPanel = new NavigationPanelRuntime();
		navigationPanel.init(i18n, EMBED, output_assetContext, output_contextProperties, input);
	});

	// Setup a handler for external requests to open or close the navigation card
	//
	var OpenCloseToken = EMBED.subscribe(OPEN_CLOSE_NAVIGATION, function(topic, value) {
		if (topic === OPEN_CLOSE_NAVIGATION) {
			switch (value) {
				case "open":  { openPanel();  break; }
				case "close": { closePanel(); break; }
				case "toggle": {
					if (panelOpen) { closePanel(); } else { openPanel(); } break; }
				default: {
					console.error('GENavigation plugin received an OpenCloseNavigation command with an invalid value: '+value);
				}
			}
		}
	});
	
	function openPanel() {
		// navElement.style.left = PANEL_LEFT_OPEN;
		var navWidth = document.querySelector('#main-nav').clientWidth
		navElement.style.width = PANEL_WIDTH_OPEN;
		navElement.style.left = navWidth + 'px'
		navElement.style.visibility = 'visible'
		mainElement.style.left = navWidth + 'px'
		panelOpen = true;
		navigationPanel.onPanelOpen();
	}

	function closePanel() {
		var navWidth = document.querySelector('#main-nav').clientWidth
		navElement.style.width = PANEL_WIDTH_CLOSED;
		navElement.style.left = -(395 + navWidth) + 'px';
		navElement.style.visibility = 'hidden'
		mainElement.style.left = navWidth + 'px'
		panelOpen = false;
	}




	$(mainElement).on("remove", function () {
		breadcrumbPanel.beforeDestroy();
		navigationPanel.beforeDestroy();
		var bNavigation = document.querySelector('.geNavigation')
		if(bNavigation) {
			bNavigation.remove()
		}
		EMBED.unsubscribe(OPEN_CLOSE_NAVIGATION, OpenCloseToken);
	});

}

console.log('breadcrumb')
function updatePositions() {
	var navWidth = document.querySelector('#main-nav').clientWidth
	if(mainElement.offsetLeft !== navWidth) {
		navElement.style.left = navWidth + 'px'
		mainElement.style.left = navWidth + 'px'
	}
}


function addEventListeners() {
	const isNewEndApp = EMBED.getElementOptions().isNewEndApp
	const logoElement = isNewEndApp ? 'brand-logo' : 'nav-button'
	const navToggleElement = isNewEndApp ? 'expand-icon' : 'side-nav'

	var toggleNavigationBar = document.querySelector('#main-header .' + logoElement)
	var expandNavToggle = document.querySelector('#main-nav .' + navToggleElement)
	
	var bodyScroll = document.querySelector('.main-page')
	toggleNavigationBar.addEventListener('click', updatePositions, false)
	expandNavToggle.addEventListener('click', updatePositions, false)
	bodyScroll.addEventListener('scroll', onScroll, false);
	window.addEventListener('resize', updatePositions, false);
	
	if(isNewEndApp) {
		const navigation = document.querySelector('#main-nav')
		navigation.addEventListener('transitionend', updatePositions, false)
		enableFixedBoxModel()
	}
}

function enableFixedBoxModel() {
	// changes for breadcrumb to work with gridster in new end app
	const { enableFixedBoxModel, disableFixedBoxModel } = EMBED.getElementOptions() || {};
	// required to unregister to handle position fix between page change
	disableFixedBoxModel('breadcrumb')
	// register to handle position fix for breadcrumb
	enableFixedBoxModel('breadcrumb');
}

setTimeout(function () {
	updatePositions()
},0)
addEventListeners()

var latestKnownScrollY = 0,
	ticking = false
	
function updateScrollPosition() {
	ticking = false;
	mainElement.style.top = (BREADCRUMB_TOP_POSITION - latestKnownScrollY) + 'px';
	navElement.style.height = 'calc(100% + ' + latestKnownScrollY + 'px)';
	navElement.style.top = (BREADCRUMB_TOP_POSITION - latestKnownScrollY) + (BREADCRUMB_TOP_POSITION - 1)  + 'px';
}


function onScroll(e) {
	// console.log(e, 'breadcrumb scroll')
	latestKnownScrollY = e.currentTarget.scrollTop; 
	requestTick();
}

function requestTick() {
	if(!ticking) {
		requestAnimationFrame(updateScrollPosition);
	}
	ticking = true;
}

/* This function adjusts the height of a container based on whether it's under a flip transformation (scaleX or scaleY = -1) 
and the space difference to its breadcrumb is <= 45 units.  
Implemented to resolve defect [DE208668]. */

function adjustBreadcrumbHeight() {
	var container = document.querySelector(".coordinated_container.plug-in-component");
	var breadcrumb = document.querySelector(".geBreadcrumb");

	if (container && breadcrumb) {
		var containerHeight = container.offsetHeight;
  		var breadcrumbHeight = breadcrumb.offsetHeight;

		var containerStyle = window.getComputedStyle(container);
		var height = containerStyle.height;
		var transformValue = window.getComputedStyle(container).transform;

		var matrixValues = transformValue.match(/matrix\(([^)]+)\)/);

		if (matrixValues && matrixValues[1]) {
			var values = matrixValues[1].split(",").map(parseFloat);
			var scaleY = values[3];
			var scaleX = values[0]

			if ((scaleY === -1 || scaleX === -1) && containerHeight - breadcrumbHeight <= BREADCRUMB_TOP_POSITION) {
				if (height.includes('%')) {
					var currentPercentage = parseFloat(height);
					container.style.height = `calc(${currentPercentage}% + 3%)`;
				} else {
					container.style.height = `${breadcrumbHeight + BREADCRUMB_TOP_POSITION}px`;
				}
			} 
		}
	} 
}

adjustBreadcrumbHeight()

