
let BreadcrumbRuntime = function () {
    'use strict';

    let contextPopup='';
    let modelElement = null;
    let pubsub = {};
    let i18n = pluginLocalizer.getInstance("GEBreadcrumb"); 
    let AssetBreadCrumbToken;
    let targetVariable = {};
	 if (!window.jQuery_latest) {
		window.jQuery_latest = window.jQuery;
	}

    const jQ = window.jQuery_latest;
    
    function _init (langLib, pubsubFcns, output) {
          
        i18n = langLib;
        pubsub = pubsubFcns;
        targetVariable = output;
        
        // language(s) loaded, finish intializing the panel
        modelElement = document.getElementById('breadcrumbModel');

        modelElement.addEventListener('mouseenter', mouseEnterHandler);
        modelElement.addEventListener('mouseleave', mouseLeaveHandler);
        modelElement.addEventListener('click', mouseClickHandler);

        document.getElementById('openCloseNavBtn').addEventListener('click', openCloseClickHandler);


        // Subscribe to the RequestedEquipmentContext. If set, process the value as if someone had
        // selected the item from the list. Currently driven by click zones in the mimic
        AssetBreadCrumbToken = pubsub.subscribe(ASSET_BREAD_CRUMB, function(topic, value) {
            setAssetBreadCrumb(value);
        });
    }


    // Handler for cleaning up events before the page is removed
    function _beforeDestroy() {
        // First unsubscribe for new breadcrumb info
        pubsub.unsubscribe(ASSET_BREAD_CRUMB, AssetBreadCrumbToken);

        modelElement.removeEventListener('mouseenter', mouseEnterHandler);
        modelElement.removeEventListener('mouseleave', mouseLeaveHandler);
        modelElement.removeEventListener('click', mouseClickHandler);

        document.getElementById('openCloseNavBtn').removeEventListener('click', openCloseClickHandler);
	}


    // Handler assigned to each asset in the breadcrumb. If one is selected, fire off a 
    // message indicating a request to change the current context to the new value
    var handleClick = function(event) {
        const dataKey = event.target.getAttribute("data-key");        
        const name = dataKey || event.target.innerText;
        if (!dataKey) console.warn(`Element ${name} has no expected data-key attribute; fall back to inner text.`);
        pubsub.publish(REQUESTED_EQUIPMENT_CONTEXT, name);
        pubsub.submitTarget(targetVariable, name);
    };


    // Add an event to each asset in the breadcrumb
    var attachClickEvents = function() {
        var elements = document.getElementsByClassName('clickable');
        for (var x=0; x<elements.length; x++) {
            elements[x].addEventListener('click', handleClick);
        }
    };


    // Remove the click event added to each asset in the breadcrumb. This is performed
    // prior to the breadcrumb being replaced with a new list of assets
    var removeClickEvents = function() {
        var elements = document.getElementsByClassName('clickable');
        for (var x=0; x<elements.length; x++) {
            elements[x].removeEventListener('click', handleClick);
        }
    };


    // Handle a mouse enter event to trigger the display of the tooltip
    var mouseEnterHandler = function() {
        var tooltip = document.getElementById('breadcrumbTooltip');
        if(tooltip) {
            tooltip.textContent = contextPopup
        } else {
            modelElement.insertAdjacentHTML('afterend', '<div id="breadcrumbTooltip">'+contextPopup+'</div>');
        }
    };


    // Handle the mouse leave event to trigger the removal of the tooltip
    var mouseLeaveHandler = function() {
        var tooltip = document.getElementById('breadcrumbTooltip');
        if ((tooltip !== null) && (tooltip !== undefined) && ("parentElement" in tooltip)) {
            tooltip.parentElement.removeChild(tooltip);
        }         
    };


    // Handle any click in the asset list by removing the tooltip. Actual navigation requests will
    // be handled by the event specific to the asset chosen
    var mouseClickHandler = function() {
        var tooltip = document.getElementById('breadcrumbTooltip');
        if ((tooltip !== null) && (tooltip !== undefined) && ("parentElement" in tooltip)) {
            tooltip.parentElement.removeChild(tooltip);
        }         
    };


    // Handle event when the Open/Close button is selected. A message is fired off
    // requesting the navigation panel opens or closes, depending upon its current state
    var openCloseClickHandler = function() {
        pubsub.publish(OPEN_CLOSE_NAVIGATION, "toggle");        
    };


    // Given a breadcrumb string, delineated with '>' characters, parse the string and build up the
    // corresponding html code to display. If the string exceeds a certain length, simply display the first
    // and last asset separated by '...'
    var splitBreadcrumb = function(modelBc){
        var contextDisplay = '';

        if (!modelBc) {modelBc='';}

        var split = modelBc.split(' > ');

        const assetName2DisplayName = NavigationPanelRuntime && NavigationPanelRuntime.assetName2DisplayName;

        for(var l = 0; l < split.length; l++) {
            const displayName = (assetName2DisplayName && assetName2DisplayName.get(split[l])) || split[l];
            // Note: use jQuery to sanitize the untrusted data, as opposed to simple concatenation.
            contextDisplay += jQ('<span>').attr("data-key", split[l]).addClass("clickable").text(displayName).prop('outerHTML');
            if (l < (split.length - 1)) {
               contextDisplay += ' <span class="geip-icon-ico_lite-arrow-next_sm"></span> ';
            }
            if (0 == l && modelBc.length > 128 && split.length > 1) {
                contextDisplay += ' . . . <span class="geip-icon-ico_lite-arrow-next_sm"></span> ';
                l += (split.length - 2);    // ensure it will be (split.length - 1) once incremented by one.
            }
        }

        contextPopup = modelBc;

        return contextDisplay;
    };

    // If a new asset breadcrumb is provided, free the events from the existing breadcrumb,
    // parse the string generating html and insert it into the breadcrumbModel element.
    var setAssetBreadCrumb = function(value) {
        if ((value !== null) && (value !== undefined) && (value !== "")) {
            if (modelElement !== null) {
                removeClickEvents();
                modelElement.innerHTML = splitBreadcrumb(value);
                attachClickEvents();
            }
        }
    };


    
    return {
		init: _init,
		beforeDestroy: _beforeDestroy	
	};
};
