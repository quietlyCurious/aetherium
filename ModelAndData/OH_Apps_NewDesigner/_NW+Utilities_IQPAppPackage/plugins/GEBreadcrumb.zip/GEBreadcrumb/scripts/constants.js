// Constants to be used across the various plugins that comprise WebHMI

// Session Variables
var EQUIPMENT_CONTEXT = "EquipmentContext";
var ASSET_BREAD_CRUMB = "AssetBreadcrumb";
var REQUESTED_EQUIPMENT_CONTEXT = "RequestedEquipmentContext";
var OPEN_CLOSE_NAVIGATION = "OpenCloseNavigation";
var FAVORITES_CHANGE = "FavoritesChange";
var FAVORITES_RELOADED = "FavoritesReloaded";

