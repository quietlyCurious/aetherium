/* globals  $*/
let NavigationPanelRuntime = function () {
	'use strict';

    var $ctl;
	var me = this;
	var drilldownCtl;
	var firstAsset;
	var jQ = {};
	var i18n; 
	var jqElement;
	var jqElementId = 'navigation_panel';
	var properties = {IDField: "to", LabelFields: ["displayName", "to"], ParentIDField: "from"};
	var restData = window.restDataAccess_geWebHmiCore.getInstance(window.location.origin);
	var ReqEqCtxToken;
	var pubsub = {};
	let assetContextVariable = {};
	let assetPropertiesVariable = {}
	var assetPropertyFormulas = {};

	const assetName2DisplayName = new Map();

	// Move the selectedItem and breadcrumb stack so can be shared across instances
	if (!('WebHMI' in window)) {
		window.WebHMI = {};
	}       
	if (!('Navigation' in window.WebHMI)) {
		window.WebHMI.Navigation = {
			selectedItem: "",
			breadcrumbStack: []
		};
	}

	// Use the IQP provided latest version of jQuery. This version won't be reloaded by anyone else
	// do the drilldown jQuery plugin won't be lost
	if (!window.jQuery_latest) {
		window.jQuery_latest = window.jQuery;
	}
	jQ = window.jQuery_latest;

    
    // This is normally not necessary because it is already loaded by someone else, but in case it is not,
    // as is the case with unit testing, set it here
    if ((!window.hasOwnProperty("$")) || (window.$ === undefined)) {
        window.$ = jQ;
    } 


    /**  
     * _init
     * 
     * Perform initialization of this plugin. Some of this is asynchronous (callbacks), so most of this function
     * is wrapped in a Promise to allow something loading it to wait until initialization is complete. 
     */
	function _init (langLib, pubsubFcns, output_assetContext, output_contextProperties, input) {
		pubsub = pubsubFcns;
		assetContextVariable = output_assetContext;
		assetPropertiesVariable = output_contextProperties;

        i18n = langLib;

        jqElement = jQ('#' + jqElementId);

        $ctl = jqElement;
        $ctl.empty();
        $ctl.append('<ul id="' + jqElementId + '-list"></ul>');

        createControl();


		setupSubscription(input);

        
		return new Promise(
			function (resolve, reject) {
                // Fetch the asset hierarchy associated with the currently loaded model.
                restData.getHierarchy("AssetHierarchy_geAsset", function (data) {
                    setHierarchy(parseHierarchy(data));
                    if (!isFirstTime()) {
                        highlightSelectedItem(window.WebHMI.Navigation.selectedItem);
					}
					if(input) {
						let globalInitValue = pubsub.getGlobalData(input);
						let manualInitValue = input.manual;
						let initValue = manualInitValue || globalInitValue;
						if(initValue) {
							setSelectedItem(initValue);
							highlightSelectedItem(initValue);
						}
					}
                    resolve('Navigation initialized successfully');
                }, function (error) {
                    reject('error returned: ' + error);
                },
				"excludeDisplayName=false");
			}
		);
	}

	/**
	 * There are multiple ways to setup a subscription to be triggered when written to by some other
	 * component. The first is to directly subscribe via the pub/sub methods added to EMBED. This is
	 * the initial method used when porting to IQP. The other is more IQP centric and involves subscribing
	 * to a change in value of a global parameter or through the change in a query.
	 * 
	 * @param {*} input The object representing the data entered in the source form in the designer 
	 */
	function setupSubscription(input) {

		// Subscribe to the RequestedEquipmentContext. If set, process the value as if someone had
		// selected the item from the list. Currently driven by click zones in the mimic.
		// This is the original method and will likely be removed at some point
        ReqEqCtxToken = pubsub.subscribe(REQUESTED_EQUIPMENT_CONTEXT, function(topic, value) {
            setSelectedItem(value);
            highlightSelectedItem(value);
		});
		
		// If using a form of global page data variable ...
		if (pubsub.fieldTypeIsGlobal(input)){

			pubsub.subscribeFieldToGlobalChange(input, function(data){    
				setSelectedItem(data);
				highlightSelectedItem(data);
			});
		}
		// or if using a query
		else if(pubsub.fieldTypeIsQuery(input)){
			
			pubsub.subscribeFieldToQueryChange(input, function(rows){  
				var output = rows[0][pubsub.getQueryOutput(input)[0].fieldName];
				setSelectedItem(output);
				highlightSelectedItem(output);
			});
		}
	}

	/**
	 * _onPanelOpen
	 * 
	 * When the panel is opened, it may not have been left in a state where the current selected item
	 * is shown. This function will find the currently selected item in the hierarchy and re-navigate
	 * to the it.
	 */
	function _onPanelOpen() {
		setItemFocus(window.WebHMI.Navigation.selectedItem);
	}

	
	function _beforeDestroy() {
		pubsub.unsubscribe(REQUESTED_EQUIPMENT_CONTEXT, ReqEqCtxToken);

		var widgetElement = jqElement;

		try {
			widgetElement.unbind();
		}
		catch (destroyErr) {
		}
	}


	/**
     * parseHierarchy
     * 
     * Parse the hierarchy data returned and place it in the format expected by the 
	 * navigation card
     */
	var parseHierarchy = function(data) {
		assetName2DisplayName.clear();
		if ('root' in data) {
			var assetArray = [];
			if (data.root.displayName) assetName2DisplayName.set(data.root.name, data.root.displayName);
			assetArray.push({connectionType: "Contains", from: "", to: data.root.name, displayName: data.root.displayName});
			parseItems(data.root, assetArray);

			return assetArray;
		} else {
			return [];
		}
	};


	/** 
     * parseItems
     * 
     * Recursive function to build the array of assets
     * */
	var parseItems = function(data, assets) {
		if (Array.isArray(data.items)) {
			for (var i=0; i<data.items.length; i++) {
				if ('name' in data.items[i]) {
					if (data.items[i].displayName) assetName2DisplayName.set(data.items[i].name, data.items[i].displayName);
					assets.push({connectionType: "Contains", from: data.name, to: data.items[i].name, displayName: data.items[i].displayName});
					if (Array.isArray(data.items[i].items) && data.items[i].items.length > 0) {
						parseItems(data.items[i], assets);
					}
				}
			}
		}
	};


    /**
     * adjustForScrollbar
     * 
     * Adds or removes a vertical scrollbar if needed
     */
	var adjustForScrollbar = function() {
		jQ('.dd-wrapper .dd-menu', $ctl).first().each(function() {
			if (this.scrollHeight > this.clientHeight) {
				jQ(this).addClass('dd-menu-scroll');
			} else {
				jQ(this).removeClass('dd-menu-scroll');
			}
		});
	};


	/**
	 * isFirstTime
	 * 
	 * If there is already a selected item, then it is not the first time.
	 * If not, then it is. Used for first time load of the plugin
	 */
	var isFirstTime = function() {
		if (window.WebHMI.Navigation.selectedItem !== "") {
			return false;
		}

		return true;
	};


	/**
	 * setItemFocus
	 * 
	 * Given the name of an asset in the hierarchy, locates the item and
	 * rebuilds the breadcrumbStack based on it. Item is then selected in the
	 * hierarchy.
	 * 
	 * @param {} item Name of the asset to navigate to and set focus.  Note, the name, not the label (aka display name).
	 * @returns String name of the item after sanitizing for use with jQuery
	 */
	var setItemFocus = function(item) {
		var escapedItem = '';

		if ((item != null) && (item !== "")) {
			 
			var targetElement = '';
			var hierarchy = [];

			if (typeof item !== 'undefined') {
				escapedItem = item.replace(/\s/g, "");
				// Selector-escape all the metacharacters inside asset name, not just dot as it was previously done.
				escapedItem = jQ.escapeSelector(escapedItem);
				targetElement = jQ('#' + escapedItem, $ctl);
			}

			if (targetElement.length === 0) {
				return;
			}
			//clear the breadcrumb stack
			window.WebHMI.Navigation.breadcrumbStack = [];

			var parent = getParentDditem(targetElement);
			while (parent !== "") {
				hierarchy.push(parent.attr("id"));
				const dataKey = parent.attr("data-key");
				if (!dataKey) console.warn(`Element ${item} has a parent ${parent.attr("id")} that has no expected data-key attribute; fall back to text content.`);
				pushBreadcrumb(dataKey || parent[0].textContent, parent.attr("id"));
				parent = getParentDditem(parent);
			}

			//put the items in the correct order now (including breadcrumbs)
			hierarchy.reverse();
			window.WebHMI.Navigation.breadcrumbStack.reverse();

		    drilldownCtl.autoNavigate(hierarchy);
		}

		return escapedItem;
	};

	
    /**
     * setHierarchy
     * 
     * Given an object containing the asset hierarchy, parse the data and add to the drilldown control
     * If no hierachy data, display an data error message
     */
	var setHierarchy = function(hierarchy) {
		var domElementId = jqElementId;
		var widgetProperties = properties;
		var widgetReference = this;

		if (Array.isArray(hierarchy) && hierarchy.length > 0) {
			$ctl = jqElement;
			$ctl.empty();
			$ctl.append('<ul id="' + domElementId + '-list" class="dd-menu" rel="1"></ul>');
			var list = jQ('#' + domElementId + '-list', $ctl);

			var IDFieldName = widgetProperties.IDField;
			var parentFieldName = widgetProperties.ParentIDField;
			var labelFieldNames = widgetProperties.LabelFields;
			var rootParentID = widgetProperties.RootParentID;
			if (rootParentID === undefined) {
				rootParentID = '';
			}

			// Sort by the "to" field
			hierarchy = _.sortBy(hierarchy, function(item){ return item.to; });

			loadChildren(list, rootParentID, parentFieldName, IDFieldName, labelFieldNames, rootParentID, hierarchy);

			createControl();
		}
		else {
			
			jqElement.find('.dd-header .dd-header-span').text(i18n.translate('No assets provisioned'));
			// Remove the data-error element to get rid of red loading bar, and stop close action when clicking on the nav panel
			var dataErrorInterval = setInterval(function() {
				var element = jQ('#' + jqElementId + '-data-error');
				if (element) {
					element.remove();
					clearInterval(dataErrorInterval);
				}
			}, 100);
		}			
	};


    var highlightSelectedItem = function(data) {

		var itemName = setItemFocus(data);
		if (itemName !== '') {
			//fire the click event on the drilldownitem's li element, i.e. click on the target item.
			//this will raise the appropriate events and set the breadcrumb.
			jQ('#' + itemName + ' > li', $ctl).click();
		}
	};


	var loadChildren = function (list, rootParentID, parentFieldName, IDFieldName, labelFieldNames, requiredParentID, rows) {
		var len = rows.length;

		for (var rowId = 0; rowId < len; rowId++) {
			var row = rows[rowId];
			var parentID = row[parentFieldName];

			if (parentID === requiredParentID) {
				var childID = row[IDFieldName];
				// if labelFieldName is an array of possible field name in order of precedence, then find the first one 
				// that exists and that is not null or undefined (hence using != but not !==).
				var labelFieldName = Array.isArray(labelFieldNames) ? 
					labelFieldNames.find(eachName => (row.hasOwnProperty(eachName) && row[eachName] != null)) : labelFieldNames;
				var label = row[labelFieldName];
				var appendObj = list;
				var newNode;

				if (list.is('li')) {
					if (list.children("ul").first().is("ul")) {
						appendObj = list.children("ul").first();
					}
					else {
						appendObj = jQ("<ul></ul>").appendTo(list);
					}
				}
				var nodeId = childID.replace(/\s/g, '');
				newNode = jQ("<li></li>").html('<div class="drilldownitem" id="' + nodeId + '" data-key="'+childID+'"><li>' + label + '</li></div>');
				
				if (firstAsset === undefined) {
					firstAsset = childID;
					// check if there is a currently selected item
					if (window.WebHMI.Navigation.selectedItem !== "") {
						setSelectedItem(window.WebHMI.Navigation.selectedItem);
					} else {
					    setSelectedItem(childID);
					}
					firstAsset = nodeId;
				}

				newNode.appendTo(appendObj);
				
				loadChildren(newNode, rootParentID, parentFieldName, IDFieldName, labelFieldNames, childID, rows);
			}
		}
	};


	/**
	 * 
	 * @param {*} assetName which is not label (aka display name).
	 */
	var setContext = function(assetName) {
		var path = '';
		for (var idx=0; idx<window.WebHMI.Navigation.breadcrumbStack.length; idx++) {
			path += window.WebHMI.Navigation.breadcrumbStack[idx].name + ' > ';
		}

		path += assetName;
		pubsub.publish(ASSET_BREAD_CRUMB, path);

		jqElement.triggerHandler("ContextSet");
		jqElement.triggerHandler("SelectedItemChanged");

		// remove context special active state
		jQ('.nav a.special-active').removeClass("special-active");
	};


	var popBreadcrumb = function () {
		var breadcrumb = window.WebHMI.Navigation.breadcrumbStack.pop();
		adjustForScrollbar();
		return breadcrumb;
	};


	var pushBreadcrumb = function (name, id) {
		var bcArray = window.WebHMI.Navigation.breadcrumbStack;

		if ((bcArray.length === 0) || (bcArray.length > 0 && bcArray[bcArray.length-1].name !== name)) {
			bcArray.push({name: name, id: id});
		}
		adjustForScrollbar();
	};


    var getParentDditem = function(dditem) {
        var parent = dditem.parent().parent().siblings(".drilldownitem");
        if (parent.length === 0) {
            return "";
        }
        return parent;
    };

	var publishAssetPropertiesToOutputByAssetName = function(assetName) {
		console.log("publishAssetPropertiesToOutputByAssetName(%s, %s)",assetName);
		
		restData.getAssetDataSources(assetName, function(successData) {
			console.log("getAssetDataSources: success: %O", successData);
			
			if(successData.content.length > 0) {

				var formulaeList = [];
				successData.content.forEach( (element) => {
					formulaeList.push("webhmi-model://" + element.assetName + "/" + element.propertyName);
				});
				assetPropertyFormulas = formulaeList.join();
				pubsub.submitTarget(assetPropertiesVariable, assetPropertyFormulas);              
				
			}        
		}, function(errorData) {
			console.log("getAssetDataSources: error: %O", errorData);
		});
	
	}

	/**
	 * Set selected item.
	 * @param {*} item the item selected, which in case label field is not the same as id field, must be the full asset name.
	 */
    var setSelectedItem = function (item) {
		window.WebHMI.Navigation.selectedItem = item;
		pubsub.publish(EQUIPMENT_CONTEXT, item);
		if(assetPropertiesVariable.id) {
			publishAssetPropertiesToOutputByAssetName(item);
		}
		pubsub.submitTarget(assetContextVariable, item);
		setContext(item);
    };


	var contextClickHandler = function() {
        var fireClick = function() {
			// we really should be relying on the data-key, not the text, which can be from a label field.
			// but fall back to the child <li> element's text for "backward compatibility", dubiously as it might be.
            var text = jQ(this).parent().attr("data-key") || jQ(this).text();
            if (text !== '') {
				setSelectedItem(text);
				pubsub.publish(OPEN_CLOSE_NAVIGATION, "close");
            }
		};
		
        //this handler was getting added every time the user hovers or clicks on an item (changed that),
        //but in case that happens again, remove it before adding it to make sure that we are not calling it
        //an increasing number of times as the user interacts with the navigation
        //panel and selects items.
        jQ('.drilldownitem > li').off('click').on('click',fireClick);
	};


	var createControl = function () {
		var $ctlList = jQ('#' + jqElementId + '-list', $ctl);

		var prompt = i18n.translate("Select your context");
	
        // display of ancestor is set to 'none' which means it has no width
        // jquery drilldown widget breaks if element has no width
        var hiddenElement = $ctlList.closest("div.wrap").parent();
        if (hiddenElement.css("display") === "none") {
            hiddenElement.css("display","block");
        }

		contextClickHandler();

        var $selectedElements = null;
        var unselectAll = function () {
            if ($selectedElements !== null) {
                $selectedElements.removeClass('selected');
            }
        };
		
		/**
		 * Select elements...
		 * @param {*} selectorEscaped A selector any metacharacters which contains MUST BE escaped.
		 */
        var selectElementsOf = function (selectorEscaped) {
            unselectAll();
            $selectedElements = jQ(selectorEscaped).children();
            $selectedElements.addClass('selected');
        };

		drilldownCtl = $ctlList.dcDrilldown(
			{
				showCount: false,
				showHeader: false,
				speed: 'slow',
				saveState: false,
				linkType: 'backButton',
				includeHdr: false,
				prompt: prompt
			});

		selectElementsOf('#' + jQ.escapeSelector(firstAsset) + '.drilldownitem');

		jQ('.drilldownitem > li', $ctl).click(function (event) {
			var node = event.currentTarget.parentNode;

			selectElementsOf('#' + jQ.escapeSelector(node.id) + '.drilldownitem');
		});

		var mseDownNavButton = false;

		jQ('.drilldownitem.dd-parent-a > .btn.btn-navigate', $ctl)
			.click(function (event) {
				var itemName = event.currentTarget.parentElement.innerText;
				const dataKey = event.currentTarget.parentElement.getAttribute("data-key");
				if (!dataKey) console.warn(`Element ${event.currentTarget.parentElement.id} has no expected data-key attribute; fall back to text content.`);
				pushBreadcrumb(dataKey || itemName, event.currentTarget.parentElement.id);
				mseDownNavButton = false;
			})
			.on("touchend", function (event) {
				event.target.click();
			})
			.mouseenter(function () {
				jQ(this).siblings('li').addClass('hovering');
				if (mseDownNavButton) {
					jQ(this).addClass('activated');
					jQ(this).siblings('li').addClass('activated');
				}
			}).mouseleave(function () {
				jQ(this).siblings('li').removeClass('hovering');
				if (mseDownNavButton) {
					jQ(this).removeClass('activated');
					jQ(this).siblings('li').removeClass('activated');
					mseDownNavButton = false;
				}
			}).mousedown(function () {
				jQ(this).addClass('activated');
				jQ(this).siblings('li').addClass('activated');
				mseDownNavButton = true;
			}).mouseup(function () {
				jQ(this).removeClass('activated');
				jQ(this).siblings('li').removeClass('activated');
				mseDownNavButton = false;
			});

			jQ('.btn.btn-navigate-back', $ctl).click(function () {
				window.setTimeout(popBreadcrumb, 200);
		});

		jQ('.drilldownitem li', $ctl)
			.mouseenter(function () {
				var element = jQ(this);

				if ((this.offsetWidth < this.scrollWidth) && !element.attr('title')) {
					element.attr('title', element.text());
				}
			});

		// listener for closing the context selector if it's open and you click outside of it
		jQ(document).on("mouseup touchend", function (e)
		{
			var container = jQ('#' + jqElementId);
			var container2 = jQ('.nav.nav-list li');

			// if the target of the click isn't the container or the breadcrumb open/close nav button,
			// nor a descendant of the container
			if (e.target.id !== "openCloseNavBtn") {
				if ((!container.is(e.target) && container.has(e.target).length === 0) && (!container2.is(e.target) && container2.has(e.target).length === 0)) 
				{
					pubsub.publish(OPEN_CLOSE_NAVIGATION, "close");
					jqElement.triggerHandler("ClickedOutsideContextSelector");
					jQ('.nav a.special-active').removeClass("special-active");
				}
			}
		});
	};


	jQ(window).resize(function() {
		adjustForScrollbar();
	});


	jQ(document).ready(function() {
		adjustForScrollbar();
	});

	NavigationPanelRuntime.assetName2DisplayName = assetName2DisplayName;

	return {
		init: _init,
		onPanelOpen: _onPanelOpen,
		beforeDestroy: _beforeDestroy	
	};
};