var dataCache = (function () {
	'use strict';

	var instance = null;

	function init() {
		var  cache = {};
		var MAX_COUNT = -1; // -1 = unlimited
		var CACHE_MAX_SIZE_KB = 100000; // max cache size in Kb, -1 = unlimited
		var CACHE_REDUCTION_SIZE = 5000; // if cache exceede, clear out this amount of data
		var CACHED_ITEM_LIFETIME = -1; // seconds to keep an item in the cache before re-fetching, -1 = until model change
		
		var cacheCurrentSize = 0;
		
		function setMaxCount(max) {
			MAX_COUNT = max;
			cacheMaintenance();
		}

		function setMaxSize(maxInKb) {
			CACHE_MAX_SIZE_KB = maxInKb;
			CACHE_REDUCTION_SIZE = CACHE_MAX_SIZE_KB / 20; // when cache full, reduce by 5%
			cacheMaintenance();
		}

		function setMaxCacheLifetime(lifetime) {
			CACHED_ITEM_LIFETIME = lifetime;
			cacheMaintenance();
		}

		function getPercentFull() {
			return (cacheCurrentSize / CACHE_MAX_SIZE_KB);
		}

		function clear() {
			cache = {};
			cacheCurrentSize = 0;
		}

		function cacheMaintenance() {
			// remove items older than CACHED_ITEM_LIFETIME
			let keys = Object.keys(cache);
			for(let i=0; i<keys.length; i++) {
				itemInCache(keys[i]); // check if item is in cache.  this will remove old items
			}

			// remove items if CACHE_MAX_SIZE_KB is exceeded
			if ( (CACHE_MAX_SIZE_KB > -1) && (cacheCurrentSize > CACHE_MAX_SIZE_KB) ) {
				console.log("CACHE SIZE EXCEEEDED, size is "+cacheCurrentSize +", CACHE_MAX_SIZE_KB="+CACHE_MAX_SIZE_KB);
				// limit to CACHE_MAX_SIZE_KB... prefer to keep recently accessed values
				let sortedKeys = Object.keys(cache).sort(function(a,b){
					if(cache[a].lastAccessed < cache[b].lastAccessed) return -1;
					if(cache[a].lastAccessed > cache[b].lastAccessed) return 1;
					return 0;
				});

				let i=0;
				//console.log("will reduce cache to at or below "+(CACHE_MAX_SIZE_KB - CACHE_REDUCTION_SIZE));
				while(cacheCurrentSize > (CACHE_MAX_SIZE_KB - CACHE_REDUCTION_SIZE)) {
					let itemSize = cache[sortedKeys[i]].size;
					cacheCurrentSize -= itemSize;
					delete cache[sortedKeys[i]];
					i++;
				}
				console.log("Cache size reduced to "+cacheCurrentSize);
			}

			// remove items in excess of MAX_COUNT
			let numToDelete = getItemCount() - MAX_COUNT;
			if( (MAX_COUNT>-1) && (numToDelete>0) ) {
				// limit to MAX_COUNT... prefer to keep recently accessed values
				let sortedKeys = Object.keys(cache).sort(function(a,b){
					if(cache[a].lastAccessed < cache[b].lastAccessed) return -1;
					if(cache[a].lastAccessed > cache[b].lastAccessed) return 1;
					return 0;
				});
				
				for(let i=0; i<numToDelete; i++) {
					let itemSize = cache[sortedKeys[i]].size;
					cacheCurrentSize -= itemSize;
					delete cache[sortedKeys[i]];
				}
			}
		}

		function getItemCount() {
			return Object.keys(cache).length;
		}

		function getSizeInKb() {
			return cacheCurrentSize;
		}

		function addItemToCache(key, item) {
			let now = (new Date()).getTime();
			let itemSize = (new TextEncoder().encode(JSON.stringify(item)).length) / 1024;
			cache[key] = {
				value: $.extend({}, item),
				timeCached: now,
				lastAccessed: now,
				size: itemSize
			};
			cacheCurrentSize += itemSize;
			if(((MAX_COUNT > -1) && (getItemCount() > MAX_COUNT)) ||
				((CACHE_MAX_SIZE_KB > -1) && (cacheCurrentSize > CACHE_MAX_SIZE_KB))) {
				cacheMaintenance();
			}
		}

		function getItemFromCache(key) {
			if(itemInCache(key)) {
				let cachedItem = cache[key];
				cachedItem.lastAccessed = (new Date()).getTime();

				let cachedValue = {};
				$.extend(true, cachedValue, cachedItem.value);

				return cachedValue;
			}
			return null;
		}

		function itemInCache(key) {
			if(cache.hasOwnProperty(key)) {
				// check item age
				let cachedItemCreateTime = cache[key].timeCached;
				let now = (new Date()).getTime();
				let timeDifference = now - cachedItemCreateTime;
				if ( (CACHED_ITEM_LIFETIME>-1) && (timeDifference > (CACHED_ITEM_LIFETIME*1000)) ) {
					// too old
					delete cache[key];
					return false;
				}
				return true;
			}
			return false;
		}

		function removeItemFromCache(key) {
			if(itemInCache(key)) {
				let itemSize = cache[key].size;
				cacheCurrentSize -= itemSize;
				delete cache[key];
				return true;
			}
			return false;
		}

		return ({
			setMaxCount: setMaxCount,
			setMaxSize: setMaxSize,
			setMaxCacheLifetime: setMaxCacheLifetime,
			getPercentFull: getPercentFull,
			clear: clear,
			getItemCount: getItemCount,
			getSizeInKb: getSizeInKb,
			addItemToCache: addItemToCache,
			getItemFromCache: getItemFromCache,
			itemInCache: itemInCache,
			removeItemFromCache: removeItemFromCache
		});
	}

	return {
		getInstance: function () {
			if(!instance) {
				instance = init();
			}
			return instance;
		}
	};
})();

if(!window.hasOwnProperty("dataCache")) {
	window.dataCache = dataCache;
}

/* exported restDataAccess_geWebHmiCore */
var restDataModule = (function () {
	'use strict';

	var instances = {};

	function init(host) {
		var serverHost = host,
			token = null,
			sessionKeepAliveTimeout = null,
			tokenListeners = [],
			cache = null,
			modelCheckTimer = null,
			lastVersionInfo = null,
			MODEL_MONITOR_INVERVAL_SECONDS = 60;

		if(window && window.dataCache) {
			cache = window.dataCache.getInstance();
			window.cacheData = true;
		}
		
		function sendRequest(method, url, authorizationHeader, data, successCallback, errorCallback, cachingEnabled = true) {
			var cacheKey = null;
			if(cache && window.cacheData && cachingEnabled && method.toUpperCase()==='GET' && (data===undefined || data===null)) {
				// we can cache this
				cacheKey = method+":"+url;
				if(cache.itemInCache(cacheKey)) {
					successCallback(cache.getItemFromCache(cacheKey));
					return; // all done!
				}
			}
			// cache disabled or value not cached
			setTimeout(function () {
				var xhr = new XMLHttpRequest();
				xhr.withCredentials = true;

				xhr.addEventListener("readystatechange", function () {
					if (this.readyState === 4) {
						if (this.status >= 200 && this.status <= 299) {
							if(xhr.responseText==="") {
								successCallback(null); // no response
							} else {
								var responseValue = JSON.parse(xhr.responseText);
								if(cache && cacheKey) { // we can cache this
									cache.addItemToCache(cacheKey, responseValue);
								}
								successCallback(responseValue);
							}
						} else {
							errorCallback(xhr.responseText);
						}
					}
				});

				xhr.open(method, url);
				xhr.setRequestHeader("Content-Type", "application/json");
				xhr.setRequestHeader("Accept", "application/json");
				xhr.setRequestHeader("Authorization", authorizationHeader);
				xhr.setRequestHeader("Cache-Control", "no-cache");
				xhr.setRequestHeader("tenant", "webhmi");

				xhr.send(data);
			}, 500);
		}

		function sendFormRequest(method, url, authorizationHeader, data, successCallback, errorCallback, cachingEnabled = true) {
			var cacheKey = null;
			if(cache && window.cacheData && cachingEnabled && method.toUpperCase()==='GET' && (data===undefined || data===null)) {
				// we can cache this
				cacheKey = method+":"+url;
				if(cache.itemInCache(cacheKey)) {
					successCallback(cache.getItemFromCache(cacheKey));
					return; // all done!
				}
			}
			// cache disabled or value not cached
			setTimeout(function () {
				var xhr = new XMLHttpRequest();
				xhr.withCredentials = true;

				xhr.addEventListener("readystatechange", function () {
					if (this.readyState === 4) {
						if (this.status >= 200 && this.status <= 299) {
							if(xhr.responseText==="") {
								successCallback(null); // no response
							} else {
								var responseValue = JSON.parse(xhr.responseText);
								if(cache && cacheKey) { // we can cache this
									cache.addItemToCache(cacheKey, responseValue);
								}
								successCallback(responseValue);
							}
						} else {
							errorCallback(xhr.responseText);
						}
					}
				});

				xhr.open(method, url);
				xhr.setRequestHeader("Content-Type", " application/x-www-form-urlencoded; charset=UTF-8");
				xhr.setRequestHeader("Accept", "application/json, text/plain, */*");
				xhr.setRequestHeader("Authorization", authorizationHeader);
				xhr.setRequestHeader("Cache-Control", "no-cache");
				xhr.setRequestHeader("tenant", "webhmi");

				xhr.send(data);
			}, 500);
		}

		/**
		 * Used in place of sendRequest for image files
		 */
		function sendRequestForBase64ArrayBuffer(method, url, authorizationHeader, data, successCallback, errorCallback) {
			setTimeout(function () {
				var xhr = new XMLHttpRequest();
				xhr.withCredentials = true;

				xhr.addEventListener("readystatechange", function () {
					if (this.readyState === 4) {
						if (this.status >= 200 && this.status <= 299) {
							let buffer = new Uint8Array(xhr.response);
							var binary = '';
							var len = buffer.byteLength;
							for (var i = 0; i < len; i++) {
								binary += String.fromCharCode(buffer[i]);
							}
							let responseValue = window.btoa( binary )

							successCallback(responseValue);
						} else {
							errorCallback(xhr.responseText);
						}
					}
				});

				xhr.open(method, url);
				xhr.setRequestHeader("Content-Type", "image/*");
				xhr.setRequestHeader("Accept", "image/*");
				xhr.setRequestHeader("Authorization", authorizationHeader);
				xhr.setRequestHeader("Cache-Control", "no-cache");
				xhr.responseType = 'arraybuffer';
				xhr.setRequestHeader("tenant", "webhmi");

				xhr.send(data);
			}, 500);
		}

		function getAsset(assetName, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/model-facade/assets/<ASSET_NAME>
				var method = "GET",
					url = serverHost + "/model-facade/assets/" + assetName,
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, successCallback, errorCallback);
			});
		}

		function getAssetDataSources(assetName, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/model-facade/data-sources/<ASSET_NAME>?page=0&size=500";
				var method = "GET",
					url = serverHost + "/model-facade/data-sources/" + assetName + "?page=0&size=500",
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, successCallback, errorCallback);
			});
		}

		function getAssetType(assetTypeName, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/model-facade/asset-types/<ASSET_TYPE_NAME>
				var method = "GET",
					url = serverHost + "/model-facade/asset-types/" + assetTypeName,
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, successCallback, errorCallback);
			});
		}

		function getAssetTypes(successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/model-facade/asset-types/
				var method = "GET",
					url = serverHost + "/model-facade/asset-types",
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, successCallback, errorCallback);
			});
		}

		function getAssets(successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/model-facade/assets
				var method = "GET",
					url = serverHost + "/model-facade/assets",
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, successCallback, errorCallback);
			});
		}

		function getControlPropertyDataForAsset(assetName, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/entity-metadata?entityType=Asset&entityNames=<ASSET_NAME>&categories=Control_geWebHMI&expandMetadata=true
				var method = "GET",
					url = serverHost + "/entity-metadata?entityType=Asset&entityNames=" + assetName + "&categories=Control_geWebHMI&expandMetadata=true",
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, function (data) {
					if (data && data.content && data.content[0]) {
						successCallback(data.content[0]);
					} else {
						errorCallback(data);
					}
				}, errorCallback);
			});
		}

		function getControlPropertyDataForAssetType(assetTypeName, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/entity-metadata?entityType=PropertyGroup&entityNames=<ASSET_TYPE_NAME>&categories=Control_geWebHMI&expandMetadata=true
				var method = "GET",
					url = serverHost + "/entity-metadata?entityType=PropertyGroup&entityNames=" + assetTypeName + "&categories=Control_geWebHMI&expandMetadata=true",
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, function (data) {
					if (data && data.content && data.content[0]) {
						successCallback(data.content[0]);
					} else {
						errorCallback(data);
					}
				}, errorCallback);
			});
		}

		function getDatasourceStockProperties(datasourceList, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//POST http://<HOSTNAME>/dataacquisition
				var request = {"event": "readOnce", "dataSourceList": datasourceList},
					method = "POST",
					url = serverHost + "/dataacquisition/",
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, JSON.stringify(request), successCallback, errorCallback);
			});
		}

		function _AwaitDatasourceStockProperties(datasourceList) {
			return new Promise(function (resolve, reject) {
				getDatasourceStockProperties(datasourceList,
					function (r) {
						if (r.status.toLowerCase().indexOf('fail') !== -1)
							reject(r);
						else
							resolve(r);
					}, reject);
			});
		}

		function getHMIAssetConfig(assetName, assetType, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/mimic-microservice/api/v0/hmiconfig
				var method = "GET",
					url = serverHost + "/mimic-microservice/api/v0/hmiconfig",
					authHeader = "Bearer " + token;
				url += "?modelIdentifier=" + assetName + "&typeIdentifier=" + assetType;
				sendRequest(method, url, authHeader, null, successCallback, errorCallback);
			});
		}

		function getMimic(mimicName, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/mimic-microservice/api/v0/mimics/<mimicName>
				var method = "GET",
					url = serverHost + "/mimic-microservice/api/v0/mimics/" + mimicName,
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, successCallback, errorCallback);
			});
		}

		function getMimicImage(mimicImagePath, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				// <mimicImagePath> is of format "<mimicName>/images/<imageName>.png"
				//GET http://<HOSTNAME>/mimic-microservice/api/v0/mimics/<mimicImagePath>
				var method = "GET",
					url = serverHost + "/mimic-microservice/api/v0/mimics/" + mimicImagePath,
					authHeader = "Bearer " + token;
				sendRequestForBase64ArrayBuffer(method, url, authHeader, null, successCallback, errorCallback);
			});
		}

		/**
		 * Set a timer to access the token in 5 minutes (or less if expiresSeconds is sooner)
		 * @param {number} expiresSeconds Number of seconds before current token expires
		 */
		function keepSessionAlive(expiresSeconds) {
			let refreshSeconds = Math.min(300, expiresSeconds);
			if(sessionKeepAliveTimeout!==null) {
				clearTimeout(sessionKeepAliveTimeout);
				sessionKeepAliveTimeout = null;
			}
			sessionKeepAliveTimeout = setTimeout(function() {
				sessionKeepAliveTimeout = null;
				getToken(function (data) {
					// no action
				}, function(err) {
					console.error("error accessing token: %s", err);
					keepSessionAlive(60); // try again in 1 minute
				});
			}, refreshSeconds*1000);
		}

		/**
		 * Notify listeners of a change in the token
		 * @param {string} newToken 
		 */
		function notifyTokenChange(newToken) {
			_.each(tokenListeners, function (callback) {
				try {
					if(callback) {
						callback(newToken);
					}
				} catch (err) { console.error(err); }
			});
		}
		/**
		 * Add a listener for a token change
		 * @param {function} callback 
		 */
		function addTokenListener(callback) {
			tokenListeners.push(callback);
		}

		function removeAllTokenListeners() {
			tokenListeners = [];
		}

		/** request the latest model version, and if changed, clear cache */
		function checkModelVersion() {
			if(cache) {
				getModelVersion(function(data) {
					if(!_.isEqual(data, lastVersionInfo)) {
						if(lastVersionInfo!==null) {
							// don't clear cache if this is the first model version we get
							console.log("data model changed, clearing REST cache");
							cache.clear();
						}
						lastVersionInfo = data;
					}
				}, function(error) {
					console.error(error);
				});
			}
		}

		function getToken(successCallback, errorCallback) {
			console.log("connecting to uaa server to get a token");
			var method = "POST",
				url = serverHost + "/app/token",
				successWrapper = function (data) {
					let oldToken = token;
					if (data && data.access_token) {
						token = data.access_token;
						if(token!==oldToken) {
							notifyTokenChange(token);
						}
						let tokenValidSeconds = parseInt(data.expires_in);
						keepSessionAlive(tokenValidSeconds - 60);

						if(modelCheckTimer===null) {
							checkModelVersion();
							modelCheckTimer = setInterval(checkModelVersion, MODEL_MONITOR_INVERVAL_SECONDS * 1000);
						}
						successCallback(data);
					} else {
						errorCallback(null);
					}
				};
			sendRequest(method, url, null, null, successWrapper, errorCallback, false); // don't cache
		}

		function _AwaitToken() {
			return new Promise(function (resolve, reject) {
				if(token!==null) {
					resolve(token);
				} else {
					getToken(function (r) {
						if (r && r.access_token) {
							resolve(token);
						} else {
							reject(r);
						}
					}, reject);
				}
			});
		}

		function getTrendablePropertyDataForAsset(assetName, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/entity-metadata?entityType=Asset&entityNames=<ASSET_NAME>&categories=Trend_geWebHMI&expandMetadata=true
				var method = "GET",
					url = serverHost + "/entity-metadata?entityType=Asset&entityNames=" + assetName + "&categories=Trend_geWebHMI&expandMetadata=true",
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, function (data) {
					if (data && data.content && data.content[0]) {
						successCallback(data.content[0]);
					} else {
						errorCallback(data);
					}
				}, errorCallback);
			});
		}

		function getTrendablePropertyDataForAssetType(assetTypeName, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/entity-metadata?entityType=PropertyGroup&entityNames=<ASSET_TYPE_NAME>&categories=Trend_geWebHMI&expandMetadata=true
				var method = "GET",
					url = serverHost + "/entity-metadata?entityType=PropertyGroup&entityNames=" + assetTypeName + "&categories=Trend_geWebHMI&expandMetadata=true",
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, function (data) {
					if (data && data.content && data.content[0]) {
						successCallback(data.content[0]);
					} else {
						errorCallback(data);
					}
				}, errorCallback);
			});
		}

		function getHierarchy(hierarchyName, successCallback, errorCallback, queryString) {
			_AwaitToken().then(function (t) {
				var method = "GET",
					url = serverHost + "/model-facade/hierarchies/" + hierarchyName,
					authHeader = "Bearer " + token;
				if (queryString) url += "?" + queryString;
				sendRequest(method, url, authHeader, null, function (data) {
					if (data) {
						successCallback(data);
					} else {
						errorCallback(null);
					}
				}, errorCallback);
			});
		}

		function getFavorites(successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				var method = "GET",
				url = serverHost + "/userdata-microservice/favorites",
				authHeader = "Bearer " + token;

				sendRequest(method, url, authHeader, null, function (data) {
					if (data) {
						successCallback(data);
					} else {
						successCallback([]);
					}
				}, errorCallback, false);
			});
		}

		function getFavorite(favoriteName, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				var method = "GET",
					url = serverHost + "/userdata-microservice/favorites/" + favoriteName,
					authHeader = "Bearer " + token;

				sendRequest(method, url, authHeader, null, function (data) {
					if (data) {
						successCallback(data);
					} else {
						errorCallback(null);
					}
				}, errorCallback, false);
			});
		}

		function deleteFavorites(successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				var method = "DELETE",
					url = serverHost + "/userdata-microservice/favorites/",
					authHeader = "Bearer " + token;

				sendRequest(method, url, authHeader, null, function (data) {
					successCallback(null);
				}, errorCallback, false);
			});
		}

		function deleteFavorite(favoriteName, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				var method = "DELETE",
					url = serverHost + "/userdata-microservice/favorites/" + favoriteName,
					authHeader = "Bearer " + token;

				sendRequest(method, url, authHeader, null, function (data) {
					successCallback(null);
				}, errorCallback, false);
			});
		}

		function addFavorite(favoriteObject, parentFolderId, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				var method = "POST",
					url = serverHost + "/userdata-microservice/favorites/" + favoriteObject.getName() + ((parentFolderId!==null) ? ("?parentFolderId="+parentFolderId) : ""),
					authHeader = "Bearer " + token;

				let simplifiedObj = favoriteObject.getJSON();
				delete simplifiedObj.Owner;
				sendRequest(method, url, authHeader, JSON.stringify(simplifiedObj), function (data) {
					successCallback(null);
				}, errorCallback, false);
			});
		}

		function updateFavorite(favoriteName, favoriteObject, parentFolderId, favoritePermissions, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				let argList = [];
				if(parentFolderId!==null) {
					argList.push('parentFolderId='+parentFolderId);
				}
				if(favoritePermissions!==null) {
					argList.push('favoritePermissions='+favoritePermissions);
				}
				let urlArgs = "";
				if(argList.length>0) {
					urlArgs = "?"+argList.join("&");
				}

				var method = "PUT",
					url = serverHost + "/userdata-microservice/favorites/" + favoriteName + urlArgs,
					authHeader = "Bearer " + token;
				let data = null;
				if(favoriteObject!==null) {
					let simplifiedObj = favoriteObject.getJSON();
					delete simplifiedObj.Owner;
					data = JSON.stringify(simplifiedObj);
				}
				
				sendRequest(method, url, authHeader, data, function (data) {
					successCallback(data);
				}, errorCallback, false);
			});
		}
		
		/**
		 * Get the namespaces for the server
		 * @param {string} encodedServer 
		 * @param {function} successCallback 
		 * @param {function} errorCallback 
		 */
		function getOpcuaNamespaces(encodedServer, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				var method = "POST",
					url = serverHost + "/uabr/v1/" + encodedServer + '/browse-references',
					authHeader = "Bearer " + token;

				// special cache handling
				var cacheKey = null;
				if(cache && window.cacheData) {
					// we can cache this
					cacheKey = method+":"+url;
					if(cache.itemInCache(cacheKey)) {
						successCallback(cache.getItemFromCache(cacheKey));
						return; // all done!
					}
				}

				var body = {
					"UrisVersion":0,
					"NamespaceUris":[],
					"ServerUris":[],
					"LocaleIds":["en","en-US"],
					"ServiceId":525,
					"ConnectionParameters":null,
					"Body": {
						"RequestHeader": {
							"AuthenticationToken": {"Id":0},
							"Timestamp": (new Date()).toISOString(),
							"RequestHandle":1,
							"ReturnDiagnostics":0,
							"AuditEntryId":"dxa-opcua-browser-elem",
							"TimeoutHint":0,
							"AdditionalHeader":null
						},
						"View":null,
						"SearchCriteria":null,
						"NodesToBrowse":[{
							"NodeId":{"Id":84},
							"BrowseDirection":0,
							"ReferenceTypeId":{"Id":33},
							"IncludeSubtypes":true,
							"NodeClassMask":11,
							"ResultMask":122
						}]
					}
				};
				sendRequest(method, url, authHeader, JSON.stringify(body), function (data) {
					if(cache && cacheKey) { // we can cache this
						cache.addItemToCache(cacheKey, data);
					}

					successCallback(data);
				}, errorCallback, false);
			});
		}

		/**
		 * Given a list of datasources, request the node types for each
		 * @param {array} datasourceList 
		 * @param {function} successCallback 
		 * @param {function} errorCallback 
		 */
		function getNodeTypes(encodedServer, namespaceUris, datasourceList, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				var method = "POST",
					url = serverHost + "/uabr/v1/" + encodedServer + '/browse-references',
					authHeader = "Bearer " + token;
				let serviceRequest = {
					"AuthenticationToken": {
						"Id": 0
					},
					"Timestamp": (new Date()).toISOString(),
					"RequestHandle": 1,
					"ReturnDiagnostics": 0,
					"AuditEntryId": "dxa-opcua-browser-elem",
					"TimeoutHint": 0,
					"AdditionalHeader": null
				};
				// create node list
				let nodesToBrowse= []; 
				_.each(datasourceList, function(ds) {
					let tagNodeId = ds.nodeId;
					let nsMatch = tagNodeId.match(/^ns=(.*?);/);
					let nodeIdMatch = tagNodeId.match(/;s=(.*)$/);
					if(nsMatch.length>=2 && nodeIdMatch.length>=2) {
						let nsNumber = parseInt(nsMatch[1]);
						let actualNodeId = nodeIdMatch[1];

						let browseNode = {
							"NodeId": { "Id": actualNodeId, "IdType": 1, "Namespace": nsNumber },
							"BrowseDirection": 0,
							"ReferenceTypeId": {
								"Id": 40
							},
							"IncludeSubtypes": true,
							"NodeClassMask": 16,
							"ResultMask": 0
						}
						nodesToBrowse.push(browseNode);
					}
				});

				let body = {
					"RequestHeader": serviceRequest,
					"View": null,
					"SearchCriteria": null,
					"RequestedMaxReferencesPerNode": 5000,
					"NodesToBrowse": nodesToBrowse
				}
				let browseRequest = {
					"UrisVersion": 0,
					"NamespaceUris": namespaceUris,
					"ServerUris": [],
					"LocaleIds": [
						"en-US",
						"en"
					],
					"ServiceId": 525,
					"Body": body
				};
				
				sendRequest(method, url, authHeader, JSON.stringify(browseRequest), function (data) {
					successCallback(data);
				}, errorCallback, false);
			});
		}

		/**
		 * Get a page of server details.
		 * NOTE: DE110876 means that the first page will always be returned, regardless of the requested page.
		 * @param page - The page number (0 based) of results to retrieve
		 * @param pageSize - Number of records per page.
		 * @param successCallback
		 * @param errorCallback
		 */
		function getServerDetails(page, pageSize, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				var method = "GET",
					url = serverHost + "/model-facade/server-details?page=" + page + "&size=" + pageSize,
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, successCallback, errorCallback);
			});
		}

		/**
		 * Get a json object representing the last changed times of parts of the data model
		 * @param {function} successCallback 
		 * @param {function} errorCallback 
		 */
		function getModelVersion(successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/model-facade/model-revision
				var method = "GET",
					url = serverHost + "/model-facade/model-revision",
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, successCallback, errorCallback, false);
			});
		}

		/**
		 * Create a new folder for favorite organization
		 * @param {string} folderName - Name of the folder
		 * @param {string} parentFolderId - Id of the parent (-1 for no parent)
		 * @param {function} successCallback 
		 * @param {function} errorCallback 
		 */
		 function addFavoriteFolder(folderName, parentFolderId, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//POST http://<HOSTNAME>/userdata-microservice/folders?folderName=abc&parentFolderId=-1
				var method = "POST",
					url = serverHost + "/userdata-microservice/folders?folderName="+folderName+"&parentFolderId="+parentFolderId,
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, successCallback, errorCallback, false);
			});
		}

		/**
		 * Delete a folder for favorite organization
		 * @param {string} folderId - GUID of the folder
		 * @param {function} successCallback 
		 * @param {function} errorCallback 
		 */
		 function deleteFavoriteFolder(folderId, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//DELETE http://<HOSTNAME>/userdata-microservice/folders/<GUID>
				var method = "DELETE",
					url = serverHost + "/userdata-microservice/folders/"+folderId,
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, successCallback, errorCallback, false);
			});
		}
		
		/**
		 * Get a folder for favorite organization
		 * @param {string} folderId - GUID of the folder
		 * @param {function} successCallback 
		 * @param {function} errorCallback 
		 */
		 function getFavoriteFolder(folderId, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/userdata-microservice/folders/<GUID>
				var method = "GET",
				url = serverHost + "/userdata-microservice/folders/"+folderId,
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, successCallback, errorCallback, false);
			});
		}

		/**
		 * Get all folders for favorite organization
		 * @param {function} successCallback 
		 * @param {function} errorCallback 
		 */
		 function getFavoriteFolders(successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/userdata-microservice/folders
				var method = "GET",
				url = serverHost + "/userdata-microservice/folders",
					authHeader = "Bearer " + token;
				sendRequest(method, url, authHeader, null, successCallback, errorCallback, false);
			});
		}		
		
		/**
		 * Modify a folder for favorite organization (rename or reparent)
		 * @param {string} folderName - Name of the folder
		 * @param {string} parentFolderId - Id of the parent (-1 for no parent)
		 * @param {function} successCallback 
		 * @param {function} errorCallback 
		 */
		 function modifyFavoriteFolder(folderId, folderName, parentFolderId, folderPermissions, successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//PUT http://<HOSTNAME>/userdata-microservice/folders/<GUID>?folderName=abc&parentFolderId=-1&folderPermissions=guid,guid,guid
				let argList = [];
				if(folderName!==null) {
					argList.push('folderName='+folderName);
				}
				if(parentFolderId!==null) {
					argList.push('parentFolderId='+parentFolderId);
				}
				if(folderPermissions!==null) {
					argList.push('folderPermissions='+folderPermissions);
				}
				let urlArgs = "";
				if(argList.length>0) {
					urlArgs = "?"+argList.join("&");
				}

				var method = "PUT",
					url = serverHost + "/userdata-microservice/folders/" + folderId + urlArgs,
					authHeader = "Bearer " + token;
					sendRequest(method, url, authHeader, null, successCallback, errorCallback, false);
			});
		}
		
		function getUserGroups(successCallback, errorCallback) {
			_AwaitToken().then(function (t) {
				//POST http://<HOSTNAME>/app/ajax/UaaApiManager
				var data = {"command":"get_uaa_groups"},
					method = "POST",
					url = serverHost + "/app/ajax/UaaApi",
					authHeader = "Bearer " + token;
				sendFormRequest(method, url, authHeader,  'data='+JSON.stringify(data), successCallback, errorCallback, false);
			});
		}

		function getUserInfo(successCallback, errorCallback) {
			 let urlParams = window.location.search;
			 if (!window.location.search && window.location.pathname) {
				let [appName, appValue, pageName, pageValue] = window.location.pathname.replace("/run/v2/", "").split("/");
				appName = appName.replace("-", "_");
				pageName = pageName.replace("-", "_");
				urlParams = `?${appName}=${appValue}&${pageName}=${pageValue}`;
      }
			_AwaitToken().then(function (t) {
				//GET http://<HOSTNAME>/app/checkLogin
				var method = "GET",
					//urlParams = window.location.search,
					url = serverHost + "/app/checkLogin" + urlParams,
					authHeader = "Bearer " + token;
					sendRequest(method, url, authHeader, null, successCallback, errorCallback, false);
			});
		}
		function getVersion() {
			return "0.18";
		}

		return ({
			getAsset: getAsset,
			getAssetDataSources: getAssetDataSources,
			getAssetType: getAssetType,
			getAssetTypes: getAssetTypes,
			getAssets: getAssets,
			getControlPropertyDataForAsset: getControlPropertyDataForAsset,
			getControlPropertyDataForAssetType: getControlPropertyDataForAssetType,
			getDatasourceStockProperties: getDatasourceStockProperties,
			getHMIAssetConfig: getHMIAssetConfig,
			getMimic: getMimic,
			getMimicImage: getMimicImage,
			addTokenListener: addTokenListener,
			removeAllTokenListeners: removeAllTokenListeners,
			getToken: getToken,
			getTrendablePropertyDataForAsset: getTrendablePropertyDataForAsset,
			getTrendablePropertyDataForAssetType: getTrendablePropertyDataForAssetType,
			getHierarchy: getHierarchy,
			getVersion: getVersion,
			awaitDatasourceStockProperties: _AwaitDatasourceStockProperties,
			getFavorites: getFavorites,
			getFavorite: getFavorite,
			deleteFavorites: deleteFavorites,
			deleteFavorite: deleteFavorite,
			addFavorite: addFavorite,
			updateFavorite: updateFavorite,
			getOpcuaNamespaces: getOpcuaNamespaces,
			getNodeTypes: getNodeTypes,
			getServerDetails: getServerDetails,
			getModelVersion: getModelVersion,
			addFavoriteFolder: addFavoriteFolder,
			deleteFavoriteFolder: deleteFavoriteFolder,
			getFavoriteFolder: getFavoriteFolder,
			getFavoriteFolders: getFavoriteFolders,
			modifyFavoriteFolder: modifyFavoriteFolder,
			getUserGroups: getUserGroups,
			getUserInfo: getUserInfo
		});
	}

	return {
		getInstance: function (hostname) {
			if(!instances.hasOwnProperty(hostname)) {
				instances[hostname] = init(hostname);
			}
			return instances[hostname];
		}
	};
})();

if(!window.hasOwnProperty("restDataAccess_geWebHmiCore")) {
	window.restDataAccess_geWebHmiCore = restDataModule;
}
