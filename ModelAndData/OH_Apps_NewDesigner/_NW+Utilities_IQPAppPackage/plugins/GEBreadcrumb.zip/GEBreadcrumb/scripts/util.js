
/*
 * insertFontFamily
 *
 * Utility to insert the html code required into a style element to get the
 * desired webfont to load. It will first check the 'style' elements found in 
 * the head section to try to determine if the webfont is already loaded. If the
 * webfont is found to be already specified in the 'style' element, then the
 * function will exit.
 * 
 * @param fontName String used to search to determine if already loaded
 * @param htmlCode String representing the html code to insert
 */
var insertFontFamily = function(fontName, htmlCode) {

	// Check if already loaded
	var styles = document.head.getElementsByTagName("style");
	for (var idx=0; idx<styles.length; idx++) {
		if (styles[idx].textContent.indexOf(fontName) !== -1) {
			// Found an instance of the font. Exit
			return;
		}
	}
		
	// Create a "style" element to load the webfont
	var fontEl = document.createElement('style');
	fontEl.innerHTML = htmlCode;
	document.head.appendChild(fontEl);
};