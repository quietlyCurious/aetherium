# EY_TabSelector

Operations Hub custom plugin for segmented tabs with datasource-driven enable/disable, integer badge counts, and per-tab Actions.

## What this plugin triggers

This plugin uses Operations Hub Actions via `EMBED.executeAction(commandId)`.

Each tab slot maps to a fixed command id:

- Tab 1 -> `onTab01Selected`
- Tab 2 -> `onTab02Selected`
- Tab 3 -> `onTab03Selected`
- Tab 4 -> `onTab04Selected`
- Tab 5 -> `onTab05Selected`
- Tab 6 -> `onTab06Selected`
- Tab 7 -> `onTab07Selected`
- Tab 8 -> `onTab08Selected`
- Tab 9 -> `onTab09Selected`
- Tab 10 -> `onTab10Selected`

Notes:

- Max tabs supported: 10.
- Initial default selection triggers the mapped action.
- Reselection due to datasource-driven disable/enable also triggers the mapped action.
- Disabled tabs do not accept click, but can still show badge value.

## Designer Configuration Playbook

Use this checklist in Operations Hub Designer.

### 1. Configure tabs in plugin settings

For each tab item:

- `label`: display text and selected-label output value.
- `enabledSource` + `enabledWhen`: controls whether tab is enabled.
- `badgeSource` or `badgeManual`: bubble value.

Set `defaultTabLabel` to one of the tab labels for initial selection.

### 2. Configure Actions per tab slot

Open the plugin instance `Actions` section.

For each command id you use (`onTab01Selected`, `onTab02Selected`, etc.), add one or more action rows.

Common pattern (based on your screen setup):

1. Action row 1: `Set global value`
2. Target: `SelectedTab` (or your global)
3. Value source: `Manual`
4. Manual value: tab-specific label, for example `Pallet Production`

Optional additional rows for the same command:

1. Action row 2: `Set global value`
2. Target: `SelectedLotStatus` (or similar)
3. Value source: `Manual`, `Data`, or `Formula`

Optional submit row:

1. Action row N: `Submit`
2. Target query: e.g. `spLocal_EY_PalletGet.Resultset1`

### 3. Recommended slot-to-tab governance

Keep a simple table in project docs and update it whenever tabs change:

- Slot 1 = All
- Slot 2 = Open
- Slot 3 = In Progress
- Slot 4 = Completed
- ...

This avoids accidental mismatch between visual tab order and configured command actions.

### 4. Output compatibility (optional)

The plugin still writes selected tab label to `selectedTabOutput` for backward compatibility.

- If Actions are your only integration path, you can leave `selectedTabOutput` unbound.
- If both are needed, keep both configured.

## Runtime Behavior Summary

- Click enabled tab -> updates selected label output -> executes mapped command.
- Selected tab becomes disabled by datasource -> auto-select next enabled tab -> executes mapped command.
- Badge value is always integer (`floor` normalization, hidden when <= 0).

## Troubleshooting

If action does not run:

- Verify command id exists in plugin manifest.
- Verify the specific command has Actions configured in the instance.
- Verify tab count does not exceed 10.
- Verify selected tab is enabled.
