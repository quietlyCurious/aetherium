(function () {
  "use strict";

  function parseMaybeJson(value) {
    if (typeof value !== "string") {
      return value;
    }
    try {
      return JSON.parse(value);
    } catch (err) {
      return value;
    }
  }

  function colorToCss(value, fallback) {
    if (!value) {
      return fallback;
    }

    var parsed = value;
    if (!parsed || !parsed.hex) {
      parsed = parseMaybeJson(value);
    }

    if (!parsed || !parsed.hex) {
      return fallback;
    }

    var alpha = 1;
    if (parsed.rgb && parsed.rgb.a !== undefined && parsed.rgb.a !== null) {
      alpha = Number(parsed.rgb.a);
      if (!isFinite(alpha)) {
        alpha = 1;
      }
    }

    if (alpha >= 1) {
      return parsed.hex;
    }

    return "rgba(" +
      Number(parsed.rgb.r || 0) + "," +
      Number(parsed.rgb.g || 0) + "," +
      Number(parsed.rgb.b || 0) + "," +
      alpha + ")";
  }

  function toPositiveInt(value) {
    var numeric = Number(value);
    if (!isFinite(numeric)) {
      return 0;
    }
    var floored = Math.floor(numeric);
    return floored > 0 ? floored : 0;
  }

  function isConfiguredField(field) {
    return !!(field && typeof field === "object" && field.type);
  }

  function normalizeBoolLike(value) {
    if (typeof value === "boolean") {
      return value;
    }
    if (typeof value === "number") {
      return value !== 0;
    }
    if (typeof value === "string") {
      var lowered = value.trim().toLowerCase();
      if (lowered === "true" || lowered === "yes" || lowered === "on" || lowered === "1") {
        return true;
      }
      if (lowered === "false" || lowered === "no" || lowered === "off" || lowered === "0" || lowered === "") {
        return false;
      }
    }
    return false;
  }

  function evalEnabledRule(rawValue, rule, matchValue, manualFallback) {
    if (rawValue === undefined || rawValue === null || rawValue === "") {
      return !!manualFallback;
    }

    switch (rule) {
      case "oneIsEnabled":
        return Number(rawValue) === 1;
      case "trueIsEnabled":
        return normalizeBoolLike(rawValue);
      case "customEquals":
        return String(rawValue) === String(matchValue);
      case "nonZeroIsEnabled":
      default:
        return Number(rawValue) !== 0;
    }
  }

  function firstQueryValue(field, rows) {
    if (!Array.isArray(rows) || !rows.length) {
      return null;
    }

    var row = rows[0];
    if (!row || typeof row !== "object") {
      return row;
    }

    var outputs = EMBED.getQueryOutput(field) || [];
    if (outputs.length && outputs[0].fieldName && row.hasOwnProperty(outputs[0].fieldName)) {
      return row[outputs[0].fieldName];
    }

    var keys = Object.keys(row);
    if (!keys.length) {
      return null;
    }

    return row[keys[0]];
  }

  function subscribeField(field, onValue) {
    if (!isConfiguredField(field)) {
      return;
    }

    if (field.type === "manual") {
      onValue(field.manual);
      return;
    }

    if (EMBED.fieldTypeIsGlobal(field)) {
      onValue(EMBED.getGlobalData(field));
      EMBED.subscribeFieldToGlobalChange(field, function (value) {
        onValue(value);
      });
      return;
    }

    if (EMBED.fieldTypeIsFormula(field)) {
      onValue(EMBED.getFormulaData(field));
      EMBED.subscribeFieldToFormulaChange(field, function (value) {
        onValue(value);
      });
      return;
    }

    if (EMBED.fieldTypeIsQuery(field)) {
      EMBED.subscribeFieldToQueryChange(field, function (rows) {
        onValue(firstQueryValue(field, rows));
      });
    }
  }

  try {
    // ===== EYTS-DEBUG SECTION A: IIFE ENTRY =====
    var _dbgEntryTime = Date.now();
    if (!window.__eytsDebug) { window.__eytsDebug = { entryCount: 0, lastEntryTime: 0, callLog: [] }; }
    window.__eytsDebug.entryCount++;
    var _dbgGap = _dbgEntryTime - window.__eytsDebug.lastEntryTime;
    window.__eytsDebug.lastEntryTime = _dbgEntryTime;
    console.warn('[EYTS-DEBUG A] IIFE entered. Count=' + window.__eytsDebug.entryCount + ', gap=' + _dbgGap + 'ms, stack:', new Error().stack);
    // ===== END SECTION A =====

    var element = EMBED.getRootElement();
    var data = (EMBED.getComponent() && EMBED.getComponent().schema && EMBED.getComponent().schema.data) || {};

    var root = element.find("#eyTabSelectorRoot")[0];
    var tabsHost = element.find("#eyTabSelectorTabs")[0];

    // ===== EYTS-DEBUG SECTION B: DOM ELEMENT CHECK =====
    console.warn('[EYTS-DEBUG B] root=' + !!root + ', tabsHost=' + !!tabsHost + ', root.dataset.eytsInitialized=' + (root ? root.dataset.eytsInitialized : 'N/A') + ', root identity=' + (root ? (root._eytsId || (root._eytsId = 'el-' + Math.random().toString(36).slice(2,8))) : 'null'));
    // ===== END SECTION B =====

    if (!root || !tabsHost) {
      console.warn('[EYTS-DEBUG] EXIT: no root or tabsHost');
      return;
    }

    // Prevent infinite re-initialization caused by Angular digest re-entry
    if (root.dataset.eytsInitialized) {
      console.warn('[EYTS-DEBUG] EXIT: already initialized (guard hit). Entry#' + window.__eytsDebug.entryCount);
      return;
    }
    root.dataset.eytsInitialized = "1";
    console.warn('[EYTS-DEBUG] Guard passed. Deferring ALL init to escape Angular digest. Entry#' + window.__eytsDebug.entryCount);

    // === DEFER ALL WORK (DOM, subscriptions, side effects) out of Angular's $digest ===
    setTimeout(function () {
      console.warn('[EYTS-DEBUG] Deferred init starting.');

      var appearance = data.appearance || {};
      var defaultTabLabel = (data.defaultTabLabel || "").trim();

      function applyAppearance() {
        root.style.setProperty("--eyts-font-family", appearance.fontFamily || "Segoe UI, Arial, sans-serif");
        root.style.setProperty("--eyts-container-bg", colorToCss(appearance.containerBackgroundColor, "#f3f5fa"));
        root.style.setProperty("--eyts-container-border", colorToCss(appearance.containerBorderColor, "#d4d8e2"));

        root.style.setProperty("--eyts-selected-bg", colorToCss(appearance.selectedBackgroundColor, "#dbe6ff"));
        root.style.setProperty("--eyts-selected-text", colorToCss(appearance.selectedTextColor, "#1d3f8f"));
        root.style.setProperty("--eyts-selected-size", String(Number(appearance.selectedFontSize) || 14) + "px");

        root.style.setProperty("--eyts-unselected-bg", colorToCss(appearance.unselectedBackgroundColor, "#ffffff"));
        root.style.setProperty("--eyts-unselected-text", colorToCss(appearance.unselectedTextColor, "#4b5567"));
        root.style.setProperty("--eyts-unselected-size", String(Number(appearance.unselectedFontSize) || 14) + "px");

        root.style.setProperty("--eyts-disabled-bg", colorToCss(appearance.disabledBackgroundColor, "#f0f2f7"));
        root.style.setProperty("--eyts-disabled-text", colorToCss(appearance.disabledTextColor, "#9aa3b2"));
        root.style.setProperty("--eyts-disabled-size", String(Number(appearance.disabledFontSize) || 14) + "px");

        root.style.setProperty("--eyts-badge-bg", colorToCss(appearance.badgeBackgroundColor, "#2e3e5c"));
        root.style.setProperty("--eyts-badge-text", colorToCss(appearance.badgeTextColor, "#ffffff"));
      }

      function parseTabs(rawTabs) {
        var candidate = parseMaybeJson(rawTabs);
        if (!Array.isArray(candidate)) {
          return [];
        }

        return candidate.map(function (item, index) {
          var tab = item || {};
          var label = (tab.label || ("Tab " + (index + 1))).toString().trim();
          if (!label) {
            label = "Tab " + (index + 1);
          }
          var tabId = (tab.tabId || "").trim();
          if (!tabId) {
            tabId = "tab-" + index;
          }

          return {
            key: tabId,
            index: index,
            label: label,
            enabledManual: tab.enabledManual !== false,
            enabledSource: tab.enabledSource,
            enabledWhen: tab.enabledWhen || "nonZeroIsEnabled",
            enabledMatchValue: tab.enabledMatchValue || "1",
            badgeSource: tab.badgeSource,
            badgeManual: Number(tab.badgeManual) || 0,
            targets: Array.isArray(tab.targets) ? tab.targets : []
          };
        });
      }

      var state = {
        tabs: parseTabs(data.tabs),
        badgeByKey: {},
        enabledByKey: {},
        selectedLabel: "",
        selectedKey: ""
      };

      function isTabEnabled(tab) {
        if (!isConfiguredField(tab.enabledSource)) {
          return !!tab.enabledManual;
        }

        var rawValue = state.enabledByKey[tab.key];
        return evalEnabledRule(rawValue, tab.enabledWhen, tab.enabledMatchValue, tab.enabledManual);
      }

      function getBadgeValue(tab) {
        var raw = isConfiguredField(tab.badgeSource) ? state.badgeByKey[tab.key] : tab.badgeManual;
        return toPositiveInt(raw);
      }

      function findFirstEnabledTab() {
        var i;
        for (i = 0; i < state.tabs.length; i++) {
          if (isTabEnabled(state.tabs[i])) {
            return state.tabs[i];
          }
        }
        return null;
      }

      function findTabByLabel(label) {
        var i;
        for (i = 0; i < state.tabs.length; i++) {
          if (state.tabs[i].label === label) {
            return state.tabs[i];
          }
        }
        return null;
      }

      function findTabByKey(key) {
        var i;
        for (i = 0; i < state.tabs.length; i++) {
          if (state.tabs[i].key === key) {
            return state.tabs[i];
          }
        }
        return null;
      }

      function resolveInitialSelection() {
        if (!state.tabs.length) {
          return null;
        }

        if (defaultTabLabel) {
          var defaultTab = findTabByLabel(defaultTabLabel);
          if (defaultTab && isTabEnabled(defaultTab)) {
            return defaultTab;
          }
        }

        return findFirstEnabledTab();
      }

      function executeSelectionCommand(tab) {
        if (!tab) {
          return;
        }

        console.warn('[EYTS-DEBUG C] executeSelectionCommand called. tab=' + tab.key + ', label=' + tab.label + ', targets=' + tab.targets.length);

        // Submit per-tab targets
        tab.targets.forEach(function (t) {
          if (isConfiguredField(t.targetField)) {
            console.warn('[EYTS-DEBUG C.1] submitTarget: value=' + t.targetValue);
            EMBED.submitTarget(t.targetField, t.targetValue || "");
          }
        });

        // Fire shared action command
        try {
          console.warn('[EYTS-DEBUG C.2] CALLING EMBED.executeAction("onTabSelected")...');
          EMBED.executeAction("onTabSelected");
          console.warn('[EYTS-DEBUG C.3] EMBED.executeAction returned normally.');
        } catch (err) {
          console.warn('[EYTS-DEBUG C.ERR] executeAction threw: ' + err.message);
        }
      }

      function setSelectedTab(nextTab, shouldFireAction) {
        var normalizedKey = nextTab ? nextTab.key : "";
        var normalizedLabel = nextTab ? nextTab.label : "";

        console.warn('[EYTS-DEBUG D] setSelectedTab. nextKey=' + normalizedKey + ', shouldFire=' + shouldFireAction + ', currentKey=' + state.selectedKey);

        if (state.selectedKey === normalizedKey && state.selectedLabel === normalizedLabel) {
          return;
        }

        state.selectedKey = normalizedKey;
        state.selectedLabel = normalizedLabel;
        renderTabs();

        if (shouldFireAction && nextTab) {
          executeSelectionCommand(nextTab);
        }
      }

      function maintainValidSelection() {
        console.warn('[EYTS-DEBUG G] maintainValidSelection. selectedKey=' + state.selectedKey);

        if (!state.selectedKey) {
          setSelectedTab(findFirstEnabledTab(), true);
          return;
        }

        var selectedTab = findTabByKey(state.selectedKey);

        if (!selectedTab || !isTabEnabled(selectedTab)) {
          setSelectedTab(findFirstEnabledTab(), true);
        }
      }

      function renderTabs() {
        tabsHost.innerHTML = "";

        if (!state.tabs.length) {
          var empty = document.createElement("div");
          empty.className = "eyts_empty";
          empty.textContent = "No tabs configured";
          tabsHost.appendChild(empty);
          return;
        }

        state.tabs.forEach(function (tab) {
          var enabled = isTabEnabled(tab);
          var isSelected = enabled && tab.key === state.selectedKey;

          var button = document.createElement("button");
          button.type = "button";
          button.className = "eyts_tab " +
            (enabled ? (isSelected ? "eyts_tab_selected" : "eyts_tab_unselected") : "eyts_tab_disabled");
          button.setAttribute("role", "tab");
          button.setAttribute("aria-selected", isSelected ? "true" : "false");
          button.setAttribute("aria-disabled", enabled ? "false" : "true");
          button.disabled = !enabled;

          var text = document.createElement("span");
          text.textContent = tab.label;
          button.appendChild(text);

          var badgeValue = getBadgeValue(tab);
          if (badgeValue > 0) {
            var badge = document.createElement("span");
            badge.className = "eyts_badge";
            badge.textContent = String(badgeValue);
            button.appendChild(badge);
          }

          if (enabled) {
            button.addEventListener("click", function () {
              setSelectedTab(tab, true);
            });
          }

          tabsHost.appendChild(button);
        });
      }

      function wireSubscriptions() {
        state.tabs.forEach(function (tab) {
          if (isConfiguredField(tab.badgeSource)) {
            subscribeField(tab.badgeSource, function (value) {
              state.badgeByKey[tab.key] = value;
              renderTabs();
            });
          }

          if (isConfiguredField(tab.enabledSource)) {
            subscribeField(tab.enabledSource, function (value) {
              state.enabledByKey[tab.key] = value;
              maintainValidSelection();
              renderTabs();
            });
          }
        });
      }

      applyAppearance();
      wireSubscriptions();
      var initialTab = resolveInitialSelection();

      console.warn('[EYTS-DEBUG E] Setting initial tab. tab=' + (initialTab ? initialTab.key : 'null') + ', label=' + (initialTab ? initialTab.label : 'null'));

      setSelectedTab(initialTab, true);
      if (!initialTab) {
        renderTabs();
      }

      console.warn('[EYTS-DEBUG F] Initialization complete. selectedKey=' + state.selectedKey);

    }, 0); // end deferred init

  } catch (err) {
    try {
      var fallbackElement = EMBED.getRootElement();
      fallbackElement.html("<div style='font-family:Arial;padding:8px;color:#b00020;'>EY_TabSelector error: " + String(err.message || err) + "</div>");
    } catch (ignore) {
      // no-op
    }
  }
})();
