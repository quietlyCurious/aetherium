var token,userPreferences;
var hostName=window.location.hostname;
function getToken(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      console.log(this.responseText);
      token=JSON.parse(this.responseText).access_token;
      
	  var dataComponent = EMBED.getComponent();
		var globalVar = dataComponent.schema.data['INPUT1'];
		if (EMBED.fieldTypeIsGlobal(globalVar)) {		
		EMBED.submitTarget(globalVar, token);
		getUnitPreferences();
		}
      
    }
  };
  xhttp.open("GET", `https://${hostName}/app/token`, true);
  xhttp.send();
}
function getUnitPreferences(){
	var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
     userPreferences = JSON.parse(this.responseText).content
      console.log(userPreferences);
      const ele = document.getElementById('myDiv');
	  let html='';
	  //headers
	  html+=`<div class="font-style" style="padding-left:100px;width:50%;display:flex">
	  <div style="width:33%;border-bottom: 1px solid black;"><b>AssetID</b></div>
	  <div style="width:33%;border-bottom: 1px solid black;"><b>Unit Name</b></div>
	  <div style="width:33%;border-bottom: 1px solid black;"><b>Line Name</b></div></div>`
	  //loop data
	  userPreferences.forEach((e)=>{
		html+=`<div style="padding-left:100px;width:50%;display:flex"><div style="width:33%">${e.assetId}</div><div style="width:33%">${e.name}</div><div style="width:33%">${e.lineName}</div></div>`
	  })
	  ele.innerHTML=html;
    }
  };
  xhttp.open("GET", `https://hydpriwin1601:8444/downtime-app-service-0.1.6/my-machines/unit-preferences`, true);
  xhttp.setRequestHeader('Authorization', 'Bearer '+token);
  xhttp.send();
}
getToken();