// Box and Whisker Quality Control Widget - Main.js (Compact Version)
(function() {
    'use strict';

    // Get the root element for THIS widget instance
    var rootElement = EMBED.getRootElement();
    
    // Ensure we have a DOM element (not a jQuery object)
    if (rootElement && rootElement.jquery) {
        rootElement = rootElement[0]; // Convert jQuery object to DOM element
    }
    
    var data = EMBED.getComponent().schema.data;

    // Default data
    var widgetData = {
        lowerRejectEnd: 0,
        lowerRejectStart: 20,
        upperRejectStart: 80,
        upperRejectEnd: 100,
        lowerQuartile: 35,
        upperQuartile: 65,
        minValue: 20,
        maxValue: 80,
        resultValue: 50,
        targetValue: 50,
        widgetTitle: 'Quality Control',
        engineeringUnits: '',
        trendHistory: []
    };

    // Track initialization state
    var isInitialized = false;

    // Chart configuration - UPDATED FOR COMPACT VERSION
    var chartConfig = {
        width: 220,  // Changed from 300 to 220
        minVal: 0,
        maxVal: 100,
        trendHeight: 30,
        maxTrendPoints: 10
    };

    // Calculate position on chart based on value
    function getPosition(value) {
        var range = chartConfig.maxVal - chartConfig.minVal || 1;
        return (value - chartConfig.minVal) / range * chartConfig.width;
    }

    // Clamp position to chart bounds (0 to chartConfig.width)
    function clampPosition(pos) {
        return Math.max(0, Math.min(chartConfig.width, pos));
    }

    // Calculate position on trend chart (inverted Y-axis for SVG)
    function getTrendY(value) {
        var range = chartConfig.maxVal - chartConfig.minVal || 1;
        var normalized = (value - chartConfig.minVal) / range;
        // Invert Y (0 at top, height at bottom) and map to trend height
        return chartConfig.trendHeight - (normalized * chartConfig.trendHeight);
    }

    // Update trend chart
    function updateTrendChart(trendData, targetValue) {
        if (!trendData || trendData.length === 0) {
            return;
        }

        // Limit to last maxTrendPoints
        var displayData = trendData.slice(-chartConfig.maxTrendPoints);
        var trendLine = rootElement.querySelector('#trendLine');
        var trendPoints = rootElement.querySelector('#trendPoints');
        var targetLine = rootElement.querySelector('#targetLine');
        
        if (!trendLine || !trendPoints) return;

        // Clear existing points
        trendPoints.innerHTML = '';

        // Calculate spacing
        var spacing = chartConfig.width / Math.max(1, displayData.length - 1);
        var points = [];

        // Generate polyline points and circles
        displayData.forEach(function(value, index) {
            var x = index * spacing;
            var y = getTrendY(value);
            points.push(x + ',' + y);

            // Create circle for each point
            var circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            circle.setAttribute('cx', x);
            circle.setAttribute('cy', y);
            
            // Last point is current value (larger, different color)
            if (index === displayData.length - 1) {
                circle.setAttribute('r', 2.5);
                circle.setAttribute('class', 'trend-point-current');
            } else {
                circle.setAttribute('r', 1.5);
                circle.setAttribute('class', 'trend-point');
            }
            
            trendPoints.appendChild(circle);
        });

        // Update polyline
        trendLine.setAttribute('points', points.join(' '));

        // Update target line position
        if (targetLine && typeof targetValue === 'number') {
            var targetY = getTrendY(targetValue);
            targetLine.setAttribute('y1', targetY);
            targetLine.setAttribute('y2', targetY);
        }
    }

    // Update the widget visualization
    function updateWidget(data) {
        if (!data) return;

        // Validate and sanitize data values
        var parsedLowerRejectEnd = parseFloat(data.lowerRejectEnd);
        var parsedLowerRejectStart = parseFloat(data.lowerRejectStart);
        var parsedUpperRejectStart = parseFloat(data.upperRejectStart);
        var parsedUpperRejectEnd = parseFloat(data.upperRejectEnd);
        var parsedLowerQuartile = parseFloat(data.lowerQuartile);
        var parsedUpperQuartile = parseFloat(data.upperQuartile);
        var parsedMinValue = parseFloat(data.minValue);
        var parsedMaxValue = parseFloat(data.maxValue);
        var parsedResultValue = parseFloat(data.resultValue);

        // Set defaults for any NaN values
        data.lowerRejectEnd = !isNaN(parsedLowerRejectEnd) ? parsedLowerRejectEnd : 0;
        data.lowerRejectStart = !isNaN(parsedLowerRejectStart) ? parsedLowerRejectStart : 20;
        data.upperRejectStart = !isNaN(parsedUpperRejectStart) ? parsedUpperRejectStart : 80;
        data.upperRejectEnd = !isNaN(parsedUpperRejectEnd) ? parsedUpperRejectEnd : 100;
        data.lowerQuartile = !isNaN(parsedLowerQuartile) ? parsedLowerQuartile : 35;
        data.upperQuartile = !isNaN(parsedUpperQuartile) ? parsedUpperQuartile : 65;
        data.minValue = !isNaN(parsedMinValue) ? parsedMinValue : 20;
        data.maxValue = !isNaN(parsedMaxValue) ? parsedMaxValue : 80;
        data.resultValue = !isNaN(parsedResultValue) ? parsedResultValue : 50;

        // Ensure proper ordering
        if (data.lowerRejectStart < data.lowerRejectEnd) {
            data.lowerRejectStart = data.lowerRejectEnd;
        }
        if (data.upperRejectStart < data.lowerRejectStart) {
            data.upperRejectStart = data.lowerRejectStart;
        }
        if (data.upperRejectEnd < data.upperRejectStart) {
            data.upperRejectEnd = data.upperRejectStart;
        }

        // Update chart configuration
        chartConfig.minVal = data.lowerRejectEnd;
        chartConfig.maxVal = data.upperRejectEnd;

        // Calculate positions
        var lowerRejectPos = getPosition(data.lowerRejectStart);
        var upperRejectPos = getPosition(data.upperRejectStart);
        var lowerQuartilePos = getPosition(data.lowerQuartile);
        var upperQuartilePos = getPosition(data.upperQuartile);
        var minValuePos = getPosition(data.minValue);
        var maxValuePos = getPosition(data.maxValue);
        var resultPos = clampPosition(getPosition(data.resultValue));

        // Update text elements
        var titleElement = rootElement.querySelector('#widgetTitle');
        if (titleElement) {
            titleElement.textContent = data.widgetTitle || 'Quality Control';
        }

        var euElement = rootElement.querySelector('#engineeringUnits');
        if (euElement) {
            euElement.textContent = data.engineeringUnits || '';
        }

        var resultDisplay = rootElement.querySelector('#resultValueDisplay');
        if (resultDisplay) {
            resultDisplay.textContent = data.resultValue;
        }

        // Update zones with safety checks
        var lowerRejectZone = rootElement.querySelector('#lowerRejectZone');
        if (lowerRejectZone) {
            lowerRejectZone.setAttribute('width', Math.max(0, lowerRejectPos));
            if (data.resultValue < data.lowerRejectStart) {
                lowerRejectZone.setAttribute('class', 'reject-zone-active');
            } else {
                lowerRejectZone.setAttribute('class', 'reject-zone');
            }
        }

        var acceptZone = rootElement.querySelector('#acceptZone');
        if (acceptZone) {
            acceptZone.setAttribute('x', lowerRejectPos);
            acceptZone.setAttribute('width', Math.max(0, upperRejectPos - lowerRejectPos));
        }

        var upperRejectZone = rootElement.querySelector('#upperRejectZone');
        if (upperRejectZone) {
            upperRejectZone.setAttribute('x', upperRejectPos);
            upperRejectZone.setAttribute('width', Math.max(0, chartConfig.width - upperRejectPos));
            if (data.resultValue > data.upperRejectStart) {
                upperRejectZone.setAttribute('class', 'reject-zone-active');
            } else {
                upperRejectZone.setAttribute('class', 'reject-zone');
            }
        }

        // Update whiskers
        var lowerWhisker = rootElement.querySelector('#lowerWhisker');
        if (lowerWhisker) {
            lowerWhisker.setAttribute('x1', minValuePos);
            lowerWhisker.setAttribute('x2', lowerQuartilePos);
        }

        var upperWhisker = rootElement.querySelector('#upperWhisker');
        if (upperWhisker) {
            upperWhisker.setAttribute('x1', upperQuartilePos);
            upperWhisker.setAttribute('x2', maxValuePos);
        }

        var lowerWhiskerCap = rootElement.querySelector('#lowerWhiskerCap');
        if (lowerWhiskerCap) {
            lowerWhiskerCap.setAttribute('x1', minValuePos);
            lowerWhiskerCap.setAttribute('x2', minValuePos);
        }

        var upperWhiskerCap = rootElement.querySelector('#upperWhiskerCap');
        if (upperWhiskerCap) {
            upperWhiskerCap.setAttribute('x1', maxValuePos);
            upperWhiskerCap.setAttribute('x2', maxValuePos);
        }

        // Update box
        var box = rootElement.querySelector('#box');
        if (box) {
            box.setAttribute('x', lowerQuartilePos);
            box.setAttribute('width', Math.max(1, upperQuartilePos - lowerQuartilePos));
        }

        // Update median
        var median = rootElement.querySelector('#median');
        if (median) {
            var medianPos = (lowerQuartilePos + upperQuartilePos) / 2;
            median.setAttribute('x1', medianPos);
            median.setAttribute('x2', medianPos);
        }

        // Update result marker
        var resultMarker = rootElement.querySelector('#resultMarker');
        if (resultMarker) {
            resultMarker.setAttribute('cx', resultPos);
        }

        // Update trend chart if trend data exists
        if (data.trendHistory && Array.isArray(data.trendHistory) && data.trendHistory.length > 0) {
            updateTrendChart(data.trendHistory, data.targetValue);
        }
    }

    // Callback to update individual field
    var updateField = function(fieldName, value) {
        widgetData[fieldName] = value;
        // Only render after initialization is complete
        if (isInitialized) {
            updateWidget(widgetData);
        }
    };

    // Helper function to create data handler
    function createDataHandler(inputField, fieldName) {
        if (!inputField) return;

        var formulaFirstTime = true;
        if ((inputField.type === 'formula') && formulaFirstTime) {
            updateField(fieldName, inputField.formula.data.value[0].value);
            formulaFirstTime = false;
        }

        if (inputField.type === 'manual') {
            updateField(fieldName, inputField.manual);
        }
        else if (EMBED.fieldTypeIsGlobal(inputField)) {
            var val = EMBED.getGlobalData(inputField);
            updateField(fieldName, val);
            EMBED.subscribeFieldToGlobalChange(inputField, function(data) {
                updateField(fieldName, data);
            });
        }
        else if(EMBED.fieldTypeIsQuery(inputField)) {
            EMBED.subscribeFieldToQueryChange(inputField, function(rows) {
                var output = rows[0][EMBED.getQueryOutput(inputField)[0].fieldName];
                updateField(fieldName, output);
            });
        }
        else if(EMBED.fieldTypeIsFormula(inputField)) {
            var val = EMBED.getFormulaData(inputField);
            updateField(fieldName, val);
            EMBED.subscribeFieldToFormulaChange(inputField, function(data) {
                updateField(fieldName, data);
            });
        }
    }

    // Special handler for trendHistory (handles query results differently)
    function createTrendHistoryHandler(inputField) {
        if (!inputField) return;

        if (inputField.type === 'manual') {
            updateField('trendHistory', inputField.manual);
        }
        else if (EMBED.fieldTypeIsGlobal(inputField)) {
            var val = EMBED.getGlobalData(inputField);
            updateField('trendHistory', val);
            EMBED.subscribeFieldToGlobalChange(inputField, function(data) {
                updateField('trendHistory', data);
            });
        }
        else if(EMBED.fieldTypeIsQuery(inputField)) {
            EMBED.subscribeFieldToQueryChange(inputField, function(rows) {
                // Extract values from query rows
                var trendArray = [];
                var outputFields = EMBED.getQueryOutput(inputField);
                if (outputFields && outputFields.length > 0) {
                    var fieldName = outputFields[0].fieldName;
                    rows.forEach(function(row) {
                        if (row[fieldName] !== null && row[fieldName] !== undefined) {
                            trendArray.push(parseFloat(row[fieldName]));
                        }
                    });
                }
                updateField('trendHistory', trendArray);
            });
        }
        else if(EMBED.fieldTypeIsFormula(inputField)) {
            var val = EMBED.getFormulaData(inputField);
            updateField('trendHistory', val);
            EMBED.subscribeFieldToFormulaChange(inputField, function(data) {
                updateField('trendHistory', data);
            });
        }
    }

    // Set up all data handlers (but don't render yet)
    createDataHandler(data.input.resultValue, 'resultValue');
    createDataHandler(data.input.lowerRejectEnd, 'lowerRejectEnd');
    createDataHandler(data.input.lowerRejectStart, 'lowerRejectStart');
    createDataHandler(data.input.upperRejectStart, 'upperRejectStart');
    createDataHandler(data.input.upperRejectEnd, 'upperRejectEnd');
    createDataHandler(data.input.lowerQuartile, 'lowerQuartile');
    createDataHandler(data.input.upperQuartile, 'upperQuartile');
    createDataHandler(data.input.minValue, 'minValue');
    createDataHandler(data.input.maxValue, 'maxValue');
    createDataHandler(data.input.widgetTitle, 'widgetTitle');
    createDataHandler(data.input.engineeringUnits, 'engineeringUnits');
    createDataHandler(data.input.targetValue, 'targetValue');
    createTrendHistoryHandler(data.input.trendHistory);

    // Mark as initialized and do initial render
    isInitialized = true;
    updateWidget(widgetData);

})();
