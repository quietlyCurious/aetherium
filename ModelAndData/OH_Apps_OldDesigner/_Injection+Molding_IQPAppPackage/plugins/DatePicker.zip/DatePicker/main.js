
(function(){
    "use strict";
    console.log("Date Picker");
    var element = EMBED.getRootElement();
  
    var datePicker = element.find("date-picker");

    var component = EMBED.getComponent();
    var data = component.schema.data;
    
    var title = data.title;
    var type = data.type;
    var displayFormat = (data.displayFormat === "Custom Display Format") ? data.customFormat : data.displayFormat;

    var outputTimezone = data.outputTimezone;

    var inputValue = data.inputValue;
    var inputTarget = data.inputTarget;
    var outputFormat = data.outputFormat;
    let perviousDateValue;
    let perviousTimeValue;


    datePicker.attr("title", title);
    datePicker.attr("type", type);
    datePicker.attr("display-format", displayFormat);

    let getDateFormat = function (date) {
        if (date === "" || date == null) {
            return "";
        }

        // For ISO outputFormat, use momentjs toISOString() ... works for both UTC and local (default locale)
        if ((type !== "time") && (outputFormat === 'ISO')) {
            let keepOffset = false;
            if (outputTimezone === 'local') {
                keepOffset = true
            }

            let output = moment(date, [moment.ISO_8601, 'HH:mm:ss']).toISOString(keepOffset);

            if (type === "date") {
                output = output.split('T')[0];
            }
            return output;
        }
        
        var format = displayFormat.replaceAll("d","D").replaceAll("y","Y").replace("EEEE", "dddd").replace("aa", "a");
        return moment(date, [moment.ISO_8601, 'HH:mm:ss']).format(format);
    };
    
    let submitTarget = function(date) {
        if (date === "" || date == null) {
            if (perviousDateValue !== null) {
                perviousDateValue = null;
                EMBED.submitTarget(inputTarget, null);
            }
            return;
        }
        if (typeof date == "string") {
           // Replace hyphens with slashes to avoid JavaScript's inconsistent date parsing with hyphenated date strings.
            date = !date.includes('T') ? date.replace(/-/g, '\/') : date;
            date =new Date(date);
        }

        if (outputTimezone === "utc" && !(outputFormat === "ISO" && type === "datetime") ) {
            var minutes = date.getMinutes() + date.getTimezoneOffset();
            date = new Date(new Date(date).setMinutes(minutes));
        }

        if (type === "date") {
            date.setHours(0,0,0,0);
        }
        if (type === "time") {
            var h = date.getHours();
            var m = date.getMinutes();
            var s = date.getSeconds();
            h = h > 9 ? h : "0" + h;
            m = m > 9 ? m : "0" + m;
            s = s > 9 ? s : "0" + s;
            var time = h + ":" + m + ":" + s;
            let formattedTime = getDateFormat(time);
            if (perviousTimeValue !== formattedTime) {
                perviousTimeValue = formattedTime;
                EMBED.submitTarget(inputTarget, formattedTime);
            }
        } else {
            let formattedDate = getDateFormat(date);
            if (perviousDateValue !== formattedDate) {
                perviousDateValue = formattedDate;
                EMBED.submitTarget(inputTarget, formattedDate);
            }
        }

    };

    let isValidDate = function(d) {
        return d instanceof Date && !isNaN(d);
    }

    let setInitialDate = function(date) {
        if (typeof date == "string") {
            let tDate;
            tDate = new Date(date.replace(/-/g, '\/'));  // fixes 1 day offset when date string has hyphens (gotta love JS)
            if (isValidDate(tDate))
            {
                date = tDate;
            }
            else
            {
                date = new Date(date);
            }
        }

        if (date && date.toDateString() != 'Invalid Date') {
            if (type === "date") {
                date.setHours(0,0,0,0);
            }
            datePicker.attr("value", date);
            submitTarget(date);
        }    
    };

    element[0].addEventListener('onDateChanged', function(event) {
        // var previousValue = event.detail.previousValue;
        var date = event.detail.value;
        submitTarget(date);
    });

    // set default date
    setInitialDate(new Date());
    
    if (EMBED.fieldTypeIsGlobal(inputValue)) {
        //globals don't go via dataChange on initial load
        const globalData = EMBED.getGlobalData(inputValue);
        let date;
        if (typeof globalData === "string") {
            date = globalData;
        } else if (Array.isArray(globalData) && globalData.length > 0) {
            date = globalData[0];
        } else {
            date = new Date();
        }
        setInitialDate(date);

        EMBED.subscribeFieldToGlobalChange(inputValue, function(rows){    
            if (rows.length > 0) {
                if(typeof rows === "string") {
                    submitTarget(rows);
                    setInitialDate(rows);
                } else {
                    submitTarget(rows[0]);
                    setInitialDate(rows[0]);
                } 
            }
        });
    } else if (EMBED.fieldTypeIsQuery(inputValue)) {
        EMBED.subscribeFieldToQueryChange(inputValue, function(rows) {
            if (rows.length > 0) {
                var val = rows[0][inputValue.query.outputFields[0].fieldName];
                 var date = new Date(val);
				if (date && date.toDateString() != "Invalid Date") {
					datePicker.attr("value", val);
				} else {
					setInitialDate(new Date());
				}
            }
        });
    } else if (EMBED.fieldTypeIsFormula(inputValue)) {
        setInitialDate(EMBED.getFormulaData(inputValue));
        EMBED.subscribeFieldToFormulaChange(inputValue, function(data) {
            setInitialDate(data);
        });
    } else if (inputValue.type && inputValue.type === "manual") {
        let date = inputValue.manual;
        if (type === "time" && date)
        {
            let now = new Date();
            var time = inputValue.manual.split(':');
            if (time.length > 0)
            {
                now.setHours(time[0]);
                if (time.length > 1) now.setMinutes(time[1]); else now.setMinutes(0);
                if (time.length > 2) now.setSeconds(time[2]); else now.setSeconds(0);
                date = now;
                console.log('time', date);
            }
        }
        else if (date)
        {
            date = new Date(inputValue.manual);
        }
        if (date && date.toDateString() != 'Invalid Date') {
            setInitialDate(date);
        }
    } 

let labelStyling = data.advanced.labelStyling;
let inputStyling = data.advanced.inputStyling;
let fontFamily = labelStyling.fontFamily;
let labelFontSize = labelStyling.fontSize;
let defaultColor = {hex:"#000000FF",rgb:{a:1}};
let labelFontColor = setColor(labelStyling.fontColor,defaultColor);
let inputFontSize = inputStyling.fontSize;
let inputFontColor = setColor(inputStyling.fontColor,defaultColor);
function setColor(value, defaultColor)
{
  var color;
  if (value && value.hasOwnProperty('hex'))
  {
    color = value;
  }
  else
  {
    color = value ? JSON.parse(value) : defaultColor;
  }
  var opacity = Math.round(parseFloat(color.rgb.a) * 255);
  opacity = opacity.toString(16);
  opacity = ('00' + opacity).slice(-2);

  return color.hex + opacity;
}

const rootElement = element[0];
if(rootElement){
	rootElement.style.setProperty('--fontFamily', fontFamily);
	rootElement.style.setProperty('--label-fontSize', labelFontSize + "px");
	rootElement.style.setProperty('--label-color', labelFontColor);
	rootElement.style.setProperty('--input-fontSize', inputFontSize + "px");
	rootElement.style.setProperty('--input-color', inputFontColor);
    if(!title){
        element.find('.dx-field-label').hide();
    }
	let labelHeight = title ? labelFontSize + 5 : 17;
	rootElement.style.setProperty('--input-height', `calc(100% - ${labelHeight}px)`);
}
 })();
