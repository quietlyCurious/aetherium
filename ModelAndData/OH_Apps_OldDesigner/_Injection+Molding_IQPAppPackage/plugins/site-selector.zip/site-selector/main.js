const component = EMBED.getComponent();
const rootElement = EMBED.getRootElement();
const appContainer = rootElement.find(`.app-container`);

// Spinner
// TODO: Update spinner with proper image
// const spinner = document.createElement("span");
// spinner.class = `${component.typeName}-spinner`;
// spinner.setAttribute("id", `${component.typeName}_spinner_${Date.now()}`);
// spinner.innerText = "Loading";

// appContainer.append(spinner);

let jsFiles = [];
// ! * This is a placeholder to replace with the actual JS files needed for the component
jsFiles = [{ fileName: "polyfills-NPWMIKQY.js", path: "custom/default/site-selector/scripts/polyfills-NPWMIKQY.js" },
{ fileName: "main-3I2EC7I2.js", path: "custom/default/site-selector/scripts/main-3I2EC7I2.js" },];

jsFiles.forEach(({ path }) => {
  if (document.querySelector(`script[src="${path}"]`)) return;

  const script = document.createElement('script');
  script.src = path;
  script.type = 'module';
  script.defer = true;

  document.head.appendChild(script);
});

// Element
const ele = appContainer[0].querySelector(component.typeName)
  ? appContainer[0].querySelector(component.typeName)
  : document.createElement(component.typeName);
if (!ele.getAttribute('id')) ele.setAttribute('id', `${component.typeName}_${Date.now()}`);

const element = document.createElement(component.typeName);
element.setAttribute('id', `${component.typeName}_${Date.now()}`);
element.class = `${component.typeName}`;
// element.assetsPath = `custom/default/${component.typeName}/assets/`;
element.EMBED = EMBED;

if (!appContainer[0].querySelector(`${component.typeName}`)) appContainer.append(element);

// Events
// TODO: See if we can show spinner during loading of the component
// element.addEventListener("onLoaded", (isLoaded) => {
//   spinner.style.display = isLoaded ? "none" : "block";
// });

element.addEventListener('onDataChange$', (data) => {
  console.log('Plugin data change', data);
});
