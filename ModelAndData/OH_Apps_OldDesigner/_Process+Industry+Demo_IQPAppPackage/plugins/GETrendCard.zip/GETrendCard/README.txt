TREND CARD
----------

Prerequisites (in PATH):
    node + npm
    Git
    
In command prompt with Admin permissions navigate to this folder and run the following:
    
Set Tools Proxy (on new systems):
    npm config set proxy http://http-proxy.corporate.gtm.ge.com:80/
    git config --global http.proxy http://http-proxy.corporate.gtm.ge.com:80/
    git config --global --unset url."https://".insteadOf git://

Global grunt and bower install:
    npm install grunt-cli bower -g   

Install dependencies:
    npm install
    bower install
    
Build Extensions(into ../dist folder):
    grunt
