/* Welcome to our javascript API
* You have Access to the global object EMBED,
* this object contains Methods:
* @ getData()
* @ onChangeData()
* @ onSingleChangeData()
* @ getRootElement()  - returns jQuery element
* function useData(data) {
*   data = data || EMBED.getData();
*   doSomethingWithData(data);
* }
* useData();
*
* trigger change data for any change
* EMBED.onChangeData(useData);
*
* trigger change data when specific field change (by field name)
* EMBED.onSingleChangeData('fieldName', function(data) {
*   doSomethingWithData(data);
* });
*/
let component=EMBED.getComponent()||{};
const userConfig = (component && component.schema) ? component.schema.data : {};
let rootElement = EMBED.getRootElement();
const { enableFixedBoxModel, isNewEndApp } = EMBED.getElementOptions() || {};
const { disableFixedBoxModel } = EMBED.getElementOptions() || {};
let pluginElement = isNewEndApp ? rootElement : rootElement.parents('.coordinated_container.plug-in-component')
		
let zIndexManager = null;
		
// // EndAppV2 fix
// let pluginElement = rootElement.parents('.coordinated_container.plug-in-component');
// //Old endapp fix
// let pluginV1Elements = rootElement.parents('.coordinated_container');
let eachStackHeight=0;
let mainElement = null;
let mainPageElement = null;
let chartElement = null;
let dataProviderElement = null;
let trendConfigElement = null;
let legendContainerElement = null;
let chartLegendSplitterContainer = null;
let sessionStorageElement = null;
let tabularComponent = null;
let errorIconElement = null;
let configButtonElement = null;
let contextMenuButtonElement = null;
let contextMenuOptionsElement = null;
let enum_contextMenuOptions = null;
let legendButtonElement = null;
let helpButtonElement = null;
let zoomOutButtonElement = null;
let zoomInButtonElement = null;
let zoomButtonElement = null;
let resetZoomButtonElement = null;
let deltaButtonElement = null;
let panButtonElement = null;
let pauseResumeButtonElement = null;
let pauseResumeSectionElement = null;
let zoomModeSelectElement = null;
let chartSelectElement = null;
let trendFavoritesElement = null;

let trendPrintTitleElement = null;
let trendPrintFavoriteTitleElement = null;
let trendChartTitleElement = null;
let buttonBarElement = null;
let trendStatisticsElement = null;
let splitInstance = null;
let localizer = null;
let trendPluginName = null;
let widgets = [];
let statsButtonElement = null;
let shiftChartUpElement = null;
let shiftChartDownElement = null;
let shiftChartLeftElement = null;
let shiftChartRightElement = null;
let headerToggleElement = null;
let headerElement = null;
let headerContainerElement = null;
let defaultSamplingMode = null;
let stackedYaxisHeight = '150px';
let defaultTrendConfigInput = {};
let publishInProgress = false;
let timeChangeTimeout = null;
let changedTimeValues = [];
let prevStatsSplitterSizes = null;
let chartResizeSensor = null;

let ADMIN_USER_GROUP = "webhmi.administrator"; // these users have full favorite access
let TREND_HELP_URL = "https://www.gevernova.com/software/documentation/opshub/windows/windows/c_about_trend_widget.html?";
let DEFAULT_HEIGHT = "400";
let CONTENT_MARGIN = 10;
let PLUGIN_MARGIN = 10;
let BORDER_WIDTH = 1;
let trendDisplayWidgetElementId;
let trendTabularDisplayWidgetElementId;
let displayResizeTimeout = null; // don't call resize rapidly 5x in a row

let equipmentContextSubscribeKey = null,
	favoritesChangeKey = null,
	favoritesReloadedKey = null;
let stackedHeight;
let previouslyLoadedData = {},
	previouslyLoadedTimeData = {},
	userName = null,
	isAdmin = 0,
	restData = null,
	tokenJson = null,
	gotUserData = false,
	portNumber = window.location.port ? ':' + window.location.port : '',
	restDataUrlValue = window.location.origin,
	websocketUrlValue = '/wsdata',
	websocketAlarmUrlValue = '',
	assetNameOverrideValue = null,
	equipmentContextValue = null,
	heightValue = DEFAULT_HEIGHT,
	chartTitleValue = null,
	xAxisLabelValue = null,
	yAxisLabelValue = null,
	timeFormatModeValue="auto",
	customTimeFormatValue="%Y-%m-%d %H:%M:%S",
	tabularViewHeight = DEFAULT_HEIGHT,
	historianTagPageSizeValue = null,
	showTrendValueAxesValue = true,
	showTrendLegendValue = true,
	showStatisticsValue = false,
	showFavoritesValue = true,
	showHeaderValue = true,
	printInProgress = false,
	scrollPercentage = 0.25,
	selFavName = null,
	trendConfigInput = {},
	trendTagsInput = "",
	trendRealtimeDurationInput = null,
	trendHistoricalEndDateTimeInput = null,
	trendHistoricalDurationInput = null,
	trendTypeInput = null,
	lastDisplayedTrendHistoricalDuration = 0,
	lastDisplayedTrendRealtimeDuration = 0,
	lastDisplayedTrendType = null,
	messageBanner = null,
	loggedInUserNameValue = 'GE Opshub User',
	showBorder = true,
	backgroundColor = "#ffffff",
	borderColor = "#bcbcbc",
	publishTimeout = null,
	lastSettingsJsonString="",
	compactViewMode = false,
	tooltipOpacity = 0.8,
	tooltipType = 'shared',
	legendPosition = 'right',
	timeSelectionMode = 'durationEnd';

// UI display text
let noTrendData;
let dataIsFlowing;
let dataNotFlowing;
let showingHistoricalData;
let liveText;
let historicalText;
let pausedText;
let pauseButtonTooltip;
let resumeButtonTooltip;
let hisEventData = false;
let tablularData = [];
let isVisible =false;
let attrProp = [];

let cardLoaded = false;
let trendDisplayWidgetRuntime = null;
let trendConfigWidgetRuntime = null;
let sessionStorageWidgetRuntime = null;
let trendDataProviderWidgetRuntime = null;

let isSafari = false;
let sessionExpiredDialog;
let isMessageBannerVisible;
let isStatisticsPanelVisible;
let isShiftDownButtonVisible;
let isShiftUpButtonVisible;
let isShiftLeftButtonVisible;
let isShiftRightButtonVisible;
let prevChartHeight;
let prevChartWidth;
let currentHeight;
let sessionExpiredDisplayStyle;
let configurePanelOpened;
let trendHeader;
let componentWrapperElement;
let flexContainerElement;
let coordinatedContainer;
let messageBannerElement;
let printHeightUsed;
let chartRestorationTimeAfterPrint;
let defaultChartType = false;
let dataModel;
let historicalDataValues=[];
let durationValues=[];
let pausedData = [], pausedTime;
let modelBasedTags= [];
const  legendValuesMap=new Map();
let socketConnector = null;
let StackedMinimumHeight=25;
let logger = new window.WebHMI.Components.ConsoleLogger();
let aspectRatioEle;

let tabularElement = null
let tableData = null
let bPublished = false
let isFixedBoxModelEnabled = false

window.WebHMI.Components.LogLevels.Trend = logger.LogLevel.Info;

logger.init('TrendChartMain', window.WebHMI.Components.LogLevels.Trend, window.WebHMI.LogSettings.LogWithTimestamps, window.WebHMI.LogSettings.LogWithLogLevelNames);
setLoggingThresholds(window.WebHMI.Components.LogLevels.Trend);

function setLoggingThresholds(logThreshold) {
	// override these to tune logging by component
	window.WebHMI.Components.LogLevels.Trend = logThreshold;
	window.WebHMI.Components.LogLevels.TrendDataProvider = logThreshold;
	window.WebHMI.Components.LogLevels.SessionStorage = logThreshold;
	window.WebHMI.Components.LogLevels.TrendDisplay = logThreshold;
	window.WebHMI.Components.LogLevels.TrendRestData = logThreshold;
	window.WebHMI.Components.LogLevels.TrendDataModel = logThreshold;

	window.WebHMI.Components.LogLevels.TrendDataSubscription = logThreshold;
	window.WebHMI.Components.LogLevels.FavoritesManager = logThreshold;
	window.WebHMI.Components.LogLevels.TrendLegendWidget = logThreshold;
	window.WebHMI.Components.LogLevels.TrendAssetBrowser = logThreshold;
	window.WebHMI.Components.LogLevels.TrendAnnotations = logThreshold;
	window.WebHMI.Components.LogLevels.TrendHistorianSampling = logThreshold;
	window.WebHMI.Components.LogLevels.TrendLineStyleComponent = logThreshold;
	window.WebHMI.Components.LogLevels.TrendSpecLimitComponent = logThreshold;
	window.WebHMI.Components.LogLevels.TrendAxisSpecComponent = logThreshold;
	window.WebHMI.Components.LogLevels.ChartYAxisConfigComponent = logThreshold;

	if (window.WebHMI.Components.DataSeries.logger) {
		window.WebHMI.Components.DataSeries.logger.changeSettings(window.WebHMI.Components.LogLevels.TrendDisplay, window.WebHMI.LogSettings.LogWithTimestamps, window.WebHMI.LogSettings.LogWithLogLevelNames);
	}
	if (window.WebHMI.Components.DataManager.logger) {
		window.WebHMI.Components.DataManager.logger.changeSettings(window.WebHMI.Components.LogLevels.TrendDisplay, window.WebHMI.LogSettings.LogWithTimestamps, window.WebHMI.LogSettings.LogWithLogLevelNames);
	}
	if (window.WebHMI.Components.TrendRESTData.logger) {
		window.WebHMI.Components.TrendRESTData.logger.changeSettings(window.WebHMI.Components.LogLevels.TrendRestData, window.WebHMI.LogSettings.LogWithTimestamps, window.WebHMI.LogSettings.LogWithLogLevelNames);
	}
}

function getSelectedAssetName() {
	return assetNameOverrideValue || equipmentContextValue || window.WebHMI.Components.AssetInitialName;
}

function getToken() {
	restData.getToken(function (tokenObj) {
		tokenJson = tokenObj;
		restData.getUserInfo(function (userData) {
			if(userData && userData.hasOwnProperty('status')) {
				if(userData.status.hasOwnProperty('username')) {
					userName = userData.status.username;
				} else if(userData.result && userData.result.length>0) {
					userName = userData.result[0].username;
				}
				if(userData.user_groups) {
					let currentUserGroups = userData.user_groups;
					let webhmiAdminGroup = currentUserGroups.find(function (grp) {
						return grp.display===ADMIN_USER_GROUP;
					});
					if(webhmiAdminGroup) {
						isAdmin = 1;
					}
				}
			}
			gotUserData = true;

			if (typeof _geidx !== "undefined") {
				if (!_geidx()) {
					return;
				}
			}

			loadTrendCard();
		}, function (error) {
			console.log("getUserInfo: error: %O", error);
		});
	}, function (errorJson) {
		console.log("getToken: error: %O", errorJson);
	});
}

function logValuePublish(sourceWidget, sourceProperty, targetWidgetProperty, value) {
	// TODO: change to Debug before release
	logger.log(logger.LogLevel.Info, 0, "logValuePublish: Forwarding %s.%s to %s: %O", sourceWidget, sourceProperty, targetWidgetProperty, value);
}

function handleConnectionError() {
	let error = dataModel.getSocketConnectionError();
	if (error !== undefined) {
		// only for live mode
		if ((dataModel.getTrendType() == window.WebHMI.Components.TrendType.realtime)) {
			jQuery(errorIconElement).removeClass('hidden');
			logger.log(logger.LogLevel.Warning, 0, 'Warning: connection error: %s', error.description);
		}
	} else {
		jQuery(errorIconElement).addClass('hidden');
	}
}

function setCardHeight() {
	let thisCard = jQuery(mainElement)[0];
	const pluginOptions = EMBED.getElementOptions();
	// height
	let duplicateHeight;
	let targetHeight = heightValue || DEFAULT_HEIGHT;

	let usingContainerBasedHeight = (jQuery(thisCard).closest(".component-container.container-based-height").length > 0);
	if (usingContainerBasedHeight) {
		let pluginContainer = jQuery(thisCard).closest(".component-container");
		if (pluginContainer) {
			targetHeight = pluginContainer.height() - CONTENT_MARGIN - 2 * PLUGIN_MARGIN - BORDER_WIDTH;
			jQuery(thisCard).height(targetHeight);
			duplicateHeight = targetHeight;
		}
	} else if(pluginOptions.isClassicApp){
		// fixed pixel height
		if (targetHeight.indexOf("%") < 0) {
			let heightVal = parseInt(targetHeight);
			if (isNaN(heightVal)) {
				heightVal = parseInt(DEFAULT_HEIGHT);
			}
			jQuery(thisCard).height(heightVal);
			duplicateHeight = heightVal;
		} else {
			// percentage height

			let pageElementHeight;
			let breadCrumbHeight = 0;
			if(element && element.parents('.coordinated_container.plug-in-component') && element.parents('.coordinated_container.plug-in-component').length) {
				pageElementHeight = element.parents('.coordinated_container.plug-in-component').height();
			}else{
				let pageElement = jQuery('.main-page')[0];
				pageElementHeight = jQuery(pageElement).height();

				// Check for breadcrumb, if present, subtract its height from the available height
				let breadCrumbElement = jQuery('div.geBreadcrumb');
				if (breadCrumbElement.length > 0) {
					breadCrumbHeight = jQuery(breadCrumbElement[0]).height();
				}
			}


			// subtract page elements to get available height, calculate percentage, then subtract plugin margins
			// subtract margins last to properly calculate height on pages with multiple charts
			let availHeight = pageElementHeight - CONTENT_MARGIN - breadCrumbHeight;
			let percentageStr = targetHeight.substring(0, targetHeight.indexOf('%'));
			let percentageVal = parseInt(percentageStr);
			let newHeight = Math.floor(availHeight * percentageVal / 100) - 2 * PLUGIN_MARGIN;
			jQuery(thisCard).height(newHeight);
			duplicateHeight = newHeight;
		}
		//stackedHeight
		//trendAvailHeight has the available chart loading space height
		let pageElement = jQuery('.main-page')[0];
			let pageElementHeight = jQuery(pageElement).height();
			let breadCrumbHeight = 0;
			let breadCrumbElement = jQuery('div.geBreadcrumb');
			if (breadCrumbElement.length > 0) {
				breadCrumbHeight = jQuery(breadCrumbElement[0]).height();
			}
		let availHeight = pageElementHeight - CONTENT_MARGIN - breadCrumbHeight;
		 let trendAvailHeight = $('#chart-' + trendDisplayWidgetElementId).css('height');
		if(stackedHeight!==undefined && stackedHeight!==null && stackedHeight!='')
		{
			stackedHeight=stackedHeight.toString();
			if ( stackedHeight.indexOf("%") < 0) {
				stackedHeight = parseInt(stackedHeight);
				if (isNaN(stackedHeight)) {
					//default case with no input setting it to 30%
					stackedHeight = Math.floor(parseInt(trendAvailHeight) * (0.3)) - 2 * PLUGIN_MARGIN;
					//stackedHeight = parseInt(DEFAULT_HEIGHT);
				}
			} else {

				// percentage height
				let pageElement = jQuery('.main-page')[0];
				let pageElementHeight = jQuery(pageElement).height();

				// Check for breadcrumb, if present, subtract its height from the available height
				let breadCrumbHeight = 0;
				let breadCrumbElement = jQuery('div.geBreadcrumb');
				if (breadCrumbElement.length > 0) {
					breadCrumbHeight = jQuery(breadCrumbElement[0]).height();
				}

				// subtract page elements to get available height, calculate percentage, then subtract plugin margins
				// subtract margins last to properly calculate height on pages with multiple charts
				let availHeight = pageElementHeight - CONTENT_MARGIN - breadCrumbHeight;
				let percentageStr = targetHeight.substring(0, targetHeight.indexOf('%'));
				let percentageVal = parseInt(percentageStr);
				let newHeight = Math.floor(availHeight * percentageVal / 100) - 2 * PLUGIN_MARGIN;
				jQuery(thisCard).height(newHeight);

				duplicateHeight = newHeight;
				//let trendAvailHeight1 = $('#chart-' + trendDisplayWidgetElementId).css('height');
				let trendAvailHeight1 = jQuery(chartElement).height()

				let help_stackheight01 = Math.floor(parseInt(trendAvailHeight1) * (parseInt(stackedHeight) / 100)) - 2 * PLUGIN_MARGIN;
				stackedHeight = help_stackheight01;
			}
		}
		else{

			let trendAvailHeight1 = jQuery(chartElement).height()
			stackedHeight = Math.floor(parseInt(trendAvailHeight1) * (0.3)) - 2 * PLUGIN_MARGIN;

		}
		if(stackedHeight!== undefined){
			dataModel.setStackChartHeight(stackedHeight);
		}

	}
	//set Height of Stack container
	let trendAvailHeight = jQuery(chartElement).height()
	let stackedTotalHeight = Math.round((parseInt(trendAvailHeight)* (0.89))  -   2 * PLUGIN_MARGIN);
	if(dataModel)
	{
		dataModel.setStackedDisplayAreaHeight(stackedTotalHeight);
	}

	setTimeout(()=>{
		updateStackedChart();
	}, 250);
}

function getWidgetId() {
	return (new Date()).getTime();
}

function updateStackedChart()
{
	if(!trendDisplayWidgetRuntime) return;

	let trendAvailHeight = jQuery(chartElement).height()
	let stackedTotalHeight = Math.round((parseInt(trendAvailHeight)* (0.89))  -   2 * PLUGIN_MARGIN);
	
	const totalChartSeries=	trendDisplayWidgetRuntime.getChartSeries().filter((tag)=>{return  tag.visible && tag.userOptions&&!tag.userOptions.isStackedSpecLimit;}).length;
	eachStackHeight=Math.round((stackedTotalHeight-(totalChartSeries*13))/totalChartSeries);
	eachStackHeight=Math.max(StackedMinimumHeight,eachStackHeight);
	const updateHeight=eachStackHeight+"px";
	
	if(dataModel && totalChartSeries>0)
	{
		dataModel.setStackedDisplayAreaHeight(stackedTotalHeight);
		dataModel.setStackChartHeight(updateHeight,true);

		trendDisplayWidgetRuntime.redrawStackedAxesSoon();
	}			
}

function toggleSeries(property) {
	let allProps = dataModel.getAllPropertiesWithAttributes();

	let propertyName = property.name || property.propertyName || null;
	let propertyAsset = property.assetName || null;
	let propertySamplingMode = property.samplingMode || null;

	let assetProps = allProps[propertyAsset] ? allProps[propertyAsset].properties : [];
	let propFound = false;
	for(let i=0;i<assetProps.length;i++){
		let assetProp = assetProps[i];
		if(propertyMatchCheck(propertyName, null, propertySamplingMode, assetProp)){
			assetProp.visible = !assetProp.visible;
			propFound = true;
			break;
		}
	}
	if(propFound) {
		dataModel.setTrendingPropertiesByAsset(allProps[propertyAsset], true);
		dataModel.updatePropertyVisibilityInBrowsedList(propertyAsset);
	}
}

function showLegend() {
	jQuery(chartLegendSplitterContainer).removeClass('legendHidden');

	jQuery(legendButtonElement).removeClass('ge-icon-less');
	jQuery(legendButtonElement).addClass('ge-icon-greater');
	legendButtonElement.setAttribute('title', localizer.translate('Hide Legend'));
	let legendComponent = jQuery(legendContainerElement).find('trend-chart-legend')[0];
	//set callback
	legendComponent.initialize((property) => { removePropertyFromChart(property); });
	legendComponent.toggleSeries((property) => { toggleSeries(property); });
	legendComponent.redraw();
	showTrendLegendValue = true;
}

function hideLegend() {
	jQuery(chartLegendSplitterContainer).addClass('legendHidden');

	jQuery(legendButtonElement).removeClass('ge-icon-greater');
	jQuery(legendButtonElement).addClass('ge-icon-less');
	legendButtonElement.setAttribute('title', localizer.translate('Show Legend'));
	showTrendLegendValue = false;
}

function showStatistics() {
	jQuery(trendStatisticsElement).removeClass('hidden');
	jQuery(statsButtonElement).addClass('selected');
	statsButtonElement.setAttribute('title', localizer.translate('Hide Statistics'));
	trendDataProviderWidgetRuntime.startStatisticsPolling();
	tabularComponent.setAttribute('statisticsupdate', true);

	showStatisticsValue = true;
	recreateStatsSplitter();
}

function destroyStatsSplitter() {
	if (splitInstance) {
		prevStatsSplitterSizes = splitInstance.getSizes(); // save for recreation
		splitInstance.destroy();
		splitInstance = null;
	}
	if (chartSelectElement.value === "trend") {
		setCardHeight();
	}
}
function recreateStatsSplitter() {
	if(!showStatisticsValue) return;

	destroyStatsSplitter();

	if(!prevStatsSplitterSizes) prevStatsSplitterSizes = [87.2, 12.8];
	if (chartSelectElement.value === "tabular") {
		if (trendStatisticsElement && tabularElement) {
			splitInstance = Split([tabularElement,trendStatisticsElement], {
				direction: 'vertical',
				sizes: prevStatsSplitterSizes,
				dragInterval: 20,
			});

			setCardHeight();
		} else {
			console.error('One or both elements not found');
		}
	} else {
		if (trendStatisticsElement && chartElement) {
			splitInstance = Split([chartElement,trendStatisticsElement], {
				direction: 'vertical',
				sizes: prevStatsSplitterSizes,
				dragInterval: 20
			});
			if(trendDisplayWidgetRuntime) {
				trendDisplayWidgetRuntime.resize(jQuery(chartElement).outerWidth(), jQuery(chartElement).outerHeight());
			}

			setCardHeight();
		} else {
			console.error('One or both elements not found');
		}
	}
}

function hideStatistics() {
	jQuery(trendStatisticsElement).addClass('hidden');
	jQuery(statsButtonElement).removeClass('selected');
	statsButtonElement.setAttribute('title', localizer.translate('Show Statistics'));
	trendDataProviderWidgetRuntime.stopStatisticsPolling();
	showStatisticsValue = false;
	tabularComponent.setAttribute('statisticsupdate', true);

	destroyStatsSplitter();

	if (chartSelectElement.value !== "tabular") {
		let w = jQuery(chartElement).outerWidth(),
			h = jQuery(chartElement).outerHeight();
		trendDisplayWidgetRuntime.resize(w, h);
	}
	setCardHeight();
}

function showContextMenu() {
	let contextMenuButtonPosition = jQuery(contextMenuButtonElement).position();
	let contextMenuButtonWidth = jQuery(contextMenuButtonElement).width();
	let contextMenuButtonHeight = jQuery(contextMenuButtonElement).height();
	jQuery(contextMenuOptionsElement).css('top', contextMenuButtonPosition.top + contextMenuButtonHeight + 5 + 'px');
	jQuery(contextMenuOptionsElement).css('left', contextMenuButtonPosition.left - jQuery(contextMenuOptionsElement).width() + contextMenuButtonWidth + 15 + 'px');

	jQuery(contextMenuOptionsElement).removeClass('hidden');
	jQuery(contextMenuButtonElement).addClass('selected');
}

function hideContextMenu() {
	jQuery(contextMenuOptionsElement).addClass('hidden');
	jQuery(contextMenuButtonElement).removeClass('selected');
}

function safeEnableFixedBoxModel() {
	if (enableFixedBoxModel && !isFixedBoxModelEnabled) {
		enableFixedBoxModel('trendCard');
		isFixedBoxModelEnabled = true;
	}
}
function safeDisableFixedBoxModel() {
	if (disableFixedBoxModel && isFixedBoxModelEnabled) {
		disableFixedBoxModel('trendCard');
		isFixedBoxModelEnabled = false;
	}
}

function setShiftButtonsStates(showButtons) {
	setShiftButtonVisibility(shiftChartUpElement, showButtons);
	setShiftButtonVisibility(shiftChartDownElement, showButtons);
	setShiftButtonVisibility(shiftChartLeftElement, showButtons);
	setShiftButtonVisibility(shiftChartRightElement, showButtons);
}

function setShiftButtonVisibility(buttonElement, visible) {
	if (visible) {
		jQuery(buttonElement).removeClass('hidden');
	}
	else {
		jQuery(buttonElement).addClass('hidden');
	}
}

/**
 * Restore visibility of the header controls (favorites, title, menu bar)
 */
function showHeader() {
	jQuery(headerElement).removeClass('hidden');
	jQuery(headerToggleElement).removeClass('ge-icon-down-arrow');
	jQuery(headerToggleElement).addClass('ge-icon-up-arrow');
	jQuery(headerContainerElement).removeClass('collapsed');
	jQuery(headerContainerElement).addClass('expanded');
	headerToggleElement.setAttribute('title', localizer.translate('Hide Controls'));
	showHeaderValue = true;
	updateTitleDisplay();
	let shiftChartUpDownDiv = mainElement.find('.shift-up-down-div')[0];
    if (shiftChartUpDownDiv) {
        shiftChartUpDownDiv.style.top = "50px";
    }
}
/**
 * Collapse the header controls (favorites, title, menu bar)
 */
function hideHeader() {
	jQuery(headerElement).addClass('hidden');
	jQuery(headerToggleElement).removeClass('ge-icon-up-arrow');
	jQuery(headerToggleElement).addClass('ge-icon-down-arrow');
	jQuery(headerContainerElement).addClass('collapsed');
	jQuery(headerContainerElement).removeClass('expanded');
	headerToggleElement.setAttribute('title', localizer.translate('Show Controls'));
	showHeaderValue = false;
	updateTitleDisplay();
	let shiftChartUpDownDiv = mainElement.find('.shift-up-down-div')[0];
    if (shiftChartUpDownDiv) {
        shiftChartUpDownDiv.style.top = "0px";
    }
}

function loadTrendCard() {
	let preferredLanguage = localizer.getPreferredLocale();
	let uniqueId = getWidgetId();
	trendPluginName = "trend-card-" + uniqueId;
	trendDisplayWidgetElementId = "geTrendCardHolder-" + uniqueId;
	trendTabularDisplayWidgetElementId = "geTrendTabularContainer-" + uniqueId;
	let trendHelpButtonElementId = "geTrendHelp-" + uniqueId;
	let trendLegendElementId = 'geTrendChartLegend-' + uniqueId;
	let trendConfigElementId = "geTrendConfig-" + uniqueId;
	let trendSessionStorageElementId = "geTrendSessionStorage-" + uniqueId;
	let trendDataProviderElementId = "geTrendDataProvider-" + uniqueId;
	let trendErrorIconElementId = "geTrendPropertyErrorIcon-" + uniqueId;
	let trendContextMenuOptionsElementId = "geContextMenuOptions" + uniqueId;
	let trendFavoritesElementId = "geTrendFavorites" + uniqueId;
	let trendChartTitleElementId = "geTrendChartTitle" + uniqueId;
	let trendButtonBarContainerId = "geTrendButtonBarContainer" + uniqueId;
	let trendPrintTitleElementId = "geTrendTitle" + uniqueId;
	let trendPrintFavoriteTitleElementId = "geTrendPrintFavoriteTitle" + uniqueId;
	let trendStatisticsElementId = "getTrendStatistics" + uniqueId;

	let trendContextMenuButtonElementId = "geContextMenu-" + uniqueId;
	let trendCfgButtonElementId = "geTrendPropertyCfgButtonHolder-" + uniqueId;
	let trendButtonBarId = "geTrendButtonBar-" + uniqueId;
	let trendLegendButtonElementId = "geTrendChartLegendButtonHolder-" + uniqueId;
	let trendDeltaButtonId = "geTrendDeltaButton" + uniqueId;
	let trendPanButtonId = "geTrendPanButton" + uniqueId;
	let trendPauseResumeButtonId = "geTrendPauseResumeButton" + uniqueId;
	let trendPauseResumeSectionId = "geTrendPauseResumeSection" + uniqueId;
	let trendZoomButtonId = "geTrendZoomButton" + uniqueId;
	let trendZoomModeSelectId = "geTrendZoomModeSelect" + uniqueId;
	let trendChartTypeId = "geTrendChartType" + uniqueId;

	let trendResetZoomButtonId = "geTrendResetZoomButton" + uniqueId;
	let trendZoomInButtonId = "geTrendZoomInButton" + uniqueId;
	let trendZoomOutButtonId = "trendZoomOutButton" + uniqueId;
	let trendStatsButtonId = "trendStatsButton" + uniqueId;
	let shiftChartLeftId = "shiftChartLeftButton" + uniqueId;
	let shiftChartRightId = "shiftChartRightButton" + uniqueId;
	let shiftChartUpId = "shiftChartUpButton" + uniqueId;
	let shiftChartDownId = "shiftChartDownButton" + uniqueId;
	let headerToggleId = "headerToggle" + uniqueId;
	let html = '<div id="' + trendConfigElementId + '" class="hidden config-popup"></div>';
	html += '<div id="messageBanner"></div>';
	html = html + '<div class="shift-up-down-div">';
	html = html + '<div id="' + shiftChartUpId + '" style="padding-left: 0px" class="config-button geip-icon-ico_arrow-up_lg hidden" title="' + localizer.translate('Shift Up') + '"></div>';
	html = html + '<div id="' + shiftChartDownId + '" style="padding-left: 0px" class="config-button geip-icon-ico_arrow-down_lg hidden" title="' + localizer.translate('Shift Down') + '"></div>';
	html = html + '</div>';

	let chartContainerHtml = 
		'<div class="trend-container">' +
			'<div id="' + trendPrintTitleElementId + '" class="trend-title inspiraFont"></div>' +
			'<div id="' + trendPrintFavoriteTitleElementId + '" class="trend-title inspiraFont"></div>' +
			'<div class="trend-header-container expanded" style="display:flex">' +
				'<div id="' + headerToggleId + '" class="trend-header-toggle-button ge-icon-up-arrow" rel="tooltip" title="' + localizer.translate('Hide Controls') + '"></div>' + 
				'<div id="trendAltTitle" class="trend-header-title-alt">' + chartTitleValue + '</div>'+
				'<div class="trend-header">' +
					'<span class="trend-header-favorites trend-header-content">' +
						'<div id="' + trendFavoritesElementId + '" class="favorites-manager-container' + (showFavoritesValue ? '' : ' hidden') + '"><favorites-manager username="'+userName+'" isadmin='+isAdmin+' language=' + preferredLanguage + ' timeSelectionMode=' + timeSelectionMode + '></favorites-manager></div>' +
					'</span>' +
					'<span id="' + trendChartTitleElementId + '" class="trend-header-title trend-header-content' + ( chartTitleValue ? '' : ' hidden' ) + '">' +
						'<div class="header-title-text">' + chartTitleValue + '</div>' +
					'</span>' +
					'<div id="' + trendButtonBarContainerId + '" class="trend-header-buttonbar-settings-container">' +
						'<span class="trend-header-settings trend-header-content">' +
							'<div class="trend-header-setting-icons">' +
								'<div class="header-setting-text" title="' + dataIsFlowing + '">' + liveText + '</div>' +
							'</div>' +
							'<div class="trend-header-setting-time"></div>' +
						'</span>' +
						'<span id="' + trendButtonBarId + '" class="trend-button-bar trend-header-content">' +
							'<div class="bannerIcon expanded hidden"><span class="messageIcon fa fa-exclamation-circle"></span></div>' +
							'<div id="' + trendErrorIconElementId + '" class="error-icon geip-icon-disconnected hidden"></div>' +
							'<div id="' + trendPauseResumeSectionId + '" class="trend-button-bar-section">' +
								'<div id="' + trendPauseResumeButtonId + '" class="config-button ge-icon-pause disabled" rel="tooltip" title="' + localizer.translate('Pause Trending') + '"></div>' +
							'</div>' +
							'<div class="trend-button-bar-section">' +
								'<div id="' + trendDeltaButtonId + '" class="config-button ge-icon-delta " rel="tooltip" title="' + localizer.translate('Delta') + '"></div>' +
							'</div>' +
							'<div class="trend-button-bar-section">' +
								'<div id="' + trendPanButtonId + '" class="config-button ge-icon-arrows disabled" rel="tooltip" title="' + localizer.translate('Pan Mode') + '"></div>' +
								'<div id="' + trendZoomButtonId + '" class="config-button ge-icon-zoom selected" rel="tooltip" title="' + localizer.translate('Zoom Mode') + '"></div>' +
								'<div id="' + trendResetZoomButtonId + '" class="config-button ge-icon-undo hide" rel="tooltip" title="' + localizer.translate('Reset Zoom mode and Pan mode') + '"></div>' +
							'</div>' +
							'<div class="trend-button-bar-section">' +
								'<div style="margin-left: 10px"><vaadin-select id="' + trendZoomModeSelectId + '" class="config-select inspiraFont new-zoom-type" theme="trend-card trend-card-button-bar" rel="tooltip" title="' + localizer.translate('Select Zoom Type') + '">' +
									'<template><vaadin-list-box theme="trend-card">' +
										'<vaadin-item theme="trend-card" class="x-item" value="x">X</vaadin-item>' +
										'<vaadin-item theme="trend-card" class="y-item" value="y">Y</vaadin-item>' +
										'<vaadin-item theme="trend-card" class="xy-item" value="xy">XY</vaadin-item>' +
									'</vaadin-list-box></template>' +
								'</vaadin-select></div>' +
							'</div>' +
							'<div class="trend-button-bar-section" id="zoom-buttons">' +
								'<div id="' + trendZoomInButtonId + '" class="config-button ge-icon-plus" rel="tooltip" title="' + localizer.translate('Zoom In') + '"></div>' +
								'<div id="' + trendZoomOutButtonId + '" class="config-button ge-icon-minus" rel="tooltip" title="' + localizer.translate('Zoom Out') + '"></div>' +
							'</div>' +
							'<div class="trend-button-bar-section">' +
								'<div id="' + trendStatsButtonId + '" class="config-button ge-icon-stats" rel="tooltip" title="' + localizer.translate('Show Statistics') + '"></div>' +
								'<div id="' + trendCfgButtonElementId + '" class="config-button geip-icon-config" rel="tooltip" title="' + localizer.translate('Configuration') + '"></div>' +
								'<vaadin-select style="width:48px;margin-top:-3px;" id="' + trendChartTypeId + '" class="config-select config-button inspiraFont new-chart-type" theme="top-styling trend-switch trend-card trend-card-button-bar" rel="tooltip" title="' + localizer.translate('SELECT CHART TYPE') + '">' +
									'<template><vaadin-list-box theme="trend-card">' +
										'<vaadin-item theme="trend-card" value="stacked"><svg style="width: 20px;vertical-align:middle; padding-right:13px" xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1" viewBox="0 0 16 20"><path d="M0,0H1V16H0ZM7,16H8V14H7ZM3,16H4V14H3Zm12-2v2h1V14Zm-4,2h1V14H11Zm.48-14L8.71,6.75,5.67,2H4.49l3.65,5.7L6.19,11.06H7.35l5.29-9H11.48Z"/></svg>'+localizer.translate("Stacked Y-Axis")+ ' </vaadin-item>' +
										'<vaadin-item theme="trend-card" value="trend"><svg style="width:20px;vertical-align:middle; padding-right:13px" xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1" viewBox="0 0 16 20"><path d="M1.5,14.5V.5H.5V15a.5.5,0,0,0,.5.5H15.5v-1Zm8.92-7.28A.49.49,0,0,0,11,7.08l4-4.7-.76-.64L10.48,6.15,6.86,4.54a.51.51,0,0,0-.56.11l-4,4.12.72.7L6.78,5.6Zm1,3.74a.49.49,0,0,1-.58.14L7.2,9.48l-2.91,3H14.5V7.31Zm3.2-5.34a.5.5,0,0,1,.88.32V13a.5.5,0,0,1-.5.5H3.12a.5.5,0,0,1-.36-.85l4-4.12a.51.51,0,0,1,.56-.11L10.9,10Z"/></svg>'+localizer.translate("Trend Card")+ '</vaadin-item>' +
										'<vaadin-item theme="trend-card" value="tabular"><svg style="width: 20px;vertical-align:middle; padding-right:13px" xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1" viewBox="0 0 16 20"><path d="M0,1V15H16V1ZM1,6H4.5V9.8H1ZM5.5,6H15V9.8H5.5ZM15,2V5H1V2ZM1,10.8H4.5V14H1ZM5.5,14V10.8H15V14Z"/></svg>' +localizer.translate("Tabular View") +'</vaadin-item>' +
									'</vaadin-list-box></template>' +
								'</vaadin-select>' +
								'<div id="' + trendContextMenuButtonElementId + '" class="config-button geip-icon-more" rel="tooltip" title="' + localizer.translate('More') + '"></div>' +
							'</div>' +
							'<div class="trend-button-bar-section">' +
								'<div id="' + trendHelpButtonElementId + '" rel="tooltip" title="' + localizer.translate('Help') + '"></div>' +
							'</div>' +
							'<div class="trend-button-bar-section">' +
								'<div id="' + trendLegendButtonElementId + '" class="config-button ge-icon-less" rel="tooltip" title="' + localizer.translate('Show Legend') + '"></div>' +
							'</div>' +
							'<div id="' + trendContextMenuOptionsElementId + '" class="hidden config-contextmenu"></div>' +
						'</span>' +
					'</div>' +
				'</div>' +
				'<div class="bannerIcon collapsed hidden"><span class="messageIcon fa fa-exclamation-circle"></span></div>' +
			'</div>' +
			'<trend-tabular-view language=' + preferredLanguage + ' id="' + trendTabularDisplayWidgetElementId + '" class="trend-tabular-view"></trend-tabular-view>' +
			'<div id="' + trendDisplayWidgetElementId + '" class="trend-chart-container"></div>' +
			'<div class="shift-left-right-div">' +
				'<div id="' + shiftChartLeftId + '" class="config-button geip-icon-ico_arrow-left_lg hidden" title="' + localizer.translate('Shift Left') + '"></div>' +
				'<div id="' + shiftChartRightId + '" class="config-button geip-icon-ico_arrow-right_lg hidden" title="' + localizer.translate('Shift Right') + '"></div>' +
			'</div>' +
			'<div id="' + trendStatisticsElementId + '" class="hidden trend-statistics-container">' +
				'<trend-statistics language=' + preferredLanguage + '></trend-statistics>' +
			'</div>' +
		'</div>';

	let legendHtml = 
		'<div id="' + trendLegendElementId + '" class="trend-legend-container">' +
			'<div class="header">' +
				'<div class="title">' + localizer.translate('Legend') + '</div>' +
			'</div>' +
			'<div class="trend-legend-content">' +
				'<trend-chart-legend language="' + preferredLanguage + '" layout="'+(legendPosition==='bottom'?'horizontal':'vertical')+'">'+
				'</trend-chart-legend>' +
			'</div>' +
		'</div>';
	
	// legend on right or bottom
	if(legendPosition==="bottom") {
		html = html + 
			'<div id="legendSplitter" class="vertical split legendHidden" style="width:100%;height:100%;">' +
				'<div id="splitter-chart" >'+chartContainerHtml+'</div>'+
				'<div id="splitter-legend" >'+legendHtml+'</div>'+
			'</div>';
	} else {
		html = html + 
			'<div id="legendSplitter" class="horizontal split legendHidden" style="width:100%;height:100%;">' +
				'<div id="splitter-chart" >'+chartContainerHtml+'</div>'+
				'<div id="splitter-legend" >'+legendHtml+'</div>'+
			'</div>';
	}
	
	html = html + '<div id="' + trendDataProviderElementId + '"></div>';
	html = html + '<div id="' + trendSessionStorageElementId + '"></div>';
	jQuery(mainElement).html(html);
	jQuery(mainElement).prop('id', trendPluginName);
	jQuery('#'+trendChartTypeId).attr('value', "trend")
	jQuery('.new-zoom-type').attr('value', "x")

	if(legendPosition==="bottom") {
		Split([mainElement.find('#splitter-chart')[0], mainElement.find('#splitter-legend')[0]], {
			direction: 'vertical',
			sizes: [75, 25],
			dragInterval: 20,
		});
	} else {
		Split([mainElement.find('#splitter-chart')[0], mainElement.find('#splitter-legend')[0]], {
			direction: 'horizontal',
			sizes: [75, 25],
			dragInterval: 20,
		});
	}

	trendPrintTitleElement = mainElement.find('#' + trendPrintTitleElementId)[0];
	trendPrintFavoriteTitleElement = mainElement.find('#' + trendPrintFavoriteTitleElementId)[0];
	chartElement = mainElement.find('#' + trendDisplayWidgetElementId)[0];
	tabularElement = mainElement.find('#' + trendTabularDisplayWidgetElementId)[0];
	dataProviderElement = mainElement.find('#' + trendDataProviderElementId)[0];
	trendConfigElement = mainElement.find('#' + trendConfigElementId)[0];
	legendContainerElement = mainElement.find('#' + trendLegendElementId)[0];
	chartLegendSplitterContainer = mainElement.find('#legendSplitter')[0];
	sessionStorageElement = mainElement.find('#' + trendSessionStorageElementId)[0];
	errorIconElement = mainElement.find('#' + trendErrorIconElementId)[0];
	configButtonElement = mainElement.find('#' + trendCfgButtonElementId)[0];
	legendButtonElement = mainElement.find('#' + trendLegendButtonElementId)[0];
	helpButtonElement = mainElement.find('#' + trendHelpButtonElementId)[0];
	contextMenuButtonElement = mainElement.find('#' + trendContextMenuButtonElementId)[0];
	contextMenuOptionsElement = mainElement.find('#' + trendContextMenuOptionsElementId)[0];
	trendFavoritesElement = mainElement.find('#' + trendFavoritesElementId)[0];
	trendChartTitleElement = mainElement.find('#' + trendChartTitleElementId)[0];
	buttonBarElement = mainElement.find('#' + trendButtonBarId)[0];
	trendStatisticsElement = mainElement.find('#' + trendStatisticsElementId)[0];
	zoomOutButtonElement = mainElement.find('#' + trendZoomOutButtonId)[0];
	zoomInButtonElement = mainElement.find('#' + trendZoomInButtonId)[0];
	zoomButtonElement = mainElement.find('#' + trendZoomButtonId)[0];
	resetZoomButtonElement = mainElement.find('#' + trendResetZoomButtonId)[0];
	deltaButtonElement = mainElement.find('#' + trendDeltaButtonId)[0];
	panButtonElement = mainElement.find('#' + trendPanButtonId)[0];
	pauseResumeButtonElement = mainElement.find('#' + trendPauseResumeButtonId)[0];
	pauseResumeSectionElement = mainElement.find('#' + trendPauseResumeSectionId)[0];
	zoomModeSelectElement = mainElement.find('#' + trendZoomModeSelectId)[0];
	chartSelectElement = mainElement.find('#' + trendChartTypeId)[0];
	statsButtonElement = mainElement.find('#' + trendStatsButtonId)[0];
	shiftChartUpElement = mainElement.find('#' + shiftChartUpId)[0];
	shiftChartDownElement = mainElement.find('#' + shiftChartDownId)[0];
	shiftChartLeftElement = mainElement.find('#' + shiftChartLeftId)[0];
	shiftChartRightElement = mainElement.find('#' + shiftChartRightId)[0];
	headerToggleElement = mainElement.find('#' + headerToggleId)[0];
	headerElement = mainElement.find('.trend-header')[0];
	headerContainerElement = mainElement.find('.trend-header-container')[0];
	let manualHorizontalPanControls = mainElement.find('.shift-left-right-div')[0];
	let shiftChartUpDownDiv = mainElement.find('.shift-up-down-div')[0];
	tabularComponent = jQuery(mainElement).find('trend-tabular-view')[0];
	//tabularComponent.hidden = true;
	$(tabularComponent).hide();
	$(chartElement).show();
	//styling
	let thisCard = jQuery(mainElement)[0];
	jQuery(thisCard).css("background-color", backgroundColor);
	jQuery(legendContainerElement).css("background-color", backgroundColor);
	if (showBorder) {
		jQuery(thisCard).css("border", '1px solid ' + borderColor);
		jQuery(legendContainerElement).css("border", '1px ' + borderColor);
		jQuery(legendContainerElement).css("border-left-style", 'solid');
	} else {
		jQuery(thisCard).css("border", 'none');
		jQuery(legendContainerElement).css("border-left-style", 'none');
	}
	//adding chart title attriute value dynamically to avoid issues due to special characters
	jQuery(trendChartTitleElement).attr("title", chartTitleValue);

	// Hide/Show Manual Horizontal Pan Controls
	if(compactViewMode) {
		jQuery(manualHorizontalPanControls).addClass('hidden');
		jQuery(mainElement).addClass('compact');
		jQuery(headerContainerElement).addClass('compact');
	} else {
		jQuery(manualHorizontalPanControls).removeClass('hidden');
		jQuery(mainElement).removeClass('compact');
		jQuery(headerContainerElement).removeClass('compact');
	}

	zIndexManager = new window.WebHMI.Components.PluginZIndexManager(mainElement);
	
	dataModel = new window.WebHMI.Components.TrendDataModel({});
    dataModel.setStackedMinimumHeight(StackedMinimumHeight);
	addDataModelListeners();

	dataModel.setTrendUniqueId(uniqueId);
	if (defaultSamplingMode) {
		dataModel.setDefaultSamplingMode(defaultSamplingMode);
	}

	// initial time settings
	if(trendRealtimeDurationInput !== null) {
		let durationNumber = parseInt(trendRealtimeDurationInput);
		if(!isNaN(durationNumber) && durationNumber>0) {
			dataModel.removeUncommittedValue('realtimeDuration');
			dataModel.removeUncommittedValue('timeNowToggle');
			dataModel.setRealtimeDuration(durationNumber);
		}
	}
	if(trendHistoricalEndDateTimeInput !==null && trendHistoricalEndDateTimeInput !=="") {
		let endDateObj = new Date(trendHistoricalEndDateTimeInput);
		dataModel.removeUncommittedValue('historicalEndTime');
		dataModel.removeUncommittedValue('timeNowToggle');
		dataModel.setTimeNowToggleValue(false);
		dataModel.setHistoricalEndTime(endDateObj);
	}
	if(trendHistoricalDurationInput !== null) {
		let durationNumber = parseInt(trendHistoricalDurationInput);
		if(!isNaN(durationNumber) && durationNumber>0) {
			dataModel.removeUncommittedValue('historicalDuration');
			dataModel.setHistoricalDuration(durationNumber);
		}
	}
	if(trendTypeInput !== null && trendTypeInput !== "") {
		let inputVal = trendTypeInput.toLowerCase();
		if(inputVal==="realtime" || inputVal==="historical") {
			trendTypeInput = inputVal;
			dataModel.removeUncommittedValue('trendType');
			dataModel.setTrendType(trendTypeInput);
		}
	}

	socketConnector = window.socketConnector_geWebHmiCore.getInstance(websocketUrlValue, websocketAlarmUrlValue);
	socketConnector.setSessionJsonWebToken(tokenJson.access_token);

	let helpButton = new window.WebHMI.Components.helpButton();
	helpButton.createHelpButton(helpButtonElement, {
		helpUrl: TREND_HELP_URL
	});

	// Initialize message banner
	messageBanner = new window.WebHMI.Components.messageBanner();
	messageBanner.createMessageBanner(mainElement.find("#messageBanner"), {});
	let messageIconElement = mainElement.find(".bannerIcon");

	trendDataProviderWidgetRuntime = new window.WebHMI.Widgets.trendDataProvider(trendDataProviderElementId, dataModel, messageBanner, restData, socketConnector, window.WebHMI.Components.LogLevels.TrendDataProvider, window.WebHMI.LogSettings.LogWithTimestamps, window.WebHMI.LogSettings.LogWithLogLevelNames);
	trendConfigWidgetRuntime = new window.WebHMI.Widgets.trendConfig(trendConfigElementId, dataModel, messageBanner, restData, timeSelectionMode, window.WebHMI.Components.LogLevels.Trend, window.WebHMI.LogSettings.LogWithTimestamps, window.WebHMI.LogSettings.LogWithLogLevelNames);
	sessionStorageWidgetRuntime = new window.WebHMI.Widgets.trendSessionStorage(trendSessionStorageElementId, dataModel, messageBanner, restData, window.WebHMI.Components.LogLevels.SessionStorage, window.WebHMI.LogSettings.LogWithTimestamps, window.WebHMI.LogSettings.LogWithLogLevelNames);
	trendDisplayWidgetRuntime = new window.WebHMI.Widgets.trendDisplay(trendDisplayWidgetElementId, dataModel, messageBanner, window.WebHMI.Components.LogLevels.TrendDisplay, window.WebHMI.LogSettings.LogWithTimestamps, window.WebHMI.LogSettings.LogWithLogLevelNames, scrollPercentage, trendConfigWidgetRuntime, tooltipOpacity, tooltipType, messageIconElement);

	let theWidgets = {
		'display': trendDisplayWidgetRuntime,
		'dataProvider': trendDataProviderWidgetRuntime,
		'config': trendConfigWidgetRuntime,
		'sessionStorage': sessionStorageWidgetRuntime
	};
	// For each of the former widgets, call renderHtml, afterRender, and setWidgets
	_.each(theWidgets, function (widgetRuntime, widgetName) {
		if (typeof widgetRuntime.renderHtml === "function") {
			try {
				widgetRuntime.renderHtml();
			} catch (err) { console.error(err); }
			if (typeof widgetRuntime.afterRender === "function") {
				try {
					widgetRuntime.afterRender();
				} catch (err) { console.error(err); }
			}
		}
		if (typeof widgetRuntime.setWidgets === "function") {
			try {
				widgetRuntime.setWidgets(theWidgets);
			} catch (err) { console.error(err); }
		}
		widgets.push(widgetRuntime);
	});

	let contextMenu = new trendContextMenu(contextMenuOptionsElement, zIndexManager, (option, ...args) => {
		contextMenuCallBack(option, ...args);
	});
	enum_contextMenuOptions = contextMenu.getContextMenuOptions();

	jQuery("#" + trendDisplayWidgetElementId).on('paused', function () {
		updateChartHeaders(true, true, true);
		if ((dataModel.getTrendType() == window.WebHMI.Components.TrendType.realtime)) {
			updatePausedData(true);
		}
	}).on('trending', function () {
		updateChartHeaders(true, false, true);
	}).on('noTrendData', function () {
		updateChartHeaders(false, false, false);
	}).on('noPauseAllowed', function () {
		updateChartHeaders(true, false, false);
	}).on('deselectDelta', function () {
		setDeltaButtonState(false);
	}).on('hideShiftButtons', function () {
		setShiftButtonsStates(false);
	}).on('showShiftChartUpButton', function () {
		if (!printInProgress) {
			setShiftButtonVisibility(shiftChartUpElement, true);
		}
	}).on('hideShiftChartUpButton', function () {
		if (!printInProgress) {
			setShiftButtonVisibility(shiftChartUpElement, false);
		}
	}).on('showShiftChartDownButton', function () {
		if (!printInProgress) {
			setShiftButtonVisibility(shiftChartDownElement, true);
		}
	}).on('hideShiftChartDownButton', function () {
		if (!printInProgress) {
			setShiftButtonVisibility(shiftChartDownElement, false);
		}
	}).on('showShiftChartLeftButton', function () {
		if (!printInProgress) {
			setShiftButtonVisibility(shiftChartLeftElement, true);
		}
	}).on('hideShiftChartLeftButton', function () {
		if (!printInProgress) {
			setShiftButtonVisibility(shiftChartLeftElement, false);
		}
	}).on('showShiftChartRightButton', function () {
		if (!printInProgress) {
			setShiftButtonVisibility(shiftChartRightElement, true);
		}
	}).on('hideShiftChartRightButton', function () {
		if (!printInProgress) {
			setShiftButtonVisibility(shiftChartRightElement, false);
		}
	}).on('resizeCompleted', function () {
		// adding event listener to wait till chart resize is completed and continue with print
		if (printInProgress) {
			callBrowserPrint();
		}
	}).on('showShiftChartUpButton showShiftChartDownButton showShiftChartLeftButton showShiftChartRightButton', function () {
		if (jQuery(panButtonElement).hasClass('disabled')) {
			jQuery(panButtonElement).removeClass('disabled');
		}
	});

	if(timeSelectionMode==='startDuration' || timeSelectionMode==='startEnd') {
		dataModel.setTimeNowToggleValue(false);
	}

	_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
		favoritesComponent.loadFavorites();
		favoritesComponent.addEventListener('loadFavorite', function (e) {
			if(chartSelectElement.value === 'stacked')
			{
				dataModel.setPropsDeletionAllowed(false);
			}
			let favoriteObject = e.detail.favorite;
			dataModel.setTagQueryCriteriaProperties([]);
			dataModel.setCurrentFavorite(favoriteObject, true);
			if (favoriteObject.trendFavorite) {
				if (favoriteObject.trendFavorite.trendHistoricalNowToggle === true) {
					// Setting this to false to ensure that the change is triggered.
					dataModel.setTimeNowToggleValue(false);
					dataModel.setTimeNowToggleValue(true);
				} else {
					dataModel.setTimeNowToggleValue(false);
				}
				dataModel.setTagQueryCriteriaProperties(favoriteObject.trendFavorite.tagQueryProperty, true);
				dataModel.setTagDisplayMode(favoriteObject.trendFavorite.tagDisplayMode)
				dataModel.setChartDropdownType(favoriteObject.trendFavorite.chartDropdownType);
				let chartDropdownType = favoriteObject.trendFavorite.chartDropdownType;
				if (chartDropdownType === "stacked") {
					$('#'+trendChartTypeId).attr('value', 'stacked')
				} else if (chartDropdownType === "trend") {
					$('#'+trendChartTypeId).attr('value', 'trend')
					let trendComponent = document.getElementsByClassName("trend-chart-container")[0];
				} else if (chartDropdownType === "tabular") {
					$('#'+trendChartTypeId).attr('value', 'tabular')
				}

				let trendProperties = favoriteObject.trendFavorite.trendProperties;

				trendProperties.forEach((property, index) => {
					if (property.yAxisPosition === undefined) { 
						property.yAxisPosition = index % 2 === 0 ? 'left' : 'right';
					}
				});
			}
		});


		favoritesComponent.addEventListener('showError', function (e) {
			showMessage(window.WebHMI.Components.MessageType.error, null, e.detail.message);
		});
		favoritesComponent.addEventListener('favoritesChanged', function (e) {
			EMBED.publish(FAVORITES_CHANGE, e.detail);
		});
		favoritesComponent.setAttribute('contextasset', getSelectedAssetName());
		if (selFavName) {
			loadSelectedFavorite(selFavName);
		}
	});

	resetLegendItems();
	trendDisplayWidgetRuntime.setShowTrendValueAxes(showTrendValueAxesValue);
	trendDisplayWidgetRuntime.setLoggedInUsername(loggedInUserNameValue);
	trendDisplayWidgetRuntime.setXAxisLabel(xAxisLabelValue);
	trendDisplayWidgetRuntime.setYAxisDesignerLabel(yAxisLabelValue);
	trendDisplayWidgetRuntime.setXAxisTimeFormat(timeFormatModeValue, customTimeFormatValue);

	sessionStorageWidgetRuntime.initializeConfiguration();

	dataModel.setContextAsset(getSelectedAssetName());

	if (historianTagPageSizeValue) {
		dataModel.setHistorianTagPageSize(historianTagPageSizeValue);
	}

	dataModel.setTrendInputConfiguration(trendConfigInput);

	if(trendTagsInput!=="" && trendTagsInput !== null) { // set initial tag list
		let tagList = trendTagsInput.split(",");
		tagList = TrendCommon.removeDuplicateStringsFromArray(tagList, false); // case-insensitive
		sessionStorageWidgetRuntime.loadFromTagList(tagList);
	}	

	console.log("\n----------\nInitial setup complete\n----------\n");

	jQuery(pauseResumeButtonElement).click(function () {
		trendDisplayWidgetRuntime.pauseOrResume(false);
		let hasTrendData = trendDisplayWidgetRuntime.haveSeriesInChart();
		//if no trend data, don't do anything. Ignore this click
		if (hasTrendData) {
			let isSelected = deltaButtonElement.classList.contains('selected');
			if (isSelected) {
				// deselct delta button
				setDeltaButtonState(!isSelected);
				// set delta mode status in trend chart
				trendDisplayWidgetRuntime.toggleDeltaMode(!isSelected);
			}
		}
	});

	document.addEventListener('click', (clickEvent) => {
		//close context menu if user click outside of context menu
		let isHidden = jQuery(contextMenuOptionsElement.classList.contains('hidden'));
		if (!(isHidden && isHidden[0] === true)) {
			jQuery(contextMenuOptionsElement).addClass('hidden');
			jQuery(contextMenuButtonElement).removeClass('selected');
		}

		//close config card if user clicks on another webhmi plugin
		let clickTargetPlugin = jQuery(clickEvent.target).closest('.web-hmi-plugin');
		if(clickTargetPlugin) {
			let clickTargetPluginId = clickTargetPlugin.prop('id') || null;
			let thisConfigIsVisible = !(trendConfigElement.classList.contains('hidden'));
			
			if(thisConfigIsVisible && clickTargetPlugin.length && (clickTargetPluginId !== trendPluginName)) {
				jQuery(trendConfigElement).find('.closeButton').trigger('click');
			}
		}
	});

	jQuery(configButtonElement).click(function () {
		logger.log(logger.LogLevel.Debug, 0, 'configButtonElement has been clicked');
		trendConfigWidgetRuntime.resizeCard();

		// Safari Overflow auto is cropping the configuration popup
		pluginElement.parent().closest('.coordinated_container')?.css("overflow","none");
	
		// changes for config popup to work with gridster in new end app
		setTimeout(()=>{
			safeEnableFixedBoxModel();
			zIndexManager.moveToFront();

			jQuery(trendConfigElement).removeClass("hidden");
			// highlight border of this card when config panel is open
			jQuery(mainElement).addClass("in-focus");
		}, 300)
	});
	
	// changes for config popup to work with gridster in new end app
	jQuery(trendConfigElement).find('.closeButton').on('click', function () {
		zIndexManager.restore();
		safeDisableFixedBoxModel();
	})

	//toggle context menu
	jQuery(contextMenuButtonElement).click(function (event) {
		event.stopPropagation();
		let isHidden = jQuery(contextMenuOptionsElement.classList.contains('hidden'));
		if (isHidden && isHidden[0] === true) {
			showContextMenu();
		} else {
			hideContextMenu();
		}
	});
	jQuery(legendButtonElement).click(function () {
		if (!showTrendLegendValue) {
			showLegend();
		} else {
			hideLegend();
		}
	});
	jQuery(statsButtonElement).click(function () {
		if (!showStatisticsValue) {
			showStatistics();
		} else {
			hideStatistics();
		}
		tabularComponent.setAttribute('statisticsupdate', true);
	});
	jQuery(deltaButtonElement).click(function () {
		let hasTrendData = trendDisplayWidgetRuntime.haveSeriesInChart();
		//if no trend data, don't do anything. Ignore this click
		if (hasTrendData) {
			let isSelected = deltaButtonElement.classList.contains('selected');
			setDeltaButtonState(!isSelected);
			//set delta mode status in trend chart
			trendDisplayWidgetRuntime.toggleDeltaMode(!isSelected);
		}
	});
	jQuery(zoomOutButtonElement).click(function () {
		trendDisplayWidgetRuntime.zoomOut();
	});
	jQuery(zoomInButtonElement).click(function () {
		trendDisplayWidgetRuntime.zoomIn();
	});
	jQuery(zoomButtonElement).click(function () {
		jQuery(zoomButtonElement).addClass('selected');
		jQuery(panButtonElement).removeClass('selected');
		trendDisplayWidgetRuntime.enterZoomMode();
	});
	jQuery(panButtonElement).click(function () {
		jQuery(zoomButtonElement).removeClass('selected');
		jQuery(panButtonElement).addClass('selected');
		trendDisplayWidgetRuntime.enterPanMode();
	});
	/**
	 * updateResetZoomElements
	 * Hide the reset Zoom Icon and add disabled class to the Pan Icon in Historical Mode
	 * Trigger zoom mode (default)
	 */
	function updateResetZoomElements() {
		jQuery(resetZoomButtonElement).hide();
		let disablePanOption = dataModel.getTrendType().toLowerCase() === window.WebHMI.Components.TrendType.historical;
		if (disablePanOption) {
			jQuery(panButtonElement).addClass('disabled');
		}
		jQuery(zoomButtonElement).trigger('click');
	}
	/**
	 * Add click event and event listener to the reset zoom button
	 * Click event will reset the chart zoom(trendDisplay.ts) and hides the reset icon
	 */
	jQuery(resetZoomButtonElement).click(function () {
		trendDisplayWidgetRuntime.resetZoom();
		updateResetZoomElements();
	});
	/**
	 * Listen to the "enableResetZoom" event dispatched from enableResetZoomOption(trendDisplay.ts) and show the zoom reset icon
	 */
	jQuery('#' + trendDisplayWidgetElementId).on('enableResetZoom', function (e) {
		jQuery(resetZoomButtonElement).show();
		jQuery(panButtonElement).removeClass('disabled');
	});
	/**
	 * Listen to the "disableResetZoom" event dispatched from disableResetZoomOption (trendDisplay.ts) when resume button is clicked and Hide the reset Zoom button
	 * resume functionality resets the chart(including zoom) and it voids the reset zoom functionality
	 */
	jQuery('#' + trendDisplayWidgetElementId).on('disableResetZoom', function (e) {
		updateResetZoomElements();
	});

	zoomModeSelectElement.addEventListener("value-changed", () => {
		dataModel.setTrendZoomType(zoomModeSelectElement.value)
		jQuery(zoomButtonElement).addClass('selected');
		jQuery(panButtonElement).removeClass('selected');
		trendDisplayWidgetRuntime.setZoomMode(zoomModeSelectElement.value);
	});
	jQuery(zoomModeSelectElement).click(function () {
		if(dataModel.getChartDropdownType()==='stacked'){
			$('.y-item').attr('disabled','true')
			$('.xy-item').attr('disabled','true')
		}else{
			$('.y-item').removeAttr('disabled')
			$('.xy-item').removeAttr('disabled')
		}
	});


	chartSelectElement.addEventListener("value-changed", () => {
		let trendComponent = document.getElementsByClassName("trend-chart-container")[0];
		const axisSpec = dataModel.getTrendAxisSpec();
		destroyStatsSplitter();
		
		if (chartSelectElement.value === 'stacked') {
			if(trendComponent)
			{
				trendComponent.style.marginLeft="0px";
			}
			dataModel.setChartDropdownType(chartSelectElement.value);
			jQuery(mainElement).find('.widget-TrendChart').css('overflow-y','scroll')
			jQuery(mainElement).find('.widget-TrendChart').css('overflow-x','hidden')
			// tabularComponent.hidden = true;
			// trendComponent.hidden = false;
			$(tabularComponent).hide();
			$(chartElement).show();

			//$(trendComponent).show();
			$('#chart-' + trendDisplayWidgetElementId).show()
			// jQuery("#trend-chart-type").removeClass('custom-fade');
			jQuery(trendConfigElement).find(".chart-y-axis-config-container").addClass('custom-fade');
			jQuery(trendConfigElement).find(".spec-limit-container").removeClass('custom-fade');
			jQuery('#'+trendDeltaButtonId).removeClass('custom-fade');
			jQuery("#"+trendZoomButtonId).removeClass('custom-fade');
			jQuery('#'+trendPanButtonId).removeClass('custom-fade');
			jQuery('#'+trendZoomInButtonId).removeClass('custom-fade');
			jQuery('#'+trendZoomOutButtonId).removeClass('custom-fade');

			// jQuery(".ge-icon-plus").removeClass('custom-fade');
			// jQuery(".ge-icon-minus").removeClass('custom-fade');
			jQuery("#"+trendZoomModeSelectId).removeClass('custom-fade');
			jQuery(".line-weight-dropdown").removeClass('custom-fade');
			jQuery(".line-style-input").removeClass('custom-fade');
			jQuery(trendConfigElement).find(".source-config-field.line-style").removeClass('custom-fade');
			jQuery(trendConfigElement).find(".trend-settings-table.notes").removeClass('custom-fade');
			jQuery(trendConfigElement).find(".showAxisConfig").removeClass('custom-fade');
			jQuery(trendConfigElement).find(".source-config-field.axis-config").removeClass('custom-fade');
			jQuery(".line-color-dropdown").removeClass('custom-fade');
			jQuery(".line-style-dropdown").removeClass('custom-fade');
			jQuery(trendConfigElement).find('.trend-chart-type').removeClass('custom-fade');
			
			$('#'+trendZoomInButtonId).removeClass('custom-fade')
			$('#'+trendZoomOutButtonId).removeClass('custom-fade');
			jQuery(trendConfigElement).find(".trend-chart-type").each(function () {
				$(this).removeClass('custom-fade');
			});
			jQuery(trendConfigElement).find(".source-yaxis-label").each(function () {
				$(this).removeClass('custom-fade')
			})
			jQuery(trendConfigElement).find(".source-yaxis-position").each(function () {
				$(this).addClass('custom-fade');
			});
			updateStackedChart();
		} else if (chartSelectElement.value === "trend") {
			dataModel.setChartDropdownType(chartSelectElement.value);
			jQuery(mainElement).find('.widget-TrendChart').css('overflow','none')
			$(tabularComponent).hide();
			$(chartElement).show();

			$('#chart-' + trendDisplayWidgetElementId).show();
			jQuery(trendConfigElement).find(".chart-y-axis-config-container").removeClass('custom-fade');
			jQuery(trendConfigElement).find(".spec-limit-container").removeClass('custom-fade');
			jQuery('#'+trendDeltaButtonId).removeClass('custom-fade');
			jQuery('#'+trendZoomButtonId).removeClass('custom-fade');
			jQuery('#'+trendPanButtonId).removeClass('custom-fade');
			jQuery('#'+trendZoomInButtonId).removeClass('custom-fade');
			jQuery('#'+trendZoomOutButtonId).removeClass('custom-fade');
			jQuery(trendConfigElement).find(".trend-settings-table.notes").removeClass('custom-fade');
			jQuery("#"+trendZoomModeSelectId).removeClass('custom-fade');
			jQuery(".line-weight-dropdown").removeClass('custom-fade');
			jQuery(trendConfigElement).find(".source-config-field.line-style").removeClass('custom-fade');
			jQuery(trendConfigElement).find(".showAxisConfig").removeClass('custom-fade');
			jQuery(trendConfigElement).find(".source-config-field.axis-config").removeClass('custom-fade');
			jQuery(".line-color-dropdown").removeClass('custom-fade');
			jQuery(".line-style-dropdown").removeClass('custom-fade');
			jQuery(trendConfigElement).find('.trend-chart-type').addClass('custom-fade');

			$('#'+trendZoomInButtonId).removeClass('custom-fade')
			$('#'+trendZoomOutButtonId).removeClass('custom-fade')

			jQuery(zoomButtonElement).removeClass('disabled');
			jQuery(trendConfigElement).find(".trend-chart-type").each(function () {
				$(this).addClass('custom-fade');
			});
			jQuery(trendConfigElement).find(".source-yaxis-label").each(function () {
				$(this).removeClass('custom-fade')
			})
			jQuery(trendConfigElement).find(".source-yaxis-position").each(function () {
				if (axisSpec && !axisSpec.singleAxis) {
					$(this).removeClass('custom-fade')
				}
			})
			
		}
		else if (chartSelectElement.value === "tabular") {
			if(trendComponent)
			{
				trendComponent.style.marginLeft="0px";
			}
			dataModel.setChartDropdownType(chartSelectElement.value);
			$(tabularComponent).show();
			$(chartElement).hide();

			$('#chart-' + trendDisplayWidgetElementId).hide();
			jQuery(trendConfigElement).find(".chart-y-axis-config-container").addClass('custom-fade');
			jQuery(trendConfigElement).find(".spec-limit-container").addClass('custom-fade');
			jQuery('#'+trendDeltaButtonId).addClass('custom-fade');
			jQuery('#'+trendZoomButtonId).addClass('custom-fade');
			jQuery('#'+trendPanButtonId).addClass('custom-fade');
			jQuery('#'+trendZoomInButtonId).addClass('custom-fade');
			jQuery('#'+trendZoomOutButtonId).addClass('custom-fade');
			jQuery(trendConfigElement).find(".source-config-field.line-style").addClass('custom-fade');
			jQuery(trendConfigElement).find(".trend-settings-table.notes").addClass('custom-fade');
			jQuery(trendConfigElement).find(".source-config-field.axis-config").addClass('custom-fade');
			jQuery(trendConfigElement).find(".showAxisConfig").addClass('custom-fade');
			jQuery("#"+trendZoomModeSelectId).addClass('custom-fade');
			jQuery(".line-weight-dropdown").addClass('custom-fade')
			jQuery(".line-color-dropdown").addClass('custom-fade');
			jQuery(".line-style-dropdown").addClass('custom-fade');
			jQuery(trendConfigElement).find('.trend-chart-type').addClass('custom-fade')

			isVisible = false
			_updateTabularTrend();

			jQuery(trendConfigElement).find(".trend-chart-type").each(function () {
				$(this).addClass('custom-fade');
			});
			jQuery(trendConfigElement).find(".source-yaxis-label").each(function () {
				$(this).addClass('custom-fade')
			})
			jQuery(trendConfigElement).find(".source-yaxis-position").each(function () {
				$(this).addClass('custom-fade')
			})
		}
		setTimeout(function () {
			recreateStatsSplitter();
			if(chartResizeSensor) chartResizeSensor.reset();
		}, 250);
		
	});
	//shift chart up/down left/right
	jQuery(shiftChartUpElement).click(function () {
		trendDisplayWidgetRuntime.shiftChartUp();
	});
	jQuery(shiftChartDownElement).click(function () {
		trendDisplayWidgetRuntime.shiftChartDown();
	});
	jQuery(shiftChartLeftElement).click(function () {
		trendDisplayWidgetRuntime.shiftChartLeft();
	});
	jQuery(shiftChartRightElement).click(function () {
		trendDisplayWidgetRuntime.shiftChartRight();
	});
	jQuery(headerToggleElement).click(function () {
		if (!showHeaderValue) {
			showHeader();
		} else {
			hideHeader();
		}
	});
	/**
	 * Resize sensor for the chart element.
	 * This function is called when the chart is resized
	 */
	chartResizeSensor = new ResizeSensor(chartElement, function (size) {
		// with resize of chart element resizing width of statistics bar
		if(displayResizeTimeout) { clearTimeout(displayResizeTimeout); }

		displayResizeTimeout = window.setTimeout(() => {
			displayResizeTimeout = null;
			trendDisplayWidgetRuntime.resize(size.width, size.height);
			jQuery(shiftChartUpDownDiv).height(size.height);

			setCardHeight();
		}, 50);
	});



	/**
	 *  (New) Resize event handler for the header element. Dynamically adjust width
	 *  of the chart title depending on the available space in the trend header.
	 */
	new ResizeSensor(headerElement, function (size) {
		if (!jQuery(trendChartTitleElement).hasClass('hidden')) {
			let trendHeaderWidth = jQuery(headerElement).width();
			let favoriteComponentWidth = jQuery(trendFavoritesElement).width();
			let buttonBarWidth = jQuery(buttonBarElement).width();

			//We have kept some pixel buffer between the conditions to avoid resize thrashing when the legend is displayed
			if (trendHeaderWidth >= favoriteComponentWidth + buttonBarWidth + 270) {
				jQuery(trendChartTitleElement).width(trendHeaderWidth - favoriteComponentWidth - buttonBarWidth - 150);
			}
			else if ((trendHeaderWidth <= favoriteComponentWidth + buttonBarWidth + 170) && (trendHeaderWidth > favoriteComponentWidth + 270)) {
				jQuery(trendChartTitleElement).width(trendHeaderWidth - favoriteComponentWidth - 50);
			}
			else if (trendHeaderWidth < favoriteComponentWidth + 230) {
				jQuery(trendChartTitleElement).width(trendHeaderWidth - 50);
			}
		}
	});

	setCardHeight();
	//set chart width and height
	trendDisplayWidgetRuntime.resize(jQuery(chartElement).width(), jQuery(chartElement).height());
	jQuery(shiftChartUpDownDiv).height(jQuery(chartElement).height());
	//set configure panel top position based on main page
	if (mainPageElement) {
		let pageTopPosition = mainPageElement.getBoundingClientRect().top;
		trendConfigElement.style.top = pageTopPosition + 'px';
	}
	else {
		trendConfigElement.style.top = '45px'; //default IQP header height
	}

	if (showTrendLegendValue) {
		showLegend();
	}
	if (!showHeaderValue) {
		hideHeader();
	} else {
		showHeader();
	}

	cardLoaded = true;
	let trendComponent = document.getElementsByClassName("trend-chart-container")[0];	
	/*
	if(trendComponent.children.length &&  trendComponent.children[2])
	{
		//trendComponent.children[2].style.transform="scaleY(1.12) translate(-18px, 10px)";
		trendComponent.style.marginBottom="-50px";
		trendComponent.style.marginLeft="-20px";;
	}*/
}

// publish current trend settings within the next 2 seconds (batches up rapid changes)
function publishCurrentSettings(favoritesComponent) {
	window.clearTimeout(publishTimeout)
	publishTimeout = window.setTimeout(() => {
		let settingsJsonString = JSON.stringify(favoritesComponent.currentTrendSettings.getJSON());
		if (userConfig.hasOwnProperty('trendConfigOutput') && userConfig.trendConfigOutput && settingsJsonString !== lastSettingsJsonString) {
			EMBED.submitTarget(userConfig.trendConfigOutput, settingsJsonString);

			// check time settings
			let previousSettingsObj = lastSettingsJsonString ? JSON.parse(lastSettingsJsonString) : {};
			let newSettingsObj = settingsJsonString ? JSON.parse(settingsJsonString) : {};

			// Fix for bug 612779/605781, where TrendType was not being published until after it was changed to historical
			// appropriately publish changes on initial change (prev=undefined, new=something)
			let valueChanged = function(propName, isTime=false) {
				if(newSettingsObj[propName]===undefined || newSettingsObj[propName]===null) return false; // nothing to publish
				if(previousSettingsObj[propName]===undefined || previousSettingsObj[propName]===null) return true; // initial change, publish!
				if(isTime) {
					let prevDateVal = (new Date(previousSettingsObj[propName])).getTime();
					let newDateVal = (new Date(newSettingsObj[propName])).getTime();
					return (prevDateVal !== newDateVal);
				}
				return (newSettingsObj[propName] !== previousSettingsObj[propName]);
			}

			publishInProgress = true;
			if(userConfig.hasOwnProperty('trendRealtimeDurationOutput') && valueChanged('TrendRealtimeDuration')) {
				EMBED.submitTarget(userConfig.trendRealtimeDurationOutput, dataModel.getRealtimeDuration());
			}
			if(userConfig.hasOwnProperty('trendHistoricalDurationOutput') && valueChanged('TrendHistoricalDuration')) {
				EMBED.submitTarget(userConfig.trendHistoricalDurationOutput, dataModel.getHistoricalDuration());
			}
			if(userConfig.hasOwnProperty('trendTypeOutput') && valueChanged('TrendType')) {
				EMBED.submitTarget(userConfig.trendTypeOutput, dataModel.getTrendType());
			}
			if(userConfig.hasOwnProperty('trendHistoricalEndDateTimeOutput') && valueChanged('TrendHistoricalEndTime', true)) {
				EMBED.submitTarget(userConfig.trendHistoricalEndDateTimeOutput, dataModel.getHistoricalEndTime());
			}
			publishInProgress = false;
			lastSettingsJsonString = settingsJsonString;
		}
	}, 2000);
}

function addDataModelListeners() {
	dataModel.addChangeListener(TrendDataModelProperties.trendType, function (event) {
		let legendComponent = jQuery(legendContainerElement).find('trend-chart-legend')[0];
		if (legendComponent) {
			legendComponent.setAttribute('trendtype', dataModel.getTrendType());
		}
		tabularComponent = jQuery(mainElement).find('trend-tabular-view')[0];
		tabularComponent.setAttribute('trendtype', dataModel.getTrendType());
		tabularComponent.setAttribute('tagdisplaymode',dataModel.getChartDropdownType());
		tabularComponent.setAttribute('allproperties', ''); // clear it so colors render correctly, will be re-set in _updateTabularTrend

		isVisible = false
		dataModel.setTabularProperties([])
		
		if (chartSelectElement.value === "tabular") {
			_updateTabularTrend();
		}

		updateTimeDisplay();
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("trendtype", dataModel.getTrendType());
			publishCurrentSettings(favoritesComponent);

		});
		// trendDisplayWidgetRuntime.resetZoom();
		// updateResetZoomElements();
	}).addChangeListener(TrendDataModelProperties.realtimeDuration, function (event) {
		updateTimeDisplay();
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("realtimeduration", dataModel.getRealtimeDuration());
			publishCurrentSettings(favoritesComponent);
		});
	}).addChangeListener(TrendDataModelProperties.historicalDuration, function (event) {
		updateTimeDisplay();
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("historicalduration", dataModel.getHistoricalDuration());
			publishCurrentSettings(favoritesComponent);

		});
	}).addChangeListener(TrendDataModelProperties.historicalEndTime, function (event) {
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("historicalendtime", dataModel.getHistoricalEndTime());
			publishCurrentSettings(favoritesComponent);
		});
	}).addChangeListener(TrendDataModelProperties.timeNowToggle, function (event) {
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("trendhistoricalnowtoggle", dataModel.getTimeNowToggleValue());
			publishCurrentSettings(favoritesComponent);
		});
	}).addChangeListener(TrendDataModelProperties.historicalSamplingIncrementType, function (event) {
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("historicalincrementtype", dataModel.getHistoricalSamplingIncrementType());
			publishCurrentSettings(favoritesComponent);
		});
	}).addChangeListener(TrendDataModelProperties.historicalSamplingIncrementValue, function (event) {
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("historicalincrementvalue", dataModel.getHistoricalSamplingIncrementValue());
			publishCurrentSettings(favoritesComponent);
		});
	}).addChangeListener(TrendDataModelProperties.historicalSamplingTimeUnit, function (event) {
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("historicaltimeunit", dataModel.getHistoricalSamplingTimeUnit());
			publishCurrentSettings(favoritesComponent);
		});
	}).addChangeListener(TrendDataModelProperties.trendSpecLimits, function (event) {
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("speclimits", dataModel.getTrendSpecLimits());
			publishCurrentSettings(favoritesComponent);
		});
	}).addChangeListener(TrendDataModelProperties.trendAxisSpec, function (event) {
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("axisspec", dataModel.getTrendAxisSpec());
			publishCurrentSettings(favoritesComponent);
		});
	}).addChangeListener(TrendDataModelProperties.tagDisplayMode, function (event) {
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("trendtagdisplaymode", dataModel.getTagDisplayMode());
			publishCurrentSettings(favoritesComponent);
		});
	}).addChangeListener(TrendDataModelProperties.chartDropdownType, function (event) {
			_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
				favoritesComponent.trendSettingChanged("trendchartdropdowntype", dataModel.getChartDropdownType());
				publishCurrentSettings(favoritesComponent);
		});
	}).addChangeListener(TrendDataModelProperties.tagQueryProperties, function (event) {
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("tagqueryproperties", dataModel.getTagQueryProperties());
			publishCurrentSettings(favoritesComponent);
		});
	}).addChangeListener('TrendConfigurationChanged', function (event) {
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("trendtype", dataModel.getTrendType());
			favoritesComponent.trendSettingChanged("trendchartdropdowntype", dataModel.getChartDropdownType());
			favoritesComponent.trendSettingChanged("trendtagdisplaymode", dataModel.getTagDisplayMode());
			favoritesComponent.trendSettingChanged("realtimeduration", dataModel.getRealtimeDuration());
			favoritesComponent.trendSettingChanged("historicalduration", dataModel.getHistoricalDuration());
			favoritesComponent.trendSettingChanged("historicalendtime", dataModel.getHistoricalEndTime());
			favoritesComponent.trendSettingChanged("trendhistoricalnowtoggle", dataModel.getTimeNowToggleValue());
			favoritesComponent.trendSettingChanged("historicalincrementtype", dataModel.getHistoricalSamplingIncrementType());
			favoritesComponent.trendSettingChanged("historicalincrementvalue", dataModel.getHistoricalSamplingIncrementValue());
			favoritesComponent.trendSettingChanged("historicaltimeunit", dataModel.getHistoricalSamplingTimeUnit());
			favoritesComponent.trendSettingChanged("speclimits", dataModel.getTrendSpecLimits());
			favoritesComponent.trendSettingChanged("axisspec", dataModel.getTrendAxisSpec());
			favoritesComponent.trendSettingChanged("tagqueryproperties", dataModel.getTagQueryProperties());
			publishCurrentSettings(favoritesComponent);
		});
	}).addChangeListener(TrendDataModelProperties.tagDisplayMode, function(event) {
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("trendtagdisplaymode", dataModel.getTagDisplayMode());
			publishCurrentSettings(favoritesComponent);
		});
	}).addChangeListener(TrendDataModelProperties.showAnnotations, function(event) {
		_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
			favoritesComponent.trendSettingChanged("showAnnotations", dataModel.getShowAnnotations());
			publishCurrentSettings(favoritesComponent);
		});
	}).addChangeListener(TrendDataModelProperties.tagDisplayMode, function (event) {
		let statisticsComp = jQuery(trendStatisticsElement).find('trend-statistics')[0];
		statisticsComp.setAttribute('tagdisplaymode', event.value);
		let legendComp = jQuery(legendContainerElement).find('trend-chart-legend')[0];

		legendComp.setAttribute('tagdisplaymode', event.value);
		if (chartSelectElement.value === "tabular") {
			_updateTabularTrend();
			tabularComponent.setAttribute('tagdisplaymode', event.value);
		}
	}).addChangeListener(TrendDataModelProperties.propertyAttributes, function (event) {
		let tabularComponent = jQuery(mainElement).find('trend-tabular-view')[0];
		historicalDataValues = []
		historicalDataValues = durationValues;
		if(dataModel.getTrendType() === window.WebHMI.Components.TrendType.realtime)
		{
			tabularComponent.setAttribute('allproperties', JSON.stringify(filterSamplingModesForRealtime(event.value)));
		}
		hisEventData = true
		sendUpdatedStatistics(); // got back attributes like description, should update stats table

		let legendComponent = jQuery(legendContainerElement).find('trend-chart-legend')[0];
		let legendItems = JSON.parse(legendComponent.getAttribute('legenditems'));

		let propValue;
		let units;
		let description;
		// adding units and description to legendItems from event input
		propValue = event.value
		if (propValue && propValue.length && legendItems.length) {
			propValue.forEach(item => {
				legendItems.forEach(value => {
					value.properties.forEach(propItem => {
						if (item.attributes) {
							if (item.attributes?.Description||item.attributes?.Units || item.attributes?.LowRange || item.attributes?.HighRange) {
								if (propItem.name === item.propertyName||propItem.propertyName === item.propertyName) {
									if(propItem.dataSourceType != 'objects' && propItem.dataSourceType)
									{
										//other than assetModel tags
										units = item.attributes.Units;
										description = item.attributes.Description;
										propItem.value=``;
										const trendValueKey=`${propItem.assetName}.${propItem.propertyName}`;
										if(legendValuesMap.has(trendValueKey) && dataModel.getUncommittedValue("TrendType") !== window.WebHMI.Components.TrendType.historical)
										{
											propItem.value =legendValuesMap.get(trendValueKey)+" ";
										}
										propItem.units=units;
										propItem.description = description;
									}else{
										//Asset Model tags
										units = item.attributes.Units;
										propItem.value=``;
										const trendValueKey=`${propItem.assetName}.${propItem.propertyName}`;
										if(legendValuesMap.has(trendValueKey) && dataModel.getUncommittedValue("TrendType") !== window.WebHMI.Components.TrendType.historical)
										{
											propItem.value =legendValuesMap.get(trendValueKey)+" ";
										}
										propItem.units = units;
									}
								}
							}
						}
					})
				})
			})
		}
		legendItems = legendItems.filter((value, index) => {
			let _value = JSON.stringify(value);
			return index === legendItems.findIndex(obj => {
				return JSON.stringify(obj) === _value;
			});
		});
		legendComponent.setAttribute('legenditems', JSON.stringify(legendItems));
	}).addChangeListener(TrendDataModelProperties.realtimeDuration, function (event) {
		let tabularComponent = jQuery(mainElement).find('trend-tabular-view')[0];
		dataModel.setTabularTrends([])
		tabularComponent.setAttribute('items', JSON.stringify([]));
		
		if (chartSelectElement.value === "tabular") {
			_updateTabularTrend();
		}
	}).addChangeListener(TrendDataModelProperties.historicalDuration, function (event) {
		hisEventData = false
		durationValues = []
		let tabularComponent = jQuery(mainElement).find('trend-tabular-view')[0];
		dataModel.setTabularTrends([])
		
		tabularComponent.setAttribute('items', JSON.stringify([]));
		if (chartSelectElement.value === "tabular") {
			_updateTabularTrend();
		}
	}).addChangeListener(TrendDataModelProperties.favoriteLoadingStatus, function (event) {
		logger.log(logger.LogLevel.Debug, 0, `dataModel config changed: ${event.property} changed: old: ${event.previousValue}, new: ${event.value}`);
		// alert favorite component if load is in-progress, so button visibility is correct
		let favoriteComponent = mainElement.find('favorites-manager')[0];
		if (favoriteComponent) {
			favoriteComponent.setLoadingStatus(dataModel.getFavoriteLoadingStatus());
		}
		if(chartSelectElement.value === 'stacked')
		{
			dataModel.setPropsDeletionAllowed(false);
		}
	}).addChangeListener(TrendDataModelProperties.tabularTrends, _updateTabularTrend())

	dataModel.addChangeListener(TrendDataModelProperties.socketConnectionError, function (event) {
		logger.log(logger.LogLevel.Debug, 0, `dataModel config changed: ${event.property} changed: old: ${event.previousValue}, new: ${event.value}`);
		handleConnectionError();
	});
	
	
	// statistics and delta values
	dataModel.addChangeListener(TrendDataModelProperties.tagStatistics, function (event) {
		sendUpdatedStatistics();
	}).addChangeListener(TrendDataModelProperties.dataDeltaValues, function (event) {
		let legendComponent = jQuery(legendContainerElement).find('trend-chart-legend')[0];
		legendComponent.setAttribute('aggregationpointvalues', JSON.stringify(event.value));
	});

	// properties
	dataModel.addEventListener(TrendDataModelEvents.newRealtimeData, function (event) {
		if(event && event.length ==0)
		{
			return
		}
		let currentTrends = dataModel.getTabularTrends();
		let trends = event;
		legendValuesMap.clear();
		let trendValueKey;
		trends.forEach((trend)=>{
			    trendValueKey=`${trend.assetName}.${trend.name}`;
				const updatedValue = pluginLocalizer.getInstance("GETrendCard").numberToLocalizedString(Number(trend.value.value));
				legendValuesMap.set(trendValueKey,updatedValue);
		});
		if (chartPaused) {
			updatePausedData(false, trends);
		}
		if (Array.isArray(currentTrends)) {
			if (currentTrends.length > 0) {
				trends = [...trends, ...currentTrends];
			}
			let endDate = new Date();
			let startDate = new Date(endDate - dataModel.getRealtimeDuration()*1000);
			trends= trends.filter(function(v){
				let currTime = new Date(v.time);
				if(currTime<=endDate && currTime>=startDate){
					return v;
				}
			})
		}
		dataModel.setTabularTrends(trends);
		if (chartSelectElement.value === "tabular") {
			_updateTabularTrend(trends)
		}
		updateLegendsValues();
	});

	dataModel.addEventListener(TrendDataModelEvents.newHistoricalData, function (event) {
		 let tabularComponent = jQuery(mainElement).find('trend-tabular-view')[0];
		 tabularComponent.setAttribute('items', JSON.stringify([]));
		//Storing the Current AssetName to remove its existing data
		let currentDatasource=event[0].assetName;
			if(durationValues.length>0)
			{
				durationValues= durationValues.filter(function(v){
					let currAsset = v.assetName;
					if(currentDatasource!=currAsset){
						return v;
					}
				})
			}
			//Merging up all the WS data received in batches in case of multiple datasources.
			durationValues= [...durationValues,...event];
			//Clearing the rest data which does not fall in the current duration
			let endDate = new Date(event[event.length-1].time);
			let startDate = new Date(endDate - dataModel.getHistoricalDuration()*1000);
			durationValues= durationValues.filter(function(v){
				let currTime = new Date(v.time);
				if(currTime<=endDate && currTime>=startDate){
					return v;
				}
			})
			dataModel.setTabularTrends(durationValues);
			if (chartSelectElement.value === "tabular") {
				_updateTabularTrend(durationValues)
			}
	});


	dataModel.addChangeListener(TrendDataModelProperties.browsedPropertyList, function (event) {
		logger.log(logger.LogLevel.Debug, 0, `dataModel config changed: ${event.property} changed: old: ${event.previousValue}, new: ${event.value}`);
	}).addEventListener(TrendDataModelEvents.assetTrendingPropertiesChanged, function (propChangeEvent) {
		logger.log(logger.LogLevel.Debug, 0, `dataModel event triggered: ${propChangeEvent}`);
		let itemsForLegend = filterPropertiesForMode(propChangeEvent.value, dataModel.getUncommittedValue("TrendType"));
		updateLegendItems(itemsForLegend);
		bPublished = true;
		if (chartSelectElement.value === "tabular") {
			_updateTabularTrend();
		}
		sendUpdatedStatistics();
		updateStackedChart();
	}).addEventListener(TrendDataModelEvents.propertyUntrendableError, function (event) {
		// logger.log(logger.LogLevel.Debug, 0, `dataModel event triggered: ${propChangeEvent}`);
		removePropertyFromChart(event.value);
	});

}
//updateLegendsValue which is a combination of units + values
function updateLegendsValues()
{
	if(dataModel.getUncommittedValue("TrendType") === window.WebHMI.Components.TrendType.historical)
	{
		return;
	}
	let legendComponent = jQuery(legendContainerElement).find('trend-chart-legend')[0];
	let legendItems = JSON.parse(legendComponent.getAttribute('legenditems'));
	if(legendItems){
		legendItems.map((legendData)=>{
			if(legendData.properties)
			{
				for(let i=0;i<legendData.properties.length;i++)
				{
					const legend=legendData.properties[i];
					const trendValueKey=`${legend.assetName}.${legend.propertyName}`;
					if(legendValuesMap.has(trendValueKey))
					{
						legend.value=legendValuesMap.get(trendValueKey)+" ";
					}
				}

			}
		 }
			
		);
		legendItems = legendItems.filter((value, index) => {		
			let _value = JSON.stringify(value);
					return index === legendItems.findIndex(obj => {
					   return JSON.stringify(obj) === _value;
			});
		});
		legendComponent.setAttribute('legenditems', JSON.stringify(legendItems));	
	}
	
}
/**
 * If trend type is realtime, filter legend props to only include props in 'RealtimeVisibleProperties'
 * @param {object} allProps
 * @param {string} chartTrendType
 * @returns
 */
function filterPropertiesForMode(allProps, chartTrendType) {
	let legendProps = jQuery.extend(true, {}, allProps);

	if(chartTrendType==='realtime' && legendProps && legendProps.hasOwnProperty('assetName')) {
		let realtimeProps = dataModel.getUncommittedValue("RealtimeVisibleProperties");
		let lAssetName = legendProps.assetName;
		if(realtimeProps && realtimeProps.hasOwnProperty(lAssetName)) {
			legendProps.properties = legendProps.properties.filter(function (lProp) {
				return (realtimeProps[lAssetName].hasOwnProperty(lProp.propertyName)) && (realtimeProps[lAssetName][lProp.propertyName]===lProp.samplingMode);
			});
		}
	}
	return legendProps;
}


/**
 * This function is used to store the data when the chart is paused
 * @param onPauseClick - true when called from paused event
 * @param newTrends - this has new live data
 */
function updatePausedData(onPauseClick, newTrends) {
	pausedTime = pausedTime || Date.now();
	if (onPauseClick) {
		pausedTime = Date.now();
		pausedData = dataModel.getTabularTrends() || [];
		pausedData = pausedData.sort((rec1,rec2) => {
			return -(rec1.time - rec2.time);
		});
		// checking if the latest record falls within the 10 sec of the time when pause is clicked and
		// considering this record time as endtime for filtering the tabular data.
		if (pausedData[0] && pausedData[0].time) {
			pausedTime = pausedData[0].time.getTime();
		}
	}
	pausedData = [...pausedData, ...(newTrends || [])];
	let _startTime = pausedTime - (dataModel.getRealtimeDuration() * 1000),
		_endTime = pausedTime;
	pausedData = pausedData.filter(record => {
		return record.time >= _startTime && record.time <= _endTime;
	});
}

/**
 * Callback to delete plot from chart and update property in configure panel
 * Called when a property is removed via the legend, or via the dataSelector when the
 * property cannot be trended due to an error.
 * @param property - the property which was deleted
 */
function removePropertyFromChart(property) {
	if(chartSelectElement.value === 'stacked')
	{
			dataModel.setPropsDeletionAllowed(true);
	}
	//update property to be untrended in storage and config
	let samplingModeToRemove = property.samplingMode;
	if (dataModel.getTrendType() === window.WebHMI.Components.TrendType.realtime) {
		samplingModeToRemove = null; // remove them all
		dataModel.setRealtimeVisibleProperty(property.assetName, property.propertyName, dataModel.getDefaultSamplingMode());
	}
	dataModel.removePropertyFromBrowsedList(property.assetName, property.propertyName, samplingModeToRemove);
	sessionStorageWidgetRuntime.updatePropertiesNotTrended(property.assetName, property.propertyName, samplingModeToRemove);
	trendConfigWidgetRuntime.updatePropertiesNotTrended(property.assetName, property.propertyName, samplingModeToRemove);
}
/**
 * Handle commands from the 'more' context menu
 * @param menuOption - an enum_contextMenuOptions value indicating which command was invoked
 */
function contextMenuCallBack(menuOption, ...args) {
	jQuery(contextMenuButtonElement).removeClass('selected');
	switch (menuOption) {
		case enum_contextMenuOptions.exportChart:
			const utf8_bom = '\uFEFF'; 
			if (args.length > 1) {
				let fileName = args[0];
				let delimiter = args[1];
				let csvData;
				if (delimiter === "\\t") {
					csvData = trendDisplayWidgetRuntime.exportChart('\t');
				} else {
					csvData = trendDisplayWidgetRuntime.exportChart(delimiter);
				}
				const exportedcsvData = utf8_bom + csvData
				// using FileSaver.js, saveAs function. Does not work correctly in iOS Safari < 13!
				saveAs(new Blob([exportedcsvData], { type: "text/csv;charset=utf-8" }), fileName);
			} else {
				console.warn('Export was invoked without required arguments');
			}
			break;
		case enum_contextMenuOptions.printChart:
			printHeightUsed = 0;
			trendPrintTitleElement.innerHTML = '';
			if (args.length > 0) {
				trendPrintTitleElement.innerHTML = args[0];
				printHeightUsed += 12;
			}
			trendPrintFavoriteTitleElement.innerHTML = '';
			let selectedFavorite = getSelectedFavoriteName();
			if (selectedFavorite) {
				trendPrintFavoriteTitleElement.innerHTML = selectedFavorite;
				printHeightUsed += 12;
			}
			printChart();
			break;
		case enum_contextMenuOptions.resetChart:
			// resume trending if chart is paused
			trendDisplayWidgetRuntime.pauseOrResume(true);

			//reset delta button if it is selected
			let isSelected = deltaButtonElement.classList.contains('selected');
			if (isSelected) {
				setDeltaButtonState(!isSelected);
				//set delta mode status in trend chart
				trendDisplayWidgetRuntime.toggleDeltaMode(!isSelected);
			}
			// clear favorite selection
			clearSelectedFavoriteName();
			//reset context. If context is not reset here, publish and reload context later won't work
			//since context is cached in asset browser

			dataModel.setContextAsset(window.WebHMI.Components.AssetInitialName);
			//reset properties
			sessionStorageWidgetRuntime.resetProperties();
			// publish current context to get context reload
			dataModel.setContextAsset(getSelectedAssetName());
			dataModel.setBrowsedPropertyList({ assetName: window.WebHMI.Components.AssetInitialName, properties: [] });
			if (dataModel.getTimeNowToggleValue()) {
				dataModel.setHistoricalEndTime(new Date((new Date()).getTime()));
			}
			break;
	}
}

/**
 * Return the name of the currently selected favorite.
 * @returns {*} - the value in the favorites combo box
 */
function getSelectedFavoriteName() {
	let favoriteComponent = mainElement.find('favorites-manager')[0];
	let comboBox = favoriteComponent.shadowRoot.querySelector("vaadin-combo-box.favoriteList");
	return comboBox.value;
}

/**
 * Clear the selected favorite from the combo box
 */
function clearSelectedFavoriteName() {
	let favoriteComponent = mainElement.find('favorites-manager')[0];
	if (favoriteComponent) {
		var clearedFavName = favoriteComponent._selectedFavoriteName;
		favoriteComponent.clearSelection();
		dataModel.setFavoriteLoadingStatus(window.WebHMI.Components.FavoriteLoadingStatus.none);
		return clearedFavName;
	}
}

function loadSelectedFavorite(name) {
	if(!mainElement || !name) {
		return;
	};

	let favoriteComponent = mainElement.find('favorites-manager')[0];
	if (favoriteComponent && favoriteComponent._selectedFavoriteName===name) return;
	if (favoriteComponent) {
		favoriteComponent._loadFavoriteByName(name);
		favoriteComponent._selectedFavoriteName = name;
	}
}

/**
 * Prints the current trend after scaling it to an appropriate print size
 */
function printChart() {
	const PRINT_WIDTH = 1000;
	const PRINT_HEIGHT = 640 - printHeightUsed;

	// hide session expired dialog
	sessionExpiredDialog = jQuery('#session-expired')[0];
	sessionExpiredDisplayStyle = '';
	if (sessionExpiredDialog) {
		sessionExpiredDisplayStyle = (getComputedStyle(sessionExpiredDialog)).display;
		sessionExpiredDialog.style.display = 'none';
	}

	//hide message banner if it is visible
	messageBannerElement = mainElement.find("#messageBanner");
	isMessageBannerVisible = jQuery(messageBannerElement).hasClass('visible');
	if (isMessageBannerVisible) {
		messageBannerElement.removeClass('visible');
		messageBannerElement.addClass('hidden');
	}
	//close configure panel if it is opened
	configurePanelOpened = !jQuery(trendConfigElement).hasClass('hidden');
	if (configurePanelOpened) {
		//hide configure panel
		jQuery(trendConfigElement).addClass('hidden');
		// remove highlight border from card
		jQuery(mainElement).removeClass('in-focus');
	}
	printInProgress = true;
	isShiftUpButtonVisible = !jQuery(shiftChartUpElement).hasClass('hidden');
	isShiftDownButtonVisible = !jQuery(shiftChartDownElement).hasClass('hidden');
	isShiftLeftButtonVisible = !jQuery(shiftChartLeftElement).hasClass('hidden');
	isShiftRightButtonVisible = !jQuery(shiftChartRightElement).hasClass('hidden');
	// hide pan buttons
	setShiftButtonsStates(false);
	// hide the entire trend-header area (favorites, live label, menu buttons)
	trendHeader = mainElement.find('.trend-header');
	let trendHeaderHeight = trendHeader.height(); //used for annotation dialog;
	trendHeader.addClass('hidden');

	// hide the statistics panel
	isStatisticsPanelVisible = showStatisticsValue;
	if (isStatisticsPanelVisible) {
		hideStatistics();
	}
	// apply print class to parent component wrapper to enable printing
	componentWrapperElement = jQuery(mainElement).parents('[id^="component-wrapper"]');
    if (componentWrapperElement.length) {
        componentWrapperElement.addClass('print');
    }
    
     let containerSectionElements = jQuery(mainElement).parents('.container-section');
    if (containerSectionElements.length) {
        containerSectionElements.addClass('print');
    }

	//Apply print class to new designer elements if old designer elements are not found
	if (componentWrapperElement.length === 0 && containerSectionElements.length === 0) {
		let coordinatedContainerElement = jQuery(mainElement).closest('.plug-in-component');
		if (coordinatedContainerElement.length) {
			flexContainerElement = jQuery(mainElement).closest('.flex_container.plug-in-component');
			if (flexContainerElement && flexContainerElement?.length) {
				flexContainerElement.addClass('print');
			} else {
				aspectRatioEle = jQuery(pluginElement).closest('#cardLevelAspectRatio');
				if(aspectRatioEle && aspectRatioEle.length) {
					aspectRatioEle.addClass('print');
				}
				coordinatedContainer = jQuery(mainElement).closest('.coordinated_container.plug-in-component');
				coordinatedContainer.addClass('print');
			}
		} else {
			console.error('Coordinated container element not found for new designer');
		}
		safeEnableFixedBoxModel();
	}

	let thisCard = jQuery(mainElement)[0];
	currentHeight = jQuery(thisCard).height();
	//retrieving initial chart size
	let chartElement = mainElement.find('#chart-' + trendDisplayWidgetElementId).find('.highcharts-series-group');
	let chartStyle = chartElement[0].getBoundingClientRect();
	prevChartHeight = chartStyle.height;
	prevChartWidth = chartStyle.width;

	// Set height and width to print scale.
	// screen dimension check is to handle tablets. Only scale as wide/high as the screen.
	jQuery(thisCard).width(Math.min(PRINT_WIDTH, screen.width));
	jQuery(thisCard).height(Math.min(PRINT_HEIGHT, screen.height));

	// remove margin around the entire card
	jQuery(mainElement).css('border', '0px');
}

/**
 * Calls the browser print
 */
function callBrowserPrint() {
	// Identify the Safari browser.
	if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
		isSafari = true;
	}

	// Set up a listener so we can restore previous state after printing has completed
	// This is required as the window.print() function is non-blocking on iOS Safari
	if (isSafari) {
		let printQuery = window.matchMedia('print');
		printQuery.addListener(function () {
			let screenQuery = window.matchMedia('screen');
			screenQuery.addListener(function () {
				// At this point the print dialog should be dismissed. However, on iOS,
				// this listener fires while the dialog is still open. To get a properprintpreview, we need to delay,
				// hence the timeout.
				restoreChartAfterPrint();
			});
		});

		// In Safari browser, Print pop-up does not open up immediately when window.print() is triggered. So document.execCommand is used incase of Safari.
		setTimeout(function () {
			try {
				document.execCommand('print', false, null);
			} catch (e) {
				window.print();
			}
		}, 2000);
	}
	else {
		restoreChartAfterPrint();
		setTimeout(() => {
			window.print();
		}, 2000);//timeout should be larger than the reposition timeout used in trenddisplay to capture the highcharts resize
	}
}

/**
 * Restores the size of the trend chart when print functionality is completed.
 */
function restoreChartAfterPrint() {
	if (isSafari) {
		chartRestorationTimeAfterPrint = 3000;
	} else {
		chartRestorationTimeAfterPrint = 5000;
	}
	printInProgress = false;
	setTimeout(() => {
		let thisCard = jQuery(mainElement)[0];
		// restore original border and size
		jQuery(mainElement).css('border', '');

		jQuery(thisCard).width('auto').height(currentHeight);

		if (componentWrapperElement && componentWrapperElement?.length !== 0) {
			componentWrapperElement.removeClass('print');

		} else if (flexContainerElement && flexContainerElement?.length !== 0) {
			flexContainerElement.removeClass('print');
		} else {
			if(aspectRatioEle && aspectRatioEle.length) {
				aspectRatioEle.removeClass('print');
			}
			coordinatedContainer.removeClass('print');
		}
		safeDisableFixedBoxModel();

		if (isStatisticsPanelVisible) {
			showStatistics();
		}
		trendHeader.removeClass('hidden');
		//show configure panel
		if (configurePanelOpened) {
			jQuery(trendConfigElement).removeClass('hidden');
			// highlight border of this card when config panel is open
			jQuery(mainElement).addClass('in-focus');
		}
		//show message banner
		if (isMessageBannerVisible) {
			messageBannerElement.addClass('visible');
			messageBannerElement.removeClass('hidden');
		}
		// restore display setting of session-expired dialog
		if (sessionExpiredDialog) {
			sessionExpiredDialog.style.display = sessionExpiredDisplayStyle;
		}
		//show pan buttons
		if (isShiftUpButtonVisible) {
			setShiftButtonVisibility(shiftChartUpElement, true);
		}
		if (isShiftDownButtonVisible) {
			setShiftButtonVisibility(shiftChartDownElement, true);
		}
		if (isShiftLeftButtonVisible) {
			setShiftButtonVisibility(shiftChartLeftElement, true);
		}
		if (isShiftRightButtonVisible) {
			setShiftButtonVisibility(shiftChartRightElement, true);
		}

	}, chartRestorationTimeAfterPrint);
}

function getBooleanValue(valStr, defVal) {
	var type = typeof (valStr);
	if (valStr === undefined || valStr === null || valStr === '') {
		return defVal;
	}
	let upper = type === "string" && valStr.toUpperCase();
	if (upper === 'TRUE' || upper === 'T' || upper === '1') {
		return true;
	}
	return type === "boolean" ? valStr : false;
}

let bAlreadyDestroyed = false;

function destroy() {
	if (bAlreadyDestroyed) {
		return;
	}
	bAlreadyDestroyed = true;
	console.log("%s: destroy()", trendPluginName);

	if(zIndexManager) {
		zIndexManager.destroy();
		zIndexManager = null;
	}

	if(timeChangeTimeout) {
		clearTimeout(timeChangeTimeout);
		timeChangeTimeout = null;
	}
	EMBED.unsubscribe(EQUIPMENT_CONTEXT, equipmentContextSubscribeKey);
	EMBED.unsubscribe(FAVORITES_CHANGE, favoritesChangeKey);
	EMBED.unsubscribe(FAVORITES_RELOADED, favoritesReloadedKey);

	if (widgets) {
		_.each(widgets, function (widget) {
			if (widget.hasOwnProperty("beforeDestroy")) {
				widget.beforeDestroy();
			}
		});
	}

	if (dataModel) {
		dataModel.destroy();
	}
	dataModel = null;
	socketConnector = null;
	widgets = null;

	jQuery(mainElement).html('');
}

function reloadFavorites() {
	_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
		favoritesComponent.loadFavorites();
	});
}

function equipmentContextChanged(topic, value) {
	//console.log("%s: equipmentContextChanged was triggered for topic '%s', its value is '%s'", trendPluginName, topic, value);
	if (!assetNameOverrideValue && equipmentContextValue !== value) {
		equipmentContextValue = value;
		if (!cardLoaded) {
			if (getSelectedAssetName()) {
				if (!tokenJson) {
					getToken();
				} else if(gotUserData){ // if we haven't gotten user data yet, trend will load once it does come back
					loadTrendCard();
				}
			}
		} else {
			// clear favorite selection, legend
			clearSelectedFavoriteName();
			clearLegendItems();
			// card is already loaded, just publish the context change
			dataModel.setContextAsset(window.WebHMI.Components.AssetInitialName);
			dataModel.setContextAsset(getSelectedAssetName());
			trendConfigWidgetRuntime.expandAssetsInCommonBrowser(getSelectedAssetName());
		}
	}
}

/**
 * Fired when a change to the favorites topic is published using pub/sub mechanism
 * Used to alert other instances of the trend favorite component of changes, so if multiple plugins exist
 * on a single page, changes to favorites on one are reflected on the other(s)
 * @param {string} topic Topic published using pub/sub mechanism in plugin.  In this case, FAVORITES_CHANGE from constants.js
 * @param {object} value Value that was published
 */
function favoritesChanged(topic, value) {
	_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
		favoritesComponent.favoritesChanged(value);
	});
}

let modelTags = [];
function _getPropertyKey(prop) {
	let keyName;
	// if (prop.isModelBased) {
	// 	if (!modelTags.includes(prop.assetName)) {
	// 		modelTags.push(prop.assetName)
	// 	}
	// }
	let assetName = prop.assetName || null ;
	if (prop.dataSourceType === "objects" || modelBasedTags.includes(assetName)) {
		if(prop.id){
			keyName = prop.id.split('$$');
			keyName = `${keyName[0]}${keyName[1]}`;
		}else{
			let individualPropName= prop.name || prop.propertyName;
			keyName= `${prop.assetName}${individualPropName}`
		}
	} else {
		keyName = prop.name || prop.propertyName || "";
	}
	let keySampling = (dataModel.getTrendType().toLowerCase() === window.WebHMI.Components.TrendType.historical) ? (prop.samplingMode || "") : "";
	let key = (keyName + keySampling);
	return key.replace(/[^a-zA-Z0-9]/g, "");
}

function propertyMatchCheck(propName, assetName, samplingMode, legendPropObj) {
	let legendPropName = legendPropObj.name || legendPropObj.propertyName;
	let legendPropAsset = legendPropObj.assetName || legendPropObj.systemAlias || legendPropObj.systemName;
	let legendPropSampling = legendPropObj.samplingMode;

	let match = (propName===null || propName === legendPropName) && (assetName===null || assetName===legendPropAsset) && (samplingMode===null || samplingMode===legendPropSampling);
	return match;
}

function _updateTabularTrend(data = null) {
	// console.log(data,"updateTabularTrend-1")
	// dataModel.setHistoricalDuration('3600');
	// let hisDuration = dataModel.getHistoricalDuration()
	// dataModel.setHistoricalDuration(hisDuration);

	//let trendData = data || dataModel.getTabularTrends();
	attrProp = [];
	let trendData = (chartPaused && (dataModel.getTrendType() == window.WebHMI.Components.TrendType.realtime)) ? pausedData : data || dataModel.getTabularTrends();
	dataModel.setTabularViewHeight(tabularViewHeight);
	if (dataModel.getChartDropdownType() == 'tabular') {
		tabularComponent.hidden = false;
		$(tabularComponent).show();
		$(chartElement).hide();
	}
	let tabularItems = [];
	let propList = dataModel.getAllPropertiesWithAttributes();
	let trendType = dataModel.getTrendType();
	for (let key in propList) {
		propList[key].properties.length >= 1 && propList[key].properties.forEach((e) => {
			e.assetName = key;
			if(propList[key].hasOwnProperty('historianServer') || propList[key].hasOwnProperty('opcuaServer')) {
				e.isDirectTag = true;
				e.isModelBased = false;
			} else {
				e.isDirectTag = false;
				e.isModelBased = true;
			}
			if(e.isModelBased){
				if(!modelBasedTags.includes(e.assetName)){
					modelBasedTags.push(e.assetName)
				}
			}
			let tabularComponent = jQuery(mainElement).find('trend-tabular-view')[0];
			tabularComponent.setAttribute('modelbasedtags', JSON.stringify(modelBasedTags));
		})
		// don't need to add the whole list of properties for every property, just once per asset
		let assetProps = propList[key].properties;
		attrProp = [...attrProp, ...assetProps];
	}
	if (attrProp.length > 0) {
		attrProp = attrProp.filter((value, index) => {
			let _value = JSON.stringify(value);
			return index === attrProp.findIndex(obj => {
				return JSON.stringify(obj) === _value;
			});
		});
		if (trendType !== 'realtime') {
			attrProp = attrProp.filter(item => {
				return (item.systemType!==undefined && item.systemType !== 'OPCUA') || (item.sourceType!==undefined && item.sourceType.toLowerCase() !== "realtime");
			})
		}
	}

	attrProp = attrProp.filter(e => e.visible !== false);
	tableData = dataModel.getTabularProperties()

	if(attrProp.length>0){
		tablularData = trendData
	}
	if (trendData && Array.isArray(trendData)) {

		trendData = trendData.filter(x => {
			return attrProp.filter(item => {
				if (item.systemType === 'OPCUA' || x.systemType === undefined) {
					return item.propertyName == x.name
				} else if (item.systemType === 'HISTORIAN') {
					return item.propertyName == x.name && item.systemAlias == x.assetName
				} else {
					return item.propertyName == x.name && item.systemName == x.assetName
				}
			}).length > 0
		})
		let groupedByTime = {};
		trendData.forEach(x => {
			if (groupedByTime.hasOwnProperty(x.time)) {
				groupedByTime[x.time] = [...groupedByTime[x.time], x];
			} else {
				groupedByTime[x.time] = [x];
			}
		})
		for (const key in groupedByTime) {
			if (Object.hasOwnProperty.call(groupedByTime, key)) {
				const element = groupedByTime[key];
				let obj = {}
				let dateSplit = new Date(key);
				obj['TIMESTAMP'] = `${dateSplit}`;
				// columns = ["TIME STAMP", ...attrProp.map(x => x.name.replace('.', '_'))]
				//columns = ["TIMESTAMP", ...attrProp.map(x => x.name ? x.name.replace(/[^a-zA-Z0-9]/g,"") : x.propertyName.replace(/[^a-zA-Z0-9]/g,""))]
				let columns = ["TIMESTAMP", ...attrProp.map(x => _getPropertyKey(x))]
				if (Array.isArray(element)) {
					element.forEach(x => {
						//let keyName = (x.name).replace(/[^a-zA-Z0-9]/g,"");
						let keyName = _getPropertyKey(x);
						if (x.value && x.value.value) {
							if(x.quality && x.quality>0){
								obj[keyName] = "-";
							}else {
								if(x.value.value === 1) {
									obj[keyName] = "1"; // boolean shows as 0/1
								} else {
									obj[keyName] = x.value.value.toFixed(2) + '';
								}
							}
						} else if(x.value.value === 0){
							if(x.quality && x.quality>0){
								obj[keyName] = "-";
							}else{
								obj[keyName] = "0";
							}
						}else{
							obj[keyName] = "-";
						}

					})

				}
				columns.forEach(x => {
					if (!Object.hasOwnProperty.call(obj, x)) {
						if(obj[x] === undefined){
						obj[x] = '-'

						}else{
							obj[x] = '0.00'

						}
					}
				})

				tabularItems.push(obj);
			}
		}

		tabularItems = tabularItems.sort(function (a, b) {
			return new Date(b['TIMESTAMP']) - new Date(a['TIMESTAMP']);
		}).map(x => {
			let dateSplit = new Date(x['TIMESTAMP']).toLocaleString()
			x['TIMESTAMP'] = `${dateSplit}`;
			return x;
		});
		//checkpoint1
		if (chartSelectElement.value === "tabular") {
			tabularComponent.setAttribute('trendtype', dataModel.getTrendType());
			tabularComponent.setAttribute('allproperties', JSON.stringify(filterSamplingModesForRealtime(attrProp)));
			tabularComponent.setAttribute('items', JSON.stringify(tabularItems));
			tabularComponent.setAttribute('tagdisplaymode', dataModel.getTagDisplayMode());
			//if (tabularViewHeight) tabularComponent.setAttribute('tabularheight', tabularViewHeight);
		}
	}
}

/**
 * For tabular view, if mode=realtime, filter out extra sampling modes
 * @param {object} properties
 */
function filterSamplingModesForRealtime(properties) {
	if(dataModel.getTrendType().toLowerCase() === window.WebHMI.Components.TrendType.historical) {
		// no change necessary
		return properties;
	}

	let visibleProperties = [];
	let realtimeVisibleProps = dataModel.getRealtimeVisibleProperties();

	properties.forEach(function (prop) {
		if(prop) {
			let assetName = prop.assetName;
			let propName = prop.propertyName;
			let samplingMode = prop.samplingMode;
			if(realtimeVisibleProps.hasOwnProperty(assetName)) {
				if(realtimeVisibleProps[assetName].hasOwnProperty(propName)) {
					let visibleSamplingMode = realtimeVisibleProps[assetName][propName];
					let isVisible = (samplingMode === visibleSamplingMode);
					if(isVisible) {
						visibleProperties.push(prop);
					}
				}
			}
		}
	});
	return visibleProperties;
}

/**
 * Convert the trending property list to an array of legend items
 * @param propertyList - the properties from the Config panel
 * @returns {Array} of properties formatted for the legend
 */
function convertPropertyListToLegendProperties(propertyList) {
	let newProperties = [];
	if (propertyList && propertyList.properties) {
		propertyList.properties.forEach(function (value) {
			if (value.color && value.color !== "") {

				// avoid bad data. sourceType can be null if property is configured as Trendable but not given a datasource in OpHub
				if (value.sourceType && value.sourceType !== "") {
					const sourceType = value.sourceType.toLowerCase();
					const trendType = window.WebHMI.Components.TrendType;
					// only plot if the chart is in realtime mode or the chart is in historical mode and the source is also historical
					if (
						dataModel.getTrendType().toLowerCase() === trendType.realtime ||
						sourceType === trendType.historical ||
						sourceType === trendType.both
					) {
						let property = {
							"assetName": propertyList.assetName,
							"historianServer": propertyList.historianServer,
							'propertyName': value.propertyName,
							'color': value.color,
							'visible': value.visible,
							'lineWidth': value.lineWidth || window['WebHMI']['Components']['TrendLineWidth'],
							'lineStyle': value.lineStyle || window['WebHMI']['Components']['TrendLineStyle'],
							'samplingMode': value.samplingMode,
							'inContext': propertyList.assetName === getSelectedAssetName(),
							'lastItem': false,
							'hasRealtimeSource': value.hasRealtimeSource,
							'hasHistoricalSource': value.hasHistoricalSource,
							'systemAlias': value.systemAlias,
							"units": value.units,
							"description": value.description,
							"chartType": value.chartType || window['WebHMI']['Components']['TrendChartType'],
							"yAxisLabel":value.yAxisLabel || window['WebHMI']['Components']['TrendYAxisLabel'],
							"yAxisPosition":value.yAxisPosition || window['WebHMI']['Components']['TrendYAxisPosition'],
							// "queryList" : value.queryList || [],
							bindingType: value.sourceType,
							systemName: value.systemName,
							propertyDatatype: value.dataType,
							systemType: value.systemType,
							name: value.name,
							attributes: [],
							nodeId: value.nodeId,
							dataSourceType: value.dataSourceType,
							bindings: value.bindings,
							id: value.id,
							'axisConfig': value.axisConfig || window['WebHMI']['Components']['TrendAxisConfig']
						};
						logger.log(logger.LogLevel.Debug, 1, "convertPropertyListToLegendProperties: pushing property %O", property);
						newProperties.push(property);
					}
				}
			}
		});
	}

	if (newProperties.length > 0) {
		newProperties[newProperties.length - 1].lastItem = true;
	}
	return newProperties;
}

/**
 * Clear out the legend when the card is reloaded.
 * Primarily used to clean the slate for unit tests.
 */
function resetLegendItems() {
	let propertyList = { "assetName": "", "properties": [] };
	updateLegendItems(propertyList);
}

/**
 * Remove all items from the legend
 */
function clearLegendItems() {
	let legendComponent = jQuery(legendContainerElement).find('trend-chart-legend')[0];
	if (legendComponent) {
		legendComponent.setAttribute('legenditems', '[]');
	}
}

/**
 * updates the properties in the common browser and checks the properties.
 * @param itemsList - propertylist that are trending
 */
function updateCommonBrowserProperties(itemsList) {
	const properties = itemsList.reduce((res, { properties = [] }) => {
		const items = properties.length ? properties.map((i) => i.id || `${i.assetName}$$${i.propertyName}`) : [];
		res = [...res, ...items];
		return res;
	}, []);
	trendConfigWidgetRuntime.updateBrowserSelectedItems(properties, true);

	if (properties.length === 0 && dataModel.getUncommittedValue("TrendType") === window.WebHMI.Components.TrendType.historical) {
		let historianSamplingComponent = jQuery(trendConfigElement).find('historian-sampling')[0];
		historianSamplingComponent.changeInfoIconColor = 'sampling-info-color';
		if (dataModel.getUncommittedValue("HistoricalSamplingIncrementType") === 'ByTime') {
			//historianSamplingComponent.defaultSizeInPopover = 8000;
			//historianSamplingComponent.requestedSizeInPopover = 0;
			historianSamplingComponent.highlightIncrementField = false;
		} else if (dataModel.getUncommittedValue("HistoricalSamplingIncrementType") === 'ByCount') {
			//historianSamplingComponent.defaultSizeInPopover = 8000;
			//historianSamplingComponent.requestedSizeInPopover = 0;
		}
	}

	if (properties.length === 0) {
		trendDisplayWidgetRuntime.resetFakeDataList();
	}
}

/**
 * Rebuild legend content from currently plotted properties.
 * @param propertyList - the properties from the Config panel
 */
 function updateLegendItems(propertyList) {
	 let legendComponent = jQuery(legendContainerElement).find('trend-chart-legend')[0];
	 let legendItems = JSON.parse(legendComponent.getAttribute('legenditems'));

	 legendComponent.setAttribute('trendtype', dataModel.getTrendType());
	let previousLegendCount = legendItems.length;
	let rtVisibleProperties = dataModel.getRealtimeVisibleProperties();

	// adding type of mode to propertylist
	let modeType = dataModel.getTrendType();
	propertyList.modeType = modeType;


	if (propertyList) {
		let newProperties = convertPropertyListToLegendProperties(propertyList);

		// get the legend item for this propertyList asset (might be undefined)
		let assetItem = legendItems.find(item => {
			return item.assetName === propertyList.assetName;
		});

		if (!assetItem) {
			if (newProperties.length > 0) {
					assetItem = {
						"assetName": propertyList.assetName ? propertyList.assetName : getSelectedAssetName(),
						'properties': newProperties
					};
					legendItems.push(assetItem);
			}
		} else {
			if (newProperties.length > 0) {
				let properties = [];
				newProperties.forEach(function (property) {
					let foundProperty = false;
					//keep properties from legend panel so aggregation values won't be cleared
					for (let i = 0; i < assetItem.properties.length; i++) {
						if (assetItem.properties[i].propertyName === property.propertyName && assetItem.properties[i].samplingMode === property.samplingMode) {
							assetItem.properties[i].lastItem = false;
							assetItem.properties[i].color = property.color;
							assetItem.properties[i].visible= property.visible;
							assetItem.properties[i].lineWidth = property.lineWidth;
							assetItem.properties[i].lineStyle = property.lineStyle;
							assetItem.properties[i].axisConfig = property.axisConfig;
							assetItem.properties[i].chartType = property.chartType;
							assetItem.properties[i].yAxisLabel= property.yAxisLabel;
							assetItem.properties[i].yAxisPosition= property.yAxisPosition;
							// assetItem.properties[i].queryList= property.queryList;
							properties.push(assetItem.properties[i]);
							foundProperty = true;
							break;
						}
					}
					//new property
					if (!foundProperty) {
						property.lastItem = false;
						properties.push(property);
					}
				});
				assetItem.properties = properties;
			} else {
				// remove asset from legend
				legendItems.splice(legendItems.findIndex(item => item.assetName === propertyList.assetName), 1);
			}
		}
	}
	// update all legend items to set inContext flag in case of context asset change
	legendItems.forEach(function (item) {
		item.properties.sort((a, b) => TrendCommon.localeSort(a.propertyName, b.propertyName));
		item.properties.forEach(function (property) {
			property.inContext = item.assetName === getSelectedAssetName();
			property.displayText = property.propertyName;
		});
		//set last item
		if (item.properties.length > 0) {
			item.properties[item.properties.length - 1].lastItem = true;
		}
	});

	let legendItemsToDisplay = window.WebHMI.Components.TrendCommon.cloneArrayOfObjects(legendItems);
	if (dataModel.getTrendType() === window.WebHMI.Components.TrendType.realtime) {
		if (rtVisibleProperties) {
			legendItemsToDisplay.forEach(function (item) {
				let legendAssetName = item.assetName;
				if (rtVisibleProperties.hasOwnProperty(legendAssetName)) {
					// if we have a list of visible property/sampling modes, use that to filter legend
					let filteredProperties = _.filter(item.properties, function (p) {
						if (rtVisibleProperties[legendAssetName].hasOwnProperty(p.propertyName)) {
							return rtVisibleProperties[legendAssetName][p.propertyName] === p.samplingMode;
						} else {
							return true;
						}
					});
					if (filteredProperties) {
						item.properties = filteredProperties;
					}
				}
			});

		}
	}

	logger.log(logger.LogLevel.Info, 0, `updateLegendDisplay: legendItemsToDisplay.length = ${legendItemsToDisplay.length}`);
	legendComponent.setAttribute('legenditems', JSON.stringify(legendItemsToDisplay));
	updateCommonBrowserProperties(legendItems);
	dataModel.setLegendItems(legendItems);
	sessionStorageWidgetRuntime.saveTrendColors(legendItems);
	//update chart message
	//first property is selected to trend. show loading message
	if (previousLegendCount === 0 && legendItems.length > 0) {
		trendDisplayWidgetRuntime.toggleLoadingMessage(true);
	}
	//Last trended property is unselected. show no data message
	if (previousLegendCount > 0 && legendItems.length === 0) {
		trendDisplayWidgetRuntime.showNoTrendDataMessage();
	}

	// send properties to favorite component
	// legend is the 'source of truth' for what properties are on the chart and should be saved to the favorite
	// In-context properties are saved to a favorite without the current context, so that they can be loaded when viewing other assets
	// This allows someone to save a 'MyPump' favorite with pump-related properties and load it on any pump
	_.each(jQuery(mainElement.find('favorites-manager')), function (favoritesComponent) {
		let allFavoriteProperties = [];
		legendItems.forEach(function (item) {
			item.properties.forEach(function (property) {
				const server = property.dataSourceType && property.dataSourceType.toLowerCase() !== 'objects' ? { [property.dataSourceType + 'Server']: property.systemName } : {}
				allFavoriteProperties.push({
					...property,
					...server,
					assetName: (property.assetName === getSelectedAssetName()) ? '' : property.assetName,
				});
			});
		});

		favoritesComponent.trendSettingChanged("properties", allFavoriteProperties);
		publishCurrentSettings(favoritesComponent);
	});

}



/**
 * Display a message to the user
 * @param messageType - the message type (window.WebHMI.Components.MessageType)
 * @param messageTitle - the message title (optional, set to null or '' to use default)
 * @param messageText - the message text
 */
function showMessage(messageType, messageTitle, messageText) {
	logger.log(logger.LogLevel.Debug, 0, `showMessage: ${messageType}:${messageTitle}:${messageText}`);
	let MessageType = window.WebHMI.Components.MessageType;
	switch (messageType) {
		case MessageType.error:
			messageBanner.addError((messageTitle || localizer.translate('Error')), messageText, false);
			break;
		case MessageType.warning:
			messageBanner.addWarning((messageTitle || localizer.translate('Warning')), messageText, false);
			break;
		case MessageType.info:
			messageBanner.addMessage((messageTitle || ''), messageText, true);
			break;
	}
}

/**
 * Remove all messages from the messageBanner
 */
function removeMessages() {
	logger.log(logger.LogLevel.Debug, 0, `removeMessages:`);
	messageBanner.removeAllMessages();
}

/**
 * Hide the favorites controls
 * Used for printing
 */
function hideFavoriteControls() {
	let faveControl = mainElement.find('.trend-header-favorites');
	console.log("faveControl=%O", faveControl);
	faveControl.addClass('hidden');
}

let chartDataSourcesSelected = false;
let chartPaused = false;
let chartPauseAllowed = true;

/**
 * Update the chart headers to reflect the current state of the chart.
 * @param dataSourcesSelected - true if data sources have been selected (vs an empty chart)
 * @param paused - true if data is trending, but the chart is paused
 * @param pauseAllowed - true if data is trending, but pausing is not allowed (ie: when zoomMode === 'Y')
 */
function updateChartHeaders(dataSourcesSelected, paused, pauseAllowed) {

	chartDataSourcesSelected = dataSourcesSelected;
	chartPaused = paused;
	chartPauseAllowed = pauseAllowed;

	let titleTextElement = mainElement.find('.header-setting-text'); // Live/Paused/Historical text

	if (dataModel.getTrendType() === window.WebHMI.Components.TrendType.historical) {
		titleTextElement.text(historicalText);
		if (dataSourcesSelected) {
			titleTextElement[0].title = showingHistoricalData;
		} else {
			titleTextElement[0].title = noTrendData;
		}
		// hide the Pause/Resume button, doesn't apply in Historical mode
		jQuery(pauseResumeSectionElement).addClass('hidden');
		// hide the Pan button in the historical mode.
		jQuery(panButtonElement).addClass('hidden');
		return;
	}
	// chart is Realtime
	jQuery(pauseResumeSectionElement).removeClass('hidden');
	jQuery(panButtonElement).removeClass('hidden');
	// no trends selected, disable the Pause button
	if (!dataSourcesSelected || !pauseAllowed) {
		titleTextElement.text(liveText);
		titleTextElement[0].title = dataSourcesSelected ? dataIsFlowing : noTrendData;
		jQuery(pauseResumeButtonElement).addClass('disabled');
		return;
	}
	// data sources are selected and pause is allowed
	jQuery(pauseResumeButtonElement).removeClass('disabled');
	if (paused) {
		titleTextElement.text(pausedText);
		titleTextElement[0].title = dataNotFlowing;
	} else {
		titleTextElement.text(liveText);
		titleTextElement[0].title = dataIsFlowing;
	}

	// update the Pause/Resume button with appropriate text and tool tip
	if (paused) {
		jQuery(pauseResumeButtonElement).removeClass('ge-icon-pause');
		jQuery(pauseResumeButtonElement).addClass('ge-icon-play');
		pauseResumeButtonElement.setAttribute('title', resumeButtonTooltip);
	} else {
		jQuery(pauseResumeButtonElement).removeClass('ge-icon-play');
		jQuery(pauseResumeButtonElement).addClass('ge-icon-pause');
		pauseResumeButtonElement.setAttribute('title', pauseButtonTooltip);
	}
}

/**
 * Update the state of the delta button
 * @param selected - Selected state of the button
 */
function setDeltaButtonState(selected) {
	if (selected === true) {
		jQuery(deltaButtonElement).addClass('selected');
	} else {
		jQuery(deltaButtonElement).removeClass('selected');
	}
}

/**
 * Update the title display in the header
 */
function updateTitleDisplay() {
	// update in both locations
	jQuery(trendChartTitleElement).attr("title", chartTitleValue);
	jQuery(trendChartTitleElement).find('div.header-title-text').text(chartTitleValue);
	jQuery(mainElement).find('#trendAltTitle').text(chartTitleValue);

	// set appropriate visibility
	const altTitle=document.getElementById("trendAltTitle");
	if(chartTitleValue==="" || chartTitleValue===null) { // no title, hide elements
		jQuery(trendChartTitleElement).addClass('hidden');
	} else { // There is a title, show it
		if(showHeaderValue) { // full header
			jQuery(trendChartTitleElement).removeClass('hidden');
		} else { // header collapsed
			jQuery(trendChartTitleElement).addClass('hidden');
		}
	}
}

/**
 * Update the time display in center of header
 */
function updateTimeDisplay() {
	let updateTime = false;
	if (lastDisplayedTrendType !== dataModel.getTrendType()) {
		lastDisplayedTrendType = dataModel.getTrendType();
		updateChartHeaders(chartDataSourcesSelected, chartPaused, chartPauseAllowed);
		updateTime = true;
	}
	if (lastDisplayedTrendRealtimeDuration !== dataModel.getRealtimeDuration()) {
		lastDisplayedTrendRealtimeDuration = dataModel.getRealtimeDuration();
		updateTime = true;
	}
	if (lastDisplayedTrendHistoricalDuration !== dataModel.getHistoricalDuration()) {
		lastDisplayedTrendHistoricalDuration = dataModel.getHistoricalDuration();
		updateTime = true;
	}

	if (updateTime) {
		let settingsTimeElement = mainElement.find('.trend-header-setting-time');

		if (dataModel.getTrendType() !== null) {
			let displayString = (dataModel.getTrendType() === window.WebHMI.Components.TrendType.realtime) ?
				'Last ' + TrendCommon.getDurationDisplayString(dataModel.getRealtimeDuration()) : TrendCommon.getDurationDisplayString(dataModel.getHistoricalDuration());
			settingsTimeElement.text(displayString);
		}
	}
	// Whenever trendType or duration changed and reset zoom option is available force hide
	// if reset zoom option not visible and trendType or duration changed in historical mode disable pan option
	if (jQuery(resetZoomButtonElement).is(':visible')) {
		if (dataModel.getTrendType() === window.WebHMI.Components.TrendType.realtime) {
			trendDisplayWidgetRuntime.disableResetZoomOption();
		}
	} else if (dataModel.getTrendType() === window.WebHMI.Components.TrendType.historical) {
		jQuery(panButtonElement).addClass('disabled');
	}
}

function tokenChanged(newToken) {
	if (socketConnector) {
		socketConnector.setSessionJsonWebToken(newToken);
	}
}

function formatColor(colorObj) {
	if (colorObj.hex === undefined) {
		return JSON.parse(colorObj);
	}
	return colorObj;
}

function init(data) {
	data = data || EMBED.getComponent();

	// special handling for time changes - do not reload card at all
	handlePluginData(EMBED, data, ["trendTypeInput", "trendRealtimeDurationInput", "trendHistoricalEndDateTimeInput", "trendHistoricalDurationInput"], function (values) {
		if(publishInProgress) return;
				
		var newValues = {};
		$.extend(newValues, previouslyLoadedTimeData, values);

		// if data hasn't changed since last call, don't respond
		if (values && values.schema && values.schema.data && previouslyLoadedTimeData && _.isEqual(values.schema.data, previouslyLoadedTimeData)) {
			return;
		}
		var valuesData = (values && values.schema && values.schema.data) || values;

		trendTypeInput = formatSubscriptionData(getInputValue(newValues, "trendTypeInput", trendTypeInput), data.schema.data, "trendTypeInput");
		trendRealtimeDurationInput = formatSubscriptionData(getInputValue(newValues, "trendRealtimeDurationInput", trendRealtimeDurationInput), data.schema.data, "trendRealtimeDurationInput");
		trendHistoricalEndDateTimeInput = formatSubscriptionData(getInputValue(newValues, "trendHistoricalEndDateTimeInput", trendHistoricalEndDateTimeInput), data.schema.data, "trendHistoricalEndDateTimeInput");
		trendHistoricalDurationInput = formatSubscriptionData(getInputValue(newValues, "trendHistoricalDurationInput", trendHistoricalDurationInput), data.schema.data, "trendHistoricalDurationInput");
		if(!cardLoaded) return; // cannot process values yet

		let valueChanged = function(key, oldValues, newValues) {
			let oldVal = oldValues.hasOwnProperty(key) ? oldValues[key] : null;
			let newVal = newValues.hasOwnProperty(key) ? newValues[key] : null;
			return oldVal!==newVal;
		}

		let queueChange = function(key, value) {
			let result = changedTimeValues.find(({ propertyName }) => propertyName === key);
			if(result) {
				result.propertyValue=value;
			} else {
				changedTimeValues.push({propertyName: key, propertyValue: value});
			}
			
		}
		
		// Realtime Duration
		if(valueChanged('trendRealtimeDurationInput', previouslyLoadedTimeData, newValues)) {
			let durationNumber = parseInt(newValues.trendRealtimeDurationInput);
			let currentVal = dataModel.getRealtimeDuration();
			if(!isNaN(durationNumber) && durationNumber>0 && currentVal!==durationNumber) {
				dataModel.removeUncommittedValue('realtimeDuration');
				dataModel.removeUncommittedValue('timeNowToggle');
				queueChange(TrendDataModelProperties.realtimeDuration, durationNumber);
			}
		}
		// Historical End Time
		if(valueChanged('trendHistoricalEndDateTimeInput', previouslyLoadedTimeData, newValues)) {
			if(newValues.trendHistoricalEndDateTimeInput) {
				let endDateObj = new Date(newValues.trendHistoricalEndDateTimeInput);
				let currentDate = dataModel.getHistoricalEndTime();
				if(endDateObj.getTime()!==currentDate.getTime()) {
					dataModel.removeUncommittedValue('historicalEndTime');
					dataModel.removeUncommittedValue('timeNowToggle');
					dataModel.setTimeNowToggleValue(false);
					queueChange(TrendDataModelProperties.timeNowToggle, false);
					queueChange(TrendDataModelProperties.historicalEndTime, endDateObj);
				}
			}
		}
		// Historical Duration
		if(valueChanged('trendHistoricalDurationInput', previouslyLoadedTimeData, newValues)) {
			let durationNumber = parseInt(newValues.trendHistoricalDurationInput);
			let currentVal = dataModel.getHistoricalDuration();
			if(!isNaN(durationNumber) && durationNumber>0 && currentVal!==durationNumber) {
				dataModel.removeUncommittedValue('historicalDuration');
				queueChange(TrendDataModelProperties.historicalDuration, durationNumber);
			}
		}
		// Trend Type
		if(valueChanged('trendTypeInput', previouslyLoadedTimeData, newValues)) {
			if(newValues.trendTypeInput) {
				let inputVal = newValues.trendTypeInput.toLowerCase();
				let currentVal = dataModel.getTrendType();
				if((inputVal==="realtime" || inputVal==="historical") && currentVal!==inputVal) {
					trendTypeInput = inputVal;
					dataModel.removeUncommittedValue('trendType');
					queueChange(TrendDataModelProperties.trendType, trendTypeInput);
				}
			}
		}
		
		// wait a bit before setting in model, in case more changes incoming.
		if(changedTimeValues.length) {
			if(timeChangeTimeout) {
				clearTimeout(timeChangeTimeout);
			}
			timeChangeTimeout = setTimeout(function(){
				dataModel.setMultipleValues(changedTimeValues, false, 'TrendConfigurationChanged');						
				changedTimeValues = [];
			}, 50);
		}

		previouslyLoadedTimeData = JSON.parse(JSON.stringify(valuesData));
	});

	var pluginInputNames = [
		"AssetName", "Height", "StackedHeight", "TabularViewHeight", "ChartTitle", "XAxisLabel", "YAxisLabel",
		"DefaultSamplingMode", "HistorianTagPageSize", "ShowHeaderControls",
		"ShowTrendValueAxes", "ShowTrendLegend", "ShowFavorites", "selectFavorite", "trendTagsInput",
		"trendConfigInput", "ScrollPercentage", "LoggingLevel", "LoggedInUserName",
		"TimeFormatMode","CustomTimeFormat"
	];

	handlePluginData(EMBED, data, pluginInputNames, function (values) {
		var newValues = {};
		$.extend(newValues, previouslyLoadedData, values);

		// if data hasn't changed since last init() call, don't reload chart
		if (values && values.schema && values.schema.data && previouslyLoadedData && _.isEqual(values.schema.data, previouslyLoadedData)) {
			return;
		}

		mainElement = EMBED.getRootElement().find('.geTrendCard');
		//get main page element. It is used to get top position for configure panel
		mainPageElement = document.getElementsByClassName('main-page')[0];
		if (!jQuery(mainElement)[0]) {
			return;
		}

		var valuesData = (values && values.schema && values.schema.data) || values;

		// don't change this to logger.log. Otherwise there's no statement to latch onto open main.js from dev console
		console.log(`init: data = ${JSON.stringify(data)}`);
		if(publishInProgress) return;
		
		assetNameOverrideValue = formatSubscriptionData(getInputValue(newValues, "AssetName"), data.schema.data, "AssetName");

		let pageSize = Number(formatSubscriptionData(getInputValue(newValues, "HistorianTagPageSize"), data.schema.data, "HistorianTagPageSize"));
		if (!Number.isNaN(pageSize)) {
			historianTagPageSizeValue = pageSize;
		}
		stackedYaxisHeight = '100px';
		stackedHeight = formatSubscriptionData(getInputValue(newValues, "StackedHeight", stackedHeight), data.schema.data, "StackedHeight");
		stackedYaxisHeight = stackedHeight;
		heightValue = formatSubscriptionData(getInputValue(newValues, "Height", heightValue), data.schema.data, "Height");
		chartTitleValue = formatSubscriptionData(getInputValue(newValues, "ChartTitle", chartTitleValue), data.schema.data, "ChartTitle");
		xAxisLabelValue = formatSubscriptionData(getInputValue(newValues, "XAxisLabel", xAxisLabelValue), data.schema.data, "XAxisLabel");
		yAxisLabelValue = formatSubscriptionData(getInputValue(newValues, "YAxisLabel", yAxisLabelValue), data.schema.data, "YAxisLabel");
		tabularViewHeight = formatSubscriptionData(getInputValue(newValues, "TabularViewHeight", tabularViewHeight), data.schema.data, "TabularViewHeight");
		showTrendValueAxesValue = getBooleanValue(formatSubscriptionData(getInputValue(newValues, 'ShowTrendValueAxes', showTrendValueAxesValue), data.schema.data, "ShowTrendValueAxes"));
		showTrendLegendValue = getBooleanValue(formatSubscriptionData(getInputValue(newValues, 'ShowTrendLegend', showTrendLegendValue), data.schema.data, "ShowTrendLegend"));
		showFavoritesValue = getBooleanValue(formatSubscriptionData(getInputValue(newValues, 'ShowFavorites', showFavoritesValue), data.schema.data, "ShowFavorites"));
		defaultSamplingMode = formatSubscriptionData(getInputValue(newValues, "DefaultSamplingMode", defaultSamplingMode), data.schema.data, "DefaultSamplingMode");
		selFavName = formatSubscriptionData(getInputValue(newValues, 'selectFavorite', selFavName), data.schema.data, "selectFavorite") || selFavName;
		trendTagsInput = formatSubscriptionData(getInputValue(newValues, "trendTagsInput", ""), data.schema.data, "trendTagsInput");
		trendConfigInput = formatSubscriptionData(getInputValue(newValues, "trendConfigInput", "{}"), data.schema.data, "trendConfigInput");
		let trendConfigInputString = trendConfigInput;
		trendTypeInput = formatSubscriptionData(getInputValue(newValues, "trendTypeInput", trendTypeInput), data.schema.data, "trendTypeInput");
		trendRealtimeDurationInput = formatSubscriptionData(getInputValue(newValues, "trendRealtimeDurationInput", trendRealtimeDurationInput), data.schema.data, "trendRealtimeDurationInput");
		trendHistoricalEndDateTimeInput = formatSubscriptionData(getInputValue(newValues, "trendHistoricalEndDateTimeInput", trendHistoricalEndDateTimeInput), data.schema.data, "trendHistoricalEndDateTimeInput");
		trendHistoricalDurationInput = formatSubscriptionData(getInputValue(newValues, "trendHistoricalDurationInput", trendHistoricalDurationInput), data.schema.data, "trendHistoricalDurationInput");

		let prevShowHeaderValue = getBooleanValue((previouslyLoadedData && previouslyLoadedData.hasOwnProperty('ShowHeaderControls')) ? previouslyLoadedData.ShowHeaderControls : true, true);
		let newShowHeaderValue = getBooleanValue(formatSubscriptionData(getInputValue(newValues, 'ShowHeaderControls', showHeaderValue), data.schema.data, "ShowHeaderControls"));
		if(prevShowHeaderValue!==newShowHeaderValue) {
			showHeaderValue = newShowHeaderValue;
		}

		let prevTimeFormatModeValue = getBooleanValue((previouslyLoadedData && previouslyLoadedData.hasOwnProperty('TimeFormatMode')) ? previouslyLoadedData.TimeFormatMode : true, true);
		let prevCustomTimeFormatValue = getBooleanValue((previouslyLoadedData && previouslyLoadedData.hasOwnProperty('CustomTimeFormat')) ? previouslyLoadedData.CustomTimeFormat : true, true);
		timeFormatModeValue = formatSubscriptionData(getInputValue(newValues, "TimeFormatMode", timeFormatModeValue), data.schema.data, "TimeFormatMode");
		customTimeFormatValue = formatSubscriptionData(getInputValue(newValues, "CustomTimeFormat", customTimeFormatValue), data.schema.data, "CustomTimeFormat");

		/*
		console.log("%c %s: plugin input changed, data.schema.data=%O, newValues=%O, values=%O, previouslyLoadedData=%O, trendTypeInput=%O, trendRealtimeDurationInput=%O, trendHistoricalEndDateTimeInput=%O, trendHistoricalDurationInput=%O", 'color:red', 
			trendPluginName, data.schema.data, JSON.parse(JSON.stringify(newValues)), JSON.parse(JSON.stringify(values)), JSON.parse(JSON.stringify(previouslyLoadedData)), trendTypeInput, trendRealtimeDurationInput, trendHistoricalEndDateTimeInput, trendHistoricalDurationInput);
		*/

		if (typeof trendConfigInput === 'string') {
			try {
				trendConfigInput = JSON.parse(trendConfigInput);
			} catch (e) {
				trendConfigInput = {};
			}
		}
		// code added to handle case when user binds to both selectFavorite and trendConfigInput
		if(newValues.hasOwnProperty('selectFavorite') && newValues.hasOwnProperty('trendConfigInput')) {
			// both properties specified - which changed most recently?
			if(previouslyLoadedData) {
				if(!previouslyLoadedData.hasOwnProperty('selectFavorite')) {
					// just set fave name
					trendConfigInput = {};
				} else if(!previouslyLoadedData.hasOwnProperty('trendConfigInput')) {
					// just set config
					selFavName = '';
				} else {
					// both were set previously, figure out what changed
					if(previouslyLoadedData.selectFavorite!==newValues.selectFavorite) {
						// fave name changed
						trendConfigInput = {};
					} else {
						// trend config changed
						selFavName = '';
					}
				}

			} else {
				// both set at same time, use fave name
				trendConfigInput = {};
			}
		}
		
		let prevChartTitleValue = (previouslyLoadedData && previouslyLoadedData.hasOwnProperty('ChartTitle')) ? previouslyLoadedData.ChartTitle : "";
		let prevTagInputValue = (previouslyLoadedData && previouslyLoadedData.hasOwnProperty('trendTagsInput')) ? previouslyLoadedData.trendTagsInput : "";
		let prevShowTrendLegendValue = (previouslyLoadedData && previouslyLoadedData.hasOwnProperty('ShowTrendLegend')) ? previouslyLoadedData.ShowTrendLegend : "";
		let tagInputChanged = (prevTagInputValue !== trendTagsInput);
		let prevFavoriteName = (previouslyLoadedData && previouslyLoadedData.hasOwnProperty('selectFavorite')) ? previouslyLoadedData.selectFavorite : "";
		let prevConfigInput = (previouslyLoadedData && previouslyLoadedData.hasOwnProperty('trendConfigInput')) ? previouslyLoadedData.trendConfigInput : "";
		
		scrollPercentage = parseFloat(formatSubscriptionData(getInputValue(newValues, "ScrollPercentage"), data.schema.data, "ScrollPercentage"));
		backgroundColor = formatColor(getInputValue(userConfig, "BackgroundColor", { hex: backgroundColor })).hex;
		showBorder = getInputValue(userConfig, "ShowBorder", showBorder);
		tooltipType = getInputValue(userConfig, "TooltipType", 'shared');
		legendPosition = getInputValue(userConfig, "LegendPosition", 'right');
		let opacityPercent = getInputValue(userConfig, "TooltipOpacity", 80);
		// ensure opacity value is 0-100
		opacityPercent = (opacityPercent<0) ? 0 : (opacityPercent>100 ? 100 : opacityPercent);
		tooltipOpacity = opacityPercent / 100;
		timeSelectionMode = getInputValue(userConfig, "TimeSelectionMode", 'durationEnd');
		borderColor = formatColor(getInputValue(userConfig, "BorderColor", {hex: borderColor})).hex;
		compactViewMode = getInputValue(userConfig, "CompactViewMode", compactViewMode);
		// Value must be a number, can not be NaN, and can not be negative
		if ((typeof scrollPercentage === "number") && (!isNaN(scrollPercentage)) && (scrollPercentage >= 0.0)) {
			if (scrollPercentage >= 1.0) {
				scrollPercentage = scrollPercentage / 100;
			}
		} else {
			console.error('scrollPercentage is not a valid number, defaulting to 0.25');
			scrollPercentage = 0.25;
		}

		let loggingLevelVal = formatSubscriptionData(getInputValue(newValues, "LoggingLevel"), data.schema.data, "LoggingLevel");
		logger.setLogThresholdByName(loggingLevelVal);
		let newLogThreshold = logger.getLogLevelForName(loggingLevelVal);
		setLoggingThresholds(newLogThreshold);

		loggedInUserNameValue = formatSubscriptionData(getInputValue(newValues, "LoggedInUserName", loggedInUserNameValue), data.schema.data, "LoggedInUserName");

		function formatSubscriptionData(newValue, schemaData, fieldToRetreive) {
			var newData = null;
			var type = typeof (newValue);

			switch (true) {
				case Array.isArray(newValue):
					newData = newValue[0];

					if (typeof (newData) === "object") {
						let field = schemaData[fieldToRetreive] && schemaData[fieldToRetreive].query && schemaData[fieldToRetreive].query.outputFields && schemaData[fieldToRetreive].query.outputFields[0] && schemaData[fieldToRetreive].query.outputFields[0].fieldName;
						newData = newData && newData[field];
					}
					break;
				case type === "string":
					newData = newValue;
					break;
				case type === "boolean":
					newData = newValue;
					break;
				case type === "object":
					let field = schemaData[fieldToRetreive] && schemaData[fieldToRetreive].query && schemaData[fieldToRetreive].query.outputFields && schemaData[fieldToRetreive].query.outputFields[0] && schemaData[fieldToRetreive].query.outputFields[0].fieldName;
					newData = newData && newData[field];
					break;
				default:
					newData = null;
					break;
			}
			return newData;
		}

		previouslyLoadedData = JSON.parse(JSON.stringify(valuesData));

		let language = [];
		let lang = window.navigator.userLanguage || window.navigator.language;
		// to test translation, uncomment following line
		// lang = 'ja-JP';
		if (lang.length >= 2) {
			language.push(lang.substr(0, 2));
		}

		// if favorite/config/time settings changed, but card already loaded, load props and exit - don't re-create card
		if(cardLoaded) {
			let changeMade = false; // allow multiple properties to change at once
			if(selFavName) {
				// 686759 - If favorite didn't change, don't reload
				if(prevFavoriteName!==selFavName) {
					loadSelectedFavorite(selFavName);
					changeMade = true;
				}
			}
			if(Object.keys(trendConfigInput).length !== 0){
				// already loaded, just set trend config and be done
				if(prevConfigInput!==trendConfigInputString) {
					dataModel.setTrendInputConfiguration(trendConfigInput, true);
					changeMade = true;
				}
			}
			if(newValues.hasOwnProperty('trendTagsInput')) {
				// 686759 - If tags didn't change, don't reload
				if(tagInputChanged) {
					let tagList = trendTagsInput.split(",");
					tagList = TrendCommon.removeDuplicateStringsFromArray(tagList, false); // case-insensitive
					if(sessionStorageWidgetRuntime) sessionStorageWidgetRuntime.loadFromTagList(tagList);
					changeMade = true;
				}
			}
			if(newValues.hasOwnProperty('ChartTitle')) {
				if(newValues.ChartTitle!==prevChartTitleValue) {
					chartTitleValue = newValues.ChartTitle;
					updateTitleDisplay();
				}
				changeMade = true;
			}
			if(newValues.hasOwnProperty('TimeFormatMode')) {
				if(newValues.TimeFormatMode!==prevTimeFormatModeValue) {
					timeFormatModeValue = newValues.TimeFormatMode;
					trendDisplayWidgetRuntime.setXAxisTimeFormat(timeFormatModeValue, customTimeFormatValue);
				}
				changeMade = true;
			}
			if(newValues.hasOwnProperty('CustomTimeFormat')) {
				if(newValues.CustomTimeFormat!==prevCustomTimeFormatValue) {
					customTimeFormatValue = newValues.CustomTimeFormat;
					trendDisplayWidgetRuntime.setXAxisTimeFormat(timeFormatModeValue, customTimeFormatValue);
				}
				changeMade = true;
			}
			if(newValues.hasOwnProperty('ShowTrendLegend')) {
				if(newValues.ShowTrendLegend!==prevShowTrendLegendValue) {
					if(showTrendLegendValue) {
						showLegend();
					} else {
						hideLegend();
					}

					changeMade = true;
				}
			}
			if(changeMade) return;
		}

		mainElement = EMBED.getRootElement().find('.geTrendCard');
		//get main page element. It is used to get top position for configure panel
		mainPageElement = document.getElementsByClassName('main-page')[0];
		if (!jQuery(mainElement)[0]) {
			console.warn('No trend card element found on page.');
			return;
		}

		if (restDataUrlValue && websocketUrlValue) {
			restData = window.restDataAccess_geWebHmiCore.getInstance(restDataUrlValue);
			restData.addTokenListener(tokenChanged);
			localizer = pluginLocalizer.getInstance("GETrendCard");
			localizer.setPreferredLanguages(language);
			localizer.loadLanguages(function () {
				noTrendData = localizer.translate('Trend Sources Not Selected');
				dataIsFlowing = localizer.translate('Data is Flowing');
				dataNotFlowing = localizer.translate('Data is Not Flowing');
				showingHistoricalData = localizer.translate('Showing Historical Data');
				liveText = localizer.translate('Live');
				historicalText = localizer.translate('Historical');
				pausedText = localizer.translate('Paused');
				pauseButtonTooltip = localizer.translate('Pause Trending');
				resumeButtonTooltip = localizer.translate('Resume Trending');

				let loadingText = localizer.translate("Loading...");
				let loadingHtml = '<span class="loading-message">' + loadingText + '</span>';
				jQuery(mainElement).html(loadingHtml);
				getToken();
			});
		}
	});
}

EMBED.onChangeData(init);

// Subscribe to EquipmentContext
equipmentContextSubscribeKey = EMBED.subscribe(EQUIPMENT_CONTEXT, equipmentContextChanged);
favoritesReloadedKey = EMBED.subscribe(FAVORITES_RELOADED, reloadFavorites);

// if page changes, destroy this plugin
let uId = 'plugin-' + (new Date()).getTime();
EMBED.registerNavChanged(uId, function () {
	EMBED.unregisterNavChanged(uId);
	destroy();
	return false; // allow page change
});

// subscribe to favorite changes
favoritesChangeKey = EMBED.subscribe(FAVORITES_CHANGE, favoritesChanged);

// special handling for time settings as they are in/out


jQuery(window).resize(function () {
	setCardHeight();
});

// init();

// Dynamically insert vendor libraries in to the end app
// as multiple instances of vendors will not work with polymer components

function loadScripts() {
	'use strict';
	console.log('trend card');
	const head = document.head;
	const scripts = [...document.querySelectorAll('script')]
	const isVendorsLoaded = scripts.some((i) => /shared.plugin.vendors.js/.test(i.src));
	const isDxaBrowserLoaded = scripts.some((i) => /dxa-opcua-browser-elem.js/.test(i.src));

	if (!isVendorsLoaded) {
		window.loadingSharedVendors = true;
		const sharedPluginVendors = document.createElement('script');
		sharedPluginVendors.setAttribute('src', 'custom/default/GETrendCard/scripts/polymer-components/shared.plugin.vendors.js');
		head.insertBefore(sharedPluginVendors, head.firstElementChild);
		sharedPluginVendors.onload = function () {
			window.loadingSharedVendors = false;
			document.dispatchEvent(new Event('sharedVendorsLoaded'))
		};
	}
	if (!isDxaBrowserLoaded) {
		const dxaBrowser = document.createElement('script');
		dxaBrowser.setAttribute('src', 'custom/default/GETrendCard/scripts/common-browser/dist/dxa-opcua-browser-elem.js');
		head.insertBefore(dxaBrowser, head.firstElementChild);
	}
	if (window.loadingSharedVendors) {
		document.addEventListener('sharedVendorsLoaded', loadPolymerComponents);
	} else {
		loadPolymerComponents();
	}
}

function loadPolymerComponents() {
	'use strict';
	const scripts = [...document.querySelectorAll('script')]
	const isPolymerComponentsLoaded = scripts.some((i) => /polymer-components.js/.test(i.src));
	if (!isPolymerComponentsLoaded) {
		const head = document.head;
		const polymerComponents = document.createElement('script');
		polymerComponents.setAttribute('src', 'custom/default/GETrendCard/scripts/polymer-components/polymer-components.js');
		head.appendChild(polymerComponents);
		polymerComponents.onload = function () {
			init();
		};
		document.removeEventListener('sharedVendorsLoaded', loadPolymerComponents);
	} else {
		init();
	}
}

function sendUpdatedStatistics() {
	if(!showStatisticsValue) return;

	let updateStatEventValue = dataModel.getTagStatistics();
	updateStatEventValue.forEach((item) => { item.description = dataModel.properties.propertyAttributes.filter((n) => n.propertyName == item.name)[0].attributes.Description; });
	updateStatEventValue.forEach((item) => { item.units = dataModel.properties.propertyAttributes.filter((n) => n.propertyName == item.name)[0].attributes.Units; });
	let tempVar;
	let allTrendingProp=dataModel.getAllTrendingProperties();
	updateStatEventValue.forEach((item) => { Object.values(allTrendingProp).forEach(prop =>{
		prop.properties.filter(function(value) { if(value.propertyName == item.name){ tempVar = value.dataSourceType;}});
		})
		if(tempVar=='objects' || tempVar==undefined)
		{
			item.description = '';
		}
	});
	updateStatEventValue = updateStatisticsTableData(updateStatEventValue);
	let statisticsComponent = jQuery(trendStatisticsElement).find('trend-statistics')[0];
	statisticsComponent.setAttribute('statistics', JSON.stringify(updateStatEventValue));
}

function updateStatisticsTableData(properties) {
	if (Array.isArray(properties)) {
		let propList = dataModel.getAllPropertiesWithAttributes();
		
		properties.forEach(function (property) {
			let assetPropList = propList[property.assetName]?.properties || [];
			let matchingAssetProp = assetPropList.filter(p => (property.name===p.name || property.name===p.propertyName));
			
			if(matchingAssetProp.length>0) {
				let isHidden = matchingAssetProp.reduce((acc, curr) => acc && (curr.visible === false), true);
				property.visible = !isHidden;
			}
			
		});
		return properties;
	} else {
		let previousStatisticsProps = dataModel.getTagStatistics();
		previousStatisticsProps.forEach(function (property) {
			if (properties.assetName === property.assetName && properties.propertyName === property.name) {
				property.visible = properties.isHidden;
			}
		})
		return previousStatisticsProps;
	}
}

loadScripts();
