/**
 * Upon initialization, the PluginZIndexManager will get the z-index of the plugin's wrapper element.
 * It will then provide methods to move the plugin to the front by setting its z-index to "999",
 * and to restore the original z-index when no longer in focus.
 */

class PluginZIndexManager {	
	constructor(mainElement) {
		this.mainElement = mainElement;
		this.isNewEndApp = this.mainElement.parents('app-plugin').length > 0;

		this.wrapperElement = this.isNewEndApp ? this.mainElement.parents('app-plugin').first() : this.mainElement;
		this.elementZindex = this.wrapperElement?.css("zIndex");
		this.isInFront = false;

		// handle grid layout
		this.gridZIndex = null;
		this.gridItem = this.mainElement.closest('gridster-item') || null;
		if(this.gridItem) 
		{
			this.gridItem.css("transition", "none");
		}
	}
	
	destroy() {
		this.mainElement = undefined;
		this.isNewEndApp = undefined;
		this.wrapperElement = undefined;
		this.elementZindex = undefined;
		this.gridItem = undefined;
		this.gridZIndex = undefined;
	}
	moveToFront() {
		if(this.isInFront) return; // already in front
		this.isInFront = true;
		this.wrapperElement?.css("zIndex", "9999");
		if(this.gridItem) 
		{
			this.gridZIndex = this.gridItem.css("zIndex"); // save to restore later
			this.gridItem.css("zIndex", "9999");
		}

		this.mainElement?.addClass("in-focus");
	}
	restore() {
		if(!this.isInFront) return; // not in front, can't restore
		this.isInFront = false;
		this.wrapperElement?.css("zIndex", this.elementZindex);
		if(this.gridItem) {
			this.gridItem.css("zIndex", this.gridZIndex);
		}

		this.mainElement?.removeClass("in-focus");
	}
}

window.WebHMI.Components.PluginZIndexManager = PluginZIndexManager;