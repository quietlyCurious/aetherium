describe('Data Cache Tests', function () {
	'use strict';

	var cache;

	beforeEach(function (done) {
		if(window && window.dataCache) {
			cache = window.dataCache.getInstance();
			cache.clear();
			cache.setMaxCount(10);
		}
		setTimeout(() => {
			done();
		}, 500);
	});

	let createObject = function(name, value={}) {
		return {
			name: name,
			value: value
		};
	}

	let addCacheItem = function(key, item) {
		console.log("adding new item: "+key);
		return new Promise((resolve, reject) => {
			setTimeout(() => {
				cache.addItemToCache(key, item);
				console.log("\tcache size is now "+cache.getSizeInKb());
				resolve();
			}, 10);
		  });
	}
	let getPaddedKey = function(index) {
		return 'obj-' + index.toString().padStart(3, 0)
	}

	let cacheItems = function(count, itemIndex, finishedCallback, testDoneCallback) {
		if(count>0) {
			let key = getPaddedKey(itemIndex);
			let obj = createObject(key);
			addCacheItem(key,obj).then(function() {
				cacheItems(count-1, itemIndex+1, finishedCallback, testDoneCallback);
			}).catch((error) => {
				testDoneCallback(error)
			});
		} else {
			finishedCallback();
		}
	};

	it('Basic Cache Functionality', function (done) {
		assert.exists(cache, 'cache exists');

		let key1 = getPaddedKey(1);
		let obj1 = createObject(key1);
		let key2 = getPaddedKey(2);
		let obj2 = createObject(key2);

		// add first item
		cache.addItemToCache(key1, obj1);

		assert.isTrue(cache.itemInCache(key1), key1+' should be in cache');
		assert.isFalse(cache.itemInCache(key2), key2+' should not be in cache');
		assert.equal(cache.getItemCount(), 1, 'Cache should have 1 item');

		assert.equal(cache.getItemFromCache(key1).name, key1, 'Cache item name should be '+key1);
		
		// add second item
		cache.addItemToCache(key2, obj2);

		assert.isTrue(cache.itemInCache(key1), key1+' should be in cache');
		assert.isTrue(cache.itemInCache(key2), key2+' should be in cache');
		assert.equal(cache.getItemFromCache(key1).name, key1, 'Cache item name should be '+key1);
		assert.equal(cache.getItemFromCache(key2).name, key2, 'Cache item name should be '+key2);
		assert.equal(cache.getItemCount(), 2, 'Cache should have 2 items');

		// remove item one
		assert.isTrue(cache.removeItemFromCache(key1), key1+' should have been removed from the cache');
		assert.isFalse(cache.itemInCache(key1), key1+' should not be in cache');
		assert.isTrue(cache.itemInCache(key2), key2+' should be in cache');
		assert.equal(cache.getItemFromCache(key2).name, key2, 'Cache item name should be '+key2);
		assert.equal(cache.getItemCount(), 1, 'Cache should have 1 item');

		// remove item two
		assert.isTrue(cache.removeItemFromCache(key2), key2+' should have been removed from the cache');
		assert.isFalse(cache.itemInCache(key1), key1+' should not be in cache');
		assert.isFalse(cache.itemInCache(key2), key2+' should not be in cache');
		assert.equal(cache.getItemCount(), 0, 'Cache should have 0 items');
		
		done();
	});

	it('Cache item count limits and item expiration', function (done) {
		this.timeout(5000);
		assert.exists(cache, 'cache exists');

		let initialSize = 10,
			downsizedSize = 5,
			obj,
			key;
		cache.setMaxCount(10);

		// cache size is 10. try to cache 15 items.  check that only last 10 get cached
		cacheItems(15, 1, function() {
			assert.equal(cache.getItemCount(), 10, 'Cache should have 10 items');

			// should show 10 most recent (obj6-15, not obj1-5)
			for(let i=1; i<=15; i++) {
				assert.equal(cache.itemInCache(getPaddedKey(i)), (i>5), 'itemInCache for '+getPaddedKey(i)+' expected to be '+(i>5));
			}

			// access a few items in cache
			cache.getItemFromCache(getPaddedKey(6));
			cache.getItemFromCache(getPaddedKey(8));
			cache.getItemFromCache(getPaddedKey(12));

			// now downsize cache to 5
			cache.setMaxCount(downsizedSize);
			assert.equal(cache.getItemCount(), downsizedSize, 'Cache should have '+downsizedSize+' items');

			// cache should now inclide items 12,8,6,15,14
			assert.isTrue(cache.itemInCache(getPaddedKey(12)), getPaddedKey(12)+' should be in cache');
			assert.isTrue(cache.itemInCache(getPaddedKey(8)), getPaddedKey(8)+' should be in cache');
			assert.isTrue(cache.itemInCache(getPaddedKey(6)), getPaddedKey(6)+' should be in cache');
			assert.isTrue(cache.itemInCache(getPaddedKey(15)), getPaddedKey(15)+' should be in cache');
			assert.isTrue(cache.itemInCache(getPaddedKey(14)), getPaddedKey(14)+' should be in cache');

			assert.isFalse(cache.itemInCache(getPaddedKey(7)), getPaddedKey(7)+' should not be in cache');
			assert.isFalse(cache.itemInCache(getPaddedKey(184)), getPaddedKey(8)+' should not be in cache');
			assert.isFalse(cache.itemInCache(getPaddedKey(10)), getPaddedKey(10)+' should not be in cache');
			assert.isFalse(cache.itemInCache(getPaddedKey(11)), getPaddedKey(11)+' should not be in cache');
			assert.isFalse(cache.itemInCache(getPaddedKey(13)), getPaddedKey(13)+' should not be in cache');
			done();
		}, done);
	});

	
	it('Cache size limit', function (done) {
		this.timeout(10000);
		assert.exists(cache, 'cache exists');
		
		// init cache config
		cache.setMaxSize(10); // 10KB max size
		cache.setMaxCount(-1);
		cache.setMaxCacheLifetime(-1);

		expect(cache.getSizeInKb()).to.equal(0);

		// cache single item and get its size
		cacheItems(1, 1, function() {
			let singleItemSize = cache.getSizeInKb();
			// cache 99 more and check size
			cacheItems(99, 2, function() {
				let cacheSize = cache.getSizeInKb();
				let expectedCacheSize = singleItemSize * 100;
				assert.closeTo(cacheSize, expectedCacheSize, .1, 'Cache size should be about '+expectedCacheSize);

				// make cache smaller
				let newSize = 2;
				let cacheAmountToClear = newSize / 20;
				expectedCacheSize = newSize - cacheAmountToClear;
				let expectedItems = Math.floor(expectedCacheSize/singleItemSize);

				cache.setMaxSize(newSize);
				assert.equal(cache.getItemCount(), expectedItems, 'Cache should have '+expectedItems+' items');			

				// make cache even smaller
				newSize = 1; 
				cacheAmountToClear = newSize / 20;
				expectedCacheSize = newSize - cacheAmountToClear;
				expectedItems = Math.floor(expectedCacheSize/singleItemSize);

				cache.setMaxSize(newSize);
				assert.equal(cache.getItemCount(), expectedItems, 'Cache should have '+expectedItems+' items');
				
				done();
			}, done);
		}, done);
	});
});