if (!('WebHMI' in window)) {
	window.WebHMI = {};
}
if (!('Components' in window.WebHMI)) {
	window.WebHMI.Components = {};
}

/**
 * Highchart Data series helper methods
 */
class DataSeries {
	constructor(assetName, propName, samplingMode) {
		// assetName.propertyName is the identifier for this data series
		this.assetName = assetName;
		this.propertyName = propName;
		this.samplingMode = samplingMode;
		// array of data points as returned from data subscription
		this.data = [];
		this.logger = DataSeries.logger;
	}

	getPropertyName() {
		return this.propertyName;
	}
	getSamplingMode() {
		return this.samplingMode;
	}
	getAssetName() {
		return this.assetName;
	}

	/**
	 * Generate series Id using asset name and property name
	 * @param assetName
	 * @param propertyName
	 * @returns {string}
	 */
	static generateSeriesId (assetName, propertyName, samplingMode){
		let seriesId = assetName + "." + propertyName + "." + samplingMode;
		return seriesId;
	}

	/**
	 * Add a data point to the series.
	 * @param dataPoint - dataPoint to add
	 */
	addData(dataPoint) {
		let pTimeString = TrendCommon.getDateStringFromTimestamp(dataPoint.timestamp);
		this.logger.log(this.logger.LogLevel.Step, 0, "addData: timestamp %s (%s)",pTimeString, dataPoint.timestamp);
		this.data.push(dataPoint);
	}

	/**
	 * Purge data older than timestamp, except for one value
	 * @param timestamp - purge data older than this timestamp
	 */
	purgeOldData(timestamp) {
		let purgeIndex = null;
		for (let i = 0; (i < this.data.length) && (purgeIndex === null); i++) {
			if (this.data[i].timestamp > timestamp) {
				purgeIndex = i - 1;
			}
		}
		if (purgeIndex >= 2) {
			this.data.splice(0, (purgeIndex - 1));
		}
	}

	/**
	 * Return the data point in the series which matches this timestamp.  If there is no data point at this timestamp,
	 * return the _first_ data point older than this timestamp.
	 *
	 * @param timestamp - return first data point on or earlier than this timestamp
	 * @returns {*} - the data point
	 */
	getLastPointAsOfTime(timestamp) {
		let pTimeString = TrendCommon.getDateStringFromTimestamp(timestamp);
		this.logger.log(this.logger.LogLevel.Step, 0, "getLastPointAsOfTime: timestamp %s(%s)",pTimeString, timestamp);

		if (this.data.length === 0) {
            this.logger.log(this.logger.LogLevel.Step,0,'getLastPointAsOfTime: data.length === 0, returning null');
			return null;
		}

        // all values are older than requested point, return most recent
        if (timestamp > TrendCommon.removeTimestampMilliseconds(this.data[this.data.length-1].timestamp)) {
            this.logger.log(this.logger.LogLevel.Step,0,'getLastPointAsOfTime: returning data point data[%d].timestamp = %s, value %d',
			    this.data.length - 1, this.data[this.data.length - 1].timestamp, this.data[this.data.length - 1].value);

            return this.data[this.data.length-1];
        }


		// we are most likely looking for a more recent data point, start at the end of the array and work backwards
		for (let i = this.data.length-1; i >= 0; i--) {
			let dpTimestampString = TrendCommon.getDateStringFromTimestamp(this.data[i].timestamp);
			let dataPointTimestampNoMS = TrendCommon.removeTimestampMilliseconds(this.data[i].timestamp);
			let dataPointTimestampNoMSString = TrendCommon.getDateStringFromTimestamp(dataPointTimestampNoMS);
			this.logger.log(this.logger.LogLevel.Step,0,'getLastPointAsOfTime: comparing data[%d].timestamp/value = %s (%s)/%s against %s',
				i, dpTimestampString, dataPointTimestampNoMSString, this.data[i].value, pTimeString);
			// Fix for DE58774 - 1 second tolerance here - since chart data has no milliseconds but datapoint timestamp does
			//         https://rally1.rallydev.com/#/60780373928d/detail/defect/184230501440
			// Instead of a 1 second tolerance, we just remove the milliseconds from the data timestamp.  That way, if the
			// data timestamp has no milliseconds (which happens when the polling occurs exactly on a 1 second boundary)
			// we will not return the point _later_ than the one we should be returning.
			// See DE111372.

			if (dataPointTimestampNoMS <= timestamp) {
                
                // If the timestamp matches exactly, return it
                if (dataPointTimestampNoMS === timestamp) {
                    this.logger.log(this.logger.LogLevel.Step,0,'getLastPointAsOfTime: returning data point data[%d].timestamp = %s, value %d',
					    i, this.data[i].timestamp, this.data[i].value);

                    return this.data[i]; 
                }

                // Fix for DE111608 - When using some sampling modes such as TrendToRaw, the behavior can change based on the size of the request.
                // In this case, asking for more points then there are raw values will trigger it into Trend mode where it now returns 2 values for each
                // interval, 1 for the min value, 1 for the max. As a result the timestamps don't match exactly. Returning the previous value results in a 
                // trend graph that is essentially upside down with the spikes getting the minimum value and the low point getting the max value.
                // As a result, we need to return the next value instead of the previous.
                
                // .. otherwise, we have now gone past the closest time stamp, return the next value
                this.logger.log(this.logger.LogLevel.Step,0,'getLastPointAsOfTime: returning data point data[%d].timestamp = %s, value %d',
					i, this.data[i+1].timestamp, this.data[i+1].value);

				return this.data[i+1];
			}
		}

		this.logger.log(this.logger.LogLevel.Step,0,'getLastPointAsOfTime: point at %s is before current data series, setting to the first value', pTimeString);

        return this.data[0];
	}
}

/**
 * Functions to manage the collection of dataseries in the HighChart
 */
class DataManager {
	constructor() {
		this.series = [];
		this.lastPurgeTimestamp = 0;
		this.PURGE_INTERVAL = 60;
		this.MAX_SIGNIFICANT_DIGITS = 7;
		this.TrendCommon = window.WebHMI.Components.TrendCommon;
		this.translate = function (stringVal) {
			return pluginLocalizer.getInstance("GETrendCard").translate(stringVal);
		};
		this.preferredLocale = pluginLocalizer.getInstance("GETrendCard").getPreferredLocale();
	}

	clear() {
		this.series = [];
		this.lastPurgeTimestamp = 0;
	}

	/**
	 * Purge data older than the given timestamp from all series.
	 * @param timestamp
	 */
	purgeOldData(timestamp) {
		if ((timestamp - this.lastPurgeTimestamp) > (this.PURGE_INTERVAL * 1000)) {
			this.lastPurgeTimestamp = timestamp;
			for (let i = 0; i < this.series.length; i++) {
				this.series[i].purgeOldData(timestamp);
			}
		}
	}

	/**
	 * Get yAxis value at xAxis (timestamp)
	 * @param timestamp - datetime to get 'Y' values
	 * @returns {Array} - 'Y' values
	 */
	getSeriesPointValues (timestamp){
		let dateString = new Date(timestamp).toLocaleTimeString();
		DataManager.logger.log(DataManager.logger.LogLevel.Step,0,"getSeriesPointValues: timestamp = %s, %s", timestamp, dateString);
		let pointValues = [];
		for (let i = 0; i < this.series.length; i++) {
			let dataPoint = this.series[i].getLastPointAsOfTime(timestamp);
			if(dataPoint !== null) {
				let assetName = this.series[i].getAssetName();
				let propertyName = this.series[i].getPropertyName();
				let samplingMode = this.series[i].getSamplingMode();
				let pointValue = dataPoint.value;
				try {
					if (!isNaN(pointValue)) {
						// @ts-ignore
						pointValue = pluginLocalizer.getInstance("GETrendCard").numberToLocalizedString(Number(pointValue));
					}
				} catch (err) {
				}
				pointValues.push({'assetName': assetName, 'propertyName': propertyName, 'samplingMode': samplingMode, 'pointValue': pointValue});
			}
		}
		return pointValues;
	}

	////////////////////  Tool tip functions /////////////////

	/**
	 * Return HTML for the tooltip timestamp
	 * @param timestamp - show string representation of this timestamp
	 * @returns {string}
	 */
	getTooltipTimestampLine(timestamp) {
		return '<span style="font-size: 10px"><b>' + (new Date(timestamp)).toLocaleString(this.preferredLocale) + '</b></span><br/>\n'
	}

	/**
	 * Return tooltip HTML for the given property
	 * @param color - display color for the tooltip
	 * @param tagName - the assetName.propertyName of the tag to display in the tooltip
	 * @param value - the value to display in the tooltip
	 * @param description - Description of the tag to display in the tooltip
	 * @param units - Units of the tag to display in the tooltip
	 * @param toolTipAssetName - Assert name of the tag selected
	 * @returns {string} - the tooltip HTML
	 */
	 getTooltipDataValueLine(color, tagName, samplingMode, value, description, units , tagTypeData, toolTipAssetName) {	
		if(samplingMode) {	
			let toolTipHtml = '<span>';	
			if(tagTypeData=='tagName'){	
				toolTipHtml=toolTipHtml+'<span style="color:' + color + ';">\u25CF</span><span style="font-weight: bold">' + tagName + ' (' + samplingMode + ')' + '</b><br/>';	
			}	
			else if(tagTypeData=='tagDesc'){	
				if(description == "" ||description == undefined) {
					toolTipHtml= toolTipHtml+ '<span style="color:' + color + '">\u25CF</span><span style="font-weight: bold">' + tagName + ' (' + samplingMode + ')' + '</b><br/>';	
				} else {
					toolTipHtml= toolTipHtml+ '<span style="color:' + color + '">\u25CF</span><span style="font-weight: bold">' + toolTipAssetName + "." + description + ' (' + samplingMode + ')' + '</b><br/>';	
				}
			}	
			else if(tagTypeData=='tagNameAndDesc'){	
				if(description == "" ||description == undefined) {	
					toolTipHtml= toolTipHtml+'<span style="color:' + color + '">\u25CF</span><span style="font-weight: bold">' + tagName + ' (' + samplingMode + ')'  + '</b><br/>';	
				}else {	
					toolTipHtml= toolTipHtml+'<span style="color:' + color + '">\u25CF</span><span style="font-weight: bold">' + tagName + ' (' + samplingMode + ')' + '</b><br/>'+'<b>'+ description +'</b><br/>';	
				}	
			}	
			if(units === undefined){	
				toolTipHtml=toolTipHtml+'<b>' + value + '</span></span> <br/>';	
			}else{	
				toolTipHtml=toolTipHtml+'<b>' + value +  " " + units + '</span></span> <br/>';	
			}	
			return toolTipHtml ;	
			// return '<span style="color:' + color + '">\u25CF</span><span>' + tagName + ' (' + samplingMode + '): <b> ' + value + '</b><br/><b>'+ description +'</b><br/><b>';	
		} else {	
			let toolTipHtml = '<span>';	
				
			if(tagTypeData=='tagName'){	
				toolTipHtml=toolTipHtml+'<span style="color:' + color + '">\u25CF</span><span style="font-weight: bold">' + tagName  + '</b><br/>';	
			}	
			else if(tagTypeData=='tagDesc'){	
				if(description == "" ||description == undefined) {
					toolTipHtml= toolTipHtml+ '<span style="color:' + color + '">\u25CF</span><span style="font-weight: bold">' + tagName +'</b><br/>';	
				} else {
					toolTipHtml= toolTipHtml+ '<span style="color:' + color + '">\u25CF</span><span style="font-weight: bold">' + toolTipAssetName + "." + description +'</b><br/>';	
				}
			}	
			else if(tagTypeData=='tagNameAndDesc'){	
				if(description == ""||description == undefined) {	
					toolTipHtml= toolTipHtml+'<span style="color:' + color + '">\u25CF</span><span style="font-weight: bold">' + tagName  + '</b><br/>';	
				}else {	
					toolTipHtml= toolTipHtml+'<span style="color:' + color + '">\u25CF</span><span style="font-weight: bold">' + tagName  + '</b><br/>'+'<b>'+ description +'</b><br/>';	
				}	
			}	
			if(units === undefined){	
				toolTipHtml=toolTipHtml+'<b>' + value + '</span></span> <br/>';	
			}else{	
				toolTipHtml=toolTipHtml+'<b>' + value +  " " + units + '</span></span> <br/>';	
			}
			return toolTipHtml ;	
		}	
	}

	/**
	 * Construct the series tooltip.
	 * The tooltip cannot be any taller than the chart plot area. Otherwise, Highcharts will simply not display it. This
	 * is very confusing to users.  So the tooltip contains only the items that will fit within the chart plot height.
	 * If not all items can be included in the tooltip, the number of items not shown is displayed as the last line
	 * of the tooltip.
	 * @param timestamp - construct tooltip for this timestamp
	 * @param chartObj - The Highchart object
	 * @param points - the points array at the x-axis as provided by Highcharts
	 * @param showSamplingMode - should sampling mode be shown in tooltip. 
	 * @param tagHelpObject - passing dataModel.properties.propertyAttributes data.
	 * @param tagTypeData - (TagdisplayMode) passing tag display toggle slected value from Trend Configuration. 
	 * @returns {string} - the tooltip HTML
	 */
	getTooltipHTML(timestamp, chartObj, points, showSamplingMode, tagHelpObject, tagTypeData, HoverIndex, chartMode, individualTooltips) {
		// the maximum height for the tooltip so that it will fit
		let availableHeight = chartObj.plotHeight;
		let timestamps = [];
		let timestampMap = {};
		let pointsHelper;
		if(points.points==undefined)
		{
			pointsHelper=points.series;
		}else{
			pointsHelper=points.points[0].series;
		}
		// DOC: Using the first point under the cursor, create a temporary tool tip object used to
		// calculate the resulting height of the tool tip as we add each point.
		let owner = pointsHelper || chartObj.tooltip;
		if (!owner.tt) {
			owner.tt = this.createTemporaryTooltipLabel(chartObj.tooltip, chartObj);
		}

		if(individualTooltips || chartMode==='stacked')
		{
			// find actual series data
			let chartSeries = chartObj.series[HoverIndex]; // hoverIndex is an index into chartObj.series NOT the data series manager series
			let seriesId = chartSeries.userOptions.id;
			let assetName = chartSeries.userOptions.assetName || chartSeries.userOptions.assetName;
			let propertyName = chartSeries.userOptions.nameNoEgu;
			let samplingMode = seriesId.substring(seriesId.indexOf("."+propertyName+".")+propertyName.length+2);
			let dataSeries = this.getSeriesByPropertyName(assetName, propertyName, samplingMode)
			
			let dataPoint = dataSeries.getLastPointAsOfTime(timestamp);
			let samplingModeDisplay = showSamplingMode ? samplingMode : null;
			let toolTipDescription= "";
			let toolTipUnits = "";
			let tagAttrObj;
			for (const key in tagHelpObject){
				if(assetName === key){
					tagAttrObj = tagHelpObject[key].properties;
				}
			}
			tagAttrObj.forEach(value => {
				if (value.Attributes !== undefined) {
					if (value.Attributes?.Description !==undefined ) {
						if (value.propertyName == propertyName) {
							toolTipDescription = value.Attributes.Description;
						}
					}
				}
			});
			tagAttrObj.forEach(value => {
				if (value.Attributes !== undefined) {
					if (value.Attributes?.Units !==undefined) {
						if (value.propertyName == propertyName) {
							toolTipUnits = value.Attributes.Units;
						}
					}
				}
			 });
			
			if(tagTypeData == "tagName"){
				toolTipDescription = '';
			} else if( tagTypeData == "tagDesc") {
				propertyName = '';
				if(toolTipDescription == undefined ||  toolTipDescription.trim().length == 0 ) {
                    toolTipDescription = dataSeries.getPropertyName();
				}
				// toolTipUnits = tagHelpObject.filter((n)=>n.propertyName==propertyName)[0].Attributes.Units;
			} else if(tagTypeData == "tagNameAndDesc") {
				propertyName = dataSeries.getPropertyName();
				toolTipUnits = toolTipUnits;
				toolTipDescription = toolTipDescription;
			}

			//if the property is not in chart, do not show it in tooltip
			//commenting it as there is no series display needed.
			// if (!chartSeries) {
			// 	continue;
			// }
			if (dataPoint !== null) {
				let visible = (chartSeries) ? chartSeries.visible : true;

				if (visible) {
					let timestampNoMilliseconds = TrendCommon.removeTimestampMilliseconds(dataPoint.timestamp);
					if (timestampMap[timestampNoMilliseconds] === undefined || timestampMap[timestampNoMilliseconds] === null) {
						timestampMap[timestampNoMilliseconds] = [];
						timestamps.push(timestampNoMilliseconds);
					}
					let ptColor = (chartSeries && chartSeries.color) ? chartSeries.color : '#000000';

					let value = dataPoint.value;
					try {
						if (!isNaN(value)) {
							// @ts-ignore
							value = pluginLocalizer.getInstance("GETrendCard").numberToLocalizedString(Number(value));
						}
					}catch (err) {	
					}	
					let tagName = assetName + "." + propertyName;	
					let toolTipAssetName = assetName;	
					let line = this.getTooltipDataValueLine(ptColor, tagName, samplingModeDisplay, value,toolTipDescription,toolTipUnits, tagTypeData, toolTipAssetName);	
					let tooltipEntry = {"tagName": tagName, "html": line};	
					timestampMap[timestampNoMilliseconds].push(tooltipEntry);	
				}	
			}
		}else{
			for (let i = 0; i < this.series.length; i++) {	
				let dataPoint = this.series[i].getLastPointAsOfTime(timestamp);	
				let assetName = this.series[i].getAssetName();	
				let propertyName = this.series[i].getPropertyName();	
				let samplingMode = this.series[i].getSamplingMode();	
				let samplingModeDisplay = showSamplingMode ? samplingMode : null;	
				let seriesId = window.WebHMI.Components.DataSeries.generateSeriesId(assetName, propertyName, samplingMode);	
				let chartSeries = chartObj.get(seriesId);	
					
				let toolTipDescription;	
				let toolTipUnits;	
				let tagAttrObj;	
				for (const key in tagHelpObject){	
					if(assetName === key){	
						tagAttrObj = tagHelpObject[key].properties;	
					}	
				}	
				tagAttrObj && tagAttrObj.forEach(value => {	
					if (value.Attributes !== undefined) {	
						//skipping when its Asset Model
						if(value.dataSourceType!="objects"&& value.dataSourceType)
						{	
							if (value.Attributes?.Description !==undefined ) {	
								if (value.propertyName == propertyName) {	
									toolTipDescription = value.Attributes.Description;	
								}	
							}
						}
					}	
				});
				
				tagAttrObj && tagAttrObj.forEach(value => {	
					if (value.Attributes !== undefined) {
						if (value.Attributes?.Units !==undefined) {	
							if (value.propertyName == propertyName) {	
								toolTipUnits = value.Attributes.Units;	
							}
						}
					}
				 });

				// if(toolTipDescription == undefined) {
				// 	toolTipDescription = ""
				// }
				if(tagTypeData == "tagName"){
					toolTipDescription = '';
				} else if( tagTypeData == "tagDesc") {
					if(!toolTipDescription ){
						toolTipDescription=  this.series[i].getPropertyName();
					}
					propertyName = '';
					// toolTipUnits = tagHelpObject.filter((n)=>n.propertyName==propertyName)[0].attributes.Units;
				} else if(tagTypeData == "tagNameAndDesc") {
					propertyName = this.series[i].getPropertyName();
					toolTipUnits = toolTipUnits;
					toolTipDescription = toolTipDescription;
				}
				//if the property is not in chart, do not show it in tooltip
				if (!chartSeries) {
					continue;
				}
				if (dataPoint !== null) {
					let visible = (chartSeries) ? chartSeries.visible : true;
	
					if (visible) {
						let timestampNoMilliseconds = TrendCommon.removeTimestampMilliseconds(dataPoint.timestamp);
						if (timestampMap[timestampNoMilliseconds] === undefined || timestampMap[timestampNoMilliseconds] === null) {
							timestampMap[timestampNoMilliseconds] = [];
							timestamps.push(timestampNoMilliseconds);
						}
						let ptColor = (chartSeries && chartSeries.color) ? chartSeries.color : '#000000';
	
						let value = dataPoint.value;
						try {
							if (!isNaN(value)) {
								// @ts-ignore
								value = pluginLocalizer.getInstance("GETrendCard").numberToLocalizedString(Number(value));
							}
						} catch (err) {
						}
						let tagName = assetName + "." + propertyName;
						let toolTipAssetName = assetName;
						let line = this.getTooltipDataValueLine(ptColor, tagName, samplingModeDisplay, value,toolTipDescription,toolTipUnits, tagTypeData, toolTipAssetName);
						let tooltipEntry = {"tagName": tagName, "html": line};
						timestampMap[timestampNoMilliseconds].push(tooltipEntry);
					}
				}
			}
		}
		// calculate the total number of points to be put on the tool tip
		// We use this number to calculate whether we are at the last point so we know if we have to keep room for
		// the ellipsis line.
		let totalPoints = 0;
		for (let j = 0; j < timestamps.length; j++) {
			totalPoints += timestampMap[timestamps[j]].length;
		}

		let pointCount = 0;
		let tooltip = '';
		let tooltipTooLarge = false;
		// sort the timestams so we can get the most recent first
		timestamps.sort((a, b) => (a - b));
		for (let j = (timestamps.length - 1); j >= 0; j--) { // most recent first
			let ts = timestamps[j];
			let timestampHtml = this.getTooltipTimestampLine(ts);
			let notShownHtml = this.getItemsNotShownHtml(pointCount, totalPoints);
			// If we are appending a date, we know we have at least 1 more point to add (i.e.: lastPoint === false).
			// If there is not enough room to include both these lines, then we will append just the ellipsis line and
			// the tooltip is full.  If there is enough room in the tooltip to include both lines, then we will append
			// the date line and go on to attempt appending the data points.
			let tooltipHeight = this.getTooltipHeight(tooltip+timestampHtml+notShownHtml, owner.tt);
			if (tooltipHeight >= availableHeight) {
				tooltip += notShownHtml;
				tooltipTooLarge = true;
				break;
			}
			tooltip += timestampHtml;
			// sort entries by assetName.propertyName within this timestamp group
			let points = timestampMap[ts].sort((a, b) => TrendCommon.localeSort(a.tagName, b.tagName));
			for (let k = 0; k < points.length; k++) {
				notShownHtml = this.getItemsNotShownHtml(pointCount, totalPoints);
				let lastPoint = ++pointCount  === totalPoints;
				// if it's not the last point to be added make sure we can add this line AND the ellipsis line.
				// We always want to make sure there is room for the ellipsis line, so that when the current line causes
				// the overflow, we still have room to append the ellipsis line.
				let appendHtml = lastPoint ? points[k].html : points[k].html + notShownHtml;
				tooltipHeight = this.getTooltipHeight(tooltip + appendHtml, owner.tt);
				if (tooltipHeight >= availableHeight) {
					tooltip += notShownHtml;
					tooltipTooLarge = true;
					break;
				}
				tooltip += points[k].html;
			}
			if (tooltipTooLarge) {
				break;
			}
		}

		// Destroy the temporary tt object.  Highcharts will recreate it the first time the tooltip is displayed
		owner.tt.destroy();
		owner.tt = undefined;
		return tooltip;
	}

	/**
	 * Return HTML for the 'items not shown' line of the tooltip
	 * @param pointCount - the number of current point to display
	 * @param totalPoints - the total number of points to add to the tooltip
	 * @returns {string}
	 */
	getItemsNotShownHtml(pointCount, totalPoints) {
		let missingPointsCount = totalPoints - pointCount;
		let itemsNotShown =  (missingPointsCount > 1) ? this.translate("items not shown. Chart size too small.") : this.translate("item not shown. Chart size too small.");
		return '<span style="font-size: 10px"><b>... ' + `${missingPointsCount} ` + itemsNotShown + '</b></span><br/>';
	}

	/**
	 * Create a temporary tool tip object used to calculate the rendered height of the tool tip as each point is added.
	 * This code is copied from Highchart.src.js renderSplit function.  The resulting object is used to calculate the
	 * rendered height of the tooltip as it is constructed.
	 * @param tooltipObj - the HighCharts tooltip object
	 * @param chartObj - the Highcharts object
	 * @returns {*} - the Highcharts tooltip
	 */
	createTemporaryTooltipLabel(tooltipObj, chartObj) {
		let options = tooltipObj.options;
		let ren = chartObj.renderer;
		let tt = ren.label(
			null,
			null,
			null,
			'callout',
			null,
			null,
			options.useHTML,
		)
			.addClass('highcharts-tooltip-box highcharts-color-none')
			.attr({
				'padding': options.padding,
				'r': options.borderRadius,

				'fill': options.backgroundColor,
				'stroke': (
					options.borderColor || '#333333'
				),
				'stroke-width': options.borderWidth
			})
			.add(tooltipObj.getLabel());
		tt.isActive = false;
		tt.css(options.style).shadow(options.shadow);
		return tt;
	}

	/**
	 * Return the tooltip height with the given text
	 * @param tooltipText - the tooltip HTML
	 * @param tt - the Highcharts tooltip object
	 * @returns {number} - the height of the tooltip, in pixels
	 */
	getTooltipHeight(tooltipText, tt) {
		tt.attr({
			text:tooltipText
		});
		return tt.getBBox().height;
	}

	////////////////////  End Tooltip functions /////////////////

	/**
	 * Return the series array for the given assetName and propertyName.
	 * If one does not exist, a new one is created.
	 * @param assetName - The asset to which the property belongs
	 * @param propertyName - return data series for this property name
	 * @returns {*}
	 */
	getSeriesByPropertyName(assetName, propertyName, samplingMode) {
		for (let i = 0; i < this.series.length; i++) {
			if (this.series[i].getAssetName() === assetName && this.series[i].getPropertyName() === propertyName && this.series[i].getSamplingMode() === samplingMode) {
				return this.series[i];
			}
		}
		let newSeries = new DataSeries(assetName, propertyName, samplingMode);
		this.series.push(newSeries);
		return newSeries;
	}

	/**
	 * Create a new data series for the given asset and property and add it to the series array
	 * @param assetName - The asset to which the property belongs
	 * @param propertyName - create data series for this property name
	 */
	addSeries(assetName, propertyName, samplingMode) {
		this.removeSeries(assetName, propertyName, samplingMode);
		let newSeries = new DataSeries(assetName, propertyName, samplingMode);
		this.series.push(newSeries);
	}

	/**
	 * Remove the data series for the given asset and property from the series array
	 * @param assetName - The asset to which the property belongs
	 * @param propertyName - create data series for this property name
	 */
	removeSeries(assetName, propertyName, samplingMode) {
		let seriesIndex = null;
		for (let i = 0; i < this.series.length; i++) {
			if (this.series[i].getAssetName() === assetName && this.series[i].getPropertyName() === propertyName && this.series[i].getSamplingMode() === samplingMode) {
				seriesIndex = i;
			}
		}
		if (seriesIndex !== null) {
			this.series.splice(seriesIndex, 1);
		}
	}

	/**
	 * Add data to series. dataRows contain assetName and propertyName to identify the correct series
	 * @param dataRows - the rows of data to add from dataProvider
	 */
	addData(dataRows) {
		let mgr = this;
		_.each(dataRows, function (dataRow) {
			if (dataRow.name !== '') {
				// let propertyName = dataRow.name.replace(/\s/g, '');
				let propertyName = dataRow.name;
				let samplingMode = dataRow.samplingMode;
				let value = null;
				if ('quality' in dataRow && dataRow.quality !== window.WebHMI.Components.DataQuality.good && dataRow.quality !== window.WebHMI.Components.DataQuality.uncertain) {
					value = null;
				} else {
					value = dataRow.value.value;
				}
				let timestamp = 0;
				if (dataRow.time instanceof Date) {
					timestamp = dataRow.time.getTime();
				} else {
					timestamp = dataRow.time;
				}
				let dataPoint = {timestamp: timestamp, value: value};

				let dataSeries = mgr.getSeriesByPropertyName(dataRow.assetName, propertyName, samplingMode);
				dataSeries.addData(dataPoint);
			}
		});

	}
}

window.WebHMI.Components.DataSeries = DataSeries;
window.WebHMI.Components.DataManager = DataManager;  // add/remove series

window.WebHMI.Components.DataSeries.logger = new window.WebHMI.Components.ConsoleLogger();
window.WebHMI.Components.DataSeries.logger.init("DataSeries", window.WebHMI.Components.LogLevels.Trend, window.WebHMI.LogSettings.LogWithTimestamps, window.WebHMI.LogSettings.LogWithLogLevelNames);

window.WebHMI.Components.DataManager.logger = new window.WebHMI.Components.ConsoleLogger();
window.WebHMI.Components.DataManager.logger.init("DataManager", window.WebHMI.Components.LogLevels.Trend, window.WebHMI.LogSettings.LogWithTimestamps, window.WebHMI.LogSettings.LogWithLogLevelNames);

