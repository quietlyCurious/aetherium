

jQuery(function(){


  console.log("init for plugin ===================");
//----------------------------------------------------------//
//Note: The use of alias fields are required here specifically for the argument field and value field
// Requiring this helps us understand which field is argument and which is value based on the user's naming/mapping
var handleSingleArray = function(dataSource, rows){

var rowData = rows;
  //replace with Alias Name
  if (dataSource.query && dataSource.query.outputFields && dataSource.query.outputFieldsAliases){

    for (var i = 0; i < dataSource.query.outputFields.length; i++){
      if (dataSource.query.outputFieldsAliases[i]){

        for (var j = 0; j < rowData.length; j++){
          rowData[j][dataSource.query.outputFieldsAliases[i]] = rowData[j][dataSource.query.outputFields[i].fieldName]
        }
      }
    }
  }

return rowData;

}

//var baseStyle = "background: rgba(1,1,1,0.05);";





//----------------------------------------------------------//
    var component = EMBED.getComponent(),
                 data = component.schema.data;

    var element = EMBED.getRootElement();

   // var gaugeContainer = element.find(".demo-container")[0];

    var minValue = data.minValue,
    maxValue = data.maxValue,
    rangeLow = data.rangeLow,
    rangeHigh = data.rangeHigh,
    backgroundColor = data.backgroundColor,
    title = data.title;


    var customTicks = [0,100, 30, 90];


    //var IDstring = "#embed" + component.id + "_0 #lineargauge";

    var gaugeID = element.find("#linearGaugeClass");
    console.log("id is: -------------------");
    console.dir(gaugeID);
    console.log("selector is: -------------------");
    console.dir(gaugeID.selector);

    var simpleGauge = jQuery(gaugeID.selector).dxLinearGauge({
      title: {
        text: "Title",
        horizontalAlignment:"left",
        font: {
          weight: "900",
          size: "18"
        },
        margin: {
          top: "0",
          bottom: "10",
          left: "10",
          right: "0"
        }
    },
      scale: {
          startValue: 0, 
          endValue: 100,
          customTicks: customTicks,
          label: {
              visible:true,
              indentFromTick:5
          }
      },
      rangeContainer: {
        offset: 0
    },
      valueIndicator: { 
          baseValue: 30,
          offset: -10
      },
      value: 90
  }).dxLinearGauge("instance");


 // gaugeContainer.style = baseStyle;
//----------------------------------------------------------//
//NOTE: I am just doing a check for query here as I know this is being hooked up to a query for learning example
// Actual production code should of course check/handle if global as well
    if(EMBED.fieldTypeIsQuery(rangeHigh)){
          EMBED.subscribeFieldToQueryChange(rangeHigh, function(rows){
            //set option
            console.log("setting the value ===================");
            simpleGauge.option("value", rows[0][EMBED.getQueryOutput(rangeHigh)[0].fieldName]);
            
            customTicks[3] =  rows[0][EMBED.getQueryOutput(rangeHigh)[0].fieldName];
            simpleGauge.option("scale.customTicks", customTicks);

         });
      }

      if(EMBED.fieldTypeIsQuery(rangeLow)){
        EMBED.subscribeFieldToQueryChange(rangeLow, function(rows){
          //set option
          console.log("setting the value ===================");
          simpleGauge.option("valueIndicator.baseValue", rows[0][EMBED.getQueryOutput(rangeLow)[0].fieldName]);

          customTicks[2] =  rows[0][EMBED.getQueryOutput(rangeLow)[0].fieldName];
          simpleGauge.option("scale.customTicks", customTicks);


       });
    }

    if(EMBED.fieldTypeIsQuery(minValue)){
      EMBED.subscribeFieldToQueryChange(minValue, function(rows){
        //set option
        console.log("setting the value ===================");
        simpleGauge.option("scale.startValue", rows[0][EMBED.getQueryOutput(minValue)[0].fieldName]);

        customTicks[0] =  rows[0][EMBED.getQueryOutput(minValue)[0].fieldName];
        simpleGauge.option("scale.customTicks", customTicks);

     });
  }

  if(EMBED.fieldTypeIsQuery(maxValue)){
    EMBED.subscribeFieldToQueryChange(maxValue, function(rows){
      //set option
      console.log("setting the value ===================");
      simpleGauge.option("scale.endValue", rows[0][EMBED.getQueryOutput(maxValue)[0].fieldName]);

      customTicks[1] =  rows[0][EMBED.getQueryOutput(maxValue)[0].fieldName];
      simpleGauge.option("scale.customTicks", customTicks);

   });
}

if(EMBED.fieldTypeIsQuery(title)){
  EMBED.subscribeFieldToQueryChange(title, function(rows){
    //set option
    console.log("setting the value ===================");
    simpleGauge.option("title.text", rows[0][EMBED.getQueryOutput(title)[0].fieldName]);


 });
}

if(EMBED.fieldTypeIsQuery(backgroundColor)){
  EMBED.subscribeFieldToQueryChange(backgroundColor, function(rows){
    //set option
    console.log("setting the value ===================");

   // baseStyle = "background: " + rows[0][EMBED.getQueryOutput(backgroundColor)[0].fieldName] + ";";
    //gaugeContainer.style = baseStyle;

    if (rows[0][EMBED.getQueryOutput(backgroundColor)[0].fieldName] == "good"){
      simpleGauge.option("rangeContainer.backgroundColor", "#a4c497");

      //gaugeContainer.style  = "background: #a4c497;";
    }
    else if (rows[0][EMBED.getQueryOutput(backgroundColor)[0].fieldName] == "bad"){
      simpleGauge.option("rangeContainer.backgroundColor", "#e8e082");

      //gaugeContainer.style  = "background: #e8e082;";
    }
    else{
      simpleGauge.option("rangeContainer.backgroundColor", "#e2e8ed");

      //gaugeContainer.style  = "background: #e2e8ed;";
    }

 });
}

});
